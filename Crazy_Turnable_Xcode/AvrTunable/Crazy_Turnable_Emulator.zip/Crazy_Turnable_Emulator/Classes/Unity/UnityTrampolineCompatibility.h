#pragma once

#if !UNITY_TRAMPOLINE_IN_USE
#include "UnityPrefix.h"

#define UNITY_CAN_USE_METAL GFX_SUPPORTS_METAL
#endif
