﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif


#include <cstring>
#include <string.h>
#include <stdio.h>
#include <cmath>
#include <limits>
#include <assert.h>
#include <stdint.h>

#include "il2cpp-class-internals.h"
#include "codegen/il2cpp-codegen.h"
#include "il2cpp-object-internals.h"


// ADS
struct ADS_t19B0242A8A62416BCF9C927D76305A252DB69367;
// CodeStage.AdvancedFPSCounter.AFPSCounter
struct AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54;
// CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData
struct DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F;
// CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData
struct FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD;
// CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData
struct MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6;
// CodeStage.AdvancedFPSCounter.Labels.DrawableLabel[]
struct DrawableLabelU5BU5D_t44C0B89CA90DC2065F8BA49C77D14FEFFFDCBADC;
// CodeStage.AdvancedFPSCounter.Labels.LabelEffect
struct LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB;
// ItemInfo
struct ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974;
// Item[]
struct ItemU5BU5D_t9B2C2BF53C23D966ADDC0D8FC7F3C6AC27993AAD;
// Menu[]
struct MenuU5BU5D_tD3192425CB52CD24F8F7ED73B1F63328723280A2;
// Photon.Pun.PhotonView
struct PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B;
// Photon.Pun.UtilityScripts.CountdownTimer/CountdownTimerHasExpired
struct CountdownTimerHasExpired_t1DA56DAFE29F4443C6A912DC7911E75B3409E4C4;
// Photon.Pun.UtilityScripts.IPunTurnManagerCallbacks
struct IPunTurnManagerCallbacks_t7DB7B81D187AE41F506E171E1A942EB54CFE3B3B;
// Photon.Pun.UtilityScripts.OnClickDestroy
struct OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D;
// Photon.Pun.UtilityScripts.OnClickRpc
struct OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C;
// Photon.Pun.UtilityScripts.PlayerNumbering/PlayerNumberingChanged
struct PlayerNumberingChanged_tC8F930EF27ACA4ED253B2C3A489705780EF8DC10;
// Photon.Pun.UtilityScripts.TabViewManager
struct TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B;
// Photon.Pun.UtilityScripts.TabViewManager/Tab
struct Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A;
// Photon.Pun.UtilityScripts.TabViewManager/TabChangeEvent
struct TabChangeEvent_t0828873D6112CB183DE5B2EB5EB05DCDB7FFBD29;
// Photon.Pun.UtilityScripts.TabViewManager/Tab[]
struct TabU5BU5D_tA7CC50FBDFCBD2045800D2F9A902DE5573A54117;
// Photon.Realtime.Player
struct Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202;
// Photon.Realtime.Player[]
struct PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83;
// Photon.Realtime.RoomInfo
struct RoomInfo_t2FA7C04D0FB706F0313E7C91AEA598D7B1BDEBE2;
// PlayerController
struct PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85;
// PlayerManager
struct PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271;
// Spawnpoint[]
struct SpawnpointU5BU5D_t704CB7EB251BB79F0910611B99E478A3E85119F7;
// System.Action`1<CodeStage.AdvancedFPSCounter.FPSLevel>
struct Action_1_tCF64480193CD47098768F77D8A792F66EE6921AC;
// System.Action`2<Photon.Realtime.Player,Photon.Pun.UtilityScripts.PhotonTeam>
struct Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55;
// System.AsyncCallback
struct AsyncCallback_t3F3DA3BEDAEE81DD1D24125DF8EB30E85EE14DA4;
// System.Char[]
struct CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2;
// System.Collections.Generic.Dictionary`2<Photon.Pun.UtilityScripts.PunTeams/Team,System.Collections.Generic.List`1<Photon.Realtime.Player>>
struct Dictionary_2_t265BADF786877C363F2584FFEE180F6D578E4107;
// System.Collections.Generic.Dictionary`2<System.Byte,Photon.Pun.UtilityScripts.PhotonTeam>
struct Dictionary_2_tDD5B0692C30925234A9EC99B99C387190BED0640;
// System.Collections.Generic.Dictionary`2<System.Byte,System.Collections.Generic.HashSet`1<Photon.Realtime.Player>>
struct Dictionary_2_tDC389DE02A0FC1608DCA730577C55CF6A7E4921E;
// System.Collections.Generic.Dictionary`2<System.String,Photon.Pun.UtilityScripts.PhotonTeam>
struct Dictionary_2_t7B02F6B4482FAECE12CC3A00B152027E0E61E653;
// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.Material>
struct Dictionary_2_t29EF377760EAE2E4C34F7125BB6CDFE3AE8985A1;
// System.Collections.Generic.Dictionary`2<UnityEngine.UI.Toggle,Photon.Pun.UtilityScripts.TabViewManager/Tab>
struct Dictionary_2_t7244DB208519913604D9D45C9C4CF652AD267B54;
// System.Collections.Generic.HashSet`1<Photon.Realtime.Player>
struct HashSet_1_t2A9A3CBCACFC556A37CB6FBF38DC5924158A4DA6;
// System.Collections.Generic.List`1<Photon.Pun.UtilityScripts.PhotonTeam>
struct List_1_tB346AB19D0AE6924D557CAA8467716755339C5BB;
// System.Collections.Generic.List`1<UnityEngine.GameObject>
struct List_1_t3D4152882C54B77C712688E910390D5C8E030463;
// System.Collections.Generic.List`1<UnityEngine.Transform>
struct List_1_t4DBFD85DCFB946888856DBE52AC08C2AF69C4DBE;
// System.Collections.Generic.List`1<UnityEngine.Vector2>
struct List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB;
// System.Collections.Generic.Stack`1<UnityEngine.GameObject>
struct Stack_1_t4DE78EEF92B4B81F045CED02BDB5FC458862E563;
// System.DelegateData
struct DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE;
// System.Delegate[]
struct DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86;
// System.Func`2<Photon.Realtime.Player,System.Int32>
struct Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE;
// System.IAsyncResult
struct IAsyncResult_t8E194308510B375B42432981AE5E7488C458D598;
// System.Int32[]
struct Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83;
// System.Object[]
struct ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A;
// System.Reflection.MethodInfo
struct MethodInfo_t;
// System.Single[]
struct SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5;
// System.String
struct String_t;
// System.String[]
struct StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E;
// System.Text.StringBuilder
struct StringBuilder_t;
// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017;
// TMPro.TMP_InputField
struct TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB;
// TMPro.TMP_Text
struct TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7;
// TMPro.TextMeshPro
struct TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2;
// TMPro.TextMeshPro[]
struct TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32;
// TrailsFX.TrailEffect/SnapshotIndex[]
struct SnapshotIndexU5BU5D_t402683559A228DC7C2025F620BF10E09387E7B3E;
// TrailsFX.TrailEffect/SnapshotTransform[]
struct SnapshotTransformU5BU5D_t36015EFB3930578852538B8391A54DA6D5A65D2A;
// TrailsFX.TrailEffectProfile
struct TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444;
// UnityEngine.AnimationCurve
struct AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C;
// UnityEngine.Animator
struct Animator_tF1A88E66B3B731DDA75A066DBAE9C55837660F5A;
// UnityEngine.AudioSource
struct AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C;
// UnityEngine.Camera
struct Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34;
// UnityEngine.Canvas
struct Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591;
// UnityEngine.Color[]
struct ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399;
// UnityEngine.Coroutine
struct Coroutine_tAE7DB2FC70A0AE6477F896F852057CB0754F06EC;
// UnityEngine.Events.InvokableCallList
struct InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F;
// UnityEngine.Events.PersistentCallGroup
struct PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F;
// UnityEngine.Font
struct Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26;
// UnityEngine.GameObject
struct GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F;
// UnityEngine.GameObject[]
struct GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520;
// UnityEngine.Gradient
struct Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A;
// UnityEngine.Material
struct Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598;
// UnityEngine.MaterialPropertyBlock
struct MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13;
// UnityEngine.Material[]
struct MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398;
// UnityEngine.Matrix4x4[]
struct Matrix4x4U5BU5D_t1C64F7A0C34058334A8A95BF165F0027690598C9;
// UnityEngine.Mesh
struct Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C;
// UnityEngine.Mesh[]
struct MeshU5BU5D_tDD9C723AA6F0225B35A93D871CDC2CEFF7F8CB89;
// UnityEngine.RectTransform
struct RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20;
// UnityEngine.Renderer
struct Renderer_t0556D67DD582620D1F495627EDE30D03284151F4;
// UnityEngine.Rigidbody
struct Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5;
// UnityEngine.Rigidbody2D
struct Rigidbody2D_tBDC6900A76D3C47E291446FF008D02B817C81CDE;
// UnityEngine.SkinnedMeshRenderer
struct SkinnedMeshRenderer_tFC8103EE7842F7F8A98BEF0C855D32A9711B7B65;
// UnityEngine.SpriteRenderer
struct SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F;
// UnityEngine.Sprite[]
struct SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7;
// UnityEngine.Texture2D
struct Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C;
// UnityEngine.Transform
struct Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA;
// UnityEngine.UI.Button
struct Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B;
// UnityEngine.UI.Button[]
struct ButtonU5BU5D_t363EC059ECDBD3DE56740518F34D8C070331649B;
// UnityEngine.UI.CanvasScaler
struct CanvasScaler_t304BA6F47EDB7402EBA405DD36CA7D6ADF723564;
// UnityEngine.UI.ContentSizeFitter
struct ContentSizeFitter_t4EA7B51457F7EFAD3BAAC51613C7D4E0C26BF4A8;
// UnityEngine.UI.Graphic
struct Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8;
// UnityEngine.UI.HorizontalLayoutGroup
struct HorizontalLayoutGroup_tEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37;
// UnityEngine.UI.Image
struct Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E;
// UnityEngine.UI.Outline
struct Outline_tB750E496976B072E79142D51C0A991AC20183095;
// UnityEngine.UI.ScrollRect
struct ScrollRect_tAD21D8FB1D33789C39BF4E4CD5CD012D9BD7DD51;
// UnityEngine.UI.Selectable
struct Selectable_tAA9065030FE0468018DEC880302F95FEA9C0133A;
// UnityEngine.UI.Shadow
struct Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1;
// UnityEngine.UI.Text
struct Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030;
// UnityEngine.UI.Toggle
struct Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106;
// UnityEngine.UI.ToggleGroup
struct ToggleGroup_t11E2B254D3C968C7D0DA11C606CC06D7D7F0D786;
// UnityEngine.Vector4[]
struct Vector4U5BU5D_t51402C154FFFCF7217A9BEC4B834F0B726C10F66;
// a
struct a_t843891B3C1396BC2023E082606A721962D84C3CB;
// checkSpeed
struct checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7;

struct Delegate_t_marshaled_com;
struct Delegate_t_marshaled_pinvoke;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END

#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif

// <Module>
struct U3CModuleU3E_t2D35D876FED2BDD175BE36DB8283DBD59BA7B06E 
{
public:

public:
};


// <Module>
struct U3CModuleU3E_t6CDDDF959E7E18A6744E43B613F41CDAC780256A 
{
public:

public:
};


// System.Object


// ADS/<ShowBannerWhenInitialized>d__5
struct U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43  : public RuntimeObject
{
public:
	// System.Int32 ADS/<ShowBannerWhenInitialized>d__5::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object ADS/<ShowBannerWhenInitialized>d__5::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// ADS ADS/<ShowBannerWhenInitialized>d__5::<>4__this
	ADS_t19B0242A8A62416BCF9C927D76305A252DB69367 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43, ___U3CU3E4__this_2)); }
	inline ADS_t19B0242A8A62416BCF9C927D76305A252DB69367 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline ADS_t19B0242A8A62416BCF9C927D76305A252DB69367 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(ADS_t19B0242A8A62416BCF9C927D76305A252DB69367 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}
};


// CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151
struct U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7  : public RuntimeObject
{
public:
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::<>4__this
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD * ___U3CU3E4__this_2;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::<previousUpdateTime>5__1
	float ___U3CpreviousUpdateTimeU3E5__1_3;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::<previousUpdateFrames>5__2
	int32_t ___U3CpreviousUpdateFramesU3E5__2_4;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::<timeElapsed>5__3
	float ___U3CtimeElapsedU3E5__3_5;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::<framesChanged>5__4
	int32_t ___U3CframesChangedU3E5__4_6;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7, ___U3CU3E4__this_2)); }
	inline FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CpreviousUpdateTimeU3E5__1_3() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7, ___U3CpreviousUpdateTimeU3E5__1_3)); }
	inline float get_U3CpreviousUpdateTimeU3E5__1_3() const { return ___U3CpreviousUpdateTimeU3E5__1_3; }
	inline float* get_address_of_U3CpreviousUpdateTimeU3E5__1_3() { return &___U3CpreviousUpdateTimeU3E5__1_3; }
	inline void set_U3CpreviousUpdateTimeU3E5__1_3(float value)
	{
		___U3CpreviousUpdateTimeU3E5__1_3 = value;
	}

	inline static int32_t get_offset_of_U3CpreviousUpdateFramesU3E5__2_4() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7, ___U3CpreviousUpdateFramesU3E5__2_4)); }
	inline int32_t get_U3CpreviousUpdateFramesU3E5__2_4() const { return ___U3CpreviousUpdateFramesU3E5__2_4; }
	inline int32_t* get_address_of_U3CpreviousUpdateFramesU3E5__2_4() { return &___U3CpreviousUpdateFramesU3E5__2_4; }
	inline void set_U3CpreviousUpdateFramesU3E5__2_4(int32_t value)
	{
		___U3CpreviousUpdateFramesU3E5__2_4 = value;
	}

	inline static int32_t get_offset_of_U3CtimeElapsedU3E5__3_5() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7, ___U3CtimeElapsedU3E5__3_5)); }
	inline float get_U3CtimeElapsedU3E5__3_5() const { return ___U3CtimeElapsedU3E5__3_5; }
	inline float* get_address_of_U3CtimeElapsedU3E5__3_5() { return &___U3CtimeElapsedU3E5__3_5; }
	inline void set_U3CtimeElapsedU3E5__3_5(float value)
	{
		___U3CtimeElapsedU3E5__3_5 = value;
	}

	inline static int32_t get_offset_of_U3CframesChangedU3E5__4_6() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7, ___U3CframesChangedU3E5__4_6)); }
	inline int32_t get_U3CframesChangedU3E5__4_6() const { return ___U3CframesChangedU3E5__4_6; }
	inline int32_t* get_address_of_U3CframesChangedU3E5__4_6() { return &___U3CframesChangedU3E5__4_6; }
	inline void set_U3CframesChangedU3E5__4_6(int32_t value)
	{
		___U3CframesChangedU3E5__4_6 = value;
	}
};


// CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48
struct U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7  : public RuntimeObject
{
public:
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::<>4__this
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 * ___U3CU3E4__this_2;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::<previousUpdateTime>5__1
	float ___U3CpreviousUpdateTimeU3E5__1_3;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7, ___U3CU3E4__this_2)); }
	inline MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CpreviousUpdateTimeU3E5__1_3() { return static_cast<int32_t>(offsetof(U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7, ___U3CpreviousUpdateTimeU3E5__1_3)); }
	inline float get_U3CpreviousUpdateTimeU3E5__1_3() const { return ___U3CpreviousUpdateTimeU3E5__1_3; }
	inline float* get_address_of_U3CpreviousUpdateTimeU3E5__1_3() { return &___U3CpreviousUpdateTimeU3E5__1_3; }
	inline void set_U3CpreviousUpdateTimeU3E5__1_3(float value)
	{
		___U3CpreviousUpdateTimeU3E5__1_3 = value;
	}
};


// CodeStage.AdvancedFPSCounter.Utils.CachedNumbers
struct CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331  : public RuntimeObject
{
public:

public:
};

struct CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331_StaticFields
{
public:
	// System.String[] CodeStage.AdvancedFPSCounter.Utils.CachedNumbers::cachedFloatDigits
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___cachedFloatDigits_1;
	// System.String[] CodeStage.AdvancedFPSCounter.Utils.CachedNumbers::cachedIntegers
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___cachedIntegers_2;

public:
	inline static int32_t get_offset_of_cachedFloatDigits_1() { return static_cast<int32_t>(offsetof(CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331_StaticFields, ___cachedFloatDigits_1)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_cachedFloatDigits_1() const { return ___cachedFloatDigits_1; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_cachedFloatDigits_1() { return &___cachedFloatDigits_1; }
	inline void set_cachedFloatDigits_1(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___cachedFloatDigits_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cachedFloatDigits_1), (void*)value);
	}

	inline static int32_t get_offset_of_cachedIntegers_2() { return static_cast<int32_t>(offsetof(CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331_StaticFields, ___cachedIntegers_2)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_cachedIntegers_2() const { return ___cachedIntegers_2; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_cachedIntegers_2() { return &___cachedIntegers_2; }
	inline void set_cachedIntegers_2(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___cachedIntegers_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cachedIntegers_2), (void*)value);
	}
};


// CodeStage.AdvancedFPSCounter.Utils.UIUtils
struct UIUtils_t3561BA661DB2F7EFDDFCE453E1F0EDF9E2D59863  : public RuntimeObject
{
public:

public:
};


// Photon.Pun.UtilityScripts.OnClickDestroy/<DestroyRpc>d__4
struct U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746  : public RuntimeObject
{
public:
	// System.Int32 Photon.Pun.UtilityScripts.OnClickDestroy/<DestroyRpc>d__4::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Photon.Pun.UtilityScripts.OnClickDestroy/<DestroyRpc>d__4::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// Photon.Pun.UtilityScripts.OnClickDestroy Photon.Pun.UtilityScripts.OnClickDestroy/<DestroyRpc>d__4::<>4__this
	OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746, ___U3CU3E4__this_2)); }
	inline OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.PhotonTeam
struct PhotonTeam_t82EDE7A41D773DF04CAD2F1D688C52260708A21B  : public RuntimeObject
{
public:
	// System.String Photon.Pun.UtilityScripts.PhotonTeam::Name
	String_t* ___Name_0;
	// System.Byte Photon.Pun.UtilityScripts.PhotonTeam::Code
	uint8_t ___Code_1;

public:
	inline static int32_t get_offset_of_Name_0() { return static_cast<int32_t>(offsetof(PhotonTeam_t82EDE7A41D773DF04CAD2F1D688C52260708A21B, ___Name_0)); }
	inline String_t* get_Name_0() const { return ___Name_0; }
	inline String_t** get_address_of_Name_0() { return &___Name_0; }
	inline void set_Name_0(String_t* value)
	{
		___Name_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Name_0), (void*)value);
	}

	inline static int32_t get_offset_of_Code_1() { return static_cast<int32_t>(offsetof(PhotonTeam_t82EDE7A41D773DF04CAD2F1D688C52260708A21B, ___Code_1)); }
	inline uint8_t get_Code_1() const { return ___Code_1; }
	inline uint8_t* get_address_of_Code_1() { return &___Code_1; }
	inline void set_Code_1(uint8_t value)
	{
		___Code_1 = value;
	}
};


// Photon.Pun.UtilityScripts.PhotonTeamExtensions
struct PhotonTeamExtensions_t52971230D9B85B8C81D134232EAA88786DC2870A  : public RuntimeObject
{
public:

public:
};


// Photon.Pun.UtilityScripts.PlayerNumbering/<>c
struct U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83  : public RuntimeObject
{
public:

public:
};

struct U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields
{
public:
	// Photon.Pun.UtilityScripts.PlayerNumbering/<>c Photon.Pun.UtilityScripts.PlayerNumbering/<>c::<>9
	U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83 * ___U3CU3E9_0;
	// System.Func`2<Photon.Realtime.Player,System.Int32> Photon.Pun.UtilityScripts.PlayerNumbering/<>c::<>9__14_0
	Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * ___U3CU3E9__14_0_1;
	// System.Func`2<Photon.Realtime.Player,System.Int32> Photon.Pun.UtilityScripts.PlayerNumbering/<>c::<>9__14_1
	Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * ___U3CU3E9__14_1_2;
	// System.Func`2<Photon.Realtime.Player,System.Int32> Photon.Pun.UtilityScripts.PlayerNumbering/<>c::<>9__14_2
	Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * ___U3CU3E9__14_2_3;

public:
	inline static int32_t get_offset_of_U3CU3E9_0() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields, ___U3CU3E9_0)); }
	inline U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83 * get_U3CU3E9_0() const { return ___U3CU3E9_0; }
	inline U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83 ** get_address_of_U3CU3E9_0() { return &___U3CU3E9_0; }
	inline void set_U3CU3E9_0(U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83 * value)
	{
		___U3CU3E9_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__14_0_1() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields, ___U3CU3E9__14_0_1)); }
	inline Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * get_U3CU3E9__14_0_1() const { return ___U3CU3E9__14_0_1; }
	inline Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE ** get_address_of_U3CU3E9__14_0_1() { return &___U3CU3E9__14_0_1; }
	inline void set_U3CU3E9__14_0_1(Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * value)
	{
		___U3CU3E9__14_0_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__14_0_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__14_1_2() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields, ___U3CU3E9__14_1_2)); }
	inline Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * get_U3CU3E9__14_1_2() const { return ___U3CU3E9__14_1_2; }
	inline Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE ** get_address_of_U3CU3E9__14_1_2() { return &___U3CU3E9__14_1_2; }
	inline void set_U3CU3E9__14_1_2(Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * value)
	{
		___U3CU3E9__14_1_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__14_1_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E9__14_2_3() { return static_cast<int32_t>(offsetof(U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields, ___U3CU3E9__14_2_3)); }
	inline Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * get_U3CU3E9__14_2_3() const { return ___U3CU3E9__14_2_3; }
	inline Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE ** get_address_of_U3CU3E9__14_2_3() { return &___U3CU3E9__14_2_3; }
	inline void set_U3CU3E9__14_2_3(Func_2_t26A947C1E867D5FBE51E6BA313E8413B4A32D8BE * value)
	{
		___U3CU3E9__14_2_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E9__14_2_3), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.PlayerNumberingExtensions
struct PlayerNumberingExtensions_t783B39081487EF9A853F9211FA63BD3C9712A035  : public RuntimeObject
{
public:

public:
};


// Photon.Pun.UtilityScripts.ScoreExtensions
struct ScoreExtensions_t9B08173082BECE20110F1EC3ABDE3C29E297880C  : public RuntimeObject
{
public:

public:
};


// Photon.Pun.UtilityScripts.TabViewManager/<>c__DisplayClass7_0
struct U3CU3Ec__DisplayClass7_0_t4488666C791C03BE6BCC095CD458EA7F2DE8610B  : public RuntimeObject
{
public:
	// Photon.Pun.UtilityScripts.TabViewManager/Tab Photon.Pun.UtilityScripts.TabViewManager/<>c__DisplayClass7_0::_tab
	Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A * ____tab_0;
	// Photon.Pun.UtilityScripts.TabViewManager Photon.Pun.UtilityScripts.TabViewManager/<>c__DisplayClass7_0::<>4__this
	TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B * ___U3CU3E4__this_1;

public:
	inline static int32_t get_offset_of__tab_0() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass7_0_t4488666C791C03BE6BCC095CD458EA7F2DE8610B, ____tab_0)); }
	inline Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A * get__tab_0() const { return ____tab_0; }
	inline Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A ** get_address_of__tab_0() { return &____tab_0; }
	inline void set__tab_0(Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A * value)
	{
		____tab_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____tab_0), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_1() { return static_cast<int32_t>(offsetof(U3CU3Ec__DisplayClass7_0_t4488666C791C03BE6BCC095CD458EA7F2DE8610B, ___U3CU3E4__this_1)); }
	inline TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B * get_U3CU3E4__this_1() const { return ___U3CU3E4__this_1; }
	inline TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B ** get_address_of_U3CU3E4__this_1() { return &___U3CU3E4__this_1; }
	inline void set_U3CU3E4__this_1(TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B * value)
	{
		___U3CU3E4__this_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_1), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.TabViewManager/Tab
struct Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A  : public RuntimeObject
{
public:
	// System.String Photon.Pun.UtilityScripts.TabViewManager/Tab::ID
	String_t* ___ID_0;
	// UnityEngine.UI.Toggle Photon.Pun.UtilityScripts.TabViewManager/Tab::Toggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___Toggle_1;
	// UnityEngine.RectTransform Photon.Pun.UtilityScripts.TabViewManager/Tab::View
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___View_2;

public:
	inline static int32_t get_offset_of_ID_0() { return static_cast<int32_t>(offsetof(Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A, ___ID_0)); }
	inline String_t* get_ID_0() const { return ___ID_0; }
	inline String_t** get_address_of_ID_0() { return &___ID_0; }
	inline void set_ID_0(String_t* value)
	{
		___ID_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ID_0), (void*)value);
	}

	inline static int32_t get_offset_of_Toggle_1() { return static_cast<int32_t>(offsetof(Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A, ___Toggle_1)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_Toggle_1() const { return ___Toggle_1; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_Toggle_1() { return &___Toggle_1; }
	inline void set_Toggle_1(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___Toggle_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Toggle_1), (void*)value);
	}

	inline static int32_t get_offset_of_View_2() { return static_cast<int32_t>(offsetof(Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A, ___View_2)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_View_2() const { return ___View_2; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_View_2() { return &___View_2; }
	inline void set_View_2(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___View_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___View_2), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.TeamExtensions
struct TeamExtensions_t602E1A3772FA5E7EB9D67EF55A96F1AFCB8693A9  : public RuntimeObject
{
public:

public:
};


// Photon.Pun.UtilityScripts.TurnExtensions
struct TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0  : public RuntimeObject
{
public:

public:
};

struct TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields
{
public:
	// System.String Photon.Pun.UtilityScripts.TurnExtensions::TurnPropKey
	String_t* ___TurnPropKey_0;
	// System.String Photon.Pun.UtilityScripts.TurnExtensions::TurnStartPropKey
	String_t* ___TurnStartPropKey_1;
	// System.String Photon.Pun.UtilityScripts.TurnExtensions::FinishedTurnPropKey
	String_t* ___FinishedTurnPropKey_2;

public:
	inline static int32_t get_offset_of_TurnPropKey_0() { return static_cast<int32_t>(offsetof(TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields, ___TurnPropKey_0)); }
	inline String_t* get_TurnPropKey_0() const { return ___TurnPropKey_0; }
	inline String_t** get_address_of_TurnPropKey_0() { return &___TurnPropKey_0; }
	inline void set_TurnPropKey_0(String_t* value)
	{
		___TurnPropKey_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TurnPropKey_0), (void*)value);
	}

	inline static int32_t get_offset_of_TurnStartPropKey_1() { return static_cast<int32_t>(offsetof(TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields, ___TurnStartPropKey_1)); }
	inline String_t* get_TurnStartPropKey_1() const { return ___TurnStartPropKey_1; }
	inline String_t** get_address_of_TurnStartPropKey_1() { return &___TurnStartPropKey_1; }
	inline void set_TurnStartPropKey_1(String_t* value)
	{
		___TurnStartPropKey_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TurnStartPropKey_1), (void*)value);
	}

	inline static int32_t get_offset_of_FinishedTurnPropKey_2() { return static_cast<int32_t>(offsetof(TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields, ___FinishedTurnPropKey_2)); }
	inline String_t* get_FinishedTurnPropKey_2() const { return ___FinishedTurnPropKey_2; }
	inline String_t** get_address_of_FinishedTurnPropKey_2() { return &___FinishedTurnPropKey_2; }
	inline void set_FinishedTurnPropKey_2(String_t* value)
	{
		___FinishedTurnPropKey_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___FinishedTurnPropKey_2), (void*)value);
	}
};


// System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF  : public RuntimeObject
{
public:

public:
};

// Native definition for P/Invoke marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.ValueType
struct ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF_marshaled_com
{
};

// TrailsFX.TrailStyleProperties
struct TrailStyleProperties_tFD27699CF82CD7BB8EAEAD3DB46F1C04A565F1BC  : public RuntimeObject
{
public:

public:
};


// UnityEngine.Events.UnityEventBase
struct UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5  : public RuntimeObject
{
public:
	// UnityEngine.Events.InvokableCallList UnityEngine.Events.UnityEventBase::m_Calls
	InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F * ___m_Calls_0;
	// UnityEngine.Events.PersistentCallGroup UnityEngine.Events.UnityEventBase::m_PersistentCalls
	PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F * ___m_PersistentCalls_1;
	// System.Boolean UnityEngine.Events.UnityEventBase::m_CallsDirty
	bool ___m_CallsDirty_2;

public:
	inline static int32_t get_offset_of_m_Calls_0() { return static_cast<int32_t>(offsetof(UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5, ___m_Calls_0)); }
	inline InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F * get_m_Calls_0() const { return ___m_Calls_0; }
	inline InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F ** get_address_of_m_Calls_0() { return &___m_Calls_0; }
	inline void set_m_Calls_0(InvokableCallList_t18AA4F473C7B295216B7D4B9723B4F3DFCCC9A3F * value)
	{
		___m_Calls_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_Calls_0), (void*)value);
	}

	inline static int32_t get_offset_of_m_PersistentCalls_1() { return static_cast<int32_t>(offsetof(UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5, ___m_PersistentCalls_1)); }
	inline PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F * get_m_PersistentCalls_1() const { return ___m_PersistentCalls_1; }
	inline PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F ** get_address_of_m_PersistentCalls_1() { return &___m_PersistentCalls_1; }
	inline void set_m_PersistentCalls_1(PersistentCallGroup_t6E5DF2EBDA42794B5FE0C6DAA97DF65F0BFF571F * value)
	{
		___m_PersistentCalls_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_PersistentCalls_1), (void*)value);
	}

	inline static int32_t get_offset_of_m_CallsDirty_2() { return static_cast<int32_t>(offsetof(UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5, ___m_CallsDirty_2)); }
	inline bool get_m_CallsDirty_2() const { return ___m_CallsDirty_2; }
	inline bool* get_address_of_m_CallsDirty_2() { return &___m_CallsDirty_2; }
	inline void set_m_CallsDirty_2(bool value)
	{
		___m_CallsDirty_2 = value;
	}
};


// a/<ShowBannerWhenInitialized>d__4
struct U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13  : public RuntimeObject
{
public:
	// System.Int32 a/<ShowBannerWhenInitialized>d__4::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object a/<ShowBannerWhenInitialized>d__4::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// a a/<ShowBannerWhenInitialized>d__4::<>4__this
	a_t843891B3C1396BC2023E082606A721962D84C3CB * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13, ___U3CU3E4__this_2)); }
	inline a_t843891B3C1396BC2023E082606A721962D84C3CB * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline a_t843891B3C1396BC2023E082606A721962D84C3CB ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(a_t843891B3C1396BC2023E082606A721962D84C3CB * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}
};


// checkSpeed/<ExampleCoroutine>d__34
struct U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551  : public RuntimeObject
{
public:
	// System.Int32 checkSpeed/<ExampleCoroutine>d__34::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object checkSpeed/<ExampleCoroutine>d__34::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// checkSpeed checkSpeed/<ExampleCoroutine>d__34::<>4__this
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7 * ___U3CU3E4__this_2;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551, ___U3CU3E4__this_2)); }
	inline checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7 * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7 ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7 * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16
struct __StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A__padding[16];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24
struct __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34__padding[24];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32
struct __StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937__padding[32];
	};

public:
};


// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=48
struct __StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981 
{
public:
	union
	{
		struct
		{
			union
			{
			};
		};
		uint8_t __StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981__padding[48];
	};

public:
};


// System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521  : public ValueType_t4D0C27076F7C36E76190FB3328E232BCB1CD1FFF
{
public:

public:
};

struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields
{
public:
	// System.Char[] System.Enum::enumSeperatorCharArray
	CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* ___enumSeperatorCharArray_0;

public:
	inline static int32_t get_offset_of_enumSeperatorCharArray_0() { return static_cast<int32_t>(offsetof(Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_StaticFields, ___enumSeperatorCharArray_0)); }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* get_enumSeperatorCharArray_0() const { return ___enumSeperatorCharArray_0; }
	inline CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2** get_address_of_enumSeperatorCharArray_0() { return &___enumSeperatorCharArray_0; }
	inline void set_enumSeperatorCharArray_0(CharU5BU5D_t4CC6ABF0AD71BEC97E3C2F1E9C5677E46D3A75C2* value)
	{
		___enumSeperatorCharArray_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___enumSeperatorCharArray_0), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_pinvoke
{
};
// Native definition for COM marshalling of System.Enum
struct Enum_t2AF27C02B8653AE29442467390005ABC74D8F521_marshaled_com
{
};

// System.IntPtr
struct IntPtr_t 
{
public:
	// System.Void* System.IntPtr::m_value
	void* ___m_value_0;

public:
	inline static int32_t get_offset_of_m_value_0() { return static_cast<int32_t>(offsetof(IntPtr_t, ___m_value_0)); }
	inline void* get_m_value_0() const { return ___m_value_0; }
	inline void** get_address_of_m_value_0() { return &___m_value_0; }
	inline void set_m_value_0(void* value)
	{
		___m_value_0 = value;
	}
};

struct IntPtr_t_StaticFields
{
public:
	// System.IntPtr System.IntPtr::Zero
	intptr_t ___Zero_1;

public:
	inline static int32_t get_offset_of_Zero_1() { return static_cast<int32_t>(offsetof(IntPtr_t_StaticFields, ___Zero_1)); }
	inline intptr_t get_Zero_1() const { return ___Zero_1; }
	inline intptr_t* get_address_of_Zero_1() { return &___Zero_1; }
	inline void set_Zero_1(intptr_t value)
	{
		___Zero_1 = value;
	}
};


// System.Void
struct Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017 
{
public:
	union
	{
		struct
		{
		};
		uint8_t Void_t22962CB4C05B1D89B55A6E1139F0E87A90987017__padding[1];
	};

public:
};


// TrailsFX.TrailEffect/SnapshotIndex
struct SnapshotIndex_t54E78E531BC3265078A39F96AFFF48944401C738 
{
public:
	// System.Single TrailsFX.TrailEffect/SnapshotIndex::t
	float ___t_0;
	// System.Int32 TrailsFX.TrailEffect/SnapshotIndex::index
	int32_t ___index_1;

public:
	inline static int32_t get_offset_of_t_0() { return static_cast<int32_t>(offsetof(SnapshotIndex_t54E78E531BC3265078A39F96AFFF48944401C738, ___t_0)); }
	inline float get_t_0() const { return ___t_0; }
	inline float* get_address_of_t_0() { return &___t_0; }
	inline void set_t_0(float value)
	{
		___t_0 = value;
	}

	inline static int32_t get_offset_of_index_1() { return static_cast<int32_t>(offsetof(SnapshotIndex_t54E78E531BC3265078A39F96AFFF48944401C738, ___index_1)); }
	inline int32_t get_index_1() const { return ___index_1; }
	inline int32_t* get_address_of_index_1() { return &___index_1; }
	inline void set_index_1(int32_t value)
	{
		___index_1 = value;
	}
};


// UnityEngine.Color
struct Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 
{
public:
	// System.Single UnityEngine.Color::r
	float ___r_0;
	// System.Single UnityEngine.Color::g
	float ___g_1;
	// System.Single UnityEngine.Color::b
	float ___b_2;
	// System.Single UnityEngine.Color::a
	float ___a_3;

public:
	inline static int32_t get_offset_of_r_0() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___r_0)); }
	inline float get_r_0() const { return ___r_0; }
	inline float* get_address_of_r_0() { return &___r_0; }
	inline void set_r_0(float value)
	{
		___r_0 = value;
	}

	inline static int32_t get_offset_of_g_1() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___g_1)); }
	inline float get_g_1() const { return ___g_1; }
	inline float* get_address_of_g_1() { return &___g_1; }
	inline void set_g_1(float value)
	{
		___g_1 = value;
	}

	inline static int32_t get_offset_of_b_2() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___b_2)); }
	inline float get_b_2() const { return ___b_2; }
	inline float* get_address_of_b_2() { return &___b_2; }
	inline void set_b_2(float value)
	{
		___b_2 = value;
	}

	inline static int32_t get_offset_of_a_3() { return static_cast<int32_t>(offsetof(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2, ___a_3)); }
	inline float get_a_3() const { return ___a_3; }
	inline float* get_address_of_a_3() { return &___a_3; }
	inline void set_a_3(float value)
	{
		___a_3 = value;
	}
};


// UnityEngine.Events.UnityEvent`1<System.String>
struct UnityEvent_1_t890F45761F13DD1B3D58738365827FDB6629BA7F  : public UnityEventBase_t6E0F7823762EE94BB8489B5AE41C7802A266D3D5
{
public:
	// System.Object[] UnityEngine.Events.UnityEvent`1::m_InvokeArray
	ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* ___m_InvokeArray_3;

public:
	inline static int32_t get_offset_of_m_InvokeArray_3() { return static_cast<int32_t>(offsetof(UnityEvent_1_t890F45761F13DD1B3D58738365827FDB6629BA7F, ___m_InvokeArray_3)); }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* get_m_InvokeArray_3() const { return ___m_InvokeArray_3; }
	inline ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A** get_address_of_m_InvokeArray_3() { return &___m_InvokeArray_3; }
	inline void set_m_InvokeArray_3(ObjectU5BU5D_t3C9242B5C88A48B2A5BD9FDA6CD0024E792AF08A* value)
	{
		___m_InvokeArray_3 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_InvokeArray_3), (void*)value);
	}
};


// UnityEngine.LayerMask
struct LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0 
{
public:
	// System.Int32 UnityEngine.LayerMask::m_Mask
	int32_t ___m_Mask_0;

public:
	inline static int32_t get_offset_of_m_Mask_0() { return static_cast<int32_t>(offsetof(LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0, ___m_Mask_0)); }
	inline int32_t get_m_Mask_0() const { return ___m_Mask_0; }
	inline int32_t* get_address_of_m_Mask_0() { return &___m_Mask_0; }
	inline void set_m_Mask_0(int32_t value)
	{
		___m_Mask_0 = value;
	}
};


// UnityEngine.Matrix4x4
struct Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA 
{
public:
	// System.Single UnityEngine.Matrix4x4::m00
	float ___m00_0;
	// System.Single UnityEngine.Matrix4x4::m10
	float ___m10_1;
	// System.Single UnityEngine.Matrix4x4::m20
	float ___m20_2;
	// System.Single UnityEngine.Matrix4x4::m30
	float ___m30_3;
	// System.Single UnityEngine.Matrix4x4::m01
	float ___m01_4;
	// System.Single UnityEngine.Matrix4x4::m11
	float ___m11_5;
	// System.Single UnityEngine.Matrix4x4::m21
	float ___m21_6;
	// System.Single UnityEngine.Matrix4x4::m31
	float ___m31_7;
	// System.Single UnityEngine.Matrix4x4::m02
	float ___m02_8;
	// System.Single UnityEngine.Matrix4x4::m12
	float ___m12_9;
	// System.Single UnityEngine.Matrix4x4::m22
	float ___m22_10;
	// System.Single UnityEngine.Matrix4x4::m32
	float ___m32_11;
	// System.Single UnityEngine.Matrix4x4::m03
	float ___m03_12;
	// System.Single UnityEngine.Matrix4x4::m13
	float ___m13_13;
	// System.Single UnityEngine.Matrix4x4::m23
	float ___m23_14;
	// System.Single UnityEngine.Matrix4x4::m33
	float ___m33_15;

public:
	inline static int32_t get_offset_of_m00_0() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m00_0)); }
	inline float get_m00_0() const { return ___m00_0; }
	inline float* get_address_of_m00_0() { return &___m00_0; }
	inline void set_m00_0(float value)
	{
		___m00_0 = value;
	}

	inline static int32_t get_offset_of_m10_1() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m10_1)); }
	inline float get_m10_1() const { return ___m10_1; }
	inline float* get_address_of_m10_1() { return &___m10_1; }
	inline void set_m10_1(float value)
	{
		___m10_1 = value;
	}

	inline static int32_t get_offset_of_m20_2() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m20_2)); }
	inline float get_m20_2() const { return ___m20_2; }
	inline float* get_address_of_m20_2() { return &___m20_2; }
	inline void set_m20_2(float value)
	{
		___m20_2 = value;
	}

	inline static int32_t get_offset_of_m30_3() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m30_3)); }
	inline float get_m30_3() const { return ___m30_3; }
	inline float* get_address_of_m30_3() { return &___m30_3; }
	inline void set_m30_3(float value)
	{
		___m30_3 = value;
	}

	inline static int32_t get_offset_of_m01_4() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m01_4)); }
	inline float get_m01_4() const { return ___m01_4; }
	inline float* get_address_of_m01_4() { return &___m01_4; }
	inline void set_m01_4(float value)
	{
		___m01_4 = value;
	}

	inline static int32_t get_offset_of_m11_5() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m11_5)); }
	inline float get_m11_5() const { return ___m11_5; }
	inline float* get_address_of_m11_5() { return &___m11_5; }
	inline void set_m11_5(float value)
	{
		___m11_5 = value;
	}

	inline static int32_t get_offset_of_m21_6() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m21_6)); }
	inline float get_m21_6() const { return ___m21_6; }
	inline float* get_address_of_m21_6() { return &___m21_6; }
	inline void set_m21_6(float value)
	{
		___m21_6 = value;
	}

	inline static int32_t get_offset_of_m31_7() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m31_7)); }
	inline float get_m31_7() const { return ___m31_7; }
	inline float* get_address_of_m31_7() { return &___m31_7; }
	inline void set_m31_7(float value)
	{
		___m31_7 = value;
	}

	inline static int32_t get_offset_of_m02_8() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m02_8)); }
	inline float get_m02_8() const { return ___m02_8; }
	inline float* get_address_of_m02_8() { return &___m02_8; }
	inline void set_m02_8(float value)
	{
		___m02_8 = value;
	}

	inline static int32_t get_offset_of_m12_9() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m12_9)); }
	inline float get_m12_9() const { return ___m12_9; }
	inline float* get_address_of_m12_9() { return &___m12_9; }
	inline void set_m12_9(float value)
	{
		___m12_9 = value;
	}

	inline static int32_t get_offset_of_m22_10() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m22_10)); }
	inline float get_m22_10() const { return ___m22_10; }
	inline float* get_address_of_m22_10() { return &___m22_10; }
	inline void set_m22_10(float value)
	{
		___m22_10 = value;
	}

	inline static int32_t get_offset_of_m32_11() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m32_11)); }
	inline float get_m32_11() const { return ___m32_11; }
	inline float* get_address_of_m32_11() { return &___m32_11; }
	inline void set_m32_11(float value)
	{
		___m32_11 = value;
	}

	inline static int32_t get_offset_of_m03_12() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m03_12)); }
	inline float get_m03_12() const { return ___m03_12; }
	inline float* get_address_of_m03_12() { return &___m03_12; }
	inline void set_m03_12(float value)
	{
		___m03_12 = value;
	}

	inline static int32_t get_offset_of_m13_13() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m13_13)); }
	inline float get_m13_13() const { return ___m13_13; }
	inline float* get_address_of_m13_13() { return &___m13_13; }
	inline void set_m13_13(float value)
	{
		___m13_13 = value;
	}

	inline static int32_t get_offset_of_m23_14() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m23_14)); }
	inline float get_m23_14() const { return ___m23_14; }
	inline float* get_address_of_m23_14() { return &___m23_14; }
	inline void set_m23_14(float value)
	{
		___m23_14 = value;
	}

	inline static int32_t get_offset_of_m33_15() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA, ___m33_15)); }
	inline float get_m33_15() const { return ___m33_15; }
	inline float* get_address_of_m33_15() { return &___m33_15; }
	inline void set_m33_15(float value)
	{
		___m33_15 = value;
	}
};

struct Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields
{
public:
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::zeroMatrix
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___zeroMatrix_16;
	// UnityEngine.Matrix4x4 UnityEngine.Matrix4x4::identityMatrix
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___identityMatrix_17;

public:
	inline static int32_t get_offset_of_zeroMatrix_16() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields, ___zeroMatrix_16)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_zeroMatrix_16() const { return ___zeroMatrix_16; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_zeroMatrix_16() { return &___zeroMatrix_16; }
	inline void set_zeroMatrix_16(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___zeroMatrix_16 = value;
	}

	inline static int32_t get_offset_of_identityMatrix_17() { return static_cast<int32_t>(offsetof(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA_StaticFields, ___identityMatrix_17)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_identityMatrix_17() const { return ___identityMatrix_17; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_identityMatrix_17() { return &___identityMatrix_17; }
	inline void set_identityMatrix_17(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___identityMatrix_17 = value;
	}
};


// UnityEngine.Quaternion
struct Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 
{
public:
	// System.Single UnityEngine.Quaternion::x
	float ___x_0;
	// System.Single UnityEngine.Quaternion::y
	float ___y_1;
	// System.Single UnityEngine.Quaternion::z
	float ___z_2;
	// System.Single UnityEngine.Quaternion::w
	float ___w_3;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}

	inline static int32_t get_offset_of_z_2() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___z_2)); }
	inline float get_z_2() const { return ___z_2; }
	inline float* get_address_of_z_2() { return &___z_2; }
	inline void set_z_2(float value)
	{
		___z_2 = value;
	}

	inline static int32_t get_offset_of_w_3() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357, ___w_3)); }
	inline float get_w_3() const { return ___w_3; }
	inline float* get_address_of_w_3() { return &___w_3; }
	inline void set_w_3(float value)
	{
		___w_3 = value;
	}
};

struct Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357_StaticFields
{
public:
	// UnityEngine.Quaternion UnityEngine.Quaternion::identityQuaternion
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___identityQuaternion_4;

public:
	inline static int32_t get_offset_of_identityQuaternion_4() { return static_cast<int32_t>(offsetof(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357_StaticFields, ___identityQuaternion_4)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_identityQuaternion_4() const { return ___identityQuaternion_4; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_identityQuaternion_4() { return &___identityQuaternion_4; }
	inline void set_identityQuaternion_4(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___identityQuaternion_4 = value;
	}
};


// UnityEngine.Vector2
struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D 
{
public:
	// System.Single UnityEngine.Vector2::x
	float ___x_0;
	// System.Single UnityEngine.Vector2::y
	float ___y_1;

public:
	inline static int32_t get_offset_of_x_0() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___x_0)); }
	inline float get_x_0() const { return ___x_0; }
	inline float* get_address_of_x_0() { return &___x_0; }
	inline void set_x_0(float value)
	{
		___x_0 = value;
	}

	inline static int32_t get_offset_of_y_1() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D, ___y_1)); }
	inline float get_y_1() const { return ___y_1; }
	inline float* get_address_of_y_1() { return &___y_1; }
	inline void set_y_1(float value)
	{
		___y_1 = value;
	}
};

struct Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields
{
public:
	// UnityEngine.Vector2 UnityEngine.Vector2::zeroVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___zeroVector_2;
	// UnityEngine.Vector2 UnityEngine.Vector2::oneVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___oneVector_3;
	// UnityEngine.Vector2 UnityEngine.Vector2::upVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___upVector_4;
	// UnityEngine.Vector2 UnityEngine.Vector2::downVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___downVector_5;
	// UnityEngine.Vector2 UnityEngine.Vector2::leftVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___leftVector_6;
	// UnityEngine.Vector2 UnityEngine.Vector2::rightVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___rightVector_7;
	// UnityEngine.Vector2 UnityEngine.Vector2::positiveInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___positiveInfinityVector_8;
	// UnityEngine.Vector2 UnityEngine.Vector2::negativeInfinityVector
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___negativeInfinityVector_9;

public:
	inline static int32_t get_offset_of_zeroVector_2() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___zeroVector_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_zeroVector_2() const { return ___zeroVector_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_zeroVector_2() { return &___zeroVector_2; }
	inline void set_zeroVector_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___zeroVector_2 = value;
	}

	inline static int32_t get_offset_of_oneVector_3() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___oneVector_3)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_oneVector_3() const { return ___oneVector_3; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_oneVector_3() { return &___oneVector_3; }
	inline void set_oneVector_3(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___oneVector_3 = value;
	}

	inline static int32_t get_offset_of_upVector_4() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___upVector_4)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_upVector_4() const { return ___upVector_4; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_upVector_4() { return &___upVector_4; }
	inline void set_upVector_4(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___upVector_4 = value;
	}

	inline static int32_t get_offset_of_downVector_5() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___downVector_5)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_downVector_5() const { return ___downVector_5; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_downVector_5() { return &___downVector_5; }
	inline void set_downVector_5(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___downVector_5 = value;
	}

	inline static int32_t get_offset_of_leftVector_6() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___leftVector_6)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_leftVector_6() const { return ___leftVector_6; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_leftVector_6() { return &___leftVector_6; }
	inline void set_leftVector_6(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___leftVector_6 = value;
	}

	inline static int32_t get_offset_of_rightVector_7() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___rightVector_7)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_rightVector_7() const { return ___rightVector_7; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_rightVector_7() { return &___rightVector_7; }
	inline void set_rightVector_7(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___rightVector_7 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_8() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___positiveInfinityVector_8)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_positiveInfinityVector_8() const { return ___positiveInfinityVector_8; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_positiveInfinityVector_8() { return &___positiveInfinityVector_8; }
	inline void set_positiveInfinityVector_8(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___positiveInfinityVector_8 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_9() { return static_cast<int32_t>(offsetof(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D_StaticFields, ___negativeInfinityVector_9)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_negativeInfinityVector_9() const { return ___negativeInfinityVector_9; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_negativeInfinityVector_9() { return &___negativeInfinityVector_9; }
	inline void set_negativeInfinityVector_9(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___negativeInfinityVector_9 = value;
	}
};


// UnityEngine.Vector3
struct Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 
{
public:
	// System.Single UnityEngine.Vector3::x
	float ___x_2;
	// System.Single UnityEngine.Vector3::y
	float ___y_3;
	// System.Single UnityEngine.Vector3::z
	float ___z_4;

public:
	inline static int32_t get_offset_of_x_2() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___x_2)); }
	inline float get_x_2() const { return ___x_2; }
	inline float* get_address_of_x_2() { return &___x_2; }
	inline void set_x_2(float value)
	{
		___x_2 = value;
	}

	inline static int32_t get_offset_of_y_3() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___y_3)); }
	inline float get_y_3() const { return ___y_3; }
	inline float* get_address_of_y_3() { return &___y_3; }
	inline void set_y_3(float value)
	{
		___y_3 = value;
	}

	inline static int32_t get_offset_of_z_4() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720, ___z_4)); }
	inline float get_z_4() const { return ___z_4; }
	inline float* get_address_of_z_4() { return &___z_4; }
	inline void set_z_4(float value)
	{
		___z_4 = value;
	}
};

struct Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields
{
public:
	// UnityEngine.Vector3 UnityEngine.Vector3::zeroVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___zeroVector_5;
	// UnityEngine.Vector3 UnityEngine.Vector3::oneVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___oneVector_6;
	// UnityEngine.Vector3 UnityEngine.Vector3::upVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___upVector_7;
	// UnityEngine.Vector3 UnityEngine.Vector3::downVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___downVector_8;
	// UnityEngine.Vector3 UnityEngine.Vector3::leftVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___leftVector_9;
	// UnityEngine.Vector3 UnityEngine.Vector3::rightVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___rightVector_10;
	// UnityEngine.Vector3 UnityEngine.Vector3::forwardVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___forwardVector_11;
	// UnityEngine.Vector3 UnityEngine.Vector3::backVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___backVector_12;
	// UnityEngine.Vector3 UnityEngine.Vector3::positiveInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___positiveInfinityVector_13;
	// UnityEngine.Vector3 UnityEngine.Vector3::negativeInfinityVector
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___negativeInfinityVector_14;

public:
	inline static int32_t get_offset_of_zeroVector_5() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___zeroVector_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_zeroVector_5() const { return ___zeroVector_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_zeroVector_5() { return &___zeroVector_5; }
	inline void set_zeroVector_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___zeroVector_5 = value;
	}

	inline static int32_t get_offset_of_oneVector_6() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___oneVector_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_oneVector_6() const { return ___oneVector_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_oneVector_6() { return &___oneVector_6; }
	inline void set_oneVector_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___oneVector_6 = value;
	}

	inline static int32_t get_offset_of_upVector_7() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___upVector_7)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_upVector_7() const { return ___upVector_7; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_upVector_7() { return &___upVector_7; }
	inline void set_upVector_7(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___upVector_7 = value;
	}

	inline static int32_t get_offset_of_downVector_8() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___downVector_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_downVector_8() const { return ___downVector_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_downVector_8() { return &___downVector_8; }
	inline void set_downVector_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___downVector_8 = value;
	}

	inline static int32_t get_offset_of_leftVector_9() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___leftVector_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_leftVector_9() const { return ___leftVector_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_leftVector_9() { return &___leftVector_9; }
	inline void set_leftVector_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___leftVector_9 = value;
	}

	inline static int32_t get_offset_of_rightVector_10() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___rightVector_10)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_rightVector_10() const { return ___rightVector_10; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_rightVector_10() { return &___rightVector_10; }
	inline void set_rightVector_10(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___rightVector_10 = value;
	}

	inline static int32_t get_offset_of_forwardVector_11() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___forwardVector_11)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_forwardVector_11() const { return ___forwardVector_11; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_forwardVector_11() { return &___forwardVector_11; }
	inline void set_forwardVector_11(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___forwardVector_11 = value;
	}

	inline static int32_t get_offset_of_backVector_12() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___backVector_12)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_backVector_12() const { return ___backVector_12; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_backVector_12() { return &___backVector_12; }
	inline void set_backVector_12(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___backVector_12 = value;
	}

	inline static int32_t get_offset_of_positiveInfinityVector_13() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___positiveInfinityVector_13)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_positiveInfinityVector_13() const { return ___positiveInfinityVector_13; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_positiveInfinityVector_13() { return &___positiveInfinityVector_13; }
	inline void set_positiveInfinityVector_13(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___positiveInfinityVector_13 = value;
	}

	inline static int32_t get_offset_of_negativeInfinityVector_14() { return static_cast<int32_t>(offsetof(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720_StaticFields, ___negativeInfinityVector_14)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_negativeInfinityVector_14() const { return ___negativeInfinityVector_14; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_negativeInfinityVector_14() { return &___negativeInfinityVector_14; }
	inline void set_negativeInfinityVector_14(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___negativeInfinityVector_14 = value;
	}
};


// <PrivateImplementationDetails>
struct U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields
{
public:
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=48 <PrivateImplementationDetails>::35FDBB6669F521B572D4AD71DD77E77F43C1B71B
	__StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981  ___35FDBB6669F521B572D4AD71DD77E77F43C1B71B_0;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=32 <PrivateImplementationDetails>::739C505E9F0985CE1E08892BC46BE5E839FF061A
	__StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937  ___739C505E9F0985CE1E08892BC46BE5E839FF061A_1;
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=16 <PrivateImplementationDetails>::8658990BAD6546E619D8A5C4F90BCF3F089E0953
	__StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A  ___8658990BAD6546E619D8A5C4F90BCF3F089E0953_2;

public:
	inline static int32_t get_offset_of_U335FDBB6669F521B572D4AD71DD77E77F43C1B71B_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields, ___35FDBB6669F521B572D4AD71DD77E77F43C1B71B_0)); }
	inline __StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981  get_U335FDBB6669F521B572D4AD71DD77E77F43C1B71B_0() const { return ___35FDBB6669F521B572D4AD71DD77E77F43C1B71B_0; }
	inline __StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981 * get_address_of_U335FDBB6669F521B572D4AD71DD77E77F43C1B71B_0() { return &___35FDBB6669F521B572D4AD71DD77E77F43C1B71B_0; }
	inline void set_U335FDBB6669F521B572D4AD71DD77E77F43C1B71B_0(__StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981  value)
	{
		___35FDBB6669F521B572D4AD71DD77E77F43C1B71B_0 = value;
	}

	inline static int32_t get_offset_of_U3739C505E9F0985CE1E08892BC46BE5E839FF061A_1() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields, ___739C505E9F0985CE1E08892BC46BE5E839FF061A_1)); }
	inline __StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937  get_U3739C505E9F0985CE1E08892BC46BE5E839FF061A_1() const { return ___739C505E9F0985CE1E08892BC46BE5E839FF061A_1; }
	inline __StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937 * get_address_of_U3739C505E9F0985CE1E08892BC46BE5E839FF061A_1() { return &___739C505E9F0985CE1E08892BC46BE5E839FF061A_1; }
	inline void set_U3739C505E9F0985CE1E08892BC46BE5E839FF061A_1(__StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937  value)
	{
		___739C505E9F0985CE1E08892BC46BE5E839FF061A_1 = value;
	}

	inline static int32_t get_offset_of_U38658990BAD6546E619D8A5C4F90BCF3F089E0953_2() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields, ___8658990BAD6546E619D8A5C4F90BCF3F089E0953_2)); }
	inline __StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A  get_U38658990BAD6546E619D8A5C4F90BCF3F089E0953_2() const { return ___8658990BAD6546E619D8A5C4F90BCF3F089E0953_2; }
	inline __StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A * get_address_of_U38658990BAD6546E619D8A5C4F90BCF3F089E0953_2() { return &___8658990BAD6546E619D8A5C4F90BCF3F089E0953_2; }
	inline void set_U38658990BAD6546E619D8A5C4F90BCF3F089E0953_2(__StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A  value)
	{
		___8658990BAD6546E619D8A5C4F90BCF3F089E0953_2 = value;
	}
};


// <PrivateImplementationDetails>
struct U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A  : public RuntimeObject
{
public:

public:
};

struct U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields
{
public:
	// <PrivateImplementationDetails>/__StaticArrayInitTypeSize=24 <PrivateImplementationDetails>::1B287FBF8016A1357E0FA5B7B88403B0659ECE97
	__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34  ___1B287FBF8016A1357E0FA5B7B88403B0659ECE97_0;

public:
	inline static int32_t get_offset_of_U31B287FBF8016A1357E0FA5B7B88403B0659ECE97_0() { return static_cast<int32_t>(offsetof(U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields, ___1B287FBF8016A1357E0FA5B7B88403B0659ECE97_0)); }
	inline __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34  get_U31B287FBF8016A1357E0FA5B7B88403B0659ECE97_0() const { return ___1B287FBF8016A1357E0FA5B7B88403B0659ECE97_0; }
	inline __StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34 * get_address_of_U31B287FBF8016A1357E0FA5B7B88403B0659ECE97_0() { return &___1B287FBF8016A1357E0FA5B7B88403B0659ECE97_0; }
	inline void set_U31B287FBF8016A1357E0FA5B7B88403B0659ECE97_0(__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34  value)
	{
		___1B287FBF8016A1357E0FA5B7B88403B0659ECE97_0 = value;
	}
};


// CodeStage.AdvancedFPSCounter.FPSLevel
struct FPSLevel_t9C2930ABEBC10506FC5ED2E8847498EC2A8EDFB5 
{
public:
	// System.Byte CodeStage.AdvancedFPSCounter.FPSLevel::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FPSLevel_t9C2930ABEBC10506FC5ED2E8847498EC2A8EDFB5, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// CodeStage.AdvancedFPSCounter.Labels.LabelAnchor
struct LabelAnchor_t4F1B2E5EA381DF7209A2F60570E1162A6CB51A5F 
{
public:
	// System.Byte CodeStage.AdvancedFPSCounter.Labels.LabelAnchor::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(LabelAnchor_t4F1B2E5EA381DF7209A2F60570E1162A6CB51A5F, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// CodeStage.AdvancedFPSCounter.Labels.LabelEffect
struct LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB  : public RuntimeObject
{
public:
	// System.Boolean CodeStage.AdvancedFPSCounter.Labels.LabelEffect::enabled
	bool ___enabled_0;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.Labels.LabelEffect::color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_1;
	// UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.Labels.LabelEffect::distance
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___distance_2;
	// System.Int32 CodeStage.AdvancedFPSCounter.Labels.LabelEffect::padding
	int32_t ___padding_3;

public:
	inline static int32_t get_offset_of_enabled_0() { return static_cast<int32_t>(offsetof(LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB, ___enabled_0)); }
	inline bool get_enabled_0() const { return ___enabled_0; }
	inline bool* get_address_of_enabled_0() { return &___enabled_0; }
	inline void set_enabled_0(bool value)
	{
		___enabled_0 = value;
	}

	inline static int32_t get_offset_of_color_1() { return static_cast<int32_t>(offsetof(LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB, ___color_1)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_color_1() const { return ___color_1; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_color_1() { return &___color_1; }
	inline void set_color_1(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___color_1 = value;
	}

	inline static int32_t get_offset_of_distance_2() { return static_cast<int32_t>(offsetof(LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB, ___distance_2)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_distance_2() const { return ___distance_2; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_distance_2() { return &___distance_2; }
	inline void set_distance_2(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___distance_2 = value;
	}

	inline static int32_t get_offset_of_padding_3() { return static_cast<int32_t>(offsetof(LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB, ___padding_3)); }
	inline int32_t get_padding_3() const { return ___padding_3; }
	inline int32_t* get_address_of_padding_3() { return &___padding_3; }
	inline void set_padding_3(int32_t value)
	{
		___padding_3 = value;
	}
};


// CodeStage.AdvancedFPSCounter.OperationMode
struct OperationMode_tFB98614BAF7F495E5139E58682A9FBD080F0B050 
{
public:
	// System.Byte CodeStage.AdvancedFPSCounter.OperationMode::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(OperationMode_tFB98614BAF7F495E5139E58682A9FBD080F0B050, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// Photon.Pun.RpcTarget
struct RpcTarget_tE30C1D8C1A41907B5F74531A47D12542724FD023 
{
public:
	// System.Int32 Photon.Pun.RpcTarget::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(RpcTarget_tE30C1D8C1A41907B5F74531A47D12542724FD023, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// Photon.Pun.UtilityScripts.OnClickInstantiate/InstantiateOption
struct InstantiateOption_t37A333580FB897EF03B46B8E7D42BAEFEF78167C 
{
public:
	// System.Int32 Photon.Pun.UtilityScripts.OnClickInstantiate/InstantiateOption::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InstantiateOption_t37A333580FB897EF03B46B8E7D42BAEFEF78167C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// Photon.Pun.UtilityScripts.OnClickRpc/<ClickFlash>d__8
struct U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A  : public RuntimeObject
{
public:
	// System.Int32 Photon.Pun.UtilityScripts.OnClickRpc/<ClickFlash>d__8::<>1__state
	int32_t ___U3CU3E1__state_0;
	// System.Object Photon.Pun.UtilityScripts.OnClickRpc/<ClickFlash>d__8::<>2__current
	RuntimeObject * ___U3CU3E2__current_1;
	// Photon.Pun.UtilityScripts.OnClickRpc Photon.Pun.UtilityScripts.OnClickRpc/<ClickFlash>d__8::<>4__this
	OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C * ___U3CU3E4__this_2;
	// System.Boolean Photon.Pun.UtilityScripts.OnClickRpc/<ClickFlash>d__8::<wasEmissive>5__1
	bool ___U3CwasEmissiveU3E5__1_3;
	// System.Single Photon.Pun.UtilityScripts.OnClickRpc/<ClickFlash>d__8::<f>5__2
	float ___U3CfU3E5__2_4;
	// UnityEngine.Color Photon.Pun.UtilityScripts.OnClickRpc/<ClickFlash>d__8::<lerped>5__3
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___U3ClerpedU3E5__3_5;

public:
	inline static int32_t get_offset_of_U3CU3E1__state_0() { return static_cast<int32_t>(offsetof(U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A, ___U3CU3E1__state_0)); }
	inline int32_t get_U3CU3E1__state_0() const { return ___U3CU3E1__state_0; }
	inline int32_t* get_address_of_U3CU3E1__state_0() { return &___U3CU3E1__state_0; }
	inline void set_U3CU3E1__state_0(int32_t value)
	{
		___U3CU3E1__state_0 = value;
	}

	inline static int32_t get_offset_of_U3CU3E2__current_1() { return static_cast<int32_t>(offsetof(U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A, ___U3CU3E2__current_1)); }
	inline RuntimeObject * get_U3CU3E2__current_1() const { return ___U3CU3E2__current_1; }
	inline RuntimeObject ** get_address_of_U3CU3E2__current_1() { return &___U3CU3E2__current_1; }
	inline void set_U3CU3E2__current_1(RuntimeObject * value)
	{
		___U3CU3E2__current_1 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E2__current_1), (void*)value);
	}

	inline static int32_t get_offset_of_U3CU3E4__this_2() { return static_cast<int32_t>(offsetof(U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A, ___U3CU3E4__this_2)); }
	inline OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C * get_U3CU3E4__this_2() const { return ___U3CU3E4__this_2; }
	inline OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C ** get_address_of_U3CU3E4__this_2() { return &___U3CU3E4__this_2; }
	inline void set_U3CU3E4__this_2(OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C * value)
	{
		___U3CU3E4__this_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CU3E4__this_2), (void*)value);
	}

	inline static int32_t get_offset_of_U3CwasEmissiveU3E5__1_3() { return static_cast<int32_t>(offsetof(U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A, ___U3CwasEmissiveU3E5__1_3)); }
	inline bool get_U3CwasEmissiveU3E5__1_3() const { return ___U3CwasEmissiveU3E5__1_3; }
	inline bool* get_address_of_U3CwasEmissiveU3E5__1_3() { return &___U3CwasEmissiveU3E5__1_3; }
	inline void set_U3CwasEmissiveU3E5__1_3(bool value)
	{
		___U3CwasEmissiveU3E5__1_3 = value;
	}

	inline static int32_t get_offset_of_U3CfU3E5__2_4() { return static_cast<int32_t>(offsetof(U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A, ___U3CfU3E5__2_4)); }
	inline float get_U3CfU3E5__2_4() const { return ___U3CfU3E5__2_4; }
	inline float* get_address_of_U3CfU3E5__2_4() { return &___U3CfU3E5__2_4; }
	inline void set_U3CfU3E5__2_4(float value)
	{
		___U3CfU3E5__2_4 = value;
	}

	inline static int32_t get_offset_of_U3ClerpedU3E5__3_5() { return static_cast<int32_t>(offsetof(U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A, ___U3ClerpedU3E5__3_5)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_U3ClerpedU3E5__3_5() const { return ___U3ClerpedU3E5__3_5; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_U3ClerpedU3E5__3_5() { return &___U3ClerpedU3E5__3_5; }
	inline void set_U3ClerpedU3E5__3_5(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___U3ClerpedU3E5__3_5 = value;
	}
};


// Photon.Pun.UtilityScripts.OnJoinedInstantiate/SpawnSequence
struct SpawnSequence_t2ADF043110FA61B097A72B2286F14F12FFCBB540 
{
public:
	// System.Int32 Photon.Pun.UtilityScripts.OnJoinedInstantiate/SpawnSequence::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(SpawnSequence_t2ADF043110FA61B097A72B2286F14F12FFCBB540, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// Photon.Pun.UtilityScripts.PunTeams/Team
struct Team_t4FA690D794BEFB3DC83AB67A6FDC920EAA9CDA5F 
{
public:
	// System.Byte Photon.Pun.UtilityScripts.PunTeams/Team::value__
	uint8_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(Team_t4FA690D794BEFB3DC83AB67A6FDC920EAA9CDA5F, ___value___2)); }
	inline uint8_t get_value___2() const { return ___value___2; }
	inline uint8_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(uint8_t value)
	{
		___value___2 = value;
	}
};


// Photon.Pun.UtilityScripts.TabViewManager/TabChangeEvent
struct TabChangeEvent_t0828873D6112CB183DE5B2EB5EB05DCDB7FFBD29  : public UnityEvent_1_t890F45761F13DD1B3D58738365827FDB6629BA7F
{
public:

public:
};


// System.Delegate
struct Delegate_t  : public RuntimeObject
{
public:
	// System.IntPtr System.Delegate::method_ptr
	Il2CppMethodPointer ___method_ptr_0;
	// System.IntPtr System.Delegate::invoke_impl
	intptr_t ___invoke_impl_1;
	// System.Object System.Delegate::m_target
	RuntimeObject * ___m_target_2;
	// System.IntPtr System.Delegate::method
	intptr_t ___method_3;
	// System.IntPtr System.Delegate::delegate_trampoline
	intptr_t ___delegate_trampoline_4;
	// System.IntPtr System.Delegate::extra_arg
	intptr_t ___extra_arg_5;
	// System.IntPtr System.Delegate::method_code
	intptr_t ___method_code_6;
	// System.Reflection.MethodInfo System.Delegate::method_info
	MethodInfo_t * ___method_info_7;
	// System.Reflection.MethodInfo System.Delegate::original_method_info
	MethodInfo_t * ___original_method_info_8;
	// System.DelegateData System.Delegate::data
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	// System.Boolean System.Delegate::method_is_virtual
	bool ___method_is_virtual_10;

public:
	inline static int32_t get_offset_of_method_ptr_0() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_ptr_0)); }
	inline Il2CppMethodPointer get_method_ptr_0() const { return ___method_ptr_0; }
	inline Il2CppMethodPointer* get_address_of_method_ptr_0() { return &___method_ptr_0; }
	inline void set_method_ptr_0(Il2CppMethodPointer value)
	{
		___method_ptr_0 = value;
	}

	inline static int32_t get_offset_of_invoke_impl_1() { return static_cast<int32_t>(offsetof(Delegate_t, ___invoke_impl_1)); }
	inline intptr_t get_invoke_impl_1() const { return ___invoke_impl_1; }
	inline intptr_t* get_address_of_invoke_impl_1() { return &___invoke_impl_1; }
	inline void set_invoke_impl_1(intptr_t value)
	{
		___invoke_impl_1 = value;
	}

	inline static int32_t get_offset_of_m_target_2() { return static_cast<int32_t>(offsetof(Delegate_t, ___m_target_2)); }
	inline RuntimeObject * get_m_target_2() const { return ___m_target_2; }
	inline RuntimeObject ** get_address_of_m_target_2() { return &___m_target_2; }
	inline void set_m_target_2(RuntimeObject * value)
	{
		___m_target_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_target_2), (void*)value);
	}

	inline static int32_t get_offset_of_method_3() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_3)); }
	inline intptr_t get_method_3() const { return ___method_3; }
	inline intptr_t* get_address_of_method_3() { return &___method_3; }
	inline void set_method_3(intptr_t value)
	{
		___method_3 = value;
	}

	inline static int32_t get_offset_of_delegate_trampoline_4() { return static_cast<int32_t>(offsetof(Delegate_t, ___delegate_trampoline_4)); }
	inline intptr_t get_delegate_trampoline_4() const { return ___delegate_trampoline_4; }
	inline intptr_t* get_address_of_delegate_trampoline_4() { return &___delegate_trampoline_4; }
	inline void set_delegate_trampoline_4(intptr_t value)
	{
		___delegate_trampoline_4 = value;
	}

	inline static int32_t get_offset_of_extra_arg_5() { return static_cast<int32_t>(offsetof(Delegate_t, ___extra_arg_5)); }
	inline intptr_t get_extra_arg_5() const { return ___extra_arg_5; }
	inline intptr_t* get_address_of_extra_arg_5() { return &___extra_arg_5; }
	inline void set_extra_arg_5(intptr_t value)
	{
		___extra_arg_5 = value;
	}

	inline static int32_t get_offset_of_method_code_6() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_code_6)); }
	inline intptr_t get_method_code_6() const { return ___method_code_6; }
	inline intptr_t* get_address_of_method_code_6() { return &___method_code_6; }
	inline void set_method_code_6(intptr_t value)
	{
		___method_code_6 = value;
	}

	inline static int32_t get_offset_of_method_info_7() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_info_7)); }
	inline MethodInfo_t * get_method_info_7() const { return ___method_info_7; }
	inline MethodInfo_t ** get_address_of_method_info_7() { return &___method_info_7; }
	inline void set_method_info_7(MethodInfo_t * value)
	{
		___method_info_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___method_info_7), (void*)value);
	}

	inline static int32_t get_offset_of_original_method_info_8() { return static_cast<int32_t>(offsetof(Delegate_t, ___original_method_info_8)); }
	inline MethodInfo_t * get_original_method_info_8() const { return ___original_method_info_8; }
	inline MethodInfo_t ** get_address_of_original_method_info_8() { return &___original_method_info_8; }
	inline void set_original_method_info_8(MethodInfo_t * value)
	{
		___original_method_info_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___original_method_info_8), (void*)value);
	}

	inline static int32_t get_offset_of_data_9() { return static_cast<int32_t>(offsetof(Delegate_t, ___data_9)); }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * get_data_9() const { return ___data_9; }
	inline DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE ** get_address_of_data_9() { return &___data_9; }
	inline void set_data_9(DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * value)
	{
		___data_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___data_9), (void*)value);
	}

	inline static int32_t get_offset_of_method_is_virtual_10() { return static_cast<int32_t>(offsetof(Delegate_t, ___method_is_virtual_10)); }
	inline bool get_method_is_virtual_10() const { return ___method_is_virtual_10; }
	inline bool* get_address_of_method_is_virtual_10() { return &___method_is_virtual_10; }
	inline void set_method_is_virtual_10(bool value)
	{
		___method_is_virtual_10 = value;
	}
};

// Native definition for P/Invoke marshalling of System.Delegate
struct Delegate_t_marshaled_pinvoke
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};
// Native definition for COM marshalling of System.Delegate
struct Delegate_t_marshaled_com
{
	intptr_t ___method_ptr_0;
	intptr_t ___invoke_impl_1;
	Il2CppIUnknown* ___m_target_2;
	intptr_t ___method_3;
	intptr_t ___delegate_trampoline_4;
	intptr_t ___extra_arg_5;
	intptr_t ___method_code_6;
	MethodInfo_t * ___method_info_7;
	MethodInfo_t * ___original_method_info_8;
	DelegateData_t1BF9F691B56DAE5F8C28C5E084FDE94F15F27BBE * ___data_9;
	int32_t ___method_is_virtual_10;
};

// TrailsFX.ColorSequence
struct ColorSequence_tDD72DDB4E444AC507C979EDB66B54CDC4F8127C0 
{
public:
	// System.Int32 TrailsFX.ColorSequence::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(ColorSequence_tDD72DDB4E444AC507C979EDB66B54CDC4F8127C0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// TrailsFX.PositionChangeRelative
struct PositionChangeRelative_t8CAD8FE50E488A3B20DB2B461B961B9CF82E4DAA 
{
public:
	// System.Int32 TrailsFX.PositionChangeRelative::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(PositionChangeRelative_t8CAD8FE50E488A3B20DB2B461B961B9CF82E4DAA, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// TrailsFX.TrailEffect/SnapshotTransform
struct SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C 
{
public:
	// UnityEngine.Matrix4x4 TrailsFX.TrailEffect/SnapshotTransform::matrix
	Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  ___matrix_0;
	// System.Single TrailsFX.TrailEffect/SnapshotTransform::time
	float ___time_1;
	// System.Int32 TrailsFX.TrailEffect/SnapshotTransform::meshIndex
	int32_t ___meshIndex_2;
	// UnityEngine.Color TrailsFX.TrailEffect/SnapshotTransform::color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_3;

public:
	inline static int32_t get_offset_of_matrix_0() { return static_cast<int32_t>(offsetof(SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C, ___matrix_0)); }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  get_matrix_0() const { return ___matrix_0; }
	inline Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA * get_address_of_matrix_0() { return &___matrix_0; }
	inline void set_matrix_0(Matrix4x4_t6BF60F70C9169DF14C9D2577672A44224B236ECA  value)
	{
		___matrix_0 = value;
	}

	inline static int32_t get_offset_of_time_1() { return static_cast<int32_t>(offsetof(SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C, ___time_1)); }
	inline float get_time_1() const { return ___time_1; }
	inline float* get_address_of_time_1() { return &___time_1; }
	inline void set_time_1(float value)
	{
		___time_1 = value;
	}

	inline static int32_t get_offset_of_meshIndex_2() { return static_cast<int32_t>(offsetof(SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C, ___meshIndex_2)); }
	inline int32_t get_meshIndex_2() const { return ___meshIndex_2; }
	inline int32_t* get_address_of_meshIndex_2() { return &___meshIndex_2; }
	inline void set_meshIndex_2(int32_t value)
	{
		___meshIndex_2 = value;
	}

	inline static int32_t get_offset_of_color_3() { return static_cast<int32_t>(offsetof(SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C, ___color_3)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_color_3() const { return ___color_3; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_color_3() { return &___color_3; }
	inline void set_color_3(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___color_3 = value;
	}
};


// TrailsFX.TrailStyle
struct TrailStyle_t1B607FC88EB81422CF2F6922B01A386B2197DD2D 
{
public:
	// System.Int32 TrailsFX.TrailStyle::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(TrailStyle_t1B607FC88EB81422CF2F6922B01A386B2197DD2D, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.EventSystems.PointerEventData/InputButton
struct InputButton_tCC7470F9FD2AFE525243394F0215B47D4BF86AB0 
{
public:
	// System.Int32 UnityEngine.EventSystems.PointerEventData/InputButton::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(InputButton_tCC7470F9FD2AFE525243394F0215B47D4BF86AB0, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.FontStyle
struct FontStyle_t273973EBB1F40C2381F6D60AB957149DE5720CF3 
{
public:
	// System.Int32 UnityEngine.FontStyle::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(FontStyle_t273973EBB1F40C2381F6D60AB957149DE5720CF3, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.KeyCode
struct KeyCode_tC93EA87C5A6901160B583ADFCD3EF6726570DC3C 
{
public:
	// System.Int32 UnityEngine.KeyCode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(KeyCode_tC93EA87C5A6901160B583ADFCD3EF6726570DC3C, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0  : public RuntimeObject
{
public:
	// System.IntPtr UnityEngine.Object::m_CachedPtr
	intptr_t ___m_CachedPtr_0;

public:
	inline static int32_t get_offset_of_m_CachedPtr_0() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0, ___m_CachedPtr_0)); }
	inline intptr_t get_m_CachedPtr_0() const { return ___m_CachedPtr_0; }
	inline intptr_t* get_address_of_m_CachedPtr_0() { return &___m_CachedPtr_0; }
	inline void set_m_CachedPtr_0(intptr_t value)
	{
		___m_CachedPtr_0 = value;
	}
};

struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields
{
public:
	// System.Int32 UnityEngine.Object::OffsetOfInstanceIDInCPlusPlusObject
	int32_t ___OffsetOfInstanceIDInCPlusPlusObject_1;

public:
	inline static int32_t get_offset_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return static_cast<int32_t>(offsetof(Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_StaticFields, ___OffsetOfInstanceIDInCPlusPlusObject_1)); }
	inline int32_t get_OffsetOfInstanceIDInCPlusPlusObject_1() const { return ___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline int32_t* get_address_of_OffsetOfInstanceIDInCPlusPlusObject_1() { return &___OffsetOfInstanceIDInCPlusPlusObject_1; }
	inline void set_OffsetOfInstanceIDInCPlusPlusObject_1(int32_t value)
	{
		___OffsetOfInstanceIDInCPlusPlusObject_1 = value;
	}
};

// Native definition for P/Invoke marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
	intptr_t ___m_CachedPtr_0;
};
// Native definition for COM marshalling of UnityEngine.Object
struct Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
	intptr_t ___m_CachedPtr_0;
};

// UnityEngine.Rendering.CullMode
struct CullMode_tB2EE0A4E3037D9632C62070AFCF12B64B7CD7D31 
{
public:
	// System.Int32 UnityEngine.Rendering.CullMode::value__
	int32_t ___value___2;

public:
	inline static int32_t get_offset_of_value___2() { return static_cast<int32_t>(offsetof(CullMode_tB2EE0A4E3037D9632C62070AFCF12B64B7CD7D31, ___value___2)); }
	inline int32_t get_value___2() const { return ___value___2; }
	inline int32_t* get_address_of_value___2() { return &___value___2; }
	inline void set_value___2(int32_t value)
	{
		___value___2 = value;
	}
};


// CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData
struct BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955  : public RuntimeObject
{
public:
	// System.Text.StringBuilder CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::text
	StringBuilder_t * ___text_4;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::dirty
	bool ___dirty_5;
	// CodeStage.AdvancedFPSCounter.AFPSCounter CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::main
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 * ___main_6;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::colorCached
	String_t* ___colorCached_7;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::inited
	bool ___inited_8;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::enabled
	bool ___enabled_9;
	// CodeStage.AdvancedFPSCounter.Labels.LabelAnchor CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::anchor
	uint8_t ___anchor_10;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_11;
	// UnityEngine.FontStyle CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::style
	int32_t ___style_12;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::extraText
	String_t* ___extraText_13;

public:
	inline static int32_t get_offset_of_text_4() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___text_4)); }
	inline StringBuilder_t * get_text_4() const { return ___text_4; }
	inline StringBuilder_t ** get_address_of_text_4() { return &___text_4; }
	inline void set_text_4(StringBuilder_t * value)
	{
		___text_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___text_4), (void*)value);
	}

	inline static int32_t get_offset_of_dirty_5() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___dirty_5)); }
	inline bool get_dirty_5() const { return ___dirty_5; }
	inline bool* get_address_of_dirty_5() { return &___dirty_5; }
	inline void set_dirty_5(bool value)
	{
		___dirty_5 = value;
	}

	inline static int32_t get_offset_of_main_6() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___main_6)); }
	inline AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 * get_main_6() const { return ___main_6; }
	inline AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 ** get_address_of_main_6() { return &___main_6; }
	inline void set_main_6(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 * value)
	{
		___main_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___main_6), (void*)value);
	}

	inline static int32_t get_offset_of_colorCached_7() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___colorCached_7)); }
	inline String_t* get_colorCached_7() const { return ___colorCached_7; }
	inline String_t** get_address_of_colorCached_7() { return &___colorCached_7; }
	inline void set_colorCached_7(String_t* value)
	{
		___colorCached_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCached_7), (void*)value);
	}

	inline static int32_t get_offset_of_inited_8() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___inited_8)); }
	inline bool get_inited_8() const { return ___inited_8; }
	inline bool* get_address_of_inited_8() { return &___inited_8; }
	inline void set_inited_8(bool value)
	{
		___inited_8 = value;
	}

	inline static int32_t get_offset_of_enabled_9() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___enabled_9)); }
	inline bool get_enabled_9() const { return ___enabled_9; }
	inline bool* get_address_of_enabled_9() { return &___enabled_9; }
	inline void set_enabled_9(bool value)
	{
		___enabled_9 = value;
	}

	inline static int32_t get_offset_of_anchor_10() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___anchor_10)); }
	inline uint8_t get_anchor_10() const { return ___anchor_10; }
	inline uint8_t* get_address_of_anchor_10() { return &___anchor_10; }
	inline void set_anchor_10(uint8_t value)
	{
		___anchor_10 = value;
	}

	inline static int32_t get_offset_of_color_11() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___color_11)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_color_11() const { return ___color_11; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_color_11() { return &___color_11; }
	inline void set_color_11(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___color_11 = value;
	}

	inline static int32_t get_offset_of_style_12() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___style_12)); }
	inline int32_t get_style_12() const { return ___style_12; }
	inline int32_t* get_address_of_style_12() { return &___style_12; }
	inline void set_style_12(int32_t value)
	{
		___style_12 = value;
	}

	inline static int32_t get_offset_of_extraText_13() { return static_cast<int32_t>(offsetof(BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955, ___extraText_13)); }
	inline String_t* get_extraText_13() const { return ___extraText_13; }
	inline String_t** get_address_of_extraText_13() { return &___extraText_13; }
	inline void set_extraText_13(String_t* value)
	{
		___extraText_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___extraText_13), (void*)value);
	}
};


// CodeStage.AdvancedFPSCounter.Labels.DrawableLabel
struct DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8  : public RuntimeObject
{
public:
	// UnityEngine.GameObject CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::container
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___container_0;
	// CodeStage.AdvancedFPSCounter.Labels.LabelAnchor CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::anchor
	uint8_t ___anchor_1;
	// System.Text.StringBuilder CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::newText
	StringBuilder_t * ___newText_2;
	// System.Boolean CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::dirty
	bool ___dirty_3;
	// UnityEngine.GameObject CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::labelGameObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___labelGameObject_4;
	// UnityEngine.RectTransform CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::labelTransform
	RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * ___labelTransform_5;
	// UnityEngine.UI.ContentSizeFitter CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::labelFitter
	ContentSizeFitter_t4EA7B51457F7EFAD3BAAC51613C7D4E0C26BF4A8 * ___labelFitter_6;
	// UnityEngine.UI.HorizontalLayoutGroup CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::labelGroup
	HorizontalLayoutGroup_tEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37 * ___labelGroup_7;
	// UnityEngine.GameObject CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::uiTextGameObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___uiTextGameObject_8;
	// UnityEngine.UI.Text CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::uiText
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___uiText_9;
	// UnityEngine.Font CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::font
	Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___font_10;
	// System.Int32 CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::fontSize
	int32_t ___fontSize_11;
	// System.Single CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::lineSpacing
	float ___lineSpacing_12;
	// UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::pixelOffset
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___pixelOffset_13;
	// CodeStage.AdvancedFPSCounter.Labels.LabelEffect CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::background
	LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * ___background_14;
	// UnityEngine.UI.Image CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::backgroundImage
	Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * ___backgroundImage_15;
	// CodeStage.AdvancedFPSCounter.Labels.LabelEffect CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::shadow
	LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * ___shadow_16;
	// UnityEngine.UI.Shadow CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::shadowComponent
	Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1 * ___shadowComponent_17;
	// CodeStage.AdvancedFPSCounter.Labels.LabelEffect CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::outline
	LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * ___outline_18;
	// UnityEngine.UI.Outline CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::outlineComponent
	Outline_tB750E496976B072E79142D51C0A991AC20183095 * ___outlineComponent_19;

public:
	inline static int32_t get_offset_of_container_0() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___container_0)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_container_0() const { return ___container_0; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_container_0() { return &___container_0; }
	inline void set_container_0(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___container_0 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___container_0), (void*)value);
	}

	inline static int32_t get_offset_of_anchor_1() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___anchor_1)); }
	inline uint8_t get_anchor_1() const { return ___anchor_1; }
	inline uint8_t* get_address_of_anchor_1() { return &___anchor_1; }
	inline void set_anchor_1(uint8_t value)
	{
		___anchor_1 = value;
	}

	inline static int32_t get_offset_of_newText_2() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___newText_2)); }
	inline StringBuilder_t * get_newText_2() const { return ___newText_2; }
	inline StringBuilder_t ** get_address_of_newText_2() { return &___newText_2; }
	inline void set_newText_2(StringBuilder_t * value)
	{
		___newText_2 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___newText_2), (void*)value);
	}

	inline static int32_t get_offset_of_dirty_3() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___dirty_3)); }
	inline bool get_dirty_3() const { return ___dirty_3; }
	inline bool* get_address_of_dirty_3() { return &___dirty_3; }
	inline void set_dirty_3(bool value)
	{
		___dirty_3 = value;
	}

	inline static int32_t get_offset_of_labelGameObject_4() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___labelGameObject_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_labelGameObject_4() const { return ___labelGameObject_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_labelGameObject_4() { return &___labelGameObject_4; }
	inline void set_labelGameObject_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___labelGameObject_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___labelGameObject_4), (void*)value);
	}

	inline static int32_t get_offset_of_labelTransform_5() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___labelTransform_5)); }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * get_labelTransform_5() const { return ___labelTransform_5; }
	inline RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 ** get_address_of_labelTransform_5() { return &___labelTransform_5; }
	inline void set_labelTransform_5(RectTransform_t285CBD8775B25174B75164F10618F8B9728E1B20 * value)
	{
		___labelTransform_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___labelTransform_5), (void*)value);
	}

	inline static int32_t get_offset_of_labelFitter_6() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___labelFitter_6)); }
	inline ContentSizeFitter_t4EA7B51457F7EFAD3BAAC51613C7D4E0C26BF4A8 * get_labelFitter_6() const { return ___labelFitter_6; }
	inline ContentSizeFitter_t4EA7B51457F7EFAD3BAAC51613C7D4E0C26BF4A8 ** get_address_of_labelFitter_6() { return &___labelFitter_6; }
	inline void set_labelFitter_6(ContentSizeFitter_t4EA7B51457F7EFAD3BAAC51613C7D4E0C26BF4A8 * value)
	{
		___labelFitter_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___labelFitter_6), (void*)value);
	}

	inline static int32_t get_offset_of_labelGroup_7() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___labelGroup_7)); }
	inline HorizontalLayoutGroup_tEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37 * get_labelGroup_7() const { return ___labelGroup_7; }
	inline HorizontalLayoutGroup_tEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37 ** get_address_of_labelGroup_7() { return &___labelGroup_7; }
	inline void set_labelGroup_7(HorizontalLayoutGroup_tEFAFA0DDCCE4FC89CC2C0BE96E7C025D243CFE37 * value)
	{
		___labelGroup_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___labelGroup_7), (void*)value);
	}

	inline static int32_t get_offset_of_uiTextGameObject_8() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___uiTextGameObject_8)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_uiTextGameObject_8() const { return ___uiTextGameObject_8; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_uiTextGameObject_8() { return &___uiTextGameObject_8; }
	inline void set_uiTextGameObject_8(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___uiTextGameObject_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___uiTextGameObject_8), (void*)value);
	}

	inline static int32_t get_offset_of_uiText_9() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___uiText_9)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_uiText_9() const { return ___uiText_9; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_uiText_9() { return &___uiText_9; }
	inline void set_uiText_9(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___uiText_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___uiText_9), (void*)value);
	}

	inline static int32_t get_offset_of_font_10() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___font_10)); }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * get_font_10() const { return ___font_10; }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 ** get_address_of_font_10() { return &___font_10; }
	inline void set_font_10(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * value)
	{
		___font_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___font_10), (void*)value);
	}

	inline static int32_t get_offset_of_fontSize_11() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___fontSize_11)); }
	inline int32_t get_fontSize_11() const { return ___fontSize_11; }
	inline int32_t* get_address_of_fontSize_11() { return &___fontSize_11; }
	inline void set_fontSize_11(int32_t value)
	{
		___fontSize_11 = value;
	}

	inline static int32_t get_offset_of_lineSpacing_12() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___lineSpacing_12)); }
	inline float get_lineSpacing_12() const { return ___lineSpacing_12; }
	inline float* get_address_of_lineSpacing_12() { return &___lineSpacing_12; }
	inline void set_lineSpacing_12(float value)
	{
		___lineSpacing_12 = value;
	}

	inline static int32_t get_offset_of_pixelOffset_13() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___pixelOffset_13)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_pixelOffset_13() const { return ___pixelOffset_13; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_pixelOffset_13() { return &___pixelOffset_13; }
	inline void set_pixelOffset_13(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___pixelOffset_13 = value;
	}

	inline static int32_t get_offset_of_background_14() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___background_14)); }
	inline LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * get_background_14() const { return ___background_14; }
	inline LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB ** get_address_of_background_14() { return &___background_14; }
	inline void set_background_14(LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * value)
	{
		___background_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___background_14), (void*)value);
	}

	inline static int32_t get_offset_of_backgroundImage_15() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___backgroundImage_15)); }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * get_backgroundImage_15() const { return ___backgroundImage_15; }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E ** get_address_of_backgroundImage_15() { return &___backgroundImage_15; }
	inline void set_backgroundImage_15(Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * value)
	{
		___backgroundImage_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___backgroundImage_15), (void*)value);
	}

	inline static int32_t get_offset_of_shadow_16() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___shadow_16)); }
	inline LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * get_shadow_16() const { return ___shadow_16; }
	inline LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB ** get_address_of_shadow_16() { return &___shadow_16; }
	inline void set_shadow_16(LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * value)
	{
		___shadow_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___shadow_16), (void*)value);
	}

	inline static int32_t get_offset_of_shadowComponent_17() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___shadowComponent_17)); }
	inline Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1 * get_shadowComponent_17() const { return ___shadowComponent_17; }
	inline Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1 ** get_address_of_shadowComponent_17() { return &___shadowComponent_17; }
	inline void set_shadowComponent_17(Shadow_tA03D2493843CDF8E64569F985AEB3FEEEEB412E1 * value)
	{
		___shadowComponent_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___shadowComponent_17), (void*)value);
	}

	inline static int32_t get_offset_of_outline_18() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___outline_18)); }
	inline LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * get_outline_18() const { return ___outline_18; }
	inline LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB ** get_address_of_outline_18() { return &___outline_18; }
	inline void set_outline_18(LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB * value)
	{
		___outline_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___outline_18), (void*)value);
	}

	inline static int32_t get_offset_of_outlineComponent_19() { return static_cast<int32_t>(offsetof(DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8, ___outlineComponent_19)); }
	inline Outline_tB750E496976B072E79142D51C0A991AC20183095 * get_outlineComponent_19() const { return ___outlineComponent_19; }
	inline Outline_tB750E496976B072E79142D51C0A991AC20183095 ** get_address_of_outlineComponent_19() { return &___outlineComponent_19; }
	inline void set_outlineComponent_19(Outline_tB750E496976B072E79142D51C0A991AC20183095 * value)
	{
		___outlineComponent_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___outlineComponent_19), (void*)value);
	}
};


// System.MulticastDelegate
struct MulticastDelegate_t  : public Delegate_t
{
public:
	// System.Delegate[] System.MulticastDelegate::delegates
	DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* ___delegates_11;

public:
	inline static int32_t get_offset_of_delegates_11() { return static_cast<int32_t>(offsetof(MulticastDelegate_t, ___delegates_11)); }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* get_delegates_11() const { return ___delegates_11; }
	inline DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86** get_address_of_delegates_11() { return &___delegates_11; }
	inline void set_delegates_11(DelegateU5BU5D_tDFCDEE2A6322F96C0FE49AF47E9ADB8C4B294E86* value)
	{
		___delegates_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___delegates_11), (void*)value);
	}
};

// Native definition for P/Invoke marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_pinvoke : public Delegate_t_marshaled_pinvoke
{
	Delegate_t_marshaled_pinvoke** ___delegates_11;
};
// Native definition for COM marshalling of System.MulticastDelegate
struct MulticastDelegate_t_marshaled_com : public Delegate_t_marshaled_com
{
	Delegate_t_marshaled_com** ___delegates_11;
};

// UnityEngine.Component
struct Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};


// UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734  : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0
{
public:

public:
};

// Native definition for P/Invoke marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_pinvoke : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_pinvoke
{
};
// Native definition for COM marshalling of UnityEngine.ScriptableObject
struct ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734_marshaled_com : public Object_tAE11E5E46CD5C37C9F3E8950C00CD8B45666A2D0_marshaled_com
{
};

// CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData
struct DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F  : public BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955
{
public:
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::platform
	bool ___platform_14;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::cpuModel
	bool ___cpuModel_15;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::cpuModelNewLine
	bool ___cpuModelNewLine_16;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::gpuModel
	bool ___gpuModel_17;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::gpuModelNewLine
	bool ___gpuModelNewLine_18;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::gpuApi
	bool ___gpuApi_19;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::gpuApiNewLine
	bool ___gpuApiNewLine_20;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::gpuSpec
	bool ___gpuSpec_21;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::gpuSpecNewLine
	bool ___gpuSpecNewLine_22;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::ramSize
	bool ___ramSize_23;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::ramSizeNewLine
	bool ___ramSizeNewLine_24;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::screenData
	bool ___screenData_25;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::screenDataNewLine
	bool ___screenDataNewLine_26;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::deviceModel
	bool ___deviceModel_27;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::deviceModelNewLine
	bool ___deviceModelNewLine_28;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::<LastValue>k__BackingField
	String_t* ___U3CLastValueU3Ek__BackingField_29;

public:
	inline static int32_t get_offset_of_platform_14() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___platform_14)); }
	inline bool get_platform_14() const { return ___platform_14; }
	inline bool* get_address_of_platform_14() { return &___platform_14; }
	inline void set_platform_14(bool value)
	{
		___platform_14 = value;
	}

	inline static int32_t get_offset_of_cpuModel_15() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___cpuModel_15)); }
	inline bool get_cpuModel_15() const { return ___cpuModel_15; }
	inline bool* get_address_of_cpuModel_15() { return &___cpuModel_15; }
	inline void set_cpuModel_15(bool value)
	{
		___cpuModel_15 = value;
	}

	inline static int32_t get_offset_of_cpuModelNewLine_16() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___cpuModelNewLine_16)); }
	inline bool get_cpuModelNewLine_16() const { return ___cpuModelNewLine_16; }
	inline bool* get_address_of_cpuModelNewLine_16() { return &___cpuModelNewLine_16; }
	inline void set_cpuModelNewLine_16(bool value)
	{
		___cpuModelNewLine_16 = value;
	}

	inline static int32_t get_offset_of_gpuModel_17() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___gpuModel_17)); }
	inline bool get_gpuModel_17() const { return ___gpuModel_17; }
	inline bool* get_address_of_gpuModel_17() { return &___gpuModel_17; }
	inline void set_gpuModel_17(bool value)
	{
		___gpuModel_17 = value;
	}

	inline static int32_t get_offset_of_gpuModelNewLine_18() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___gpuModelNewLine_18)); }
	inline bool get_gpuModelNewLine_18() const { return ___gpuModelNewLine_18; }
	inline bool* get_address_of_gpuModelNewLine_18() { return &___gpuModelNewLine_18; }
	inline void set_gpuModelNewLine_18(bool value)
	{
		___gpuModelNewLine_18 = value;
	}

	inline static int32_t get_offset_of_gpuApi_19() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___gpuApi_19)); }
	inline bool get_gpuApi_19() const { return ___gpuApi_19; }
	inline bool* get_address_of_gpuApi_19() { return &___gpuApi_19; }
	inline void set_gpuApi_19(bool value)
	{
		___gpuApi_19 = value;
	}

	inline static int32_t get_offset_of_gpuApiNewLine_20() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___gpuApiNewLine_20)); }
	inline bool get_gpuApiNewLine_20() const { return ___gpuApiNewLine_20; }
	inline bool* get_address_of_gpuApiNewLine_20() { return &___gpuApiNewLine_20; }
	inline void set_gpuApiNewLine_20(bool value)
	{
		___gpuApiNewLine_20 = value;
	}

	inline static int32_t get_offset_of_gpuSpec_21() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___gpuSpec_21)); }
	inline bool get_gpuSpec_21() const { return ___gpuSpec_21; }
	inline bool* get_address_of_gpuSpec_21() { return &___gpuSpec_21; }
	inline void set_gpuSpec_21(bool value)
	{
		___gpuSpec_21 = value;
	}

	inline static int32_t get_offset_of_gpuSpecNewLine_22() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___gpuSpecNewLine_22)); }
	inline bool get_gpuSpecNewLine_22() const { return ___gpuSpecNewLine_22; }
	inline bool* get_address_of_gpuSpecNewLine_22() { return &___gpuSpecNewLine_22; }
	inline void set_gpuSpecNewLine_22(bool value)
	{
		___gpuSpecNewLine_22 = value;
	}

	inline static int32_t get_offset_of_ramSize_23() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___ramSize_23)); }
	inline bool get_ramSize_23() const { return ___ramSize_23; }
	inline bool* get_address_of_ramSize_23() { return &___ramSize_23; }
	inline void set_ramSize_23(bool value)
	{
		___ramSize_23 = value;
	}

	inline static int32_t get_offset_of_ramSizeNewLine_24() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___ramSizeNewLine_24)); }
	inline bool get_ramSizeNewLine_24() const { return ___ramSizeNewLine_24; }
	inline bool* get_address_of_ramSizeNewLine_24() { return &___ramSizeNewLine_24; }
	inline void set_ramSizeNewLine_24(bool value)
	{
		___ramSizeNewLine_24 = value;
	}

	inline static int32_t get_offset_of_screenData_25() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___screenData_25)); }
	inline bool get_screenData_25() const { return ___screenData_25; }
	inline bool* get_address_of_screenData_25() { return &___screenData_25; }
	inline void set_screenData_25(bool value)
	{
		___screenData_25 = value;
	}

	inline static int32_t get_offset_of_screenDataNewLine_26() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___screenDataNewLine_26)); }
	inline bool get_screenDataNewLine_26() const { return ___screenDataNewLine_26; }
	inline bool* get_address_of_screenDataNewLine_26() { return &___screenDataNewLine_26; }
	inline void set_screenDataNewLine_26(bool value)
	{
		___screenDataNewLine_26 = value;
	}

	inline static int32_t get_offset_of_deviceModel_27() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___deviceModel_27)); }
	inline bool get_deviceModel_27() const { return ___deviceModel_27; }
	inline bool* get_address_of_deviceModel_27() { return &___deviceModel_27; }
	inline void set_deviceModel_27(bool value)
	{
		___deviceModel_27 = value;
	}

	inline static int32_t get_offset_of_deviceModelNewLine_28() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___deviceModelNewLine_28)); }
	inline bool get_deviceModelNewLine_28() const { return ___deviceModelNewLine_28; }
	inline bool* get_address_of_deviceModelNewLine_28() { return &___deviceModelNewLine_28; }
	inline void set_deviceModelNewLine_28(bool value)
	{
		___deviceModelNewLine_28 = value;
	}

	inline static int32_t get_offset_of_U3CLastValueU3Ek__BackingField_29() { return static_cast<int32_t>(offsetof(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F, ___U3CLastValueU3Ek__BackingField_29)); }
	inline String_t* get_U3CLastValueU3Ek__BackingField_29() const { return ___U3CLastValueU3Ek__BackingField_29; }
	inline String_t** get_address_of_U3CLastValueU3Ek__BackingField_29() { return &___U3CLastValueU3Ek__BackingField_29; }
	inline void set_U3CLastValueU3Ek__BackingField_29(String_t* value)
	{
		___U3CLastValueU3Ek__BackingField_29 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CLastValueU3Ek__BackingField_29), (void*)value);
	}
};


// CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData
struct UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E  : public BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955
{
public:
	// UnityEngine.Coroutine CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::updateCoroutine
	Coroutine_tAE7DB2FC70A0AE6477F896F852057CB0754F06EC * ___updateCoroutine_14;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::updateInterval
	float ___updateInterval_15;

public:
	inline static int32_t get_offset_of_updateCoroutine_14() { return static_cast<int32_t>(offsetof(UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E, ___updateCoroutine_14)); }
	inline Coroutine_tAE7DB2FC70A0AE6477F896F852057CB0754F06EC * get_updateCoroutine_14() const { return ___updateCoroutine_14; }
	inline Coroutine_tAE7DB2FC70A0AE6477F896F852057CB0754F06EC ** get_address_of_updateCoroutine_14() { return &___updateCoroutine_14; }
	inline void set_updateCoroutine_14(Coroutine_tAE7DB2FC70A0AE6477F896F852057CB0754F06EC * value)
	{
		___updateCoroutine_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___updateCoroutine_14), (void*)value);
	}

	inline static int32_t get_offset_of_updateInterval_15() { return static_cast<int32_t>(offsetof(UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E, ___updateInterval_15)); }
	inline float get_updateInterval_15() const { return ___updateInterval_15; }
	inline float* get_address_of_updateInterval_15() { return &___updateInterval_15; }
	inline void set_updateInterval_15(float value)
	{
		___updateInterval_15 = value;
	}
};


// ItemInfo
struct ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// System.String ItemInfo::itemName
	String_t* ___itemName_4;

public:
	inline static int32_t get_offset_of_itemName_4() { return static_cast<int32_t>(offsetof(ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974, ___itemName_4)); }
	inline String_t* get_itemName_4() const { return ___itemName_4; }
	inline String_t** get_address_of_itemName_4() { return &___itemName_4; }
	inline void set_itemName_4(String_t* value)
	{
		___itemName_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___itemName_4), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.CountdownTimer/CountdownTimerHasExpired
struct CountdownTimerHasExpired_t1DA56DAFE29F4443C6A912DC7911E75B3409E4C4  : public MulticastDelegate_t
{
public:

public:
};


// Photon.Pun.UtilityScripts.PlayerNumbering/PlayerNumberingChanged
struct PlayerNumberingChanged_tC8F930EF27ACA4ED253B2C3A489705780EF8DC10  : public MulticastDelegate_t
{
public:

public:
};


// TrailsFX.TrailEffectProfile
struct TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444  : public ScriptableObject_tAB015486CEAB714DA0D5C1BA389B84FB90427734
{
public:
	// TrailsFX.TrailEffectProfile TrailsFX.TrailEffectProfile::profile
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 * ___profile_4;
	// System.Boolean TrailsFX.TrailEffectProfile::active
	bool ___active_5;
	// System.Int32 TrailsFX.TrailEffectProfile::ignoreFrames
	int32_t ___ignoreFrames_6;
	// System.Single TrailsFX.TrailEffectProfile::duration
	float ___duration_7;
	// System.Boolean TrailsFX.TrailEffectProfile::continuous
	bool ___continuous_8;
	// System.Boolean TrailsFX.TrailEffectProfile::smooth
	bool ___smooth_9;
	// System.Boolean TrailsFX.TrailEffectProfile::checkWorldPosition
	bool ___checkWorldPosition_10;
	// System.Single TrailsFX.TrailEffectProfile::minDistance
	float ___minDistance_11;
	// TrailsFX.PositionChangeRelative TrailsFX.TrailEffectProfile::worldPositionRelativeOption
	int32_t ___worldPositionRelativeOption_12;
	// UnityEngine.Transform TrailsFX.TrailEffectProfile::worldPositionRelativeTransform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___worldPositionRelativeTransform_13;
	// System.Boolean TrailsFX.TrailEffectProfile::checkScreenPosition
	bool ___checkScreenPosition_14;
	// System.Int32 TrailsFX.TrailEffectProfile::minPixelDistance
	int32_t ___minPixelDistance_15;
	// System.Int32 TrailsFX.TrailEffectProfile::maxStepsPerFrame
	int32_t ___maxStepsPerFrame_16;
	// System.Boolean TrailsFX.TrailEffectProfile::checkTime
	bool ___checkTime_17;
	// System.Single TrailsFX.TrailEffectProfile::timeInterval
	float ___timeInterval_18;
	// System.Boolean TrailsFX.TrailEffectProfile::checkCollisions
	bool ___checkCollisions_19;
	// System.Boolean TrailsFX.TrailEffectProfile::orientToSurface
	bool ___orientToSurface_20;
	// System.Boolean TrailsFX.TrailEffectProfile::ground
	bool ___ground_21;
	// System.Single TrailsFX.TrailEffectProfile::surfaceOffset
	float ___surfaceOffset_22;
	// UnityEngine.LayerMask TrailsFX.TrailEffectProfile::collisionLayerMask
	LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  ___collisionLayerMask_23;
	// System.Boolean TrailsFX.TrailEffectProfile::drawBehind
	bool ___drawBehind_24;
	// System.Int32 TrailsFX.TrailEffectProfile::subMeshMask
	int32_t ___subMeshMask_25;
	// UnityEngine.Rendering.CullMode TrailsFX.TrailEffectProfile::cullMode
	int32_t ___cullMode_26;
	// UnityEngine.Gradient TrailsFX.TrailEffectProfile::colorOverTime
	Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * ___colorOverTime_27;
	// TrailsFX.ColorSequence TrailsFX.TrailEffectProfile::colorSequence
	int32_t ___colorSequence_28;
	// UnityEngine.Color TrailsFX.TrailEffectProfile::color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_29;
	// System.Single TrailsFX.TrailEffectProfile::colorCycleDuration
	float ___colorCycleDuration_30;
	// System.Single TrailsFX.TrailEffectProfile::pingPongSpeed
	float ___pingPongSpeed_31;
	// UnityEngine.Gradient TrailsFX.TrailEffectProfile::colorStartPalette
	Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * ___colorStartPalette_32;
	// UnityEngine.Camera TrailsFX.TrailEffectProfile::cam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___cam_33;
	// TrailsFX.TrailStyle TrailsFX.TrailEffectProfile::effect
	int32_t ___effect_34;
	// UnityEngine.Texture2D TrailsFX.TrailEffectProfile::texture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture_35;
	// UnityEngine.Vector3 TrailsFX.TrailEffectProfile::scale
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___scale_36;
	// UnityEngine.Vector3 TrailsFX.TrailEffectProfile::scaleStartRandomMin
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___scaleStartRandomMin_37;
	// UnityEngine.Vector3 TrailsFX.TrailEffectProfile::scaleStartRandomMax
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___scaleStartRandomMax_38;
	// UnityEngine.AnimationCurve TrailsFX.TrailEffectProfile::scaleOverTime
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___scaleOverTime_39;
	// System.Boolean TrailsFX.TrailEffectProfile::scaleUniform
	bool ___scaleUniform_40;
	// UnityEngine.Vector3 TrailsFX.TrailEffectProfile::localPositionRandomMin
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___localPositionRandomMin_41;
	// UnityEngine.Vector3 TrailsFX.TrailEffectProfile::localPositionRandomMax
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___localPositionRandomMax_42;
	// System.Single TrailsFX.TrailEffectProfile::laserBandWidth
	float ___laserBandWidth_43;
	// System.Single TrailsFX.TrailEffectProfile::laserIntensity
	float ___laserIntensity_44;
	// System.Single TrailsFX.TrailEffectProfile::laserFlash
	float ___laserFlash_45;
	// UnityEngine.Transform TrailsFX.TrailEffectProfile::lookTarget
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___lookTarget_46;
	// System.Boolean TrailsFX.TrailEffectProfile::lookToCamera
	bool ___lookToCamera_47;
	// System.Single TrailsFX.TrailEffectProfile::textureCutOff
	float ___textureCutOff_48;
	// System.Single TrailsFX.TrailEffectProfile::normalThreshold
	float ___normalThreshold_49;
	// System.Boolean TrailsFX.TrailEffectProfile::useLastAnimationState
	bool ___useLastAnimationState_50;
	// System.Int32 TrailsFX.TrailEffectProfile::maxBatches
	int32_t ___maxBatches_51;
	// System.Int32 TrailsFX.TrailEffectProfile::meshPoolSize
	int32_t ___meshPoolSize_52;
	// System.String TrailsFX.TrailEffectProfile::animationStates
	String_t* ___animationStates_53;

public:
	inline static int32_t get_offset_of_profile_4() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___profile_4)); }
	inline TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 * get_profile_4() const { return ___profile_4; }
	inline TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 ** get_address_of_profile_4() { return &___profile_4; }
	inline void set_profile_4(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 * value)
	{
		___profile_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___profile_4), (void*)value);
	}

	inline static int32_t get_offset_of_active_5() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___active_5)); }
	inline bool get_active_5() const { return ___active_5; }
	inline bool* get_address_of_active_5() { return &___active_5; }
	inline void set_active_5(bool value)
	{
		___active_5 = value;
	}

	inline static int32_t get_offset_of_ignoreFrames_6() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___ignoreFrames_6)); }
	inline int32_t get_ignoreFrames_6() const { return ___ignoreFrames_6; }
	inline int32_t* get_address_of_ignoreFrames_6() { return &___ignoreFrames_6; }
	inline void set_ignoreFrames_6(int32_t value)
	{
		___ignoreFrames_6 = value;
	}

	inline static int32_t get_offset_of_duration_7() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___duration_7)); }
	inline float get_duration_7() const { return ___duration_7; }
	inline float* get_address_of_duration_7() { return &___duration_7; }
	inline void set_duration_7(float value)
	{
		___duration_7 = value;
	}

	inline static int32_t get_offset_of_continuous_8() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___continuous_8)); }
	inline bool get_continuous_8() const { return ___continuous_8; }
	inline bool* get_address_of_continuous_8() { return &___continuous_8; }
	inline void set_continuous_8(bool value)
	{
		___continuous_8 = value;
	}

	inline static int32_t get_offset_of_smooth_9() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___smooth_9)); }
	inline bool get_smooth_9() const { return ___smooth_9; }
	inline bool* get_address_of_smooth_9() { return &___smooth_9; }
	inline void set_smooth_9(bool value)
	{
		___smooth_9 = value;
	}

	inline static int32_t get_offset_of_checkWorldPosition_10() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___checkWorldPosition_10)); }
	inline bool get_checkWorldPosition_10() const { return ___checkWorldPosition_10; }
	inline bool* get_address_of_checkWorldPosition_10() { return &___checkWorldPosition_10; }
	inline void set_checkWorldPosition_10(bool value)
	{
		___checkWorldPosition_10 = value;
	}

	inline static int32_t get_offset_of_minDistance_11() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___minDistance_11)); }
	inline float get_minDistance_11() const { return ___minDistance_11; }
	inline float* get_address_of_minDistance_11() { return &___minDistance_11; }
	inline void set_minDistance_11(float value)
	{
		___minDistance_11 = value;
	}

	inline static int32_t get_offset_of_worldPositionRelativeOption_12() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___worldPositionRelativeOption_12)); }
	inline int32_t get_worldPositionRelativeOption_12() const { return ___worldPositionRelativeOption_12; }
	inline int32_t* get_address_of_worldPositionRelativeOption_12() { return &___worldPositionRelativeOption_12; }
	inline void set_worldPositionRelativeOption_12(int32_t value)
	{
		___worldPositionRelativeOption_12 = value;
	}

	inline static int32_t get_offset_of_worldPositionRelativeTransform_13() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___worldPositionRelativeTransform_13)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_worldPositionRelativeTransform_13() const { return ___worldPositionRelativeTransform_13; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_worldPositionRelativeTransform_13() { return &___worldPositionRelativeTransform_13; }
	inline void set_worldPositionRelativeTransform_13(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___worldPositionRelativeTransform_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___worldPositionRelativeTransform_13), (void*)value);
	}

	inline static int32_t get_offset_of_checkScreenPosition_14() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___checkScreenPosition_14)); }
	inline bool get_checkScreenPosition_14() const { return ___checkScreenPosition_14; }
	inline bool* get_address_of_checkScreenPosition_14() { return &___checkScreenPosition_14; }
	inline void set_checkScreenPosition_14(bool value)
	{
		___checkScreenPosition_14 = value;
	}

	inline static int32_t get_offset_of_minPixelDistance_15() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___minPixelDistance_15)); }
	inline int32_t get_minPixelDistance_15() const { return ___minPixelDistance_15; }
	inline int32_t* get_address_of_minPixelDistance_15() { return &___minPixelDistance_15; }
	inline void set_minPixelDistance_15(int32_t value)
	{
		___minPixelDistance_15 = value;
	}

	inline static int32_t get_offset_of_maxStepsPerFrame_16() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___maxStepsPerFrame_16)); }
	inline int32_t get_maxStepsPerFrame_16() const { return ___maxStepsPerFrame_16; }
	inline int32_t* get_address_of_maxStepsPerFrame_16() { return &___maxStepsPerFrame_16; }
	inline void set_maxStepsPerFrame_16(int32_t value)
	{
		___maxStepsPerFrame_16 = value;
	}

	inline static int32_t get_offset_of_checkTime_17() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___checkTime_17)); }
	inline bool get_checkTime_17() const { return ___checkTime_17; }
	inline bool* get_address_of_checkTime_17() { return &___checkTime_17; }
	inline void set_checkTime_17(bool value)
	{
		___checkTime_17 = value;
	}

	inline static int32_t get_offset_of_timeInterval_18() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___timeInterval_18)); }
	inline float get_timeInterval_18() const { return ___timeInterval_18; }
	inline float* get_address_of_timeInterval_18() { return &___timeInterval_18; }
	inline void set_timeInterval_18(float value)
	{
		___timeInterval_18 = value;
	}

	inline static int32_t get_offset_of_checkCollisions_19() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___checkCollisions_19)); }
	inline bool get_checkCollisions_19() const { return ___checkCollisions_19; }
	inline bool* get_address_of_checkCollisions_19() { return &___checkCollisions_19; }
	inline void set_checkCollisions_19(bool value)
	{
		___checkCollisions_19 = value;
	}

	inline static int32_t get_offset_of_orientToSurface_20() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___orientToSurface_20)); }
	inline bool get_orientToSurface_20() const { return ___orientToSurface_20; }
	inline bool* get_address_of_orientToSurface_20() { return &___orientToSurface_20; }
	inline void set_orientToSurface_20(bool value)
	{
		___orientToSurface_20 = value;
	}

	inline static int32_t get_offset_of_ground_21() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___ground_21)); }
	inline bool get_ground_21() const { return ___ground_21; }
	inline bool* get_address_of_ground_21() { return &___ground_21; }
	inline void set_ground_21(bool value)
	{
		___ground_21 = value;
	}

	inline static int32_t get_offset_of_surfaceOffset_22() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___surfaceOffset_22)); }
	inline float get_surfaceOffset_22() const { return ___surfaceOffset_22; }
	inline float* get_address_of_surfaceOffset_22() { return &___surfaceOffset_22; }
	inline void set_surfaceOffset_22(float value)
	{
		___surfaceOffset_22 = value;
	}

	inline static int32_t get_offset_of_collisionLayerMask_23() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___collisionLayerMask_23)); }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  get_collisionLayerMask_23() const { return ___collisionLayerMask_23; }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0 * get_address_of_collisionLayerMask_23() { return &___collisionLayerMask_23; }
	inline void set_collisionLayerMask_23(LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  value)
	{
		___collisionLayerMask_23 = value;
	}

	inline static int32_t get_offset_of_drawBehind_24() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___drawBehind_24)); }
	inline bool get_drawBehind_24() const { return ___drawBehind_24; }
	inline bool* get_address_of_drawBehind_24() { return &___drawBehind_24; }
	inline void set_drawBehind_24(bool value)
	{
		___drawBehind_24 = value;
	}

	inline static int32_t get_offset_of_subMeshMask_25() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___subMeshMask_25)); }
	inline int32_t get_subMeshMask_25() const { return ___subMeshMask_25; }
	inline int32_t* get_address_of_subMeshMask_25() { return &___subMeshMask_25; }
	inline void set_subMeshMask_25(int32_t value)
	{
		___subMeshMask_25 = value;
	}

	inline static int32_t get_offset_of_cullMode_26() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___cullMode_26)); }
	inline int32_t get_cullMode_26() const { return ___cullMode_26; }
	inline int32_t* get_address_of_cullMode_26() { return &___cullMode_26; }
	inline void set_cullMode_26(int32_t value)
	{
		___cullMode_26 = value;
	}

	inline static int32_t get_offset_of_colorOverTime_27() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___colorOverTime_27)); }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * get_colorOverTime_27() const { return ___colorOverTime_27; }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A ** get_address_of_colorOverTime_27() { return &___colorOverTime_27; }
	inline void set_colorOverTime_27(Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * value)
	{
		___colorOverTime_27 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorOverTime_27), (void*)value);
	}

	inline static int32_t get_offset_of_colorSequence_28() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___colorSequence_28)); }
	inline int32_t get_colorSequence_28() const { return ___colorSequence_28; }
	inline int32_t* get_address_of_colorSequence_28() { return &___colorSequence_28; }
	inline void set_colorSequence_28(int32_t value)
	{
		___colorSequence_28 = value;
	}

	inline static int32_t get_offset_of_color_29() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___color_29)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_color_29() const { return ___color_29; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_color_29() { return &___color_29; }
	inline void set_color_29(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___color_29 = value;
	}

	inline static int32_t get_offset_of_colorCycleDuration_30() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___colorCycleDuration_30)); }
	inline float get_colorCycleDuration_30() const { return ___colorCycleDuration_30; }
	inline float* get_address_of_colorCycleDuration_30() { return &___colorCycleDuration_30; }
	inline void set_colorCycleDuration_30(float value)
	{
		___colorCycleDuration_30 = value;
	}

	inline static int32_t get_offset_of_pingPongSpeed_31() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___pingPongSpeed_31)); }
	inline float get_pingPongSpeed_31() const { return ___pingPongSpeed_31; }
	inline float* get_address_of_pingPongSpeed_31() { return &___pingPongSpeed_31; }
	inline void set_pingPongSpeed_31(float value)
	{
		___pingPongSpeed_31 = value;
	}

	inline static int32_t get_offset_of_colorStartPalette_32() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___colorStartPalette_32)); }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * get_colorStartPalette_32() const { return ___colorStartPalette_32; }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A ** get_address_of_colorStartPalette_32() { return &___colorStartPalette_32; }
	inline void set_colorStartPalette_32(Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * value)
	{
		___colorStartPalette_32 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorStartPalette_32), (void*)value);
	}

	inline static int32_t get_offset_of_cam_33() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___cam_33)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_cam_33() const { return ___cam_33; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_cam_33() { return &___cam_33; }
	inline void set_cam_33(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___cam_33 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cam_33), (void*)value);
	}

	inline static int32_t get_offset_of_effect_34() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___effect_34)); }
	inline int32_t get_effect_34() const { return ___effect_34; }
	inline int32_t* get_address_of_effect_34() { return &___effect_34; }
	inline void set_effect_34(int32_t value)
	{
		___effect_34 = value;
	}

	inline static int32_t get_offset_of_texture_35() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___texture_35)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_texture_35() const { return ___texture_35; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_texture_35() { return &___texture_35; }
	inline void set_texture_35(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___texture_35 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___texture_35), (void*)value);
	}

	inline static int32_t get_offset_of_scale_36() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___scale_36)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_scale_36() const { return ___scale_36; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_scale_36() { return &___scale_36; }
	inline void set_scale_36(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___scale_36 = value;
	}

	inline static int32_t get_offset_of_scaleStartRandomMin_37() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___scaleStartRandomMin_37)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_scaleStartRandomMin_37() const { return ___scaleStartRandomMin_37; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_scaleStartRandomMin_37() { return &___scaleStartRandomMin_37; }
	inline void set_scaleStartRandomMin_37(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___scaleStartRandomMin_37 = value;
	}

	inline static int32_t get_offset_of_scaleStartRandomMax_38() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___scaleStartRandomMax_38)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_scaleStartRandomMax_38() const { return ___scaleStartRandomMax_38; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_scaleStartRandomMax_38() { return &___scaleStartRandomMax_38; }
	inline void set_scaleStartRandomMax_38(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___scaleStartRandomMax_38 = value;
	}

	inline static int32_t get_offset_of_scaleOverTime_39() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___scaleOverTime_39)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_scaleOverTime_39() const { return ___scaleOverTime_39; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_scaleOverTime_39() { return &___scaleOverTime_39; }
	inline void set_scaleOverTime_39(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___scaleOverTime_39 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___scaleOverTime_39), (void*)value);
	}

	inline static int32_t get_offset_of_scaleUniform_40() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___scaleUniform_40)); }
	inline bool get_scaleUniform_40() const { return ___scaleUniform_40; }
	inline bool* get_address_of_scaleUniform_40() { return &___scaleUniform_40; }
	inline void set_scaleUniform_40(bool value)
	{
		___scaleUniform_40 = value;
	}

	inline static int32_t get_offset_of_localPositionRandomMin_41() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___localPositionRandomMin_41)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_localPositionRandomMin_41() const { return ___localPositionRandomMin_41; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_localPositionRandomMin_41() { return &___localPositionRandomMin_41; }
	inline void set_localPositionRandomMin_41(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___localPositionRandomMin_41 = value;
	}

	inline static int32_t get_offset_of_localPositionRandomMax_42() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___localPositionRandomMax_42)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_localPositionRandomMax_42() const { return ___localPositionRandomMax_42; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_localPositionRandomMax_42() { return &___localPositionRandomMax_42; }
	inline void set_localPositionRandomMax_42(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___localPositionRandomMax_42 = value;
	}

	inline static int32_t get_offset_of_laserBandWidth_43() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___laserBandWidth_43)); }
	inline float get_laserBandWidth_43() const { return ___laserBandWidth_43; }
	inline float* get_address_of_laserBandWidth_43() { return &___laserBandWidth_43; }
	inline void set_laserBandWidth_43(float value)
	{
		___laserBandWidth_43 = value;
	}

	inline static int32_t get_offset_of_laserIntensity_44() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___laserIntensity_44)); }
	inline float get_laserIntensity_44() const { return ___laserIntensity_44; }
	inline float* get_address_of_laserIntensity_44() { return &___laserIntensity_44; }
	inline void set_laserIntensity_44(float value)
	{
		___laserIntensity_44 = value;
	}

	inline static int32_t get_offset_of_laserFlash_45() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___laserFlash_45)); }
	inline float get_laserFlash_45() const { return ___laserFlash_45; }
	inline float* get_address_of_laserFlash_45() { return &___laserFlash_45; }
	inline void set_laserFlash_45(float value)
	{
		___laserFlash_45 = value;
	}

	inline static int32_t get_offset_of_lookTarget_46() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___lookTarget_46)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_lookTarget_46() const { return ___lookTarget_46; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_lookTarget_46() { return &___lookTarget_46; }
	inline void set_lookTarget_46(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___lookTarget_46 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___lookTarget_46), (void*)value);
	}

	inline static int32_t get_offset_of_lookToCamera_47() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___lookToCamera_47)); }
	inline bool get_lookToCamera_47() const { return ___lookToCamera_47; }
	inline bool* get_address_of_lookToCamera_47() { return &___lookToCamera_47; }
	inline void set_lookToCamera_47(bool value)
	{
		___lookToCamera_47 = value;
	}

	inline static int32_t get_offset_of_textureCutOff_48() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___textureCutOff_48)); }
	inline float get_textureCutOff_48() const { return ___textureCutOff_48; }
	inline float* get_address_of_textureCutOff_48() { return &___textureCutOff_48; }
	inline void set_textureCutOff_48(float value)
	{
		___textureCutOff_48 = value;
	}

	inline static int32_t get_offset_of_normalThreshold_49() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___normalThreshold_49)); }
	inline float get_normalThreshold_49() const { return ___normalThreshold_49; }
	inline float* get_address_of_normalThreshold_49() { return &___normalThreshold_49; }
	inline void set_normalThreshold_49(float value)
	{
		___normalThreshold_49 = value;
	}

	inline static int32_t get_offset_of_useLastAnimationState_50() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___useLastAnimationState_50)); }
	inline bool get_useLastAnimationState_50() const { return ___useLastAnimationState_50; }
	inline bool* get_address_of_useLastAnimationState_50() { return &___useLastAnimationState_50; }
	inline void set_useLastAnimationState_50(bool value)
	{
		___useLastAnimationState_50 = value;
	}

	inline static int32_t get_offset_of_maxBatches_51() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___maxBatches_51)); }
	inline int32_t get_maxBatches_51() const { return ___maxBatches_51; }
	inline int32_t* get_address_of_maxBatches_51() { return &___maxBatches_51; }
	inline void set_maxBatches_51(int32_t value)
	{
		___maxBatches_51 = value;
	}

	inline static int32_t get_offset_of_meshPoolSize_52() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___meshPoolSize_52)); }
	inline int32_t get_meshPoolSize_52() const { return ___meshPoolSize_52; }
	inline int32_t* get_address_of_meshPoolSize_52() { return &___meshPoolSize_52; }
	inline void set_meshPoolSize_52(int32_t value)
	{
		___meshPoolSize_52 = value;
	}

	inline static int32_t get_offset_of_animationStates_53() { return static_cast<int32_t>(offsetof(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444, ___animationStates_53)); }
	inline String_t* get_animationStates_53() const { return ___animationStates_53; }
	inline String_t** get_address_of_animationStates_53() { return &___animationStates_53; }
	inline void set_animationStates_53(String_t* value)
	{
		___animationStates_53 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___animationStates_53), (void*)value);
	}
};


// UnityEngine.Behaviour
struct Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8  : public Component_t05064EF382ABCAF4B8C94F8A350EA85184C26621
{
public:

public:
};


// CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData
struct FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD  : public UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E
{
public:
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::warningLevelValue
	int32_t ___warningLevelValue_25;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::criticalLevelValue
	int32_t ___criticalLevelValue_26;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::resetAverageOnNewScene
	bool ___resetAverageOnNewScene_27;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::resetMinMaxOnNewScene
	bool ___resetMinMaxOnNewScene_28;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::minMaxIntervalsToSkip
	int32_t ___minMaxIntervalsToSkip_29;
	// System.Action`1<CodeStage.AdvancedFPSCounter.FPSLevel> CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::OnFPSLevelChange
	Action_1_tCF64480193CD47098768F77D8A792F66EE6921AC * ___OnFPSLevelChange_30;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::newValue
	float ___newValue_31;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCachedMs
	String_t* ___colorCachedMs_32;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCachedMin
	String_t* ___colorCachedMin_33;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCachedMax
	String_t* ___colorCachedMax_34;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCachedAvg
	String_t* ___colorCachedAvg_35;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCachedRender
	String_t* ___colorCachedRender_36;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorWarningCached
	String_t* ___colorWarningCached_37;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorWarningCachedMs
	String_t* ___colorWarningCachedMs_38;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorWarningCachedMin
	String_t* ___colorWarningCachedMin_39;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorWarningCachedMax
	String_t* ___colorWarningCachedMax_40;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorWarningCachedAvg
	String_t* ___colorWarningCachedAvg_41;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCriticalCached
	String_t* ___colorCriticalCached_42;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCriticalCachedMs
	String_t* ___colorCriticalCachedMs_43;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCriticalCachedMin
	String_t* ___colorCriticalCachedMin_44;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCriticalCachedMax
	String_t* ___colorCriticalCachedMax_45;
	// System.String CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCriticalCachedAvg
	String_t* ___colorCriticalCachedAvg_46;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::currentAverageSamples
	int32_t ___currentAverageSamples_47;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::currentAverageRaw
	float ___currentAverageRaw_48;
	// System.Single[] CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::accumulatedAverageSamples
	SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* ___accumulatedAverageSamples_49;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::minMaxIntervalsSkipped
	int32_t ___minMaxIntervalsSkipped_50;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::renderTimeBank
	float ___renderTimeBank_51;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::previousFrameCount
	int32_t ___previousFrameCount_52;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::realtimeFPS
	bool ___realtimeFPS_53;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::milliseconds
	bool ___milliseconds_54;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::average
	bool ___average_55;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::averageMilliseconds
	bool ___averageMilliseconds_56;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::averageNewLine
	bool ___averageNewLine_57;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::averageSamples
	int32_t ___averageSamples_58;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::minMax
	bool ___minMax_59;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::minMaxMilliseconds
	bool ___minMaxMilliseconds_60;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::minMaxNewLine
	bool ___minMaxNewLine_61;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::minMaxTwoLines
	bool ___minMaxTwoLines_62;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::render
	bool ___render_63;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::renderNewLine
	bool ___renderNewLine_64;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::renderAutoAdd
	bool ___renderAutoAdd_65;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorWarning
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___colorWarning_66;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorCritical
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___colorCritical_67;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::colorRender
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___colorRender_68;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastValue>k__BackingField
	int32_t ___U3CLastValueU3Ek__BackingField_69;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastMillisecondsValue>k__BackingField
	float ___U3CLastMillisecondsValueU3Ek__BackingField_70;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastRenderValue>k__BackingField
	float ___U3CLastRenderValueU3Ek__BackingField_71;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastAverageValue>k__BackingField
	int32_t ___U3CLastAverageValueU3Ek__BackingField_72;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastAverageMillisecondsValue>k__BackingField
	float ___U3CLastAverageMillisecondsValueU3Ek__BackingField_73;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastMinimumValue>k__BackingField
	int32_t ___U3CLastMinimumValueU3Ek__BackingField_74;
	// System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastMaximumValue>k__BackingField
	int32_t ___U3CLastMaximumValueU3Ek__BackingField_75;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastMinMillisecondsValue>k__BackingField
	float ___U3CLastMinMillisecondsValueU3Ek__BackingField_76;
	// System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<LastMaxMillisecondsValue>k__BackingField
	float ___U3CLastMaxMillisecondsValueU3Ek__BackingField_77;
	// CodeStage.AdvancedFPSCounter.FPSLevel CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::<CurrentFpsLevel>k__BackingField
	uint8_t ___U3CCurrentFpsLevelU3Ek__BackingField_78;

public:
	inline static int32_t get_offset_of_warningLevelValue_25() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___warningLevelValue_25)); }
	inline int32_t get_warningLevelValue_25() const { return ___warningLevelValue_25; }
	inline int32_t* get_address_of_warningLevelValue_25() { return &___warningLevelValue_25; }
	inline void set_warningLevelValue_25(int32_t value)
	{
		___warningLevelValue_25 = value;
	}

	inline static int32_t get_offset_of_criticalLevelValue_26() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___criticalLevelValue_26)); }
	inline int32_t get_criticalLevelValue_26() const { return ___criticalLevelValue_26; }
	inline int32_t* get_address_of_criticalLevelValue_26() { return &___criticalLevelValue_26; }
	inline void set_criticalLevelValue_26(int32_t value)
	{
		___criticalLevelValue_26 = value;
	}

	inline static int32_t get_offset_of_resetAverageOnNewScene_27() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___resetAverageOnNewScene_27)); }
	inline bool get_resetAverageOnNewScene_27() const { return ___resetAverageOnNewScene_27; }
	inline bool* get_address_of_resetAverageOnNewScene_27() { return &___resetAverageOnNewScene_27; }
	inline void set_resetAverageOnNewScene_27(bool value)
	{
		___resetAverageOnNewScene_27 = value;
	}

	inline static int32_t get_offset_of_resetMinMaxOnNewScene_28() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___resetMinMaxOnNewScene_28)); }
	inline bool get_resetMinMaxOnNewScene_28() const { return ___resetMinMaxOnNewScene_28; }
	inline bool* get_address_of_resetMinMaxOnNewScene_28() { return &___resetMinMaxOnNewScene_28; }
	inline void set_resetMinMaxOnNewScene_28(bool value)
	{
		___resetMinMaxOnNewScene_28 = value;
	}

	inline static int32_t get_offset_of_minMaxIntervalsToSkip_29() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___minMaxIntervalsToSkip_29)); }
	inline int32_t get_minMaxIntervalsToSkip_29() const { return ___minMaxIntervalsToSkip_29; }
	inline int32_t* get_address_of_minMaxIntervalsToSkip_29() { return &___minMaxIntervalsToSkip_29; }
	inline void set_minMaxIntervalsToSkip_29(int32_t value)
	{
		___minMaxIntervalsToSkip_29 = value;
	}

	inline static int32_t get_offset_of_OnFPSLevelChange_30() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___OnFPSLevelChange_30)); }
	inline Action_1_tCF64480193CD47098768F77D8A792F66EE6921AC * get_OnFPSLevelChange_30() const { return ___OnFPSLevelChange_30; }
	inline Action_1_tCF64480193CD47098768F77D8A792F66EE6921AC ** get_address_of_OnFPSLevelChange_30() { return &___OnFPSLevelChange_30; }
	inline void set_OnFPSLevelChange_30(Action_1_tCF64480193CD47098768F77D8A792F66EE6921AC * value)
	{
		___OnFPSLevelChange_30 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OnFPSLevelChange_30), (void*)value);
	}

	inline static int32_t get_offset_of_newValue_31() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___newValue_31)); }
	inline float get_newValue_31() const { return ___newValue_31; }
	inline float* get_address_of_newValue_31() { return &___newValue_31; }
	inline void set_newValue_31(float value)
	{
		___newValue_31 = value;
	}

	inline static int32_t get_offset_of_colorCachedMs_32() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCachedMs_32)); }
	inline String_t* get_colorCachedMs_32() const { return ___colorCachedMs_32; }
	inline String_t** get_address_of_colorCachedMs_32() { return &___colorCachedMs_32; }
	inline void set_colorCachedMs_32(String_t* value)
	{
		___colorCachedMs_32 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCachedMs_32), (void*)value);
	}

	inline static int32_t get_offset_of_colorCachedMin_33() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCachedMin_33)); }
	inline String_t* get_colorCachedMin_33() const { return ___colorCachedMin_33; }
	inline String_t** get_address_of_colorCachedMin_33() { return &___colorCachedMin_33; }
	inline void set_colorCachedMin_33(String_t* value)
	{
		___colorCachedMin_33 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCachedMin_33), (void*)value);
	}

	inline static int32_t get_offset_of_colorCachedMax_34() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCachedMax_34)); }
	inline String_t* get_colorCachedMax_34() const { return ___colorCachedMax_34; }
	inline String_t** get_address_of_colorCachedMax_34() { return &___colorCachedMax_34; }
	inline void set_colorCachedMax_34(String_t* value)
	{
		___colorCachedMax_34 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCachedMax_34), (void*)value);
	}

	inline static int32_t get_offset_of_colorCachedAvg_35() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCachedAvg_35)); }
	inline String_t* get_colorCachedAvg_35() const { return ___colorCachedAvg_35; }
	inline String_t** get_address_of_colorCachedAvg_35() { return &___colorCachedAvg_35; }
	inline void set_colorCachedAvg_35(String_t* value)
	{
		___colorCachedAvg_35 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCachedAvg_35), (void*)value);
	}

	inline static int32_t get_offset_of_colorCachedRender_36() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCachedRender_36)); }
	inline String_t* get_colorCachedRender_36() const { return ___colorCachedRender_36; }
	inline String_t** get_address_of_colorCachedRender_36() { return &___colorCachedRender_36; }
	inline void set_colorCachedRender_36(String_t* value)
	{
		___colorCachedRender_36 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCachedRender_36), (void*)value);
	}

	inline static int32_t get_offset_of_colorWarningCached_37() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorWarningCached_37)); }
	inline String_t* get_colorWarningCached_37() const { return ___colorWarningCached_37; }
	inline String_t** get_address_of_colorWarningCached_37() { return &___colorWarningCached_37; }
	inline void set_colorWarningCached_37(String_t* value)
	{
		___colorWarningCached_37 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorWarningCached_37), (void*)value);
	}

	inline static int32_t get_offset_of_colorWarningCachedMs_38() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorWarningCachedMs_38)); }
	inline String_t* get_colorWarningCachedMs_38() const { return ___colorWarningCachedMs_38; }
	inline String_t** get_address_of_colorWarningCachedMs_38() { return &___colorWarningCachedMs_38; }
	inline void set_colorWarningCachedMs_38(String_t* value)
	{
		___colorWarningCachedMs_38 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorWarningCachedMs_38), (void*)value);
	}

	inline static int32_t get_offset_of_colorWarningCachedMin_39() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorWarningCachedMin_39)); }
	inline String_t* get_colorWarningCachedMin_39() const { return ___colorWarningCachedMin_39; }
	inline String_t** get_address_of_colorWarningCachedMin_39() { return &___colorWarningCachedMin_39; }
	inline void set_colorWarningCachedMin_39(String_t* value)
	{
		___colorWarningCachedMin_39 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorWarningCachedMin_39), (void*)value);
	}

	inline static int32_t get_offset_of_colorWarningCachedMax_40() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorWarningCachedMax_40)); }
	inline String_t* get_colorWarningCachedMax_40() const { return ___colorWarningCachedMax_40; }
	inline String_t** get_address_of_colorWarningCachedMax_40() { return &___colorWarningCachedMax_40; }
	inline void set_colorWarningCachedMax_40(String_t* value)
	{
		___colorWarningCachedMax_40 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorWarningCachedMax_40), (void*)value);
	}

	inline static int32_t get_offset_of_colorWarningCachedAvg_41() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorWarningCachedAvg_41)); }
	inline String_t* get_colorWarningCachedAvg_41() const { return ___colorWarningCachedAvg_41; }
	inline String_t** get_address_of_colorWarningCachedAvg_41() { return &___colorWarningCachedAvg_41; }
	inline void set_colorWarningCachedAvg_41(String_t* value)
	{
		___colorWarningCachedAvg_41 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorWarningCachedAvg_41), (void*)value);
	}

	inline static int32_t get_offset_of_colorCriticalCached_42() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCriticalCached_42)); }
	inline String_t* get_colorCriticalCached_42() const { return ___colorCriticalCached_42; }
	inline String_t** get_address_of_colorCriticalCached_42() { return &___colorCriticalCached_42; }
	inline void set_colorCriticalCached_42(String_t* value)
	{
		___colorCriticalCached_42 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCriticalCached_42), (void*)value);
	}

	inline static int32_t get_offset_of_colorCriticalCachedMs_43() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCriticalCachedMs_43)); }
	inline String_t* get_colorCriticalCachedMs_43() const { return ___colorCriticalCachedMs_43; }
	inline String_t** get_address_of_colorCriticalCachedMs_43() { return &___colorCriticalCachedMs_43; }
	inline void set_colorCriticalCachedMs_43(String_t* value)
	{
		___colorCriticalCachedMs_43 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCriticalCachedMs_43), (void*)value);
	}

	inline static int32_t get_offset_of_colorCriticalCachedMin_44() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCriticalCachedMin_44)); }
	inline String_t* get_colorCriticalCachedMin_44() const { return ___colorCriticalCachedMin_44; }
	inline String_t** get_address_of_colorCriticalCachedMin_44() { return &___colorCriticalCachedMin_44; }
	inline void set_colorCriticalCachedMin_44(String_t* value)
	{
		___colorCriticalCachedMin_44 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCriticalCachedMin_44), (void*)value);
	}

	inline static int32_t get_offset_of_colorCriticalCachedMax_45() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCriticalCachedMax_45)); }
	inline String_t* get_colorCriticalCachedMax_45() const { return ___colorCriticalCachedMax_45; }
	inline String_t** get_address_of_colorCriticalCachedMax_45() { return &___colorCriticalCachedMax_45; }
	inline void set_colorCriticalCachedMax_45(String_t* value)
	{
		___colorCriticalCachedMax_45 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCriticalCachedMax_45), (void*)value);
	}

	inline static int32_t get_offset_of_colorCriticalCachedAvg_46() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCriticalCachedAvg_46)); }
	inline String_t* get_colorCriticalCachedAvg_46() const { return ___colorCriticalCachedAvg_46; }
	inline String_t** get_address_of_colorCriticalCachedAvg_46() { return &___colorCriticalCachedAvg_46; }
	inline void set_colorCriticalCachedAvg_46(String_t* value)
	{
		___colorCriticalCachedAvg_46 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorCriticalCachedAvg_46), (void*)value);
	}

	inline static int32_t get_offset_of_currentAverageSamples_47() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___currentAverageSamples_47)); }
	inline int32_t get_currentAverageSamples_47() const { return ___currentAverageSamples_47; }
	inline int32_t* get_address_of_currentAverageSamples_47() { return &___currentAverageSamples_47; }
	inline void set_currentAverageSamples_47(int32_t value)
	{
		___currentAverageSamples_47 = value;
	}

	inline static int32_t get_offset_of_currentAverageRaw_48() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___currentAverageRaw_48)); }
	inline float get_currentAverageRaw_48() const { return ___currentAverageRaw_48; }
	inline float* get_address_of_currentAverageRaw_48() { return &___currentAverageRaw_48; }
	inline void set_currentAverageRaw_48(float value)
	{
		___currentAverageRaw_48 = value;
	}

	inline static int32_t get_offset_of_accumulatedAverageSamples_49() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___accumulatedAverageSamples_49)); }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* get_accumulatedAverageSamples_49() const { return ___accumulatedAverageSamples_49; }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5** get_address_of_accumulatedAverageSamples_49() { return &___accumulatedAverageSamples_49; }
	inline void set_accumulatedAverageSamples_49(SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* value)
	{
		___accumulatedAverageSamples_49 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___accumulatedAverageSamples_49), (void*)value);
	}

	inline static int32_t get_offset_of_minMaxIntervalsSkipped_50() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___minMaxIntervalsSkipped_50)); }
	inline int32_t get_minMaxIntervalsSkipped_50() const { return ___minMaxIntervalsSkipped_50; }
	inline int32_t* get_address_of_minMaxIntervalsSkipped_50() { return &___minMaxIntervalsSkipped_50; }
	inline void set_minMaxIntervalsSkipped_50(int32_t value)
	{
		___minMaxIntervalsSkipped_50 = value;
	}

	inline static int32_t get_offset_of_renderTimeBank_51() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___renderTimeBank_51)); }
	inline float get_renderTimeBank_51() const { return ___renderTimeBank_51; }
	inline float* get_address_of_renderTimeBank_51() { return &___renderTimeBank_51; }
	inline void set_renderTimeBank_51(float value)
	{
		___renderTimeBank_51 = value;
	}

	inline static int32_t get_offset_of_previousFrameCount_52() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___previousFrameCount_52)); }
	inline int32_t get_previousFrameCount_52() const { return ___previousFrameCount_52; }
	inline int32_t* get_address_of_previousFrameCount_52() { return &___previousFrameCount_52; }
	inline void set_previousFrameCount_52(int32_t value)
	{
		___previousFrameCount_52 = value;
	}

	inline static int32_t get_offset_of_realtimeFPS_53() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___realtimeFPS_53)); }
	inline bool get_realtimeFPS_53() const { return ___realtimeFPS_53; }
	inline bool* get_address_of_realtimeFPS_53() { return &___realtimeFPS_53; }
	inline void set_realtimeFPS_53(bool value)
	{
		___realtimeFPS_53 = value;
	}

	inline static int32_t get_offset_of_milliseconds_54() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___milliseconds_54)); }
	inline bool get_milliseconds_54() const { return ___milliseconds_54; }
	inline bool* get_address_of_milliseconds_54() { return &___milliseconds_54; }
	inline void set_milliseconds_54(bool value)
	{
		___milliseconds_54 = value;
	}

	inline static int32_t get_offset_of_average_55() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___average_55)); }
	inline bool get_average_55() const { return ___average_55; }
	inline bool* get_address_of_average_55() { return &___average_55; }
	inline void set_average_55(bool value)
	{
		___average_55 = value;
	}

	inline static int32_t get_offset_of_averageMilliseconds_56() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___averageMilliseconds_56)); }
	inline bool get_averageMilliseconds_56() const { return ___averageMilliseconds_56; }
	inline bool* get_address_of_averageMilliseconds_56() { return &___averageMilliseconds_56; }
	inline void set_averageMilliseconds_56(bool value)
	{
		___averageMilliseconds_56 = value;
	}

	inline static int32_t get_offset_of_averageNewLine_57() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___averageNewLine_57)); }
	inline bool get_averageNewLine_57() const { return ___averageNewLine_57; }
	inline bool* get_address_of_averageNewLine_57() { return &___averageNewLine_57; }
	inline void set_averageNewLine_57(bool value)
	{
		___averageNewLine_57 = value;
	}

	inline static int32_t get_offset_of_averageSamples_58() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___averageSamples_58)); }
	inline int32_t get_averageSamples_58() const { return ___averageSamples_58; }
	inline int32_t* get_address_of_averageSamples_58() { return &___averageSamples_58; }
	inline void set_averageSamples_58(int32_t value)
	{
		___averageSamples_58 = value;
	}

	inline static int32_t get_offset_of_minMax_59() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___minMax_59)); }
	inline bool get_minMax_59() const { return ___minMax_59; }
	inline bool* get_address_of_minMax_59() { return &___minMax_59; }
	inline void set_minMax_59(bool value)
	{
		___minMax_59 = value;
	}

	inline static int32_t get_offset_of_minMaxMilliseconds_60() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___minMaxMilliseconds_60)); }
	inline bool get_minMaxMilliseconds_60() const { return ___minMaxMilliseconds_60; }
	inline bool* get_address_of_minMaxMilliseconds_60() { return &___minMaxMilliseconds_60; }
	inline void set_minMaxMilliseconds_60(bool value)
	{
		___minMaxMilliseconds_60 = value;
	}

	inline static int32_t get_offset_of_minMaxNewLine_61() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___minMaxNewLine_61)); }
	inline bool get_minMaxNewLine_61() const { return ___minMaxNewLine_61; }
	inline bool* get_address_of_minMaxNewLine_61() { return &___minMaxNewLine_61; }
	inline void set_minMaxNewLine_61(bool value)
	{
		___minMaxNewLine_61 = value;
	}

	inline static int32_t get_offset_of_minMaxTwoLines_62() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___minMaxTwoLines_62)); }
	inline bool get_minMaxTwoLines_62() const { return ___minMaxTwoLines_62; }
	inline bool* get_address_of_minMaxTwoLines_62() { return &___minMaxTwoLines_62; }
	inline void set_minMaxTwoLines_62(bool value)
	{
		___minMaxTwoLines_62 = value;
	}

	inline static int32_t get_offset_of_render_63() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___render_63)); }
	inline bool get_render_63() const { return ___render_63; }
	inline bool* get_address_of_render_63() { return &___render_63; }
	inline void set_render_63(bool value)
	{
		___render_63 = value;
	}

	inline static int32_t get_offset_of_renderNewLine_64() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___renderNewLine_64)); }
	inline bool get_renderNewLine_64() const { return ___renderNewLine_64; }
	inline bool* get_address_of_renderNewLine_64() { return &___renderNewLine_64; }
	inline void set_renderNewLine_64(bool value)
	{
		___renderNewLine_64 = value;
	}

	inline static int32_t get_offset_of_renderAutoAdd_65() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___renderAutoAdd_65)); }
	inline bool get_renderAutoAdd_65() const { return ___renderAutoAdd_65; }
	inline bool* get_address_of_renderAutoAdd_65() { return &___renderAutoAdd_65; }
	inline void set_renderAutoAdd_65(bool value)
	{
		___renderAutoAdd_65 = value;
	}

	inline static int32_t get_offset_of_colorWarning_66() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorWarning_66)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_colorWarning_66() const { return ___colorWarning_66; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_colorWarning_66() { return &___colorWarning_66; }
	inline void set_colorWarning_66(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___colorWarning_66 = value;
	}

	inline static int32_t get_offset_of_colorCritical_67() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorCritical_67)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_colorCritical_67() const { return ___colorCritical_67; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_colorCritical_67() { return &___colorCritical_67; }
	inline void set_colorCritical_67(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___colorCritical_67 = value;
	}

	inline static int32_t get_offset_of_colorRender_68() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___colorRender_68)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_colorRender_68() const { return ___colorRender_68; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_colorRender_68() { return &___colorRender_68; }
	inline void set_colorRender_68(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___colorRender_68 = value;
	}

	inline static int32_t get_offset_of_U3CLastValueU3Ek__BackingField_69() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastValueU3Ek__BackingField_69)); }
	inline int32_t get_U3CLastValueU3Ek__BackingField_69() const { return ___U3CLastValueU3Ek__BackingField_69; }
	inline int32_t* get_address_of_U3CLastValueU3Ek__BackingField_69() { return &___U3CLastValueU3Ek__BackingField_69; }
	inline void set_U3CLastValueU3Ek__BackingField_69(int32_t value)
	{
		___U3CLastValueU3Ek__BackingField_69 = value;
	}

	inline static int32_t get_offset_of_U3CLastMillisecondsValueU3Ek__BackingField_70() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastMillisecondsValueU3Ek__BackingField_70)); }
	inline float get_U3CLastMillisecondsValueU3Ek__BackingField_70() const { return ___U3CLastMillisecondsValueU3Ek__BackingField_70; }
	inline float* get_address_of_U3CLastMillisecondsValueU3Ek__BackingField_70() { return &___U3CLastMillisecondsValueU3Ek__BackingField_70; }
	inline void set_U3CLastMillisecondsValueU3Ek__BackingField_70(float value)
	{
		___U3CLastMillisecondsValueU3Ek__BackingField_70 = value;
	}

	inline static int32_t get_offset_of_U3CLastRenderValueU3Ek__BackingField_71() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastRenderValueU3Ek__BackingField_71)); }
	inline float get_U3CLastRenderValueU3Ek__BackingField_71() const { return ___U3CLastRenderValueU3Ek__BackingField_71; }
	inline float* get_address_of_U3CLastRenderValueU3Ek__BackingField_71() { return &___U3CLastRenderValueU3Ek__BackingField_71; }
	inline void set_U3CLastRenderValueU3Ek__BackingField_71(float value)
	{
		___U3CLastRenderValueU3Ek__BackingField_71 = value;
	}

	inline static int32_t get_offset_of_U3CLastAverageValueU3Ek__BackingField_72() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastAverageValueU3Ek__BackingField_72)); }
	inline int32_t get_U3CLastAverageValueU3Ek__BackingField_72() const { return ___U3CLastAverageValueU3Ek__BackingField_72; }
	inline int32_t* get_address_of_U3CLastAverageValueU3Ek__BackingField_72() { return &___U3CLastAverageValueU3Ek__BackingField_72; }
	inline void set_U3CLastAverageValueU3Ek__BackingField_72(int32_t value)
	{
		___U3CLastAverageValueU3Ek__BackingField_72 = value;
	}

	inline static int32_t get_offset_of_U3CLastAverageMillisecondsValueU3Ek__BackingField_73() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastAverageMillisecondsValueU3Ek__BackingField_73)); }
	inline float get_U3CLastAverageMillisecondsValueU3Ek__BackingField_73() const { return ___U3CLastAverageMillisecondsValueU3Ek__BackingField_73; }
	inline float* get_address_of_U3CLastAverageMillisecondsValueU3Ek__BackingField_73() { return &___U3CLastAverageMillisecondsValueU3Ek__BackingField_73; }
	inline void set_U3CLastAverageMillisecondsValueU3Ek__BackingField_73(float value)
	{
		___U3CLastAverageMillisecondsValueU3Ek__BackingField_73 = value;
	}

	inline static int32_t get_offset_of_U3CLastMinimumValueU3Ek__BackingField_74() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastMinimumValueU3Ek__BackingField_74)); }
	inline int32_t get_U3CLastMinimumValueU3Ek__BackingField_74() const { return ___U3CLastMinimumValueU3Ek__BackingField_74; }
	inline int32_t* get_address_of_U3CLastMinimumValueU3Ek__BackingField_74() { return &___U3CLastMinimumValueU3Ek__BackingField_74; }
	inline void set_U3CLastMinimumValueU3Ek__BackingField_74(int32_t value)
	{
		___U3CLastMinimumValueU3Ek__BackingField_74 = value;
	}

	inline static int32_t get_offset_of_U3CLastMaximumValueU3Ek__BackingField_75() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastMaximumValueU3Ek__BackingField_75)); }
	inline int32_t get_U3CLastMaximumValueU3Ek__BackingField_75() const { return ___U3CLastMaximumValueU3Ek__BackingField_75; }
	inline int32_t* get_address_of_U3CLastMaximumValueU3Ek__BackingField_75() { return &___U3CLastMaximumValueU3Ek__BackingField_75; }
	inline void set_U3CLastMaximumValueU3Ek__BackingField_75(int32_t value)
	{
		___U3CLastMaximumValueU3Ek__BackingField_75 = value;
	}

	inline static int32_t get_offset_of_U3CLastMinMillisecondsValueU3Ek__BackingField_76() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastMinMillisecondsValueU3Ek__BackingField_76)); }
	inline float get_U3CLastMinMillisecondsValueU3Ek__BackingField_76() const { return ___U3CLastMinMillisecondsValueU3Ek__BackingField_76; }
	inline float* get_address_of_U3CLastMinMillisecondsValueU3Ek__BackingField_76() { return &___U3CLastMinMillisecondsValueU3Ek__BackingField_76; }
	inline void set_U3CLastMinMillisecondsValueU3Ek__BackingField_76(float value)
	{
		___U3CLastMinMillisecondsValueU3Ek__BackingField_76 = value;
	}

	inline static int32_t get_offset_of_U3CLastMaxMillisecondsValueU3Ek__BackingField_77() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CLastMaxMillisecondsValueU3Ek__BackingField_77)); }
	inline float get_U3CLastMaxMillisecondsValueU3Ek__BackingField_77() const { return ___U3CLastMaxMillisecondsValueU3Ek__BackingField_77; }
	inline float* get_address_of_U3CLastMaxMillisecondsValueU3Ek__BackingField_77() { return &___U3CLastMaxMillisecondsValueU3Ek__BackingField_77; }
	inline void set_U3CLastMaxMillisecondsValueU3Ek__BackingField_77(float value)
	{
		___U3CLastMaxMillisecondsValueU3Ek__BackingField_77 = value;
	}

	inline static int32_t get_offset_of_U3CCurrentFpsLevelU3Ek__BackingField_78() { return static_cast<int32_t>(offsetof(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD, ___U3CCurrentFpsLevelU3Ek__BackingField_78)); }
	inline uint8_t get_U3CCurrentFpsLevelU3Ek__BackingField_78() const { return ___U3CCurrentFpsLevelU3Ek__BackingField_78; }
	inline uint8_t* get_address_of_U3CCurrentFpsLevelU3Ek__BackingField_78() { return &___U3CCurrentFpsLevelU3Ek__BackingField_78; }
	inline void set_U3CCurrentFpsLevelU3Ek__BackingField_78(uint8_t value)
	{
		___U3CCurrentFpsLevelU3Ek__BackingField_78 = value;
	}
};


// CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData
struct MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6  : public UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E
{
public:
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::precise
	bool ___precise_24;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::total
	bool ___total_25;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::allocated
	bool ___allocated_26;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::monoUsage
	bool ___monoUsage_27;
	// System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::gfx
	bool ___gfx_28;
	// System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::<LastTotalValue>k__BackingField
	int64_t ___U3CLastTotalValueU3Ek__BackingField_29;
	// System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::<LastAllocatedValue>k__BackingField
	int64_t ___U3CLastAllocatedValueU3Ek__BackingField_30;
	// System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::<LastMonoValue>k__BackingField
	int64_t ___U3CLastMonoValueU3Ek__BackingField_31;
	// System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::<LastGfxValue>k__BackingField
	int64_t ___U3CLastGfxValueU3Ek__BackingField_32;

public:
	inline static int32_t get_offset_of_precise_24() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___precise_24)); }
	inline bool get_precise_24() const { return ___precise_24; }
	inline bool* get_address_of_precise_24() { return &___precise_24; }
	inline void set_precise_24(bool value)
	{
		___precise_24 = value;
	}

	inline static int32_t get_offset_of_total_25() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___total_25)); }
	inline bool get_total_25() const { return ___total_25; }
	inline bool* get_address_of_total_25() { return &___total_25; }
	inline void set_total_25(bool value)
	{
		___total_25 = value;
	}

	inline static int32_t get_offset_of_allocated_26() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___allocated_26)); }
	inline bool get_allocated_26() const { return ___allocated_26; }
	inline bool* get_address_of_allocated_26() { return &___allocated_26; }
	inline void set_allocated_26(bool value)
	{
		___allocated_26 = value;
	}

	inline static int32_t get_offset_of_monoUsage_27() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___monoUsage_27)); }
	inline bool get_monoUsage_27() const { return ___monoUsage_27; }
	inline bool* get_address_of_monoUsage_27() { return &___monoUsage_27; }
	inline void set_monoUsage_27(bool value)
	{
		___monoUsage_27 = value;
	}

	inline static int32_t get_offset_of_gfx_28() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___gfx_28)); }
	inline bool get_gfx_28() const { return ___gfx_28; }
	inline bool* get_address_of_gfx_28() { return &___gfx_28; }
	inline void set_gfx_28(bool value)
	{
		___gfx_28 = value;
	}

	inline static int32_t get_offset_of_U3CLastTotalValueU3Ek__BackingField_29() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___U3CLastTotalValueU3Ek__BackingField_29)); }
	inline int64_t get_U3CLastTotalValueU3Ek__BackingField_29() const { return ___U3CLastTotalValueU3Ek__BackingField_29; }
	inline int64_t* get_address_of_U3CLastTotalValueU3Ek__BackingField_29() { return &___U3CLastTotalValueU3Ek__BackingField_29; }
	inline void set_U3CLastTotalValueU3Ek__BackingField_29(int64_t value)
	{
		___U3CLastTotalValueU3Ek__BackingField_29 = value;
	}

	inline static int32_t get_offset_of_U3CLastAllocatedValueU3Ek__BackingField_30() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___U3CLastAllocatedValueU3Ek__BackingField_30)); }
	inline int64_t get_U3CLastAllocatedValueU3Ek__BackingField_30() const { return ___U3CLastAllocatedValueU3Ek__BackingField_30; }
	inline int64_t* get_address_of_U3CLastAllocatedValueU3Ek__BackingField_30() { return &___U3CLastAllocatedValueU3Ek__BackingField_30; }
	inline void set_U3CLastAllocatedValueU3Ek__BackingField_30(int64_t value)
	{
		___U3CLastAllocatedValueU3Ek__BackingField_30 = value;
	}

	inline static int32_t get_offset_of_U3CLastMonoValueU3Ek__BackingField_31() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___U3CLastMonoValueU3Ek__BackingField_31)); }
	inline int64_t get_U3CLastMonoValueU3Ek__BackingField_31() const { return ___U3CLastMonoValueU3Ek__BackingField_31; }
	inline int64_t* get_address_of_U3CLastMonoValueU3Ek__BackingField_31() { return &___U3CLastMonoValueU3Ek__BackingField_31; }
	inline void set_U3CLastMonoValueU3Ek__BackingField_31(int64_t value)
	{
		___U3CLastMonoValueU3Ek__BackingField_31 = value;
	}

	inline static int32_t get_offset_of_U3CLastGfxValueU3Ek__BackingField_32() { return static_cast<int32_t>(offsetof(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6, ___U3CLastGfxValueU3Ek__BackingField_32)); }
	inline int64_t get_U3CLastGfxValueU3Ek__BackingField_32() const { return ___U3CLastGfxValueU3Ek__BackingField_32; }
	inline int64_t* get_address_of_U3CLastGfxValueU3Ek__BackingField_32() { return &___U3CLastGfxValueU3Ek__BackingField_32; }
	inline void set_U3CLastGfxValueU3Ek__BackingField_32(int64_t value)
	{
		___U3CLastGfxValueU3Ek__BackingField_32 = value;
	}
};


// GunInfo
struct GunInfo_t37CA1BBD2E470CE396A728413D958DC698770F81  : public ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974
{
public:
	// System.Single GunInfo::damage
	float ___damage_5;

public:
	inline static int32_t get_offset_of_damage_5() { return static_cast<int32_t>(offsetof(GunInfo_t37CA1BBD2E470CE396A728413D958DC698770F81, ___damage_5)); }
	inline float get_damage_5() const { return ___damage_5; }
	inline float* get_address_of_damage_5() { return &___damage_5; }
	inline void set_damage_5(float value)
	{
		___damage_5 = value;
	}
};


// UnityEngine.MonoBehaviour
struct MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429  : public Behaviour_tBDC7E9C3C898AD8348891B82D3E345801D920CA8
{
public:

public:
};


// ADS
struct ADS_t19B0242A8A62416BCF9C927D76305A252DB69367  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String ADS::GooglePlay_ID
	String_t* ___GooglePlay_ID_4;
	// System.String ADS::placementId
	String_t* ___placementId_5;
	// System.Boolean ADS::testMode
	bool ___testMode_6;

public:
	inline static int32_t get_offset_of_GooglePlay_ID_4() { return static_cast<int32_t>(offsetof(ADS_t19B0242A8A62416BCF9C927D76305A252DB69367, ___GooglePlay_ID_4)); }
	inline String_t* get_GooglePlay_ID_4() const { return ___GooglePlay_ID_4; }
	inline String_t** get_address_of_GooglePlay_ID_4() { return &___GooglePlay_ID_4; }
	inline void set_GooglePlay_ID_4(String_t* value)
	{
		___GooglePlay_ID_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___GooglePlay_ID_4), (void*)value);
	}

	inline static int32_t get_offset_of_placementId_5() { return static_cast<int32_t>(offsetof(ADS_t19B0242A8A62416BCF9C927D76305A252DB69367, ___placementId_5)); }
	inline String_t* get_placementId_5() const { return ___placementId_5; }
	inline String_t** get_address_of_placementId_5() { return &___placementId_5; }
	inline void set_placementId_5(String_t* value)
	{
		___placementId_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___placementId_5), (void*)value);
	}

	inline static int32_t get_offset_of_testMode_6() { return static_cast<int32_t>(offsetof(ADS_t19B0242A8A62416BCF9C927D76305A252DB69367, ___testMode_6)); }
	inline bool get_testMode_6() const { return ___testMode_6; }
	inline bool* get_address_of_testMode_6() { return &___testMode_6; }
	inline void set_testMode_6(bool value)
	{
		___testMode_6 = value;
	}
};


// Actif
struct Actif_t2DF53FC0444467754E765E2F08C94CE2ACAAEFE8  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject Actif::ActiveObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___ActiveObject_4;
	// UnityEngine.GameObject Actif::CurenObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___CurenObject_5;

public:
	inline static int32_t get_offset_of_ActiveObject_4() { return static_cast<int32_t>(offsetof(Actif_t2DF53FC0444467754E765E2F08C94CE2ACAAEFE8, ___ActiveObject_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_ActiveObject_4() const { return ___ActiveObject_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_ActiveObject_4() { return &___ActiveObject_4; }
	inline void set_ActiveObject_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___ActiveObject_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ActiveObject_4), (void*)value);
	}

	inline static int32_t get_offset_of_CurenObject_5() { return static_cast<int32_t>(offsetof(Actif_t2DF53FC0444467754E765E2F08C94CE2ACAAEFE8, ___CurenObject_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_CurenObject_5() const { return ___CurenObject_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_CurenObject_5() { return &___CurenObject_5; }
	inline void set_CurenObject_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___CurenObject_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___CurenObject_5), (void*)value);
	}
};


// AddForce
struct AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single AddForce::RotateSpeed
	float ___RotateSpeed_4;
	// System.Boolean AddForce::Drag
	bool ___Drag_5;
	// UnityEngine.Rigidbody AddForce::rb
	Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * ___rb_6;

public:
	inline static int32_t get_offset_of_RotateSpeed_4() { return static_cast<int32_t>(offsetof(AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9, ___RotateSpeed_4)); }
	inline float get_RotateSpeed_4() const { return ___RotateSpeed_4; }
	inline float* get_address_of_RotateSpeed_4() { return &___RotateSpeed_4; }
	inline void set_RotateSpeed_4(float value)
	{
		___RotateSpeed_4 = value;
	}

	inline static int32_t get_offset_of_Drag_5() { return static_cast<int32_t>(offsetof(AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9, ___Drag_5)); }
	inline bool get_Drag_5() const { return ___Drag_5; }
	inline bool* get_address_of_Drag_5() { return &___Drag_5; }
	inline void set_Drag_5(bool value)
	{
		___Drag_5 = value;
	}

	inline static int32_t get_offset_of_rb_6() { return static_cast<int32_t>(offsetof(AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9, ___rb_6)); }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * get_rb_6() const { return ___rb_6; }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 ** get_address_of_rb_6() { return &___rb_6; }
	inline void set_rb_6(Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * value)
	{
		___rb_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rb_6), (void*)value);
	}
};


// ChangeTheme
struct ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Sprite[] ChangeTheme::WheelTextureTheme
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___WheelTextureTheme_4;
	// UnityEngine.Sprite[] ChangeTheme::ArrowTheme
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___ArrowTheme_5;
	// UnityEngine.Sprite[] ChangeTheme::GlowingTheme
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___GlowingTheme_6;
	// UnityEngine.Sprite[] ChangeTheme::BackgroundTheme
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___BackgroundTheme_7;
	// UnityEngine.Sprite[] ChangeTheme::MenuButton
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___MenuButton_8;
	// UnityEngine.Sprite[] ChangeTheme::MenuBackgroundButton
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___MenuBackgroundButton_9;
	// UnityEngine.Sprite[] ChangeTheme::PlanetTheme
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___PlanetTheme_10;
	// UnityEngine.Sprite[] ChangeTheme::PlanetTheme1
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___PlanetTheme1_11;
	// UnityEngine.Sprite[] ChangeTheme::PlanetTheme2
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___PlanetTheme2_12;
	// UnityEngine.Sprite[] ChangeTheme::PlanetTheme3
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___PlanetTheme3_13;
	// UnityEngine.Sprite[] ChangeTheme::PlanetTheme4
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___PlanetTheme4_14;
	// UnityEngine.Sprite[] ChangeTheme::PlanetTheme5
	SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* ___PlanetTheme5_15;
	// UnityEngine.SpriteRenderer ChangeTheme::WheelTexture
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___WheelTexture_16;
	// UnityEngine.SpriteRenderer ChangeTheme::Arrow
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Arrow_17;
	// UnityEngine.SpriteRenderer ChangeTheme::Glowing
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Glowing_18;
	// UnityEngine.SpriteRenderer ChangeTheme::Background
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Background_19;
	// UnityEngine.UI.Image ChangeTheme::Menu
	Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * ___Menu_20;
	// UnityEngine.UI.Image ChangeTheme::backgroundMenu
	Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * ___backgroundMenu_21;
	// UnityEngine.SpriteRenderer ChangeTheme::Planet
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Planet_22;
	// UnityEngine.SpriteRenderer ChangeTheme::Planet1
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Planet1_23;
	// UnityEngine.SpriteRenderer ChangeTheme::Planet2
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Planet2_24;
	// UnityEngine.SpriteRenderer ChangeTheme::Planet3
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Planet3_25;
	// UnityEngine.SpriteRenderer ChangeTheme::Planet4
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Planet4_26;
	// UnityEngine.SpriteRenderer ChangeTheme::Planet5
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___Planet5_27;
	// System.Int32 ChangeTheme::NumberOfPlanet
	int32_t ___NumberOfPlanet_28;

public:
	inline static int32_t get_offset_of_WheelTextureTheme_4() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___WheelTextureTheme_4)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_WheelTextureTheme_4() const { return ___WheelTextureTheme_4; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_WheelTextureTheme_4() { return &___WheelTextureTheme_4; }
	inline void set_WheelTextureTheme_4(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___WheelTextureTheme_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WheelTextureTheme_4), (void*)value);
	}

	inline static int32_t get_offset_of_ArrowTheme_5() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___ArrowTheme_5)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_ArrowTheme_5() const { return ___ArrowTheme_5; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_ArrowTheme_5() { return &___ArrowTheme_5; }
	inline void set_ArrowTheme_5(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___ArrowTheme_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ArrowTheme_5), (void*)value);
	}

	inline static int32_t get_offset_of_GlowingTheme_6() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___GlowingTheme_6)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_GlowingTheme_6() const { return ___GlowingTheme_6; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_GlowingTheme_6() { return &___GlowingTheme_6; }
	inline void set_GlowingTheme_6(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___GlowingTheme_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___GlowingTheme_6), (void*)value);
	}

	inline static int32_t get_offset_of_BackgroundTheme_7() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___BackgroundTheme_7)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_BackgroundTheme_7() const { return ___BackgroundTheme_7; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_BackgroundTheme_7() { return &___BackgroundTheme_7; }
	inline void set_BackgroundTheme_7(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___BackgroundTheme_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___BackgroundTheme_7), (void*)value);
	}

	inline static int32_t get_offset_of_MenuButton_8() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___MenuButton_8)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_MenuButton_8() const { return ___MenuButton_8; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_MenuButton_8() { return &___MenuButton_8; }
	inline void set_MenuButton_8(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___MenuButton_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___MenuButton_8), (void*)value);
	}

	inline static int32_t get_offset_of_MenuBackgroundButton_9() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___MenuBackgroundButton_9)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_MenuBackgroundButton_9() const { return ___MenuBackgroundButton_9; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_MenuBackgroundButton_9() { return &___MenuBackgroundButton_9; }
	inline void set_MenuBackgroundButton_9(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___MenuBackgroundButton_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___MenuBackgroundButton_9), (void*)value);
	}

	inline static int32_t get_offset_of_PlanetTheme_10() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___PlanetTheme_10)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_PlanetTheme_10() const { return ___PlanetTheme_10; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_PlanetTheme_10() { return &___PlanetTheme_10; }
	inline void set_PlanetTheme_10(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___PlanetTheme_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlanetTheme_10), (void*)value);
	}

	inline static int32_t get_offset_of_PlanetTheme1_11() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___PlanetTheme1_11)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_PlanetTheme1_11() const { return ___PlanetTheme1_11; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_PlanetTheme1_11() { return &___PlanetTheme1_11; }
	inline void set_PlanetTheme1_11(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___PlanetTheme1_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlanetTheme1_11), (void*)value);
	}

	inline static int32_t get_offset_of_PlanetTheme2_12() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___PlanetTheme2_12)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_PlanetTheme2_12() const { return ___PlanetTheme2_12; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_PlanetTheme2_12() { return &___PlanetTheme2_12; }
	inline void set_PlanetTheme2_12(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___PlanetTheme2_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlanetTheme2_12), (void*)value);
	}

	inline static int32_t get_offset_of_PlanetTheme3_13() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___PlanetTheme3_13)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_PlanetTheme3_13() const { return ___PlanetTheme3_13; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_PlanetTheme3_13() { return &___PlanetTheme3_13; }
	inline void set_PlanetTheme3_13(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___PlanetTheme3_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlanetTheme3_13), (void*)value);
	}

	inline static int32_t get_offset_of_PlanetTheme4_14() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___PlanetTheme4_14)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_PlanetTheme4_14() const { return ___PlanetTheme4_14; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_PlanetTheme4_14() { return &___PlanetTheme4_14; }
	inline void set_PlanetTheme4_14(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___PlanetTheme4_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlanetTheme4_14), (void*)value);
	}

	inline static int32_t get_offset_of_PlanetTheme5_15() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___PlanetTheme5_15)); }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* get_PlanetTheme5_15() const { return ___PlanetTheme5_15; }
	inline SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7** get_address_of_PlanetTheme5_15() { return &___PlanetTheme5_15; }
	inline void set_PlanetTheme5_15(SpriteU5BU5D_tF94AD07E062BC08ECD019A21E7A7B861654905F7* value)
	{
		___PlanetTheme5_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlanetTheme5_15), (void*)value);
	}

	inline static int32_t get_offset_of_WheelTexture_16() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___WheelTexture_16)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_WheelTexture_16() const { return ___WheelTexture_16; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_WheelTexture_16() { return &___WheelTexture_16; }
	inline void set_WheelTexture_16(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___WheelTexture_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WheelTexture_16), (void*)value);
	}

	inline static int32_t get_offset_of_Arrow_17() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Arrow_17)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Arrow_17() const { return ___Arrow_17; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Arrow_17() { return &___Arrow_17; }
	inline void set_Arrow_17(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Arrow_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Arrow_17), (void*)value);
	}

	inline static int32_t get_offset_of_Glowing_18() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Glowing_18)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Glowing_18() const { return ___Glowing_18; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Glowing_18() { return &___Glowing_18; }
	inline void set_Glowing_18(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Glowing_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Glowing_18), (void*)value);
	}

	inline static int32_t get_offset_of_Background_19() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Background_19)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Background_19() const { return ___Background_19; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Background_19() { return &___Background_19; }
	inline void set_Background_19(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Background_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Background_19), (void*)value);
	}

	inline static int32_t get_offset_of_Menu_20() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Menu_20)); }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * get_Menu_20() const { return ___Menu_20; }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E ** get_address_of_Menu_20() { return &___Menu_20; }
	inline void set_Menu_20(Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * value)
	{
		___Menu_20 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Menu_20), (void*)value);
	}

	inline static int32_t get_offset_of_backgroundMenu_21() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___backgroundMenu_21)); }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * get_backgroundMenu_21() const { return ___backgroundMenu_21; }
	inline Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E ** get_address_of_backgroundMenu_21() { return &___backgroundMenu_21; }
	inline void set_backgroundMenu_21(Image_t18FED07D8646917E1C563745518CF3DD57FF0B3E * value)
	{
		___backgroundMenu_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___backgroundMenu_21), (void*)value);
	}

	inline static int32_t get_offset_of_Planet_22() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Planet_22)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Planet_22() const { return ___Planet_22; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Planet_22() { return &___Planet_22; }
	inline void set_Planet_22(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Planet_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planet_22), (void*)value);
	}

	inline static int32_t get_offset_of_Planet1_23() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Planet1_23)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Planet1_23() const { return ___Planet1_23; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Planet1_23() { return &___Planet1_23; }
	inline void set_Planet1_23(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Planet1_23 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planet1_23), (void*)value);
	}

	inline static int32_t get_offset_of_Planet2_24() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Planet2_24)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Planet2_24() const { return ___Planet2_24; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Planet2_24() { return &___Planet2_24; }
	inline void set_Planet2_24(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Planet2_24 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planet2_24), (void*)value);
	}

	inline static int32_t get_offset_of_Planet3_25() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Planet3_25)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Planet3_25() const { return ___Planet3_25; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Planet3_25() { return &___Planet3_25; }
	inline void set_Planet3_25(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Planet3_25 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planet3_25), (void*)value);
	}

	inline static int32_t get_offset_of_Planet4_26() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Planet4_26)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Planet4_26() const { return ___Planet4_26; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Planet4_26() { return &___Planet4_26; }
	inline void set_Planet4_26(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Planet4_26 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planet4_26), (void*)value);
	}

	inline static int32_t get_offset_of_Planet5_27() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___Planet5_27)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_Planet5_27() const { return ___Planet5_27; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_Planet5_27() { return &___Planet5_27; }
	inline void set_Planet5_27(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___Planet5_27 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planet5_27), (void*)value);
	}

	inline static int32_t get_offset_of_NumberOfPlanet_28() { return static_cast<int32_t>(offsetof(ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF, ___NumberOfPlanet_28)); }
	inline int32_t get_NumberOfPlanet_28() const { return ___NumberOfPlanet_28; }
	inline int32_t* get_address_of_NumberOfPlanet_28() { return &___NumberOfPlanet_28; }
	inline void set_NumberOfPlanet_28(int32_t value)
	{
		___NumberOfPlanet_28 = value;
	}
};


// CodeStage.AdvancedFPSCounter.AFPSCounter
struct AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData CodeStage.AdvancedFPSCounter.AFPSCounter::fpsCounter
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD * ___fpsCounter_9;
	// CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData CodeStage.AdvancedFPSCounter.AFPSCounter::memoryCounter
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 * ___memoryCounter_10;
	// CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData CodeStage.AdvancedFPSCounter.AFPSCounter::deviceInfoCounter
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F * ___deviceInfoCounter_11;
	// UnityEngine.KeyCode CodeStage.AdvancedFPSCounter.AFPSCounter::hotKey
	int32_t ___hotKey_12;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::circleGesture
	bool ___circleGesture_13;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::hotKeyCtrl
	bool ___hotKeyCtrl_14;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::hotKeyShift
	bool ___hotKeyShift_15;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::hotKeyAlt
	bool ___hotKeyAlt_16;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::keepAlive
	bool ___keepAlive_17;
	// UnityEngine.Canvas CodeStage.AdvancedFPSCounter.AFPSCounter::canvas
	Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * ___canvas_18;
	// UnityEngine.UI.CanvasScaler CodeStage.AdvancedFPSCounter.AFPSCounter::canvasScaler
	CanvasScaler_t304BA6F47EDB7402EBA405DD36CA7D6ADF723564 * ___canvasScaler_19;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::externalCanvas
	bool ___externalCanvas_20;
	// CodeStage.AdvancedFPSCounter.Labels.DrawableLabel[] CodeStage.AdvancedFPSCounter.AFPSCounter::labels
	DrawableLabelU5BU5D_t44C0B89CA90DC2065F8BA49C77D14FEFFFDCBADC* ___labels_21;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::anchorsCount
	int32_t ___anchorsCount_22;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::cachedVSync
	int32_t ___cachedVSync_23;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::cachedFrameRate
	int32_t ___cachedFrameRate_24;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::inited
	bool ___inited_25;
	// System.Collections.Generic.List`1<UnityEngine.Vector2> CodeStage.AdvancedFPSCounter.AFPSCounter::gesturePoints
	List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * ___gesturePoints_26;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::gestureCount
	int32_t ___gestureCount_27;
	// CodeStage.AdvancedFPSCounter.OperationMode CodeStage.AdvancedFPSCounter.AFPSCounter::operationMode
	uint8_t ___operationMode_28;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::forceFrameRate
	bool ___forceFrameRate_29;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::forcedFrameRate
	int32_t ___forcedFrameRate_30;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::background
	bool ___background_31;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.AFPSCounter::backgroundColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___backgroundColor_32;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::backgroundPadding
	int32_t ___backgroundPadding_33;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::shadow
	bool ___shadow_34;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.AFPSCounter::shadowColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___shadowColor_35;
	// UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.AFPSCounter::shadowDistance
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___shadowDistance_36;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::outline
	bool ___outline_37;
	// UnityEngine.Color CodeStage.AdvancedFPSCounter.AFPSCounter::outlineColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___outlineColor_38;
	// UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.AFPSCounter::outlineDistance
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___outlineDistance_39;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::autoScale
	bool ___autoScale_40;
	// System.Single CodeStage.AdvancedFPSCounter.AFPSCounter::scaleFactor
	float ___scaleFactor_41;
	// UnityEngine.Font CodeStage.AdvancedFPSCounter.AFPSCounter::labelsFont
	Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * ___labelsFont_42;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::fontSize
	int32_t ___fontSize_43;
	// System.Single CodeStage.AdvancedFPSCounter.AFPSCounter::lineSpacing
	float ___lineSpacing_44;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::countersSpacing
	int32_t ___countersSpacing_45;
	// UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.AFPSCounter::paddingOffset
	Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  ___paddingOffset_46;
	// System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::pixelPerfect
	bool ___pixelPerfect_47;
	// System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::sortingOrder
	int32_t ___sortingOrder_48;

public:
	inline static int32_t get_offset_of_fpsCounter_9() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___fpsCounter_9)); }
	inline FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD * get_fpsCounter_9() const { return ___fpsCounter_9; }
	inline FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD ** get_address_of_fpsCounter_9() { return &___fpsCounter_9; }
	inline void set_fpsCounter_9(FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD * value)
	{
		___fpsCounter_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___fpsCounter_9), (void*)value);
	}

	inline static int32_t get_offset_of_memoryCounter_10() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___memoryCounter_10)); }
	inline MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 * get_memoryCounter_10() const { return ___memoryCounter_10; }
	inline MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 ** get_address_of_memoryCounter_10() { return &___memoryCounter_10; }
	inline void set_memoryCounter_10(MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6 * value)
	{
		___memoryCounter_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___memoryCounter_10), (void*)value);
	}

	inline static int32_t get_offset_of_deviceInfoCounter_11() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___deviceInfoCounter_11)); }
	inline DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F * get_deviceInfoCounter_11() const { return ___deviceInfoCounter_11; }
	inline DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F ** get_address_of_deviceInfoCounter_11() { return &___deviceInfoCounter_11; }
	inline void set_deviceInfoCounter_11(DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F * value)
	{
		___deviceInfoCounter_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___deviceInfoCounter_11), (void*)value);
	}

	inline static int32_t get_offset_of_hotKey_12() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___hotKey_12)); }
	inline int32_t get_hotKey_12() const { return ___hotKey_12; }
	inline int32_t* get_address_of_hotKey_12() { return &___hotKey_12; }
	inline void set_hotKey_12(int32_t value)
	{
		___hotKey_12 = value;
	}

	inline static int32_t get_offset_of_circleGesture_13() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___circleGesture_13)); }
	inline bool get_circleGesture_13() const { return ___circleGesture_13; }
	inline bool* get_address_of_circleGesture_13() { return &___circleGesture_13; }
	inline void set_circleGesture_13(bool value)
	{
		___circleGesture_13 = value;
	}

	inline static int32_t get_offset_of_hotKeyCtrl_14() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___hotKeyCtrl_14)); }
	inline bool get_hotKeyCtrl_14() const { return ___hotKeyCtrl_14; }
	inline bool* get_address_of_hotKeyCtrl_14() { return &___hotKeyCtrl_14; }
	inline void set_hotKeyCtrl_14(bool value)
	{
		___hotKeyCtrl_14 = value;
	}

	inline static int32_t get_offset_of_hotKeyShift_15() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___hotKeyShift_15)); }
	inline bool get_hotKeyShift_15() const { return ___hotKeyShift_15; }
	inline bool* get_address_of_hotKeyShift_15() { return &___hotKeyShift_15; }
	inline void set_hotKeyShift_15(bool value)
	{
		___hotKeyShift_15 = value;
	}

	inline static int32_t get_offset_of_hotKeyAlt_16() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___hotKeyAlt_16)); }
	inline bool get_hotKeyAlt_16() const { return ___hotKeyAlt_16; }
	inline bool* get_address_of_hotKeyAlt_16() { return &___hotKeyAlt_16; }
	inline void set_hotKeyAlt_16(bool value)
	{
		___hotKeyAlt_16 = value;
	}

	inline static int32_t get_offset_of_keepAlive_17() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___keepAlive_17)); }
	inline bool get_keepAlive_17() const { return ___keepAlive_17; }
	inline bool* get_address_of_keepAlive_17() { return &___keepAlive_17; }
	inline void set_keepAlive_17(bool value)
	{
		___keepAlive_17 = value;
	}

	inline static int32_t get_offset_of_canvas_18() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___canvas_18)); }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * get_canvas_18() const { return ___canvas_18; }
	inline Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 ** get_address_of_canvas_18() { return &___canvas_18; }
	inline void set_canvas_18(Canvas_tBC28BF1DD8D8499A89B5781505833D3728CF8591 * value)
	{
		___canvas_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___canvas_18), (void*)value);
	}

	inline static int32_t get_offset_of_canvasScaler_19() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___canvasScaler_19)); }
	inline CanvasScaler_t304BA6F47EDB7402EBA405DD36CA7D6ADF723564 * get_canvasScaler_19() const { return ___canvasScaler_19; }
	inline CanvasScaler_t304BA6F47EDB7402EBA405DD36CA7D6ADF723564 ** get_address_of_canvasScaler_19() { return &___canvasScaler_19; }
	inline void set_canvasScaler_19(CanvasScaler_t304BA6F47EDB7402EBA405DD36CA7D6ADF723564 * value)
	{
		___canvasScaler_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___canvasScaler_19), (void*)value);
	}

	inline static int32_t get_offset_of_externalCanvas_20() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___externalCanvas_20)); }
	inline bool get_externalCanvas_20() const { return ___externalCanvas_20; }
	inline bool* get_address_of_externalCanvas_20() { return &___externalCanvas_20; }
	inline void set_externalCanvas_20(bool value)
	{
		___externalCanvas_20 = value;
	}

	inline static int32_t get_offset_of_labels_21() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___labels_21)); }
	inline DrawableLabelU5BU5D_t44C0B89CA90DC2065F8BA49C77D14FEFFFDCBADC* get_labels_21() const { return ___labels_21; }
	inline DrawableLabelU5BU5D_t44C0B89CA90DC2065F8BA49C77D14FEFFFDCBADC** get_address_of_labels_21() { return &___labels_21; }
	inline void set_labels_21(DrawableLabelU5BU5D_t44C0B89CA90DC2065F8BA49C77D14FEFFFDCBADC* value)
	{
		___labels_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___labels_21), (void*)value);
	}

	inline static int32_t get_offset_of_anchorsCount_22() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___anchorsCount_22)); }
	inline int32_t get_anchorsCount_22() const { return ___anchorsCount_22; }
	inline int32_t* get_address_of_anchorsCount_22() { return &___anchorsCount_22; }
	inline void set_anchorsCount_22(int32_t value)
	{
		___anchorsCount_22 = value;
	}

	inline static int32_t get_offset_of_cachedVSync_23() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___cachedVSync_23)); }
	inline int32_t get_cachedVSync_23() const { return ___cachedVSync_23; }
	inline int32_t* get_address_of_cachedVSync_23() { return &___cachedVSync_23; }
	inline void set_cachedVSync_23(int32_t value)
	{
		___cachedVSync_23 = value;
	}

	inline static int32_t get_offset_of_cachedFrameRate_24() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___cachedFrameRate_24)); }
	inline int32_t get_cachedFrameRate_24() const { return ___cachedFrameRate_24; }
	inline int32_t* get_address_of_cachedFrameRate_24() { return &___cachedFrameRate_24; }
	inline void set_cachedFrameRate_24(int32_t value)
	{
		___cachedFrameRate_24 = value;
	}

	inline static int32_t get_offset_of_inited_25() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___inited_25)); }
	inline bool get_inited_25() const { return ___inited_25; }
	inline bool* get_address_of_inited_25() { return &___inited_25; }
	inline void set_inited_25(bool value)
	{
		___inited_25 = value;
	}

	inline static int32_t get_offset_of_gesturePoints_26() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___gesturePoints_26)); }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * get_gesturePoints_26() const { return ___gesturePoints_26; }
	inline List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB ** get_address_of_gesturePoints_26() { return &___gesturePoints_26; }
	inline void set_gesturePoints_26(List_1_t0737D51EB43DAAA1BDC9C2B83B393A4B9B9BE8EB * value)
	{
		___gesturePoints_26 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___gesturePoints_26), (void*)value);
	}

	inline static int32_t get_offset_of_gestureCount_27() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___gestureCount_27)); }
	inline int32_t get_gestureCount_27() const { return ___gestureCount_27; }
	inline int32_t* get_address_of_gestureCount_27() { return &___gestureCount_27; }
	inline void set_gestureCount_27(int32_t value)
	{
		___gestureCount_27 = value;
	}

	inline static int32_t get_offset_of_operationMode_28() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___operationMode_28)); }
	inline uint8_t get_operationMode_28() const { return ___operationMode_28; }
	inline uint8_t* get_address_of_operationMode_28() { return &___operationMode_28; }
	inline void set_operationMode_28(uint8_t value)
	{
		___operationMode_28 = value;
	}

	inline static int32_t get_offset_of_forceFrameRate_29() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___forceFrameRate_29)); }
	inline bool get_forceFrameRate_29() const { return ___forceFrameRate_29; }
	inline bool* get_address_of_forceFrameRate_29() { return &___forceFrameRate_29; }
	inline void set_forceFrameRate_29(bool value)
	{
		___forceFrameRate_29 = value;
	}

	inline static int32_t get_offset_of_forcedFrameRate_30() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___forcedFrameRate_30)); }
	inline int32_t get_forcedFrameRate_30() const { return ___forcedFrameRate_30; }
	inline int32_t* get_address_of_forcedFrameRate_30() { return &___forcedFrameRate_30; }
	inline void set_forcedFrameRate_30(int32_t value)
	{
		___forcedFrameRate_30 = value;
	}

	inline static int32_t get_offset_of_background_31() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___background_31)); }
	inline bool get_background_31() const { return ___background_31; }
	inline bool* get_address_of_background_31() { return &___background_31; }
	inline void set_background_31(bool value)
	{
		___background_31 = value;
	}

	inline static int32_t get_offset_of_backgroundColor_32() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___backgroundColor_32)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_backgroundColor_32() const { return ___backgroundColor_32; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_backgroundColor_32() { return &___backgroundColor_32; }
	inline void set_backgroundColor_32(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___backgroundColor_32 = value;
	}

	inline static int32_t get_offset_of_backgroundPadding_33() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___backgroundPadding_33)); }
	inline int32_t get_backgroundPadding_33() const { return ___backgroundPadding_33; }
	inline int32_t* get_address_of_backgroundPadding_33() { return &___backgroundPadding_33; }
	inline void set_backgroundPadding_33(int32_t value)
	{
		___backgroundPadding_33 = value;
	}

	inline static int32_t get_offset_of_shadow_34() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___shadow_34)); }
	inline bool get_shadow_34() const { return ___shadow_34; }
	inline bool* get_address_of_shadow_34() { return &___shadow_34; }
	inline void set_shadow_34(bool value)
	{
		___shadow_34 = value;
	}

	inline static int32_t get_offset_of_shadowColor_35() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___shadowColor_35)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_shadowColor_35() const { return ___shadowColor_35; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_shadowColor_35() { return &___shadowColor_35; }
	inline void set_shadowColor_35(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___shadowColor_35 = value;
	}

	inline static int32_t get_offset_of_shadowDistance_36() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___shadowDistance_36)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_shadowDistance_36() const { return ___shadowDistance_36; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_shadowDistance_36() { return &___shadowDistance_36; }
	inline void set_shadowDistance_36(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___shadowDistance_36 = value;
	}

	inline static int32_t get_offset_of_outline_37() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___outline_37)); }
	inline bool get_outline_37() const { return ___outline_37; }
	inline bool* get_address_of_outline_37() { return &___outline_37; }
	inline void set_outline_37(bool value)
	{
		___outline_37 = value;
	}

	inline static int32_t get_offset_of_outlineColor_38() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___outlineColor_38)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_outlineColor_38() const { return ___outlineColor_38; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_outlineColor_38() { return &___outlineColor_38; }
	inline void set_outlineColor_38(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___outlineColor_38 = value;
	}

	inline static int32_t get_offset_of_outlineDistance_39() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___outlineDistance_39)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_outlineDistance_39() const { return ___outlineDistance_39; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_outlineDistance_39() { return &___outlineDistance_39; }
	inline void set_outlineDistance_39(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___outlineDistance_39 = value;
	}

	inline static int32_t get_offset_of_autoScale_40() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___autoScale_40)); }
	inline bool get_autoScale_40() const { return ___autoScale_40; }
	inline bool* get_address_of_autoScale_40() { return &___autoScale_40; }
	inline void set_autoScale_40(bool value)
	{
		___autoScale_40 = value;
	}

	inline static int32_t get_offset_of_scaleFactor_41() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___scaleFactor_41)); }
	inline float get_scaleFactor_41() const { return ___scaleFactor_41; }
	inline float* get_address_of_scaleFactor_41() { return &___scaleFactor_41; }
	inline void set_scaleFactor_41(float value)
	{
		___scaleFactor_41 = value;
	}

	inline static int32_t get_offset_of_labelsFont_42() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___labelsFont_42)); }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * get_labelsFont_42() const { return ___labelsFont_42; }
	inline Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 ** get_address_of_labelsFont_42() { return &___labelsFont_42; }
	inline void set_labelsFont_42(Font_t1EDE54AF557272BE314EB4B40EFA50CEB353CA26 * value)
	{
		___labelsFont_42 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___labelsFont_42), (void*)value);
	}

	inline static int32_t get_offset_of_fontSize_43() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___fontSize_43)); }
	inline int32_t get_fontSize_43() const { return ___fontSize_43; }
	inline int32_t* get_address_of_fontSize_43() { return &___fontSize_43; }
	inline void set_fontSize_43(int32_t value)
	{
		___fontSize_43 = value;
	}

	inline static int32_t get_offset_of_lineSpacing_44() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___lineSpacing_44)); }
	inline float get_lineSpacing_44() const { return ___lineSpacing_44; }
	inline float* get_address_of_lineSpacing_44() { return &___lineSpacing_44; }
	inline void set_lineSpacing_44(float value)
	{
		___lineSpacing_44 = value;
	}

	inline static int32_t get_offset_of_countersSpacing_45() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___countersSpacing_45)); }
	inline int32_t get_countersSpacing_45() const { return ___countersSpacing_45; }
	inline int32_t* get_address_of_countersSpacing_45() { return &___countersSpacing_45; }
	inline void set_countersSpacing_45(int32_t value)
	{
		___countersSpacing_45 = value;
	}

	inline static int32_t get_offset_of_paddingOffset_46() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___paddingOffset_46)); }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  get_paddingOffset_46() const { return ___paddingOffset_46; }
	inline Vector2_tA85D2DD88578276CA8A8796756458277E72D073D * get_address_of_paddingOffset_46() { return &___paddingOffset_46; }
	inline void set_paddingOffset_46(Vector2_tA85D2DD88578276CA8A8796756458277E72D073D  value)
	{
		___paddingOffset_46 = value;
	}

	inline static int32_t get_offset_of_pixelPerfect_47() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___pixelPerfect_47)); }
	inline bool get_pixelPerfect_47() const { return ___pixelPerfect_47; }
	inline bool* get_address_of_pixelPerfect_47() { return &___pixelPerfect_47; }
	inline void set_pixelPerfect_47(bool value)
	{
		___pixelPerfect_47 = value;
	}

	inline static int32_t get_offset_of_sortingOrder_48() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54, ___sortingOrder_48)); }
	inline int32_t get_sortingOrder_48() const { return ___sortingOrder_48; }
	inline int32_t* get_address_of_sortingOrder_48() { return &___sortingOrder_48; }
	inline void set_sortingOrder_48(int32_t value)
	{
		___sortingOrder_48 = value;
	}
};

struct AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54_StaticFields
{
public:
	// CodeStage.AdvancedFPSCounter.AFPSCounter CodeStage.AdvancedFPSCounter.AFPSCounter::<Instance>k__BackingField
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 * ___U3CInstanceU3Ek__BackingField_49;

public:
	inline static int32_t get_offset_of_U3CInstanceU3Ek__BackingField_49() { return static_cast<int32_t>(offsetof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54_StaticFields, ___U3CInstanceU3Ek__BackingField_49)); }
	inline AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 * get_U3CInstanceU3Ek__BackingField_49() const { return ___U3CInstanceU3Ek__BackingField_49; }
	inline AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 ** get_address_of_U3CInstanceU3Ek__BackingField_49() { return &___U3CInstanceU3Ek__BackingField_49; }
	inline void set_U3CInstanceU3Ek__BackingField_49(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54 * value)
	{
		___U3CInstanceU3Ek__BackingField_49 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___U3CInstanceU3Ek__BackingField_49), (void*)value);
	}
};


// CodeStage.AdvancedFPSCounter.APITester
struct APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 CodeStage.AdvancedFPSCounter.APITester::selectedTab
	int32_t ___selectedTab_4;
	// System.String[] CodeStage.AdvancedFPSCounter.APITester::tabs
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___tabs_5;
	// CodeStage.AdvancedFPSCounter.FPSLevel CodeStage.AdvancedFPSCounter.APITester::currentFPSLevel
	uint8_t ___currentFPSLevel_6;

public:
	inline static int32_t get_offset_of_selectedTab_4() { return static_cast<int32_t>(offsetof(APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6, ___selectedTab_4)); }
	inline int32_t get_selectedTab_4() const { return ___selectedTab_4; }
	inline int32_t* get_address_of_selectedTab_4() { return &___selectedTab_4; }
	inline void set_selectedTab_4(int32_t value)
	{
		___selectedTab_4 = value;
	}

	inline static int32_t get_offset_of_tabs_5() { return static_cast<int32_t>(offsetof(APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6, ___tabs_5)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_tabs_5() const { return ___tabs_5; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_tabs_5() { return &___tabs_5; }
	inline void set_tabs_5(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___tabs_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___tabs_5), (void*)value);
	}

	inline static int32_t get_offset_of_currentFPSLevel_6() { return static_cast<int32_t>(offsetof(APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6, ___currentFPSLevel_6)); }
	inline uint8_t get_currentFPSLevel_6() const { return ___currentFPSLevel_6; }
	inline uint8_t* get_address_of_currentFPSLevel_6() { return &___currentFPSLevel_6; }
	inline void set_currentFPSLevel_6(uint8_t value)
	{
		___currentFPSLevel_6 = value;
	}
};


// CodeStage.AdvancedFPSCounter.Utils.AFPSRenderRecorder
struct AFPSRenderRecorder_tAB8806BA73AA09300A7CF90219F9E7F1085A4E0F  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Boolean CodeStage.AdvancedFPSCounter.Utils.AFPSRenderRecorder::recording
	bool ___recording_4;
	// System.Single CodeStage.AdvancedFPSCounter.Utils.AFPSRenderRecorder::renderTime
	float ___renderTime_5;

public:
	inline static int32_t get_offset_of_recording_4() { return static_cast<int32_t>(offsetof(AFPSRenderRecorder_tAB8806BA73AA09300A7CF90219F9E7F1085A4E0F, ___recording_4)); }
	inline bool get_recording_4() const { return ___recording_4; }
	inline bool* get_address_of_recording_4() { return &___recording_4; }
	inline void set_recording_4(bool value)
	{
		___recording_4 = value;
	}

	inline static int32_t get_offset_of_renderTime_5() { return static_cast<int32_t>(offsetof(AFPSRenderRecorder_tAB8806BA73AA09300A7CF90219F9E7F1085A4E0F, ___renderTime_5)); }
	inline float get_renderTime_5() const { return ___renderTime_5; }
	inline float* get_address_of_renderTime_5() { return &___renderTime_5; }
	inline void set_renderTime_5(float value)
	{
		___renderTime_5 = value;
	}
};


// ConvertToLineMesh
struct ConvertToLineMesh_tD6DEC04CC1271CEECEC3587122270D16FA7BD46A  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Mesh ConvertToLineMesh::mesh
	Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * ___mesh_4;

public:
	inline static int32_t get_offset_of_mesh_4() { return static_cast<int32_t>(offsetof(ConvertToLineMesh_tD6DEC04CC1271CEECEC3587122270D16FA7BD46A, ___mesh_4)); }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * get_mesh_4() const { return ___mesh_4; }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C ** get_address_of_mesh_4() { return &___mesh_4; }
	inline void set_mesh_4(Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * value)
	{
		___mesh_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___mesh_4), (void*)value);
	}
};


// ConvertToPointMesh
struct ConvertToPointMesh_t5FE8AE962B066A59AAAE16EB6FDE9426BB4E00FB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Mesh ConvertToPointMesh::mesh
	Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * ___mesh_4;

public:
	inline static int32_t get_offset_of_mesh_4() { return static_cast<int32_t>(offsetof(ConvertToPointMesh_t5FE8AE962B066A59AAAE16EB6FDE9426BB4E00FB, ___mesh_4)); }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * get_mesh_4() const { return ___mesh_4; }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C ** get_address_of_mesh_4() { return &___mesh_4; }
	inline void set_mesh_4(Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * value)
	{
		___mesh_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___mesh_4), (void*)value);
	}
};


// DIDIDI
struct DIDIDI_tAD03F2DE79252B98EF831C3E629BF14E915BBDBC  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject DIDIDI::PanelMenu
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___PanelMenu_4;

public:
	inline static int32_t get_offset_of_PanelMenu_4() { return static_cast<int32_t>(offsetof(DIDIDI_tAD03F2DE79252B98EF831C3E629BF14E915BBDBC, ___PanelMenu_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_PanelMenu_4() const { return ___PanelMenu_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_PanelMenu_4() { return &___PanelMenu_4; }
	inline void set_PanelMenu_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___PanelMenu_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PanelMenu_4), (void*)value);
	}
};


// Item
struct Item_t1FD274D610B07F7F6E6AA093A93FB9E32210D36E  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// ItemInfo Item::itemInfo
	ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974 * ___itemInfo_4;
	// UnityEngine.GameObject Item::itemGameObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___itemGameObject_5;

public:
	inline static int32_t get_offset_of_itemInfo_4() { return static_cast<int32_t>(offsetof(Item_t1FD274D610B07F7F6E6AA093A93FB9E32210D36E, ___itemInfo_4)); }
	inline ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974 * get_itemInfo_4() const { return ___itemInfo_4; }
	inline ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974 ** get_address_of_itemInfo_4() { return &___itemInfo_4; }
	inline void set_itemInfo_4(ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974 * value)
	{
		___itemInfo_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___itemInfo_4), (void*)value);
	}

	inline static int32_t get_offset_of_itemGameObject_5() { return static_cast<int32_t>(offsetof(Item_t1FD274D610B07F7F6E6AA093A93FB9E32210D36E, ___itemGameObject_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_itemGameObject_5() const { return ___itemGameObject_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_itemGameObject_5() { return &___itemGameObject_5; }
	inline void set_itemGameObject_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___itemGameObject_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___itemGameObject_5), (void*)value);
	}
};


// Menu
struct Menu_t7D066A010AF240D53C2DDA2B05DF31FD0B5F3129  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String Menu::menuName
	String_t* ___menuName_4;
	// System.Boolean Menu::open
	bool ___open_5;

public:
	inline static int32_t get_offset_of_menuName_4() { return static_cast<int32_t>(offsetof(Menu_t7D066A010AF240D53C2DDA2B05DF31FD0B5F3129, ___menuName_4)); }
	inline String_t* get_menuName_4() const { return ___menuName_4; }
	inline String_t** get_address_of_menuName_4() { return &___menuName_4; }
	inline void set_menuName_4(String_t* value)
	{
		___menuName_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___menuName_4), (void*)value);
	}

	inline static int32_t get_offset_of_open_5() { return static_cast<int32_t>(offsetof(Menu_t7D066A010AF240D53C2DDA2B05DF31FD0B5F3129, ___open_5)); }
	inline bool get_open_5() const { return ___open_5; }
	inline bool* get_address_of_open_5() { return &___open_5; }
	inline void set_open_5(bool value)
	{
		___open_5 = value;
	}
};


// MenuManager
struct MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Menu[] MenuManager::menus
	MenuU5BU5D_tD3192425CB52CD24F8F7ED73B1F63328723280A2* ___menus_5;

public:
	inline static int32_t get_offset_of_menus_5() { return static_cast<int32_t>(offsetof(MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5, ___menus_5)); }
	inline MenuU5BU5D_tD3192425CB52CD24F8F7ED73B1F63328723280A2* get_menus_5() const { return ___menus_5; }
	inline MenuU5BU5D_tD3192425CB52CD24F8F7ED73B1F63328723280A2** get_address_of_menus_5() { return &___menus_5; }
	inline void set_menus_5(MenuU5BU5D_tD3192425CB52CD24F8F7ED73B1F63328723280A2* value)
	{
		___menus_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___menus_5), (void*)value);
	}
};

struct MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5_StaticFields
{
public:
	// MenuManager MenuManager::Instance
	MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5 * ___Instance_4;

public:
	inline static int32_t get_offset_of_Instance_4() { return static_cast<int32_t>(offsetof(MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5_StaticFields, ___Instance_4)); }
	inline MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5 * get_Instance_4() const { return ___Instance_4; }
	inline MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5 ** get_address_of_Instance_4() { return &___Instance_4; }
	inline void set_Instance_4(MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5 * value)
	{
		___Instance_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Instance_4), (void*)value);
	}
};


// Photon.Pun.MonoBehaviourPun
struct MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Photon.Pun.PhotonView Photon.Pun.MonoBehaviourPun::pvCache
	PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * ___pvCache_4;

public:
	inline static int32_t get_offset_of_pvCache_4() { return static_cast<int32_t>(offsetof(MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A, ___pvCache_4)); }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * get_pvCache_4() const { return ___pvCache_4; }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B ** get_address_of_pvCache_4() { return &___pvCache_4; }
	inline void set_pvCache_4(PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * value)
	{
		___pvCache_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___pvCache_4), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.ButtonInsideScrollList
struct ButtonInsideScrollList_t255DA2A0A1585550226BFFF4F314BBD685827CA8  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.ScrollRect Photon.Pun.UtilityScripts.ButtonInsideScrollList::scrollRect
	ScrollRect_tAD21D8FB1D33789C39BF4E4CD5CD012D9BD7DD51 * ___scrollRect_4;

public:
	inline static int32_t get_offset_of_scrollRect_4() { return static_cast<int32_t>(offsetof(ButtonInsideScrollList_t255DA2A0A1585550226BFFF4F314BBD685827CA8, ___scrollRect_4)); }
	inline ScrollRect_tAD21D8FB1D33789C39BF4E4CD5CD012D9BD7DD51 * get_scrollRect_4() const { return ___scrollRect_4; }
	inline ScrollRect_tAD21D8FB1D33789C39BF4E4CD5CD012D9BD7DD51 ** get_address_of_scrollRect_4() { return &___scrollRect_4; }
	inline void set_scrollRect_4(ScrollRect_tAD21D8FB1D33789C39BF4E4CD5CD012D9BD7DD51 * value)
	{
		___scrollRect_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___scrollRect_4), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.EventSystemSpawner
struct EventSystemSpawner_t3AACFD4D822CE099002B524BFFA902E39CC634ED  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition
struct GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.Toggle Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition::toggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___toggle_4;
	// UnityEngine.UI.Graphic Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition::_graphic
	Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * ____graphic_5;
	// UnityEngine.Color Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition::NormalOnColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___NormalOnColor_6;
	// UnityEngine.Color Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition::NormalOffColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___NormalOffColor_7;
	// UnityEngine.Color Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition::HoverOnColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___HoverOnColor_8;
	// UnityEngine.Color Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition::HoverOffColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___HoverOffColor_9;
	// System.Boolean Photon.Pun.UtilityScripts.GraphicToggleIsOnTransition::isHover
	bool ___isHover_10;

public:
	inline static int32_t get_offset_of_toggle_4() { return static_cast<int32_t>(offsetof(GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433, ___toggle_4)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_toggle_4() const { return ___toggle_4; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_toggle_4() { return &___toggle_4; }
	inline void set_toggle_4(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___toggle_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___toggle_4), (void*)value);
	}

	inline static int32_t get_offset_of__graphic_5() { return static_cast<int32_t>(offsetof(GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433, ____graphic_5)); }
	inline Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * get__graphic_5() const { return ____graphic_5; }
	inline Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 ** get_address_of__graphic_5() { return &____graphic_5; }
	inline void set__graphic_5(Graphic_tBA2C3EF11D3DAEBB57F6879AB0BB4F8BD40D00D8 * value)
	{
		____graphic_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____graphic_5), (void*)value);
	}

	inline static int32_t get_offset_of_NormalOnColor_6() { return static_cast<int32_t>(offsetof(GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433, ___NormalOnColor_6)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_NormalOnColor_6() const { return ___NormalOnColor_6; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_NormalOnColor_6() { return &___NormalOnColor_6; }
	inline void set_NormalOnColor_6(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___NormalOnColor_6 = value;
	}

	inline static int32_t get_offset_of_NormalOffColor_7() { return static_cast<int32_t>(offsetof(GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433, ___NormalOffColor_7)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_NormalOffColor_7() const { return ___NormalOffColor_7; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_NormalOffColor_7() { return &___NormalOffColor_7; }
	inline void set_NormalOffColor_7(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___NormalOffColor_7 = value;
	}

	inline static int32_t get_offset_of_HoverOnColor_8() { return static_cast<int32_t>(offsetof(GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433, ___HoverOnColor_8)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_HoverOnColor_8() const { return ___HoverOnColor_8; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_HoverOnColor_8() { return &___HoverOnColor_8; }
	inline void set_HoverOnColor_8(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___HoverOnColor_8 = value;
	}

	inline static int32_t get_offset_of_HoverOffColor_9() { return static_cast<int32_t>(offsetof(GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433, ___HoverOffColor_9)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_HoverOffColor_9() const { return ___HoverOffColor_9; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_HoverOffColor_9() { return &___HoverOffColor_9; }
	inline void set_HoverOffColor_9(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___HoverOffColor_9 = value;
	}

	inline static int32_t get_offset_of_isHover_10() { return static_cast<int32_t>(offsetof(GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433, ___isHover_10)); }
	inline bool get_isHover_10() const { return ___isHover_10; }
	inline bool* get_address_of_isHover_10() { return &___isHover_10; }
	inline void set_isHover_10(bool value)
	{
		___isHover_10 = value;
	}
};


// Photon.Pun.UtilityScripts.OnClickInstantiate
struct OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.EventSystems.PointerEventData/InputButton Photon.Pun.UtilityScripts.OnClickInstantiate::Button
	int32_t ___Button_4;
	// UnityEngine.KeyCode Photon.Pun.UtilityScripts.OnClickInstantiate::ModifierKey
	int32_t ___ModifierKey_5;
	// UnityEngine.GameObject Photon.Pun.UtilityScripts.OnClickInstantiate::Prefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___Prefab_6;
	// Photon.Pun.UtilityScripts.OnClickInstantiate/InstantiateOption Photon.Pun.UtilityScripts.OnClickInstantiate::InstantiateType
	int32_t ___InstantiateType_7;

public:
	inline static int32_t get_offset_of_Button_4() { return static_cast<int32_t>(offsetof(OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4, ___Button_4)); }
	inline int32_t get_Button_4() const { return ___Button_4; }
	inline int32_t* get_address_of_Button_4() { return &___Button_4; }
	inline void set_Button_4(int32_t value)
	{
		___Button_4 = value;
	}

	inline static int32_t get_offset_of_ModifierKey_5() { return static_cast<int32_t>(offsetof(OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4, ___ModifierKey_5)); }
	inline int32_t get_ModifierKey_5() const { return ___ModifierKey_5; }
	inline int32_t* get_address_of_ModifierKey_5() { return &___ModifierKey_5; }
	inline void set_ModifierKey_5(int32_t value)
	{
		___ModifierKey_5 = value;
	}

	inline static int32_t get_offset_of_Prefab_6() { return static_cast<int32_t>(offsetof(OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4, ___Prefab_6)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_Prefab_6() const { return ___Prefab_6; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_Prefab_6() { return &___Prefab_6; }
	inline void set_Prefab_6(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___Prefab_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Prefab_6), (void*)value);
	}

	inline static int32_t get_offset_of_InstantiateType_7() { return static_cast<int32_t>(offsetof(OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4, ___InstantiateType_7)); }
	inline int32_t get_InstantiateType_7() const { return ___InstantiateType_7; }
	inline int32_t* get_address_of_InstantiateType_7() { return &___InstantiateType_7; }
	inline void set_InstantiateType_7(int32_t value)
	{
		___InstantiateType_7 = value;
	}
};


// Photon.Pun.UtilityScripts.OnEscapeQuit
struct OnEscapeQuit_tA10895B32C54F77B4DF1D2D2B731E8E746CE455B  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// Photon.Pun.UtilityScripts.OnJoinedInstantiate
struct OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Transform Photon.Pun.UtilityScripts.OnJoinedInstantiate::SpawnPosition
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___SpawnPosition_4;
	// Photon.Pun.UtilityScripts.OnJoinedInstantiate/SpawnSequence Photon.Pun.UtilityScripts.OnJoinedInstantiate::Sequence
	int32_t ___Sequence_5;
	// System.Collections.Generic.List`1<UnityEngine.Transform> Photon.Pun.UtilityScripts.OnJoinedInstantiate::SpawnPoints
	List_1_t4DBFD85DCFB946888856DBE52AC08C2AF69C4DBE * ___SpawnPoints_6;
	// System.Boolean Photon.Pun.UtilityScripts.OnJoinedInstantiate::UseRandomOffset
	bool ___UseRandomOffset_7;
	// System.Single Photon.Pun.UtilityScripts.OnJoinedInstantiate::RandomOffset
	float ___RandomOffset_8;
	// System.Collections.Generic.List`1<UnityEngine.GameObject> Photon.Pun.UtilityScripts.OnJoinedInstantiate::PrefabsToInstantiate
	List_1_t3D4152882C54B77C712688E910390D5C8E030463 * ___PrefabsToInstantiate_9;
	// System.Boolean Photon.Pun.UtilityScripts.OnJoinedInstantiate::autoSpawnObjects
	bool ___autoSpawnObjects_10;
	// System.Collections.Generic.Stack`1<UnityEngine.GameObject> Photon.Pun.UtilityScripts.OnJoinedInstantiate::SpawnedObjects
	Stack_1_t4DE78EEF92B4B81F045CED02BDB5FC458862E563 * ___SpawnedObjects_11;
	// System.Int32 Photon.Pun.UtilityScripts.OnJoinedInstantiate::lastUsedSpawnPointIndex
	int32_t ___lastUsedSpawnPointIndex_12;

public:
	inline static int32_t get_offset_of_SpawnPosition_4() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___SpawnPosition_4)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_SpawnPosition_4() const { return ___SpawnPosition_4; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_SpawnPosition_4() { return &___SpawnPosition_4; }
	inline void set_SpawnPosition_4(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___SpawnPosition_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___SpawnPosition_4), (void*)value);
	}

	inline static int32_t get_offset_of_Sequence_5() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___Sequence_5)); }
	inline int32_t get_Sequence_5() const { return ___Sequence_5; }
	inline int32_t* get_address_of_Sequence_5() { return &___Sequence_5; }
	inline void set_Sequence_5(int32_t value)
	{
		___Sequence_5 = value;
	}

	inline static int32_t get_offset_of_SpawnPoints_6() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___SpawnPoints_6)); }
	inline List_1_t4DBFD85DCFB946888856DBE52AC08C2AF69C4DBE * get_SpawnPoints_6() const { return ___SpawnPoints_6; }
	inline List_1_t4DBFD85DCFB946888856DBE52AC08C2AF69C4DBE ** get_address_of_SpawnPoints_6() { return &___SpawnPoints_6; }
	inline void set_SpawnPoints_6(List_1_t4DBFD85DCFB946888856DBE52AC08C2AF69C4DBE * value)
	{
		___SpawnPoints_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___SpawnPoints_6), (void*)value);
	}

	inline static int32_t get_offset_of_UseRandomOffset_7() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___UseRandomOffset_7)); }
	inline bool get_UseRandomOffset_7() const { return ___UseRandomOffset_7; }
	inline bool* get_address_of_UseRandomOffset_7() { return &___UseRandomOffset_7; }
	inline void set_UseRandomOffset_7(bool value)
	{
		___UseRandomOffset_7 = value;
	}

	inline static int32_t get_offset_of_RandomOffset_8() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___RandomOffset_8)); }
	inline float get_RandomOffset_8() const { return ___RandomOffset_8; }
	inline float* get_address_of_RandomOffset_8() { return &___RandomOffset_8; }
	inline void set_RandomOffset_8(float value)
	{
		___RandomOffset_8 = value;
	}

	inline static int32_t get_offset_of_PrefabsToInstantiate_9() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___PrefabsToInstantiate_9)); }
	inline List_1_t3D4152882C54B77C712688E910390D5C8E030463 * get_PrefabsToInstantiate_9() const { return ___PrefabsToInstantiate_9; }
	inline List_1_t3D4152882C54B77C712688E910390D5C8E030463 ** get_address_of_PrefabsToInstantiate_9() { return &___PrefabsToInstantiate_9; }
	inline void set_PrefabsToInstantiate_9(List_1_t3D4152882C54B77C712688E910390D5C8E030463 * value)
	{
		___PrefabsToInstantiate_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PrefabsToInstantiate_9), (void*)value);
	}

	inline static int32_t get_offset_of_autoSpawnObjects_10() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___autoSpawnObjects_10)); }
	inline bool get_autoSpawnObjects_10() const { return ___autoSpawnObjects_10; }
	inline bool* get_address_of_autoSpawnObjects_10() { return &___autoSpawnObjects_10; }
	inline void set_autoSpawnObjects_10(bool value)
	{
		___autoSpawnObjects_10 = value;
	}

	inline static int32_t get_offset_of_SpawnedObjects_11() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___SpawnedObjects_11)); }
	inline Stack_1_t4DE78EEF92B4B81F045CED02BDB5FC458862E563 * get_SpawnedObjects_11() const { return ___SpawnedObjects_11; }
	inline Stack_1_t4DE78EEF92B4B81F045CED02BDB5FC458862E563 ** get_address_of_SpawnedObjects_11() { return &___SpawnedObjects_11; }
	inline void set_SpawnedObjects_11(Stack_1_t4DE78EEF92B4B81F045CED02BDB5FC458862E563 * value)
	{
		___SpawnedObjects_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___SpawnedObjects_11), (void*)value);
	}

	inline static int32_t get_offset_of_lastUsedSpawnPointIndex_12() { return static_cast<int32_t>(offsetof(OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6, ___lastUsedSpawnPointIndex_12)); }
	inline int32_t get_lastUsedSpawnPointIndex_12() const { return ___lastUsedSpawnPointIndex_12; }
	inline int32_t* get_address_of_lastUsedSpawnPointIndex_12() { return &___lastUsedSpawnPointIndex_12; }
	inline void set_lastUsedSpawnPointIndex_12(int32_t value)
	{
		___lastUsedSpawnPointIndex_12 = value;
	}
};


// Photon.Pun.UtilityScripts.OnPointerOverTooltip
struct OnPointerOverTooltip_tBE4835AFC7D43B58F3514A1309456F3782680549  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// Photon.Pun.UtilityScripts.OnStartDelete
struct OnStartDelete_t642BD77F5CE819CEB868BD8DE327A124A3CDDEAE  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// Photon.Pun.UtilityScripts.PhotonTeamsManager
struct PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Collections.Generic.List`1<Photon.Pun.UtilityScripts.PhotonTeam> Photon.Pun.UtilityScripts.PhotonTeamsManager::teamsList
	List_1_tB346AB19D0AE6924D557CAA8467716755339C5BB * ___teamsList_4;
	// System.Collections.Generic.Dictionary`2<System.Byte,Photon.Pun.UtilityScripts.PhotonTeam> Photon.Pun.UtilityScripts.PhotonTeamsManager::teamsByCode
	Dictionary_2_tDD5B0692C30925234A9EC99B99C387190BED0640 * ___teamsByCode_5;
	// System.Collections.Generic.Dictionary`2<System.String,Photon.Pun.UtilityScripts.PhotonTeam> Photon.Pun.UtilityScripts.PhotonTeamsManager::teamsByName
	Dictionary_2_t7B02F6B4482FAECE12CC3A00B152027E0E61E653 * ___teamsByName_6;
	// System.Collections.Generic.Dictionary`2<System.Byte,System.Collections.Generic.HashSet`1<Photon.Realtime.Player>> Photon.Pun.UtilityScripts.PhotonTeamsManager::playersPerTeam
	Dictionary_2_tDC389DE02A0FC1608DCA730577C55CF6A7E4921E * ___playersPerTeam_7;

public:
	inline static int32_t get_offset_of_teamsList_4() { return static_cast<int32_t>(offsetof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06, ___teamsList_4)); }
	inline List_1_tB346AB19D0AE6924D557CAA8467716755339C5BB * get_teamsList_4() const { return ___teamsList_4; }
	inline List_1_tB346AB19D0AE6924D557CAA8467716755339C5BB ** get_address_of_teamsList_4() { return &___teamsList_4; }
	inline void set_teamsList_4(List_1_tB346AB19D0AE6924D557CAA8467716755339C5BB * value)
	{
		___teamsList_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___teamsList_4), (void*)value);
	}

	inline static int32_t get_offset_of_teamsByCode_5() { return static_cast<int32_t>(offsetof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06, ___teamsByCode_5)); }
	inline Dictionary_2_tDD5B0692C30925234A9EC99B99C387190BED0640 * get_teamsByCode_5() const { return ___teamsByCode_5; }
	inline Dictionary_2_tDD5B0692C30925234A9EC99B99C387190BED0640 ** get_address_of_teamsByCode_5() { return &___teamsByCode_5; }
	inline void set_teamsByCode_5(Dictionary_2_tDD5B0692C30925234A9EC99B99C387190BED0640 * value)
	{
		___teamsByCode_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___teamsByCode_5), (void*)value);
	}

	inline static int32_t get_offset_of_teamsByName_6() { return static_cast<int32_t>(offsetof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06, ___teamsByName_6)); }
	inline Dictionary_2_t7B02F6B4482FAECE12CC3A00B152027E0E61E653 * get_teamsByName_6() const { return ___teamsByName_6; }
	inline Dictionary_2_t7B02F6B4482FAECE12CC3A00B152027E0E61E653 ** get_address_of_teamsByName_6() { return &___teamsByName_6; }
	inline void set_teamsByName_6(Dictionary_2_t7B02F6B4482FAECE12CC3A00B152027E0E61E653 * value)
	{
		___teamsByName_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___teamsByName_6), (void*)value);
	}

	inline static int32_t get_offset_of_playersPerTeam_7() { return static_cast<int32_t>(offsetof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06, ___playersPerTeam_7)); }
	inline Dictionary_2_tDC389DE02A0FC1608DCA730577C55CF6A7E4921E * get_playersPerTeam_7() const { return ___playersPerTeam_7; }
	inline Dictionary_2_tDC389DE02A0FC1608DCA730577C55CF6A7E4921E ** get_address_of_playersPerTeam_7() { return &___playersPerTeam_7; }
	inline void set_playersPerTeam_7(Dictionary_2_tDC389DE02A0FC1608DCA730577C55CF6A7E4921E * value)
	{
		___playersPerTeam_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___playersPerTeam_7), (void*)value);
	}
};

struct PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields
{
public:
	// System.Action`2<Photon.Realtime.Player,Photon.Pun.UtilityScripts.PhotonTeam> Photon.Pun.UtilityScripts.PhotonTeamsManager::PlayerJoinedTeam
	Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 * ___PlayerJoinedTeam_9;
	// System.Action`2<Photon.Realtime.Player,Photon.Pun.UtilityScripts.PhotonTeam> Photon.Pun.UtilityScripts.PhotonTeamsManager::PlayerLeftTeam
	Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 * ___PlayerLeftTeam_10;
	// Photon.Pun.UtilityScripts.PhotonTeamsManager Photon.Pun.UtilityScripts.PhotonTeamsManager::instance
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06 * ___instance_11;

public:
	inline static int32_t get_offset_of_PlayerJoinedTeam_9() { return static_cast<int32_t>(offsetof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields, ___PlayerJoinedTeam_9)); }
	inline Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 * get_PlayerJoinedTeam_9() const { return ___PlayerJoinedTeam_9; }
	inline Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 ** get_address_of_PlayerJoinedTeam_9() { return &___PlayerJoinedTeam_9; }
	inline void set_PlayerJoinedTeam_9(Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 * value)
	{
		___PlayerJoinedTeam_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlayerJoinedTeam_9), (void*)value);
	}

	inline static int32_t get_offset_of_PlayerLeftTeam_10() { return static_cast<int32_t>(offsetof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields, ___PlayerLeftTeam_10)); }
	inline Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 * get_PlayerLeftTeam_10() const { return ___PlayerLeftTeam_10; }
	inline Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 ** get_address_of_PlayerLeftTeam_10() { return &___PlayerLeftTeam_10; }
	inline void set_PlayerLeftTeam_10(Action_2_t1F65F0343D40C78280E60ECD250AF8B54A4ACD55 * value)
	{
		___PlayerLeftTeam_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlayerLeftTeam_10), (void*)value);
	}

	inline static int32_t get_offset_of_instance_11() { return static_cast<int32_t>(offsetof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields, ___instance_11)); }
	inline PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06 * get_instance_11() const { return ___instance_11; }
	inline PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06 ** get_address_of_instance_11() { return &___instance_11; }
	inline void set_instance_11(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06 * value)
	{
		___instance_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___instance_11), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.PunPlayerScores
struct PunPlayerScores_tFD956FEE88DB4C0CCA3EB963F99BC67B8EE4BDE2  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// Photon.Pun.UtilityScripts.TabViewManager
struct TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.ToggleGroup Photon.Pun.UtilityScripts.TabViewManager::ToggleGroup
	ToggleGroup_t11E2B254D3C968C7D0DA11C606CC06D7D7F0D786 * ___ToggleGroup_4;
	// Photon.Pun.UtilityScripts.TabViewManager/Tab[] Photon.Pun.UtilityScripts.TabViewManager::Tabs
	TabU5BU5D_tA7CC50FBDFCBD2045800D2F9A902DE5573A54117* ___Tabs_5;
	// Photon.Pun.UtilityScripts.TabViewManager/TabChangeEvent Photon.Pun.UtilityScripts.TabViewManager::OnTabChanged
	TabChangeEvent_t0828873D6112CB183DE5B2EB5EB05DCDB7FFBD29 * ___OnTabChanged_6;
	// Photon.Pun.UtilityScripts.TabViewManager/Tab Photon.Pun.UtilityScripts.TabViewManager::CurrentTab
	Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A * ___CurrentTab_7;
	// System.Collections.Generic.Dictionary`2<UnityEngine.UI.Toggle,Photon.Pun.UtilityScripts.TabViewManager/Tab> Photon.Pun.UtilityScripts.TabViewManager::Tab_lut
	Dictionary_2_t7244DB208519913604D9D45C9C4CF652AD267B54 * ___Tab_lut_8;

public:
	inline static int32_t get_offset_of_ToggleGroup_4() { return static_cast<int32_t>(offsetof(TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B, ___ToggleGroup_4)); }
	inline ToggleGroup_t11E2B254D3C968C7D0DA11C606CC06D7D7F0D786 * get_ToggleGroup_4() const { return ___ToggleGroup_4; }
	inline ToggleGroup_t11E2B254D3C968C7D0DA11C606CC06D7D7F0D786 ** get_address_of_ToggleGroup_4() { return &___ToggleGroup_4; }
	inline void set_ToggleGroup_4(ToggleGroup_t11E2B254D3C968C7D0DA11C606CC06D7D7F0D786 * value)
	{
		___ToggleGroup_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ToggleGroup_4), (void*)value);
	}

	inline static int32_t get_offset_of_Tabs_5() { return static_cast<int32_t>(offsetof(TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B, ___Tabs_5)); }
	inline TabU5BU5D_tA7CC50FBDFCBD2045800D2F9A902DE5573A54117* get_Tabs_5() const { return ___Tabs_5; }
	inline TabU5BU5D_tA7CC50FBDFCBD2045800D2F9A902DE5573A54117** get_address_of_Tabs_5() { return &___Tabs_5; }
	inline void set_Tabs_5(TabU5BU5D_tA7CC50FBDFCBD2045800D2F9A902DE5573A54117* value)
	{
		___Tabs_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Tabs_5), (void*)value);
	}

	inline static int32_t get_offset_of_OnTabChanged_6() { return static_cast<int32_t>(offsetof(TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B, ___OnTabChanged_6)); }
	inline TabChangeEvent_t0828873D6112CB183DE5B2EB5EB05DCDB7FFBD29 * get_OnTabChanged_6() const { return ___OnTabChanged_6; }
	inline TabChangeEvent_t0828873D6112CB183DE5B2EB5EB05DCDB7FFBD29 ** get_address_of_OnTabChanged_6() { return &___OnTabChanged_6; }
	inline void set_OnTabChanged_6(TabChangeEvent_t0828873D6112CB183DE5B2EB5EB05DCDB7FFBD29 * value)
	{
		___OnTabChanged_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OnTabChanged_6), (void*)value);
	}

	inline static int32_t get_offset_of_CurrentTab_7() { return static_cast<int32_t>(offsetof(TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B, ___CurrentTab_7)); }
	inline Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A * get_CurrentTab_7() const { return ___CurrentTab_7; }
	inline Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A ** get_address_of_CurrentTab_7() { return &___CurrentTab_7; }
	inline void set_CurrentTab_7(Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A * value)
	{
		___CurrentTab_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___CurrentTab_7), (void*)value);
	}

	inline static int32_t get_offset_of_Tab_lut_8() { return static_cast<int32_t>(offsetof(TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B, ___Tab_lut_8)); }
	inline Dictionary_2_t7244DB208519913604D9D45C9C4CF652AD267B54 * get_Tab_lut_8() const { return ___Tab_lut_8; }
	inline Dictionary_2_t7244DB208519913604D9D45C9C4CF652AD267B54 ** get_address_of_Tab_lut_8() { return &___Tab_lut_8; }
	inline void set_Tab_lut_8(Dictionary_2_t7244DB208519913604D9D45C9C4CF652AD267B54 * value)
	{
		___Tab_lut_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Tab_lut_8), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.TextButtonTransition
struct TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.Text Photon.Pun.UtilityScripts.TextButtonTransition::_text
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ____text_4;
	// UnityEngine.UI.Selectable Photon.Pun.UtilityScripts.TextButtonTransition::Selectable
	Selectable_tAA9065030FE0468018DEC880302F95FEA9C0133A * ___Selectable_5;
	// UnityEngine.Color Photon.Pun.UtilityScripts.TextButtonTransition::NormalColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___NormalColor_6;
	// UnityEngine.Color Photon.Pun.UtilityScripts.TextButtonTransition::HoverColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___HoverColor_7;

public:
	inline static int32_t get_offset_of__text_4() { return static_cast<int32_t>(offsetof(TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A, ____text_4)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get__text_4() const { return ____text_4; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of__text_4() { return &____text_4; }
	inline void set__text_4(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		____text_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____text_4), (void*)value);
	}

	inline static int32_t get_offset_of_Selectable_5() { return static_cast<int32_t>(offsetof(TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A, ___Selectable_5)); }
	inline Selectable_tAA9065030FE0468018DEC880302F95FEA9C0133A * get_Selectable_5() const { return ___Selectable_5; }
	inline Selectable_tAA9065030FE0468018DEC880302F95FEA9C0133A ** get_address_of_Selectable_5() { return &___Selectable_5; }
	inline void set_Selectable_5(Selectable_tAA9065030FE0468018DEC880302F95FEA9C0133A * value)
	{
		___Selectable_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Selectable_5), (void*)value);
	}

	inline static int32_t get_offset_of_NormalColor_6() { return static_cast<int32_t>(offsetof(TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A, ___NormalColor_6)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_NormalColor_6() const { return ___NormalColor_6; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_NormalColor_6() { return &___NormalColor_6; }
	inline void set_NormalColor_6(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___NormalColor_6 = value;
	}

	inline static int32_t get_offset_of_HoverColor_7() { return static_cast<int32_t>(offsetof(TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A, ___HoverColor_7)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_HoverColor_7() const { return ___HoverColor_7; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_HoverColor_7() { return &___HoverColor_7; }
	inline void set_HoverColor_7(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___HoverColor_7 = value;
	}
};


// Photon.Pun.UtilityScripts.TextToggleIsOnTransition
struct TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.Toggle Photon.Pun.UtilityScripts.TextToggleIsOnTransition::toggle
	Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * ___toggle_4;
	// UnityEngine.UI.Text Photon.Pun.UtilityScripts.TextToggleIsOnTransition::_text
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ____text_5;
	// UnityEngine.Color Photon.Pun.UtilityScripts.TextToggleIsOnTransition::NormalOnColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___NormalOnColor_6;
	// UnityEngine.Color Photon.Pun.UtilityScripts.TextToggleIsOnTransition::NormalOffColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___NormalOffColor_7;
	// UnityEngine.Color Photon.Pun.UtilityScripts.TextToggleIsOnTransition::HoverOnColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___HoverOnColor_8;
	// UnityEngine.Color Photon.Pun.UtilityScripts.TextToggleIsOnTransition::HoverOffColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___HoverOffColor_9;
	// System.Boolean Photon.Pun.UtilityScripts.TextToggleIsOnTransition::isHover
	bool ___isHover_10;

public:
	inline static int32_t get_offset_of_toggle_4() { return static_cast<int32_t>(offsetof(TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83, ___toggle_4)); }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * get_toggle_4() const { return ___toggle_4; }
	inline Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 ** get_address_of_toggle_4() { return &___toggle_4; }
	inline void set_toggle_4(Toggle_t9ADD572046F831945ED0E48A01B50FEA1CA52106 * value)
	{
		___toggle_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___toggle_4), (void*)value);
	}

	inline static int32_t get_offset_of__text_5() { return static_cast<int32_t>(offsetof(TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83, ____text_5)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get__text_5() const { return ____text_5; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of__text_5() { return &____text_5; }
	inline void set__text_5(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		____text_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&____text_5), (void*)value);
	}

	inline static int32_t get_offset_of_NormalOnColor_6() { return static_cast<int32_t>(offsetof(TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83, ___NormalOnColor_6)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_NormalOnColor_6() const { return ___NormalOnColor_6; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_NormalOnColor_6() { return &___NormalOnColor_6; }
	inline void set_NormalOnColor_6(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___NormalOnColor_6 = value;
	}

	inline static int32_t get_offset_of_NormalOffColor_7() { return static_cast<int32_t>(offsetof(TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83, ___NormalOffColor_7)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_NormalOffColor_7() const { return ___NormalOffColor_7; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_NormalOffColor_7() { return &___NormalOffColor_7; }
	inline void set_NormalOffColor_7(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___NormalOffColor_7 = value;
	}

	inline static int32_t get_offset_of_HoverOnColor_8() { return static_cast<int32_t>(offsetof(TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83, ___HoverOnColor_8)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_HoverOnColor_8() const { return ___HoverOnColor_8; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_HoverOnColor_8() { return &___HoverOnColor_8; }
	inline void set_HoverOnColor_8(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___HoverOnColor_8 = value;
	}

	inline static int32_t get_offset_of_HoverOffColor_9() { return static_cast<int32_t>(offsetof(TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83, ___HoverOffColor_9)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_HoverOffColor_9() const { return ___HoverOffColor_9; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_HoverOffColor_9() { return &___HoverOffColor_9; }
	inline void set_HoverOffColor_9(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___HoverOffColor_9 = value;
	}

	inline static int32_t get_offset_of_isHover_10() { return static_cast<int32_t>(offsetof(TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83, ___isHover_10)); }
	inline bool get_isHover_10() const { return ___isHover_10; }
	inline bool* get_address_of_isHover_10() { return &___isHover_10; }
	inline void set_isHover_10(bool value)
	{
		___isHover_10 = value;
	}
};


// PlayerGroundCheck
struct PlayerGroundCheck_tD335E73FDC4816ABAB3617C1F7065F1E074FFA2B  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// PlayerController PlayerGroundCheck::playerController
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85 * ___playerController_4;

public:
	inline static int32_t get_offset_of_playerController_4() { return static_cast<int32_t>(offsetof(PlayerGroundCheck_tD335E73FDC4816ABAB3617C1F7065F1E074FFA2B, ___playerController_4)); }
	inline PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85 * get_playerController_4() const { return ___playerController_4; }
	inline PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85 ** get_address_of_playerController_4() { return &___playerController_4; }
	inline void set_playerController_4(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85 * value)
	{
		___playerController_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___playerController_4), (void*)value);
	}
};


// PlayerManager
struct PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Photon.Pun.PhotonView PlayerManager::PV
	PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * ___PV_4;
	// UnityEngine.GameObject PlayerManager::controller
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___controller_5;

public:
	inline static int32_t get_offset_of_PV_4() { return static_cast<int32_t>(offsetof(PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271, ___PV_4)); }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * get_PV_4() const { return ___PV_4; }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B ** get_address_of_PV_4() { return &___PV_4; }
	inline void set_PV_4(PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * value)
	{
		___PV_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PV_4), (void*)value);
	}

	inline static int32_t get_offset_of_controller_5() { return static_cast<int32_t>(offsetof(PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271, ___controller_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_controller_5() const { return ___controller_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_controller_5() { return &___controller_5; }
	inline void set_controller_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___controller_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___controller_5), (void*)value);
	}
};


// RoomListItem
struct RoomListItem_t9EB55F749CE65437078175747E9F6F1CDCF959C2  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TMPro.TMP_Text RoomListItem::text
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___text_4;
	// Photon.Realtime.RoomInfo RoomListItem::info
	RoomInfo_t2FA7C04D0FB706F0313E7C91AEA598D7B1BDEBE2 * ___info_5;

public:
	inline static int32_t get_offset_of_text_4() { return static_cast<int32_t>(offsetof(RoomListItem_t9EB55F749CE65437078175747E9F6F1CDCF959C2, ___text_4)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_text_4() const { return ___text_4; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_text_4() { return &___text_4; }
	inline void set_text_4(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___text_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___text_4), (void*)value);
	}

	inline static int32_t get_offset_of_info_5() { return static_cast<int32_t>(offsetof(RoomListItem_t9EB55F749CE65437078175747E9F6F1CDCF959C2, ___info_5)); }
	inline RoomInfo_t2FA7C04D0FB706F0313E7C91AEA598D7B1BDEBE2 * get_info_5() const { return ___info_5; }
	inline RoomInfo_t2FA7C04D0FB706F0313E7C91AEA598D7B1BDEBE2 ** get_address_of_info_5() { return &___info_5; }
	inline void set_info_5(RoomInfo_t2FA7C04D0FB706F0313E7C91AEA598D7B1BDEBE2 * value)
	{
		___info_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___info_5), (void*)value);
	}
};


// RotateTowardsCamera
struct RotateTowardsCamera_t3A3F5E9CBC867A256FF2F93B164FC38ED142EB09  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.Camera RotateTowardsCamera::cam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___cam_4;

public:
	inline static int32_t get_offset_of_cam_4() { return static_cast<int32_t>(offsetof(RotateTowardsCamera_t3A3F5E9CBC867A256FF2F93B164FC38ED142EB09, ___cam_4)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_cam_4() const { return ___cam_4; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_cam_4() { return &___cam_4; }
	inline void set_cam_4(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___cam_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cam_4), (void*)value);
	}
};


// SimpleControl
struct SimpleControl_t082F92BF5EC835071423AA0C555673621232E23B  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// SimpleControl2
struct SimpleControl2_t5E025C38905F685A08A71FCC1FA23B7EAFE7D82F  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// SliderMenuAnim
struct SliderMenuAnim_tB1725766011E165282E6E1419E09044AACA7686B  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject SliderMenuAnim::PanelMenu
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___PanelMenu_4;
	// UnityEngine.UI.Button SliderMenuAnim::m_YourFirstButton
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___m_YourFirstButton_5;

public:
	inline static int32_t get_offset_of_PanelMenu_4() { return static_cast<int32_t>(offsetof(SliderMenuAnim_tB1725766011E165282E6E1419E09044AACA7686B, ___PanelMenu_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_PanelMenu_4() const { return ___PanelMenu_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_PanelMenu_4() { return &___PanelMenu_4; }
	inline void set_PanelMenu_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___PanelMenu_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PanelMenu_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_YourFirstButton_5() { return static_cast<int32_t>(offsetof(SliderMenuAnim_tB1725766011E165282E6E1419E09044AACA7686B, ___m_YourFirstButton_5)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_m_YourFirstButton_5() const { return ___m_YourFirstButton_5; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_m_YourFirstButton_5() { return &___m_YourFirstButton_5; }
	inline void set_m_YourFirstButton_5(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___m_YourFirstButton_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_YourFirstButton_5), (void*)value);
	}
};


// SpawnManager
struct SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// Spawnpoint[] SpawnManager::spawnpoints
	SpawnpointU5BU5D_t704CB7EB251BB79F0910611B99E478A3E85119F7* ___spawnpoints_5;

public:
	inline static int32_t get_offset_of_spawnpoints_5() { return static_cast<int32_t>(offsetof(SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0, ___spawnpoints_5)); }
	inline SpawnpointU5BU5D_t704CB7EB251BB79F0910611B99E478A3E85119F7* get_spawnpoints_5() const { return ___spawnpoints_5; }
	inline SpawnpointU5BU5D_t704CB7EB251BB79F0910611B99E478A3E85119F7** get_address_of_spawnpoints_5() { return &___spawnpoints_5; }
	inline void set_spawnpoints_5(SpawnpointU5BU5D_t704CB7EB251BB79F0910611B99E478A3E85119F7* value)
	{
		___spawnpoints_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___spawnpoints_5), (void*)value);
	}
};

struct SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0_StaticFields
{
public:
	// SpawnManager SpawnManager::Instance
	SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0 * ___Instance_4;

public:
	inline static int32_t get_offset_of_Instance_4() { return static_cast<int32_t>(offsetof(SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0_StaticFields, ___Instance_4)); }
	inline SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0 * get_Instance_4() const { return ___Instance_4; }
	inline SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0 ** get_address_of_Instance_4() { return &___Instance_4; }
	inline void set_Instance_4(SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0 * value)
	{
		___Instance_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Instance_4), (void*)value);
	}
};


// Spawnpoint
struct Spawnpoint_tF779AE5E6A6B8F72FC83205F1E42198307427C54  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject Spawnpoint::graphics
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___graphics_4;

public:
	inline static int32_t get_offset_of_graphics_4() { return static_cast<int32_t>(offsetof(Spawnpoint_tF779AE5E6A6B8F72FC83205F1E42198307427C54, ___graphics_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_graphics_4() const { return ___graphics_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_graphics_4() { return &___graphics_4; }
	inline void set_graphics_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___graphics_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___graphics_4), (void*)value);
	}
};


// SphereRotationCopy
struct SphereRotationCopy_tCE281B63A156B721CB832F196A1548EA9142A48D  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject SphereRotationCopy::sphere
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___sphere_4;

public:
	inline static int32_t get_offset_of_sphere_4() { return static_cast<int32_t>(offsetof(SphereRotationCopy_tCE281B63A156B721CB832F196A1548EA9142A48D, ___sphere_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_sphere_4() const { return ___sphere_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_sphere_4() { return &___sphere_4; }
	inline void set_sphere_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___sphere_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___sphere_4), (void*)value);
	}
};


// TestScript
struct TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Int32 TestScript::ngaunhien
	int32_t ___ngaunhien_4;
	// TMPro.TextMeshPro TestScript::MyText
	TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * ___MyText_5;
	// TMPro.TextMeshPro[] TestScript::ThemeText
	TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* ___ThemeText_6;
	// TMPro.TextMeshPro[] TestScript::ThemeTextResult
	TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* ___ThemeTextResult_7;

public:
	inline static int32_t get_offset_of_ngaunhien_4() { return static_cast<int32_t>(offsetof(TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1, ___ngaunhien_4)); }
	inline int32_t get_ngaunhien_4() const { return ___ngaunhien_4; }
	inline int32_t* get_address_of_ngaunhien_4() { return &___ngaunhien_4; }
	inline void set_ngaunhien_4(int32_t value)
	{
		___ngaunhien_4 = value;
	}

	inline static int32_t get_offset_of_MyText_5() { return static_cast<int32_t>(offsetof(TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1, ___MyText_5)); }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * get_MyText_5() const { return ___MyText_5; }
	inline TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 ** get_address_of_MyText_5() { return &___MyText_5; }
	inline void set_MyText_5(TextMeshPro_t6FF60D9DCAF295045FE47C014CC855C5784752E2 * value)
	{
		___MyText_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___MyText_5), (void*)value);
	}

	inline static int32_t get_offset_of_ThemeText_6() { return static_cast<int32_t>(offsetof(TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1, ___ThemeText_6)); }
	inline TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* get_ThemeText_6() const { return ___ThemeText_6; }
	inline TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32** get_address_of_ThemeText_6() { return &___ThemeText_6; }
	inline void set_ThemeText_6(TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* value)
	{
		___ThemeText_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ThemeText_6), (void*)value);
	}

	inline static int32_t get_offset_of_ThemeTextResult_7() { return static_cast<int32_t>(offsetof(TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1, ___ThemeTextResult_7)); }
	inline TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* get_ThemeTextResult_7() const { return ___ThemeTextResult_7; }
	inline TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32** get_address_of_ThemeTextResult_7() { return &___ThemeTextResult_7; }
	inline void set_ThemeTextResult_7(TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* value)
	{
		___ThemeTextResult_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ThemeTextResult_7), (void*)value);
	}
};


// TrailsFX.Demos.MoveObject
struct MoveObject_t5BDF6EB08C1B8AF546FF9281F5DCC196B32821CC  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:

public:
};


// TrailsFX.Demos.RotateObject
struct RotateObject_t003EA34487C2C5EA234868B4B9A86E62CDED5FF1  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single TrailsFX.Demos.RotateObject::speed
	float ___speed_4;
	// UnityEngine.Vector3 TrailsFX.Demos.RotateObject::eulerAngles
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___eulerAngles_5;

public:
	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(RotateObject_t003EA34487C2C5EA234868B4B9A86E62CDED5FF1, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_eulerAngles_5() { return static_cast<int32_t>(offsetof(RotateObject_t003EA34487C2C5EA234868B4B9A86E62CDED5FF1, ___eulerAngles_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_eulerAngles_5() const { return ___eulerAngles_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_eulerAngles_5() { return &___eulerAngles_5; }
	inline void set_eulerAngles_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___eulerAngles_5 = value;
	}
};


// TrailsFX.Demos.Shooter
struct Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single TrailsFX.Demos.Shooter::timeInterval
	float ___timeInterval_4;
	// UnityEngine.GameObject[] TrailsFX.Demos.Shooter::bulletPrefabs
	GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* ___bulletPrefabs_5;
	// UnityEngine.Quaternion TrailsFX.Demos.Shooter::targetRot
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___targetRot_6;
	// System.Single TrailsFX.Demos.Shooter::lastTargetTime
	float ___lastTargetTime_7;
	// UnityEngine.Vector3 TrailsFX.Demos.Shooter::lookAt
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___lookAt_8;
	// UnityEngine.Vector3 TrailsFX.Demos.Shooter::previousLookAt
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___previousLookAt_9;
	// UnityEngine.GameObject[] TrailsFX.Demos.Shooter::bulletPool
	GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* ___bulletPool_10;
	// System.Int32 TrailsFX.Demos.Shooter::poolIndex
	int32_t ___poolIndex_11;
	// UnityEngine.Vector3 TrailsFX.Demos.Shooter::startPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___startPos_12;

public:
	inline static int32_t get_offset_of_timeInterval_4() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___timeInterval_4)); }
	inline float get_timeInterval_4() const { return ___timeInterval_4; }
	inline float* get_address_of_timeInterval_4() { return &___timeInterval_4; }
	inline void set_timeInterval_4(float value)
	{
		___timeInterval_4 = value;
	}

	inline static int32_t get_offset_of_bulletPrefabs_5() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___bulletPrefabs_5)); }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* get_bulletPrefabs_5() const { return ___bulletPrefabs_5; }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520** get_address_of_bulletPrefabs_5() { return &___bulletPrefabs_5; }
	inline void set_bulletPrefabs_5(GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* value)
	{
		___bulletPrefabs_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bulletPrefabs_5), (void*)value);
	}

	inline static int32_t get_offset_of_targetRot_6() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___targetRot_6)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_targetRot_6() const { return ___targetRot_6; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_targetRot_6() { return &___targetRot_6; }
	inline void set_targetRot_6(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___targetRot_6 = value;
	}

	inline static int32_t get_offset_of_lastTargetTime_7() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___lastTargetTime_7)); }
	inline float get_lastTargetTime_7() const { return ___lastTargetTime_7; }
	inline float* get_address_of_lastTargetTime_7() { return &___lastTargetTime_7; }
	inline void set_lastTargetTime_7(float value)
	{
		___lastTargetTime_7 = value;
	}

	inline static int32_t get_offset_of_lookAt_8() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___lookAt_8)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_lookAt_8() const { return ___lookAt_8; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_lookAt_8() { return &___lookAt_8; }
	inline void set_lookAt_8(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___lookAt_8 = value;
	}

	inline static int32_t get_offset_of_previousLookAt_9() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___previousLookAt_9)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_previousLookAt_9() const { return ___previousLookAt_9; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_previousLookAt_9() { return &___previousLookAt_9; }
	inline void set_previousLookAt_9(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___previousLookAt_9 = value;
	}

	inline static int32_t get_offset_of_bulletPool_10() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___bulletPool_10)); }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* get_bulletPool_10() const { return ___bulletPool_10; }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520** get_address_of_bulletPool_10() { return &___bulletPool_10; }
	inline void set_bulletPool_10(GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* value)
	{
		___bulletPool_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bulletPool_10), (void*)value);
	}

	inline static int32_t get_offset_of_poolIndex_11() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___poolIndex_11)); }
	inline int32_t get_poolIndex_11() const { return ___poolIndex_11; }
	inline int32_t* get_address_of_poolIndex_11() { return &___poolIndex_11; }
	inline void set_poolIndex_11(int32_t value)
	{
		___poolIndex_11 = value;
	}

	inline static int32_t get_offset_of_startPos_12() { return static_cast<int32_t>(offsetof(Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C, ___startPos_12)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_startPos_12() const { return ___startPos_12; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_startPos_12() { return &___startPos_12; }
	inline void set_startPos_12(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___startPos_12 = value;
	}
};


// TrailsFX.Demos.quay
struct quay_t9DD8EC457CF6D2BBCEEE306DDF28E6900F9F3A00  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single TrailsFX.Demos.quay::speed
	float ___speed_4;
	// UnityEngine.Vector3 TrailsFX.Demos.quay::eulerAngles
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___eulerAngles_5;

public:
	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(quay_t9DD8EC457CF6D2BBCEEE306DDF28E6900F9F3A00, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_eulerAngles_5() { return static_cast<int32_t>(offsetof(quay_t9DD8EC457CF6D2BBCEEE306DDF28E6900F9F3A00, ___eulerAngles_5)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_eulerAngles_5() const { return ___eulerAngles_5; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_eulerAngles_5() { return &___eulerAngles_5; }
	inline void set_eulerAngles_5(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___eulerAngles_5 = value;
	}
};


// TrailsFX.TrailEffect
struct TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// TrailsFX.TrailEffectProfile TrailsFX.TrailEffect::profile
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 * ___profile_4;
	// System.Boolean TrailsFX.TrailEffect::profileSync
	bool ___profileSync_5;
	// UnityEngine.Transform TrailsFX.TrailEffect::target
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___target_6;
	// System.Boolean TrailsFX.TrailEffect::_active
	bool ____active_7;
	// System.Boolean TrailsFX.TrailEffect::executeInEditMode
	bool ___executeInEditMode_8;
	// System.Int32 TrailsFX.TrailEffect::ignoreFrames
	int32_t ___ignoreFrames_9;
	// System.Single TrailsFX.TrailEffect::duration
	float ___duration_10;
	// System.Boolean TrailsFX.TrailEffect::continuous
	bool ___continuous_11;
	// System.Boolean TrailsFX.TrailEffect::smooth
	bool ___smooth_12;
	// System.Boolean TrailsFX.TrailEffect::checkWorldPosition
	bool ___checkWorldPosition_13;
	// System.Single TrailsFX.TrailEffect::minDistance
	float ___minDistance_14;
	// TrailsFX.PositionChangeRelative TrailsFX.TrailEffect::worldPositionRelativeOption
	int32_t ___worldPositionRelativeOption_15;
	// UnityEngine.Transform TrailsFX.TrailEffect::worldPositionRelativeTransform
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___worldPositionRelativeTransform_16;
	// System.Boolean TrailsFX.TrailEffect::checkScreenPosition
	bool ___checkScreenPosition_17;
	// System.Int32 TrailsFX.TrailEffect::minPixelDistance
	int32_t ___minPixelDistance_18;
	// System.Int32 TrailsFX.TrailEffect::stepsBufferSize
	int32_t ___stepsBufferSize_19;
	// System.Int32 TrailsFX.TrailEffect::maxStepsPerFrame
	int32_t ___maxStepsPerFrame_20;
	// System.Boolean TrailsFX.TrailEffect::checkTime
	bool ___checkTime_21;
	// System.Single TrailsFX.TrailEffect::timeInterval
	float ___timeInterval_22;
	// System.Boolean TrailsFX.TrailEffect::checkCollisions
	bool ___checkCollisions_23;
	// System.Boolean TrailsFX.TrailEffect::orientToSurface
	bool ___orientToSurface_24;
	// System.Boolean TrailsFX.TrailEffect::ground
	bool ___ground_25;
	// System.Single TrailsFX.TrailEffect::surfaceOffset
	float ___surfaceOffset_26;
	// UnityEngine.LayerMask TrailsFX.TrailEffect::collisionLayerMask
	LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  ___collisionLayerMask_27;
	// System.Boolean TrailsFX.TrailEffect::drawBehind
	bool ___drawBehind_28;
	// UnityEngine.Rendering.CullMode TrailsFX.TrailEffect::cullMode
	int32_t ___cullMode_29;
	// System.Int32 TrailsFX.TrailEffect::subMeshMask
	int32_t ___subMeshMask_30;
	// UnityEngine.Gradient TrailsFX.TrailEffect::colorOverTime
	Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * ___colorOverTime_31;
	// TrailsFX.ColorSequence TrailsFX.TrailEffect::colorSequence
	int32_t ___colorSequence_32;
	// UnityEngine.Color TrailsFX.TrailEffect::color
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___color_33;
	// System.Single TrailsFX.TrailEffect::colorCycleDuration
	float ___colorCycleDuration_34;
	// System.Single TrailsFX.TrailEffect::pingPongSpeed
	float ___pingPongSpeed_35;
	// UnityEngine.Gradient TrailsFX.TrailEffect::colorStartPalette
	Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * ___colorStartPalette_36;
	// UnityEngine.Camera TrailsFX.TrailEffect::cam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___cam_37;
	// TrailsFX.TrailStyle TrailsFX.TrailEffect::effect
	int32_t ___effect_38;
	// UnityEngine.Texture2D TrailsFX.TrailEffect::texture
	Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * ___texture_39;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::scale
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___scale_40;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::scaleStartRandomMin
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___scaleStartRandomMin_41;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::scaleStartRandomMax
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___scaleStartRandomMax_42;
	// UnityEngine.AnimationCurve TrailsFX.TrailEffect::scaleOverTime
	AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * ___scaleOverTime_43;
	// System.Boolean TrailsFX.TrailEffect::scaleUniform
	bool ___scaleUniform_44;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::localPositionRandomMin
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___localPositionRandomMin_45;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::localPositionRandomMax
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___localPositionRandomMax_46;
	// System.Single TrailsFX.TrailEffect::laserBandWidth
	float ___laserBandWidth_47;
	// System.Single TrailsFX.TrailEffect::laserIntensity
	float ___laserIntensity_48;
	// System.Single TrailsFX.TrailEffect::laserFlash
	float ___laserFlash_49;
	// System.String TrailsFX.TrailEffect::animationStates
	String_t* ___animationStates_50;
	// UnityEngine.Transform TrailsFX.TrailEffect::lookTarget
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___lookTarget_51;
	// System.Boolean TrailsFX.TrailEffect::lookToCamera
	bool ___lookToCamera_52;
	// System.Single TrailsFX.TrailEffect::textureCutOff
	float ___textureCutOff_53;
	// System.Single TrailsFX.TrailEffect::normalThreshold
	float ___normalThreshold_54;
	// System.Boolean TrailsFX.TrailEffect::useLastAnimationState
	bool ___useLastAnimationState_55;
	// System.Int32 TrailsFX.TrailEffect::maxBatches
	int32_t ___maxBatches_56;
	// System.Int32 TrailsFX.TrailEffect::meshPoolSize
	int32_t ___meshPoolSize_57;
	// TrailsFX.TrailEffect/SnapshotTransform[] TrailsFX.TrailEffect::trail
	SnapshotTransformU5BU5D_t36015EFB3930578852538B8391A54DA6D5A65D2A* ___trail_61;
	// TrailsFX.TrailEffect/SnapshotIndex[] TrailsFX.TrailEffect::sortIndices
	SnapshotIndexU5BU5D_t402683559A228DC7C2025F620BF10E09387E7B3E* ___sortIndices_62;
	// System.Int32 TrailsFX.TrailEffect::trailIndex
	int32_t ___trailIndex_63;
	// UnityEngine.Mesh[] TrailsFX.TrailEffect::meshPool
	MeshU5BU5D_tDD9C723AA6F0225B35A93D871CDC2CEFF7F8CB89* ___meshPool_64;
	// System.Int32 TrailsFX.TrailEffect::meshPoolIndex
	int32_t ___meshPoolIndex_65;
	// UnityEngine.Material TrailsFX.TrailEffect::trailMask
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___trailMask_66;
	// UnityEngine.Material TrailsFX.TrailEffect::trailClearMask
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___trailClearMask_67;
	// UnityEngine.Material[] TrailsFX.TrailEffect::trailMaterial
	MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398* ___trailMaterial_68;
	// System.Int32 TrailsFX.TrailEffect::propColorArrayId
	int32_t ___propColorArrayId_69;
	// UnityEngine.Renderer TrailsFX.TrailEffect::theRenderer
	Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * ___theRenderer_70;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::lastCornerMinPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___lastCornerMinPos_71;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::lastCornerMaxPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___lastCornerMaxPos_72;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::lastPosition
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___lastPosition_73;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::lastRandomizedPosition
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___lastRandomizedPosition_74;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::lastRelativePosition
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___lastRelativePosition_75;
	// UnityEngine.Quaternion TrailsFX.TrailEffect::lastRotation
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___lastRotation_76;
	// System.Single TrailsFX.TrailEffect::lastIntervalTimeCheck
	float ___lastIntervalTimeCheck_77;
	// UnityEngine.MaterialPropertyBlock TrailsFX.TrailEffect::properties
	MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * ___properties_78;
	// UnityEngine.Matrix4x4[] TrailsFX.TrailEffect::matrices
	Matrix4x4U5BU5D_t1C64F7A0C34058334A8A95BF165F0027690598C9* ___matrices_79;
	// UnityEngine.Vector4[] TrailsFX.TrailEffect::colors
	Vector4U5BU5D_t51402C154FFFCF7217A9BEC4B834F0B726C10F66* ___colors_80;
	// System.Int32 TrailsFX.TrailEffect::renderQueue
	int32_t ___renderQueue_82;
	// UnityEngine.SkinnedMeshRenderer TrailsFX.TrailEffect::skinnedMeshRenderer
	SkinnedMeshRenderer_tFC8103EE7842F7F8A98BEF0C855D32A9711B7B65 * ___skinnedMeshRenderer_83;
	// System.Boolean TrailsFX.TrailEffect::isSkinned
	bool ___isSkinned_84;
	// System.Int32 TrailsFX.TrailEffect::bakeTime
	int32_t ___bakeTime_85;
	// System.Int32 TrailsFX.TrailEffect::batchNumber
	int32_t ___batchNumber_86;
	// UnityEngine.Mesh TrailsFX.TrailEffect::quadMesh
	Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * ___quadMesh_87;
	// System.Collections.Generic.Dictionary`2<System.String,UnityEngine.Material> TrailsFX.TrailEffect::effectMaterials
	Dictionary_2_t29EF377760EAE2E4C34F7125BB6CDFE3AE8985A1 * ___effectMaterials_88;
	// System.Boolean TrailsFX.TrailEffect::orient
	bool ___orient_89;
	// UnityEngine.Vector3 TrailsFX.TrailEffect::groundNormal
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___groundNormal_90;
	// System.Int32 TrailsFX.TrailEffect::startFrameCount
	int32_t ___startFrameCount_91;
	// System.Single TrailsFX.TrailEffect::smoothDuration
	float ___smoothDuration_92;
	// UnityEngine.Animator TrailsFX.TrailEffect::animator
	Animator_tF1A88E66B3B731DDA75A066DBAE9C55837660F5A * ___animator_93;
	// System.Boolean TrailsFX.TrailEffect::isLimitedToAnimationStates
	bool ___isLimitedToAnimationStates_94;
	// System.Int32[] TrailsFX.TrailEffect::stateHashes
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___stateHashes_95;
	// System.Boolean TrailsFX.TrailEffect::supportsGPUInstancing
	bool ___supportsGPUInstancing_96;
	// UnityEngine.MaterialPropertyBlock TrailsFX.TrailEffect::propertyBlock
	MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * ___propertyBlock_97;
	// UnityEngine.Color TrailsFX.TrailEffect::colorRandomAtStart
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___colorRandomAtStart_98;
	// UnityEngine.Color[] TrailsFX.TrailEffect::bakedColorOverTime
	ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* ___bakedColorOverTime_99;
	// UnityEngine.Color[] TrailsFX.TrailEffect::bakedColorStartPalette
	ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* ___bakedColorStartPalette_100;
	// System.Single[] TrailsFX.TrailEffect::bakedScaleOverTime
	SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* ___bakedScaleOverTime_101;
	// System.Boolean TrailsFX.TrailEffect::wasInactive
	bool ___wasInactive_102;

public:
	inline static int32_t get_offset_of_profile_4() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___profile_4)); }
	inline TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 * get_profile_4() const { return ___profile_4; }
	inline TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 ** get_address_of_profile_4() { return &___profile_4; }
	inline void set_profile_4(TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444 * value)
	{
		___profile_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___profile_4), (void*)value);
	}

	inline static int32_t get_offset_of_profileSync_5() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___profileSync_5)); }
	inline bool get_profileSync_5() const { return ___profileSync_5; }
	inline bool* get_address_of_profileSync_5() { return &___profileSync_5; }
	inline void set_profileSync_5(bool value)
	{
		___profileSync_5 = value;
	}

	inline static int32_t get_offset_of_target_6() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___target_6)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_target_6() const { return ___target_6; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_target_6() { return &___target_6; }
	inline void set_target_6(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___target_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___target_6), (void*)value);
	}

	inline static int32_t get_offset_of__active_7() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ____active_7)); }
	inline bool get__active_7() const { return ____active_7; }
	inline bool* get_address_of__active_7() { return &____active_7; }
	inline void set__active_7(bool value)
	{
		____active_7 = value;
	}

	inline static int32_t get_offset_of_executeInEditMode_8() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___executeInEditMode_8)); }
	inline bool get_executeInEditMode_8() const { return ___executeInEditMode_8; }
	inline bool* get_address_of_executeInEditMode_8() { return &___executeInEditMode_8; }
	inline void set_executeInEditMode_8(bool value)
	{
		___executeInEditMode_8 = value;
	}

	inline static int32_t get_offset_of_ignoreFrames_9() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___ignoreFrames_9)); }
	inline int32_t get_ignoreFrames_9() const { return ___ignoreFrames_9; }
	inline int32_t* get_address_of_ignoreFrames_9() { return &___ignoreFrames_9; }
	inline void set_ignoreFrames_9(int32_t value)
	{
		___ignoreFrames_9 = value;
	}

	inline static int32_t get_offset_of_duration_10() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___duration_10)); }
	inline float get_duration_10() const { return ___duration_10; }
	inline float* get_address_of_duration_10() { return &___duration_10; }
	inline void set_duration_10(float value)
	{
		___duration_10 = value;
	}

	inline static int32_t get_offset_of_continuous_11() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___continuous_11)); }
	inline bool get_continuous_11() const { return ___continuous_11; }
	inline bool* get_address_of_continuous_11() { return &___continuous_11; }
	inline void set_continuous_11(bool value)
	{
		___continuous_11 = value;
	}

	inline static int32_t get_offset_of_smooth_12() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___smooth_12)); }
	inline bool get_smooth_12() const { return ___smooth_12; }
	inline bool* get_address_of_smooth_12() { return &___smooth_12; }
	inline void set_smooth_12(bool value)
	{
		___smooth_12 = value;
	}

	inline static int32_t get_offset_of_checkWorldPosition_13() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___checkWorldPosition_13)); }
	inline bool get_checkWorldPosition_13() const { return ___checkWorldPosition_13; }
	inline bool* get_address_of_checkWorldPosition_13() { return &___checkWorldPosition_13; }
	inline void set_checkWorldPosition_13(bool value)
	{
		___checkWorldPosition_13 = value;
	}

	inline static int32_t get_offset_of_minDistance_14() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___minDistance_14)); }
	inline float get_minDistance_14() const { return ___minDistance_14; }
	inline float* get_address_of_minDistance_14() { return &___minDistance_14; }
	inline void set_minDistance_14(float value)
	{
		___minDistance_14 = value;
	}

	inline static int32_t get_offset_of_worldPositionRelativeOption_15() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___worldPositionRelativeOption_15)); }
	inline int32_t get_worldPositionRelativeOption_15() const { return ___worldPositionRelativeOption_15; }
	inline int32_t* get_address_of_worldPositionRelativeOption_15() { return &___worldPositionRelativeOption_15; }
	inline void set_worldPositionRelativeOption_15(int32_t value)
	{
		___worldPositionRelativeOption_15 = value;
	}

	inline static int32_t get_offset_of_worldPositionRelativeTransform_16() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___worldPositionRelativeTransform_16)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_worldPositionRelativeTransform_16() const { return ___worldPositionRelativeTransform_16; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_worldPositionRelativeTransform_16() { return &___worldPositionRelativeTransform_16; }
	inline void set_worldPositionRelativeTransform_16(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___worldPositionRelativeTransform_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___worldPositionRelativeTransform_16), (void*)value);
	}

	inline static int32_t get_offset_of_checkScreenPosition_17() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___checkScreenPosition_17)); }
	inline bool get_checkScreenPosition_17() const { return ___checkScreenPosition_17; }
	inline bool* get_address_of_checkScreenPosition_17() { return &___checkScreenPosition_17; }
	inline void set_checkScreenPosition_17(bool value)
	{
		___checkScreenPosition_17 = value;
	}

	inline static int32_t get_offset_of_minPixelDistance_18() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___minPixelDistance_18)); }
	inline int32_t get_minPixelDistance_18() const { return ___minPixelDistance_18; }
	inline int32_t* get_address_of_minPixelDistance_18() { return &___minPixelDistance_18; }
	inline void set_minPixelDistance_18(int32_t value)
	{
		___minPixelDistance_18 = value;
	}

	inline static int32_t get_offset_of_stepsBufferSize_19() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___stepsBufferSize_19)); }
	inline int32_t get_stepsBufferSize_19() const { return ___stepsBufferSize_19; }
	inline int32_t* get_address_of_stepsBufferSize_19() { return &___stepsBufferSize_19; }
	inline void set_stepsBufferSize_19(int32_t value)
	{
		___stepsBufferSize_19 = value;
	}

	inline static int32_t get_offset_of_maxStepsPerFrame_20() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___maxStepsPerFrame_20)); }
	inline int32_t get_maxStepsPerFrame_20() const { return ___maxStepsPerFrame_20; }
	inline int32_t* get_address_of_maxStepsPerFrame_20() { return &___maxStepsPerFrame_20; }
	inline void set_maxStepsPerFrame_20(int32_t value)
	{
		___maxStepsPerFrame_20 = value;
	}

	inline static int32_t get_offset_of_checkTime_21() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___checkTime_21)); }
	inline bool get_checkTime_21() const { return ___checkTime_21; }
	inline bool* get_address_of_checkTime_21() { return &___checkTime_21; }
	inline void set_checkTime_21(bool value)
	{
		___checkTime_21 = value;
	}

	inline static int32_t get_offset_of_timeInterval_22() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___timeInterval_22)); }
	inline float get_timeInterval_22() const { return ___timeInterval_22; }
	inline float* get_address_of_timeInterval_22() { return &___timeInterval_22; }
	inline void set_timeInterval_22(float value)
	{
		___timeInterval_22 = value;
	}

	inline static int32_t get_offset_of_checkCollisions_23() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___checkCollisions_23)); }
	inline bool get_checkCollisions_23() const { return ___checkCollisions_23; }
	inline bool* get_address_of_checkCollisions_23() { return &___checkCollisions_23; }
	inline void set_checkCollisions_23(bool value)
	{
		___checkCollisions_23 = value;
	}

	inline static int32_t get_offset_of_orientToSurface_24() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___orientToSurface_24)); }
	inline bool get_orientToSurface_24() const { return ___orientToSurface_24; }
	inline bool* get_address_of_orientToSurface_24() { return &___orientToSurface_24; }
	inline void set_orientToSurface_24(bool value)
	{
		___orientToSurface_24 = value;
	}

	inline static int32_t get_offset_of_ground_25() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___ground_25)); }
	inline bool get_ground_25() const { return ___ground_25; }
	inline bool* get_address_of_ground_25() { return &___ground_25; }
	inline void set_ground_25(bool value)
	{
		___ground_25 = value;
	}

	inline static int32_t get_offset_of_surfaceOffset_26() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___surfaceOffset_26)); }
	inline float get_surfaceOffset_26() const { return ___surfaceOffset_26; }
	inline float* get_address_of_surfaceOffset_26() { return &___surfaceOffset_26; }
	inline void set_surfaceOffset_26(float value)
	{
		___surfaceOffset_26 = value;
	}

	inline static int32_t get_offset_of_collisionLayerMask_27() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___collisionLayerMask_27)); }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  get_collisionLayerMask_27() const { return ___collisionLayerMask_27; }
	inline LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0 * get_address_of_collisionLayerMask_27() { return &___collisionLayerMask_27; }
	inline void set_collisionLayerMask_27(LayerMask_tBB9173D8B6939D476E67E849280AC9F4EC4D93B0  value)
	{
		___collisionLayerMask_27 = value;
	}

	inline static int32_t get_offset_of_drawBehind_28() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___drawBehind_28)); }
	inline bool get_drawBehind_28() const { return ___drawBehind_28; }
	inline bool* get_address_of_drawBehind_28() { return &___drawBehind_28; }
	inline void set_drawBehind_28(bool value)
	{
		___drawBehind_28 = value;
	}

	inline static int32_t get_offset_of_cullMode_29() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___cullMode_29)); }
	inline int32_t get_cullMode_29() const { return ___cullMode_29; }
	inline int32_t* get_address_of_cullMode_29() { return &___cullMode_29; }
	inline void set_cullMode_29(int32_t value)
	{
		___cullMode_29 = value;
	}

	inline static int32_t get_offset_of_subMeshMask_30() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___subMeshMask_30)); }
	inline int32_t get_subMeshMask_30() const { return ___subMeshMask_30; }
	inline int32_t* get_address_of_subMeshMask_30() { return &___subMeshMask_30; }
	inline void set_subMeshMask_30(int32_t value)
	{
		___subMeshMask_30 = value;
	}

	inline static int32_t get_offset_of_colorOverTime_31() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___colorOverTime_31)); }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * get_colorOverTime_31() const { return ___colorOverTime_31; }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A ** get_address_of_colorOverTime_31() { return &___colorOverTime_31; }
	inline void set_colorOverTime_31(Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * value)
	{
		___colorOverTime_31 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorOverTime_31), (void*)value);
	}

	inline static int32_t get_offset_of_colorSequence_32() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___colorSequence_32)); }
	inline int32_t get_colorSequence_32() const { return ___colorSequence_32; }
	inline int32_t* get_address_of_colorSequence_32() { return &___colorSequence_32; }
	inline void set_colorSequence_32(int32_t value)
	{
		___colorSequence_32 = value;
	}

	inline static int32_t get_offset_of_color_33() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___color_33)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_color_33() const { return ___color_33; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_color_33() { return &___color_33; }
	inline void set_color_33(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___color_33 = value;
	}

	inline static int32_t get_offset_of_colorCycleDuration_34() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___colorCycleDuration_34)); }
	inline float get_colorCycleDuration_34() const { return ___colorCycleDuration_34; }
	inline float* get_address_of_colorCycleDuration_34() { return &___colorCycleDuration_34; }
	inline void set_colorCycleDuration_34(float value)
	{
		___colorCycleDuration_34 = value;
	}

	inline static int32_t get_offset_of_pingPongSpeed_35() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___pingPongSpeed_35)); }
	inline float get_pingPongSpeed_35() const { return ___pingPongSpeed_35; }
	inline float* get_address_of_pingPongSpeed_35() { return &___pingPongSpeed_35; }
	inline void set_pingPongSpeed_35(float value)
	{
		___pingPongSpeed_35 = value;
	}

	inline static int32_t get_offset_of_colorStartPalette_36() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___colorStartPalette_36)); }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * get_colorStartPalette_36() const { return ___colorStartPalette_36; }
	inline Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A ** get_address_of_colorStartPalette_36() { return &___colorStartPalette_36; }
	inline void set_colorStartPalette_36(Gradient_t35A694DDA1066524440E325E582B01E33DE66A3A * value)
	{
		___colorStartPalette_36 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colorStartPalette_36), (void*)value);
	}

	inline static int32_t get_offset_of_cam_37() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___cam_37)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_cam_37() const { return ___cam_37; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_cam_37() { return &___cam_37; }
	inline void set_cam_37(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___cam_37 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cam_37), (void*)value);
	}

	inline static int32_t get_offset_of_effect_38() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___effect_38)); }
	inline int32_t get_effect_38() const { return ___effect_38; }
	inline int32_t* get_address_of_effect_38() { return &___effect_38; }
	inline void set_effect_38(int32_t value)
	{
		___effect_38 = value;
	}

	inline static int32_t get_offset_of_texture_39() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___texture_39)); }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * get_texture_39() const { return ___texture_39; }
	inline Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C ** get_address_of_texture_39() { return &___texture_39; }
	inline void set_texture_39(Texture2D_tBBF96AC337723E2EF156DF17E09D4379FD05DE1C * value)
	{
		___texture_39 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___texture_39), (void*)value);
	}

	inline static int32_t get_offset_of_scale_40() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___scale_40)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_scale_40() const { return ___scale_40; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_scale_40() { return &___scale_40; }
	inline void set_scale_40(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___scale_40 = value;
	}

	inline static int32_t get_offset_of_scaleStartRandomMin_41() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___scaleStartRandomMin_41)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_scaleStartRandomMin_41() const { return ___scaleStartRandomMin_41; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_scaleStartRandomMin_41() { return &___scaleStartRandomMin_41; }
	inline void set_scaleStartRandomMin_41(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___scaleStartRandomMin_41 = value;
	}

	inline static int32_t get_offset_of_scaleStartRandomMax_42() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___scaleStartRandomMax_42)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_scaleStartRandomMax_42() const { return ___scaleStartRandomMax_42; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_scaleStartRandomMax_42() { return &___scaleStartRandomMax_42; }
	inline void set_scaleStartRandomMax_42(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___scaleStartRandomMax_42 = value;
	}

	inline static int32_t get_offset_of_scaleOverTime_43() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___scaleOverTime_43)); }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * get_scaleOverTime_43() const { return ___scaleOverTime_43; }
	inline AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C ** get_address_of_scaleOverTime_43() { return &___scaleOverTime_43; }
	inline void set_scaleOverTime_43(AnimationCurve_tD2F265379583AAF1BF8D84F1BB8DB12980FA504C * value)
	{
		___scaleOverTime_43 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___scaleOverTime_43), (void*)value);
	}

	inline static int32_t get_offset_of_scaleUniform_44() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___scaleUniform_44)); }
	inline bool get_scaleUniform_44() const { return ___scaleUniform_44; }
	inline bool* get_address_of_scaleUniform_44() { return &___scaleUniform_44; }
	inline void set_scaleUniform_44(bool value)
	{
		___scaleUniform_44 = value;
	}

	inline static int32_t get_offset_of_localPositionRandomMin_45() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___localPositionRandomMin_45)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_localPositionRandomMin_45() const { return ___localPositionRandomMin_45; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_localPositionRandomMin_45() { return &___localPositionRandomMin_45; }
	inline void set_localPositionRandomMin_45(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___localPositionRandomMin_45 = value;
	}

	inline static int32_t get_offset_of_localPositionRandomMax_46() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___localPositionRandomMax_46)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_localPositionRandomMax_46() const { return ___localPositionRandomMax_46; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_localPositionRandomMax_46() { return &___localPositionRandomMax_46; }
	inline void set_localPositionRandomMax_46(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___localPositionRandomMax_46 = value;
	}

	inline static int32_t get_offset_of_laserBandWidth_47() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___laserBandWidth_47)); }
	inline float get_laserBandWidth_47() const { return ___laserBandWidth_47; }
	inline float* get_address_of_laserBandWidth_47() { return &___laserBandWidth_47; }
	inline void set_laserBandWidth_47(float value)
	{
		___laserBandWidth_47 = value;
	}

	inline static int32_t get_offset_of_laserIntensity_48() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___laserIntensity_48)); }
	inline float get_laserIntensity_48() const { return ___laserIntensity_48; }
	inline float* get_address_of_laserIntensity_48() { return &___laserIntensity_48; }
	inline void set_laserIntensity_48(float value)
	{
		___laserIntensity_48 = value;
	}

	inline static int32_t get_offset_of_laserFlash_49() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___laserFlash_49)); }
	inline float get_laserFlash_49() const { return ___laserFlash_49; }
	inline float* get_address_of_laserFlash_49() { return &___laserFlash_49; }
	inline void set_laserFlash_49(float value)
	{
		___laserFlash_49 = value;
	}

	inline static int32_t get_offset_of_animationStates_50() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___animationStates_50)); }
	inline String_t* get_animationStates_50() const { return ___animationStates_50; }
	inline String_t** get_address_of_animationStates_50() { return &___animationStates_50; }
	inline void set_animationStates_50(String_t* value)
	{
		___animationStates_50 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___animationStates_50), (void*)value);
	}

	inline static int32_t get_offset_of_lookTarget_51() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lookTarget_51)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_lookTarget_51() const { return ___lookTarget_51; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_lookTarget_51() { return &___lookTarget_51; }
	inline void set_lookTarget_51(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___lookTarget_51 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___lookTarget_51), (void*)value);
	}

	inline static int32_t get_offset_of_lookToCamera_52() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lookToCamera_52)); }
	inline bool get_lookToCamera_52() const { return ___lookToCamera_52; }
	inline bool* get_address_of_lookToCamera_52() { return &___lookToCamera_52; }
	inline void set_lookToCamera_52(bool value)
	{
		___lookToCamera_52 = value;
	}

	inline static int32_t get_offset_of_textureCutOff_53() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___textureCutOff_53)); }
	inline float get_textureCutOff_53() const { return ___textureCutOff_53; }
	inline float* get_address_of_textureCutOff_53() { return &___textureCutOff_53; }
	inline void set_textureCutOff_53(float value)
	{
		___textureCutOff_53 = value;
	}

	inline static int32_t get_offset_of_normalThreshold_54() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___normalThreshold_54)); }
	inline float get_normalThreshold_54() const { return ___normalThreshold_54; }
	inline float* get_address_of_normalThreshold_54() { return &___normalThreshold_54; }
	inline void set_normalThreshold_54(float value)
	{
		___normalThreshold_54 = value;
	}

	inline static int32_t get_offset_of_useLastAnimationState_55() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___useLastAnimationState_55)); }
	inline bool get_useLastAnimationState_55() const { return ___useLastAnimationState_55; }
	inline bool* get_address_of_useLastAnimationState_55() { return &___useLastAnimationState_55; }
	inline void set_useLastAnimationState_55(bool value)
	{
		___useLastAnimationState_55 = value;
	}

	inline static int32_t get_offset_of_maxBatches_56() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___maxBatches_56)); }
	inline int32_t get_maxBatches_56() const { return ___maxBatches_56; }
	inline int32_t* get_address_of_maxBatches_56() { return &___maxBatches_56; }
	inline void set_maxBatches_56(int32_t value)
	{
		___maxBatches_56 = value;
	}

	inline static int32_t get_offset_of_meshPoolSize_57() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___meshPoolSize_57)); }
	inline int32_t get_meshPoolSize_57() const { return ___meshPoolSize_57; }
	inline int32_t* get_address_of_meshPoolSize_57() { return &___meshPoolSize_57; }
	inline void set_meshPoolSize_57(int32_t value)
	{
		___meshPoolSize_57 = value;
	}

	inline static int32_t get_offset_of_trail_61() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___trail_61)); }
	inline SnapshotTransformU5BU5D_t36015EFB3930578852538B8391A54DA6D5A65D2A* get_trail_61() const { return ___trail_61; }
	inline SnapshotTransformU5BU5D_t36015EFB3930578852538B8391A54DA6D5A65D2A** get_address_of_trail_61() { return &___trail_61; }
	inline void set_trail_61(SnapshotTransformU5BU5D_t36015EFB3930578852538B8391A54DA6D5A65D2A* value)
	{
		___trail_61 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___trail_61), (void*)value);
	}

	inline static int32_t get_offset_of_sortIndices_62() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___sortIndices_62)); }
	inline SnapshotIndexU5BU5D_t402683559A228DC7C2025F620BF10E09387E7B3E* get_sortIndices_62() const { return ___sortIndices_62; }
	inline SnapshotIndexU5BU5D_t402683559A228DC7C2025F620BF10E09387E7B3E** get_address_of_sortIndices_62() { return &___sortIndices_62; }
	inline void set_sortIndices_62(SnapshotIndexU5BU5D_t402683559A228DC7C2025F620BF10E09387E7B3E* value)
	{
		___sortIndices_62 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___sortIndices_62), (void*)value);
	}

	inline static int32_t get_offset_of_trailIndex_63() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___trailIndex_63)); }
	inline int32_t get_trailIndex_63() const { return ___trailIndex_63; }
	inline int32_t* get_address_of_trailIndex_63() { return &___trailIndex_63; }
	inline void set_trailIndex_63(int32_t value)
	{
		___trailIndex_63 = value;
	}

	inline static int32_t get_offset_of_meshPool_64() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___meshPool_64)); }
	inline MeshU5BU5D_tDD9C723AA6F0225B35A93D871CDC2CEFF7F8CB89* get_meshPool_64() const { return ___meshPool_64; }
	inline MeshU5BU5D_tDD9C723AA6F0225B35A93D871CDC2CEFF7F8CB89** get_address_of_meshPool_64() { return &___meshPool_64; }
	inline void set_meshPool_64(MeshU5BU5D_tDD9C723AA6F0225B35A93D871CDC2CEFF7F8CB89* value)
	{
		___meshPool_64 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___meshPool_64), (void*)value);
	}

	inline static int32_t get_offset_of_meshPoolIndex_65() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___meshPoolIndex_65)); }
	inline int32_t get_meshPoolIndex_65() const { return ___meshPoolIndex_65; }
	inline int32_t* get_address_of_meshPoolIndex_65() { return &___meshPoolIndex_65; }
	inline void set_meshPoolIndex_65(int32_t value)
	{
		___meshPoolIndex_65 = value;
	}

	inline static int32_t get_offset_of_trailMask_66() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___trailMask_66)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_trailMask_66() const { return ___trailMask_66; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_trailMask_66() { return &___trailMask_66; }
	inline void set_trailMask_66(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___trailMask_66 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___trailMask_66), (void*)value);
	}

	inline static int32_t get_offset_of_trailClearMask_67() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___trailClearMask_67)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_trailClearMask_67() const { return ___trailClearMask_67; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_trailClearMask_67() { return &___trailClearMask_67; }
	inline void set_trailClearMask_67(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___trailClearMask_67 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___trailClearMask_67), (void*)value);
	}

	inline static int32_t get_offset_of_trailMaterial_68() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___trailMaterial_68)); }
	inline MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398* get_trailMaterial_68() const { return ___trailMaterial_68; }
	inline MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398** get_address_of_trailMaterial_68() { return &___trailMaterial_68; }
	inline void set_trailMaterial_68(MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398* value)
	{
		___trailMaterial_68 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___trailMaterial_68), (void*)value);
	}

	inline static int32_t get_offset_of_propColorArrayId_69() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___propColorArrayId_69)); }
	inline int32_t get_propColorArrayId_69() const { return ___propColorArrayId_69; }
	inline int32_t* get_address_of_propColorArrayId_69() { return &___propColorArrayId_69; }
	inline void set_propColorArrayId_69(int32_t value)
	{
		___propColorArrayId_69 = value;
	}

	inline static int32_t get_offset_of_theRenderer_70() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___theRenderer_70)); }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * get_theRenderer_70() const { return ___theRenderer_70; }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 ** get_address_of_theRenderer_70() { return &___theRenderer_70; }
	inline void set_theRenderer_70(Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * value)
	{
		___theRenderer_70 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___theRenderer_70), (void*)value);
	}

	inline static int32_t get_offset_of_lastCornerMinPos_71() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lastCornerMinPos_71)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_lastCornerMinPos_71() const { return ___lastCornerMinPos_71; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_lastCornerMinPos_71() { return &___lastCornerMinPos_71; }
	inline void set_lastCornerMinPos_71(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___lastCornerMinPos_71 = value;
	}

	inline static int32_t get_offset_of_lastCornerMaxPos_72() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lastCornerMaxPos_72)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_lastCornerMaxPos_72() const { return ___lastCornerMaxPos_72; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_lastCornerMaxPos_72() { return &___lastCornerMaxPos_72; }
	inline void set_lastCornerMaxPos_72(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___lastCornerMaxPos_72 = value;
	}

	inline static int32_t get_offset_of_lastPosition_73() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lastPosition_73)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_lastPosition_73() const { return ___lastPosition_73; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_lastPosition_73() { return &___lastPosition_73; }
	inline void set_lastPosition_73(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___lastPosition_73 = value;
	}

	inline static int32_t get_offset_of_lastRandomizedPosition_74() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lastRandomizedPosition_74)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_lastRandomizedPosition_74() const { return ___lastRandomizedPosition_74; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_lastRandomizedPosition_74() { return &___lastRandomizedPosition_74; }
	inline void set_lastRandomizedPosition_74(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___lastRandomizedPosition_74 = value;
	}

	inline static int32_t get_offset_of_lastRelativePosition_75() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lastRelativePosition_75)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_lastRelativePosition_75() const { return ___lastRelativePosition_75; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_lastRelativePosition_75() { return &___lastRelativePosition_75; }
	inline void set_lastRelativePosition_75(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___lastRelativePosition_75 = value;
	}

	inline static int32_t get_offset_of_lastRotation_76() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lastRotation_76)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_lastRotation_76() const { return ___lastRotation_76; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_lastRotation_76() { return &___lastRotation_76; }
	inline void set_lastRotation_76(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___lastRotation_76 = value;
	}

	inline static int32_t get_offset_of_lastIntervalTimeCheck_77() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___lastIntervalTimeCheck_77)); }
	inline float get_lastIntervalTimeCheck_77() const { return ___lastIntervalTimeCheck_77; }
	inline float* get_address_of_lastIntervalTimeCheck_77() { return &___lastIntervalTimeCheck_77; }
	inline void set_lastIntervalTimeCheck_77(float value)
	{
		___lastIntervalTimeCheck_77 = value;
	}

	inline static int32_t get_offset_of_properties_78() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___properties_78)); }
	inline MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * get_properties_78() const { return ___properties_78; }
	inline MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 ** get_address_of_properties_78() { return &___properties_78; }
	inline void set_properties_78(MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * value)
	{
		___properties_78 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___properties_78), (void*)value);
	}

	inline static int32_t get_offset_of_matrices_79() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___matrices_79)); }
	inline Matrix4x4U5BU5D_t1C64F7A0C34058334A8A95BF165F0027690598C9* get_matrices_79() const { return ___matrices_79; }
	inline Matrix4x4U5BU5D_t1C64F7A0C34058334A8A95BF165F0027690598C9** get_address_of_matrices_79() { return &___matrices_79; }
	inline void set_matrices_79(Matrix4x4U5BU5D_t1C64F7A0C34058334A8A95BF165F0027690598C9* value)
	{
		___matrices_79 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___matrices_79), (void*)value);
	}

	inline static int32_t get_offset_of_colors_80() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___colors_80)); }
	inline Vector4U5BU5D_t51402C154FFFCF7217A9BEC4B834F0B726C10F66* get_colors_80() const { return ___colors_80; }
	inline Vector4U5BU5D_t51402C154FFFCF7217A9BEC4B834F0B726C10F66** get_address_of_colors_80() { return &___colors_80; }
	inline void set_colors_80(Vector4U5BU5D_t51402C154FFFCF7217A9BEC4B834F0B726C10F66* value)
	{
		___colors_80 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___colors_80), (void*)value);
	}

	inline static int32_t get_offset_of_renderQueue_82() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___renderQueue_82)); }
	inline int32_t get_renderQueue_82() const { return ___renderQueue_82; }
	inline int32_t* get_address_of_renderQueue_82() { return &___renderQueue_82; }
	inline void set_renderQueue_82(int32_t value)
	{
		___renderQueue_82 = value;
	}

	inline static int32_t get_offset_of_skinnedMeshRenderer_83() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___skinnedMeshRenderer_83)); }
	inline SkinnedMeshRenderer_tFC8103EE7842F7F8A98BEF0C855D32A9711B7B65 * get_skinnedMeshRenderer_83() const { return ___skinnedMeshRenderer_83; }
	inline SkinnedMeshRenderer_tFC8103EE7842F7F8A98BEF0C855D32A9711B7B65 ** get_address_of_skinnedMeshRenderer_83() { return &___skinnedMeshRenderer_83; }
	inline void set_skinnedMeshRenderer_83(SkinnedMeshRenderer_tFC8103EE7842F7F8A98BEF0C855D32A9711B7B65 * value)
	{
		___skinnedMeshRenderer_83 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___skinnedMeshRenderer_83), (void*)value);
	}

	inline static int32_t get_offset_of_isSkinned_84() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___isSkinned_84)); }
	inline bool get_isSkinned_84() const { return ___isSkinned_84; }
	inline bool* get_address_of_isSkinned_84() { return &___isSkinned_84; }
	inline void set_isSkinned_84(bool value)
	{
		___isSkinned_84 = value;
	}

	inline static int32_t get_offset_of_bakeTime_85() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___bakeTime_85)); }
	inline int32_t get_bakeTime_85() const { return ___bakeTime_85; }
	inline int32_t* get_address_of_bakeTime_85() { return &___bakeTime_85; }
	inline void set_bakeTime_85(int32_t value)
	{
		___bakeTime_85 = value;
	}

	inline static int32_t get_offset_of_batchNumber_86() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___batchNumber_86)); }
	inline int32_t get_batchNumber_86() const { return ___batchNumber_86; }
	inline int32_t* get_address_of_batchNumber_86() { return &___batchNumber_86; }
	inline void set_batchNumber_86(int32_t value)
	{
		___batchNumber_86 = value;
	}

	inline static int32_t get_offset_of_quadMesh_87() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___quadMesh_87)); }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * get_quadMesh_87() const { return ___quadMesh_87; }
	inline Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C ** get_address_of_quadMesh_87() { return &___quadMesh_87; }
	inline void set_quadMesh_87(Mesh_t6106B8D8E4C691321581AB0445552EC78B947B8C * value)
	{
		___quadMesh_87 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___quadMesh_87), (void*)value);
	}

	inline static int32_t get_offset_of_effectMaterials_88() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___effectMaterials_88)); }
	inline Dictionary_2_t29EF377760EAE2E4C34F7125BB6CDFE3AE8985A1 * get_effectMaterials_88() const { return ___effectMaterials_88; }
	inline Dictionary_2_t29EF377760EAE2E4C34F7125BB6CDFE3AE8985A1 ** get_address_of_effectMaterials_88() { return &___effectMaterials_88; }
	inline void set_effectMaterials_88(Dictionary_2_t29EF377760EAE2E4C34F7125BB6CDFE3AE8985A1 * value)
	{
		___effectMaterials_88 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___effectMaterials_88), (void*)value);
	}

	inline static int32_t get_offset_of_orient_89() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___orient_89)); }
	inline bool get_orient_89() const { return ___orient_89; }
	inline bool* get_address_of_orient_89() { return &___orient_89; }
	inline void set_orient_89(bool value)
	{
		___orient_89 = value;
	}

	inline static int32_t get_offset_of_groundNormal_90() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___groundNormal_90)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_groundNormal_90() const { return ___groundNormal_90; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_groundNormal_90() { return &___groundNormal_90; }
	inline void set_groundNormal_90(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___groundNormal_90 = value;
	}

	inline static int32_t get_offset_of_startFrameCount_91() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___startFrameCount_91)); }
	inline int32_t get_startFrameCount_91() const { return ___startFrameCount_91; }
	inline int32_t* get_address_of_startFrameCount_91() { return &___startFrameCount_91; }
	inline void set_startFrameCount_91(int32_t value)
	{
		___startFrameCount_91 = value;
	}

	inline static int32_t get_offset_of_smoothDuration_92() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___smoothDuration_92)); }
	inline float get_smoothDuration_92() const { return ___smoothDuration_92; }
	inline float* get_address_of_smoothDuration_92() { return &___smoothDuration_92; }
	inline void set_smoothDuration_92(float value)
	{
		___smoothDuration_92 = value;
	}

	inline static int32_t get_offset_of_animator_93() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___animator_93)); }
	inline Animator_tF1A88E66B3B731DDA75A066DBAE9C55837660F5A * get_animator_93() const { return ___animator_93; }
	inline Animator_tF1A88E66B3B731DDA75A066DBAE9C55837660F5A ** get_address_of_animator_93() { return &___animator_93; }
	inline void set_animator_93(Animator_tF1A88E66B3B731DDA75A066DBAE9C55837660F5A * value)
	{
		___animator_93 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___animator_93), (void*)value);
	}

	inline static int32_t get_offset_of_isLimitedToAnimationStates_94() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___isLimitedToAnimationStates_94)); }
	inline bool get_isLimitedToAnimationStates_94() const { return ___isLimitedToAnimationStates_94; }
	inline bool* get_address_of_isLimitedToAnimationStates_94() { return &___isLimitedToAnimationStates_94; }
	inline void set_isLimitedToAnimationStates_94(bool value)
	{
		___isLimitedToAnimationStates_94 = value;
	}

	inline static int32_t get_offset_of_stateHashes_95() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___stateHashes_95)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_stateHashes_95() const { return ___stateHashes_95; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_stateHashes_95() { return &___stateHashes_95; }
	inline void set_stateHashes_95(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___stateHashes_95 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___stateHashes_95), (void*)value);
	}

	inline static int32_t get_offset_of_supportsGPUInstancing_96() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___supportsGPUInstancing_96)); }
	inline bool get_supportsGPUInstancing_96() const { return ___supportsGPUInstancing_96; }
	inline bool* get_address_of_supportsGPUInstancing_96() { return &___supportsGPUInstancing_96; }
	inline void set_supportsGPUInstancing_96(bool value)
	{
		___supportsGPUInstancing_96 = value;
	}

	inline static int32_t get_offset_of_propertyBlock_97() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___propertyBlock_97)); }
	inline MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * get_propertyBlock_97() const { return ___propertyBlock_97; }
	inline MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 ** get_address_of_propertyBlock_97() { return &___propertyBlock_97; }
	inline void set_propertyBlock_97(MaterialPropertyBlock_t72A481768111C6F11DCDCD44F0C7F99F1CA79E13 * value)
	{
		___propertyBlock_97 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___propertyBlock_97), (void*)value);
	}

	inline static int32_t get_offset_of_colorRandomAtStart_98() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___colorRandomAtStart_98)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_colorRandomAtStart_98() const { return ___colorRandomAtStart_98; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_colorRandomAtStart_98() { return &___colorRandomAtStart_98; }
	inline void set_colorRandomAtStart_98(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___colorRandomAtStart_98 = value;
	}

	inline static int32_t get_offset_of_bakedColorOverTime_99() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___bakedColorOverTime_99)); }
	inline ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* get_bakedColorOverTime_99() const { return ___bakedColorOverTime_99; }
	inline ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399** get_address_of_bakedColorOverTime_99() { return &___bakedColorOverTime_99; }
	inline void set_bakedColorOverTime_99(ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* value)
	{
		___bakedColorOverTime_99 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bakedColorOverTime_99), (void*)value);
	}

	inline static int32_t get_offset_of_bakedColorStartPalette_100() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___bakedColorStartPalette_100)); }
	inline ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* get_bakedColorStartPalette_100() const { return ___bakedColorStartPalette_100; }
	inline ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399** get_address_of_bakedColorStartPalette_100() { return &___bakedColorStartPalette_100; }
	inline void set_bakedColorStartPalette_100(ColorU5BU5D_t166D390E0E6F24360F990D1F81881A72B73CA399* value)
	{
		___bakedColorStartPalette_100 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bakedColorStartPalette_100), (void*)value);
	}

	inline static int32_t get_offset_of_bakedScaleOverTime_101() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___bakedScaleOverTime_101)); }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* get_bakedScaleOverTime_101() const { return ___bakedScaleOverTime_101; }
	inline SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5** get_address_of_bakedScaleOverTime_101() { return &___bakedScaleOverTime_101; }
	inline void set_bakedScaleOverTime_101(SingleU5BU5D_tA7139B7CAA40EAEF9178E2C386C8A5993754FDD5* value)
	{
		___bakedScaleOverTime_101 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bakedScaleOverTime_101), (void*)value);
	}

	inline static int32_t get_offset_of_wasInactive_102() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6, ___wasInactive_102)); }
	inline bool get_wasInactive_102() const { return ___wasInactive_102; }
	inline bool* get_address_of_wasInactive_102() { return &___wasInactive_102; }
	inline void set_wasInactive_102(bool value)
	{
		___wasInactive_102 = value;
	}
};

struct TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6_StaticFields
{
public:
	// System.Int32 TrailsFX.TrailEffect::globalRenderQueue
	int32_t ___globalRenderQueue_81;

public:
	inline static int32_t get_offset_of_globalRenderQueue_81() { return static_cast<int32_t>(offsetof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6_StaticFields, ___globalRenderQueue_81)); }
	inline int32_t get_globalRenderQueue_81() const { return ___globalRenderQueue_81; }
	inline int32_t* get_address_of_globalRenderQueue_81() { return &___globalRenderQueue_81; }
	inline void set_globalRenderQueue_81(int32_t value)
	{
		___globalRenderQueue_81 = value;
	}
};


// Try
struct Try_t068DE3CDE93ECDCFD443751A0EE5CBF727782B31  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.Single Try::speed
	float ___speed_4;
	// UnityEngine.Transform Try::target
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___target_5;

public:
	inline static int32_t get_offset_of_speed_4() { return static_cast<int32_t>(offsetof(Try_t068DE3CDE93ECDCFD443751A0EE5CBF727782B31, ___speed_4)); }
	inline float get_speed_4() const { return ___speed_4; }
	inline float* get_address_of_speed_4() { return &___speed_4; }
	inline void set_speed_4(float value)
	{
		___speed_4 = value;
	}

	inline static int32_t get_offset_of_target_5() { return static_cast<int32_t>(offsetof(Try_t068DE3CDE93ECDCFD443751A0EE5CBF727782B31, ___target_5)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_target_5() const { return ___target_5; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_target_5() { return &___target_5; }
	inline void set_target_5(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___target_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___target_5), (void*)value);
	}
};


// UIController
struct UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.Button[] UIController::but
	ButtonU5BU5D_t363EC059ECDBD3DE56740518F34D8C070331649B* ___but_4;
	// UnityEngine.Material[] UIController::mat
	MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398* ___mat_5;
	// System.Int32 UIController::x
	int32_t ___x_6;
	// UnityEngine.Renderer UIController::Ren
	Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * ___Ren_7;
	// UnityEngine.GameObject UIController::text
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___text_8;
	// UnityEngine.GameObject UIController::moveAnimObject
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___moveAnimObject_9;
	// UnityEngine.GameObject UIController::Planett
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___Planett_10;
	// UnityEngine.GameObject[] UIController::Planettt
	GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* ___Planettt_11;
	// UnityEngine.GameObject[] UIController::Planetttt
	GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* ___Planetttt_12;

public:
	inline static int32_t get_offset_of_but_4() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___but_4)); }
	inline ButtonU5BU5D_t363EC059ECDBD3DE56740518F34D8C070331649B* get_but_4() const { return ___but_4; }
	inline ButtonU5BU5D_t363EC059ECDBD3DE56740518F34D8C070331649B** get_address_of_but_4() { return &___but_4; }
	inline void set_but_4(ButtonU5BU5D_t363EC059ECDBD3DE56740518F34D8C070331649B* value)
	{
		___but_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___but_4), (void*)value);
	}

	inline static int32_t get_offset_of_mat_5() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___mat_5)); }
	inline MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398* get_mat_5() const { return ___mat_5; }
	inline MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398** get_address_of_mat_5() { return &___mat_5; }
	inline void set_mat_5(MaterialU5BU5D_tD2350F98F2A1BB6C7A5FBFE1474DFC47331AB398* value)
	{
		___mat_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___mat_5), (void*)value);
	}

	inline static int32_t get_offset_of_x_6() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___x_6)); }
	inline int32_t get_x_6() const { return ___x_6; }
	inline int32_t* get_address_of_x_6() { return &___x_6; }
	inline void set_x_6(int32_t value)
	{
		___x_6 = value;
	}

	inline static int32_t get_offset_of_Ren_7() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___Ren_7)); }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * get_Ren_7() const { return ___Ren_7; }
	inline Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 ** get_address_of_Ren_7() { return &___Ren_7; }
	inline void set_Ren_7(Renderer_t0556D67DD582620D1F495627EDE30D03284151F4 * value)
	{
		___Ren_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Ren_7), (void*)value);
	}

	inline static int32_t get_offset_of_text_8() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___text_8)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_text_8() const { return ___text_8; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_text_8() { return &___text_8; }
	inline void set_text_8(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___text_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___text_8), (void*)value);
	}

	inline static int32_t get_offset_of_moveAnimObject_9() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___moveAnimObject_9)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_moveAnimObject_9() const { return ___moveAnimObject_9; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_moveAnimObject_9() { return &___moveAnimObject_9; }
	inline void set_moveAnimObject_9(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___moveAnimObject_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___moveAnimObject_9), (void*)value);
	}

	inline static int32_t get_offset_of_Planett_10() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___Planett_10)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_Planett_10() const { return ___Planett_10; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_Planett_10() { return &___Planett_10; }
	inline void set_Planett_10(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___Planett_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planett_10), (void*)value);
	}

	inline static int32_t get_offset_of_Planettt_11() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___Planettt_11)); }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* get_Planettt_11() const { return ___Planettt_11; }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520** get_address_of_Planettt_11() { return &___Planettt_11; }
	inline void set_Planettt_11(GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* value)
	{
		___Planettt_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planettt_11), (void*)value);
	}

	inline static int32_t get_offset_of_Planetttt_12() { return static_cast<int32_t>(offsetof(UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE, ___Planetttt_12)); }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* get_Planetttt_12() const { return ___Planetttt_12; }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520** get_address_of_Planetttt_12() { return &___Planetttt_12; }
	inline void set_Planetttt_12(GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* value)
	{
		___Planetttt_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Planetttt_12), (void*)value);
	}
};


// Zoom
struct Zoom_t880AFB749C3A75A781108A6A230D45E6B07952F0  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.SpriteRenderer Zoom::targetSize
	SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * ___targetSize_4;

public:
	inline static int32_t get_offset_of_targetSize_4() { return static_cast<int32_t>(offsetof(Zoom_t880AFB749C3A75A781108A6A230D45E6B07952F0, ___targetSize_4)); }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * get_targetSize_4() const { return ___targetSize_4; }
	inline SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F ** get_address_of_targetSize_4() { return &___targetSize_4; }
	inline void set_targetSize_4(SpriteRenderer_tCD51E875611195DBB91123B68434881D3441BC6F * value)
	{
		___targetSize_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___targetSize_4), (void*)value);
	}
};


// a
struct a_t843891B3C1396BC2023E082606A721962D84C3CB  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// System.String a::gameId
	String_t* ___gameId_4;
	// System.String a::surfacingId
	String_t* ___surfacingId_5;
	// System.Boolean a::testMode
	bool ___testMode_6;

public:
	inline static int32_t get_offset_of_gameId_4() { return static_cast<int32_t>(offsetof(a_t843891B3C1396BC2023E082606A721962D84C3CB, ___gameId_4)); }
	inline String_t* get_gameId_4() const { return ___gameId_4; }
	inline String_t** get_address_of_gameId_4() { return &___gameId_4; }
	inline void set_gameId_4(String_t* value)
	{
		___gameId_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___gameId_4), (void*)value);
	}

	inline static int32_t get_offset_of_surfacingId_5() { return static_cast<int32_t>(offsetof(a_t843891B3C1396BC2023E082606A721962D84C3CB, ___surfacingId_5)); }
	inline String_t* get_surfacingId_5() const { return ___surfacingId_5; }
	inline String_t** get_address_of_surfacingId_5() { return &___surfacingId_5; }
	inline void set_surfacingId_5(String_t* value)
	{
		___surfacingId_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___surfacingId_5), (void*)value);
	}

	inline static int32_t get_offset_of_testMode_6() { return static_cast<int32_t>(offsetof(a_t843891B3C1396BC2023E082606A721962D84C3CB, ___testMode_6)); }
	inline bool get_testMode_6() const { return ___testMode_6; }
	inline bool* get_address_of_testMode_6() { return &___testMode_6; }
	inline void set_testMode_6(bool value)
	{
		___testMode_6 = value;
	}
};


// autoRotate
struct autoRotate_tE85101E00B3E6285EBEC40692C8D0319A9017ED4  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject autoRotate::cube1
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___cube1_4;
	// System.Int32 autoRotate::t
	int32_t ___t_5;

public:
	inline static int32_t get_offset_of_cube1_4() { return static_cast<int32_t>(offsetof(autoRotate_tE85101E00B3E6285EBEC40692C8D0319A9017ED4, ___cube1_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_cube1_4() const { return ___cube1_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_cube1_4() { return &___cube1_4; }
	inline void set_cube1_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___cube1_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cube1_4), (void*)value);
	}

	inline static int32_t get_offset_of_t_5() { return static_cast<int32_t>(offsetof(autoRotate_tE85101E00B3E6285EBEC40692C8D0319A9017ED4, ___t_5)); }
	inline int32_t get_t_5() const { return ___t_5; }
	inline int32_t* get_address_of_t_5() { return &___t_5; }
	inline void set_t_5(int32_t value)
	{
		___t_5 = value;
	}
};


// checkSpeed
struct checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.UI.Text checkSpeed::m_MyText
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___m_MyText_4;
	// UnityEngine.Rigidbody checkSpeed::WheelWeight
	Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * ___WheelWeight_5;
	// UnityEngine.GameObject checkSpeed::ButtonGroupOff
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___ButtonGroupOff_6;
	// UnityEngine.GameObject checkSpeed::NonTouchingPanel
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___NonTouchingPanel_7;
	// UnityEngine.GameObject checkSpeed::mmm
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___mmm_8;
	// UnityEngine.GameObject[] checkSpeed::QuayGradient
	GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* ___QuayGradient_9;
	// UnityEngine.GameObject checkSpeed::flashLight
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___flashLight_10;
	// UnityEngine.GameObject checkSpeed::ResultPanel
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___ResultPanel_11;
	// UnityEngine.UI.Button checkSpeed::yourButton
	Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * ___yourButton_12;
	// System.Int32 checkSpeed::Random
	int32_t ___Random_13;
	// UnityEngine.GameObject checkSpeed::Sound
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___Sound_14;
	// System.Int32 checkSpeed::l
	int32_t ___l_15;
	// System.Int32 checkSpeed::t
	int32_t ___t_16;
	// System.Single checkSpeed::k
	float ___k_17;
	// System.Int32 checkSpeed::count
	int32_t ___count_18;
	// System.Boolean checkSpeed::count1
	bool ___count1_19;
	// System.Int32 checkSpeed::boi
	int32_t ___boi_20;
	// UnityEngine.UI.Text checkSpeed::DebugAngularVelocity
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___DebugAngularVelocity_21;
	// UnityEngine.UI.Text checkSpeed::DebugAngular
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___DebugAngular_22;
	// System.Int32 checkSpeed::x
	int32_t ___x_23;
	// System.Int32 checkSpeed::ll
	int32_t ___ll_24;
	// UnityEngine.Vector3 checkSpeed::eulerAngles
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___eulerAngles_25;
	// System.Boolean checkSpeed::isFirstExplode
	bool ___isFirstExplode_26;
	// System.Boolean checkSpeed::isShowResult
	bool ___isShowResult_27;
	// System.Single checkSpeed::time
	float ___time_28;

public:
	inline static int32_t get_offset_of_m_MyText_4() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___m_MyText_4)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_m_MyText_4() const { return ___m_MyText_4; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_m_MyText_4() { return &___m_MyText_4; }
	inline void set_m_MyText_4(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___m_MyText_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_MyText_4), (void*)value);
	}

	inline static int32_t get_offset_of_WheelWeight_5() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___WheelWeight_5)); }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * get_WheelWeight_5() const { return ___WheelWeight_5; }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 ** get_address_of_WheelWeight_5() { return &___WheelWeight_5; }
	inline void set_WheelWeight_5(Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * value)
	{
		___WheelWeight_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___WheelWeight_5), (void*)value);
	}

	inline static int32_t get_offset_of_ButtonGroupOff_6() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___ButtonGroupOff_6)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_ButtonGroupOff_6() const { return ___ButtonGroupOff_6; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_ButtonGroupOff_6() { return &___ButtonGroupOff_6; }
	inline void set_ButtonGroupOff_6(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___ButtonGroupOff_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ButtonGroupOff_6), (void*)value);
	}

	inline static int32_t get_offset_of_NonTouchingPanel_7() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___NonTouchingPanel_7)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_NonTouchingPanel_7() const { return ___NonTouchingPanel_7; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_NonTouchingPanel_7() { return &___NonTouchingPanel_7; }
	inline void set_NonTouchingPanel_7(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___NonTouchingPanel_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___NonTouchingPanel_7), (void*)value);
	}

	inline static int32_t get_offset_of_mmm_8() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___mmm_8)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_mmm_8() const { return ___mmm_8; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_mmm_8() { return &___mmm_8; }
	inline void set_mmm_8(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___mmm_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___mmm_8), (void*)value);
	}

	inline static int32_t get_offset_of_QuayGradient_9() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___QuayGradient_9)); }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* get_QuayGradient_9() const { return ___QuayGradient_9; }
	inline GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520** get_address_of_QuayGradient_9() { return &___QuayGradient_9; }
	inline void set_QuayGradient_9(GameObjectU5BU5D_tBF9D474747511CF34A040A1697E34C74C19BB520* value)
	{
		___QuayGradient_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___QuayGradient_9), (void*)value);
	}

	inline static int32_t get_offset_of_flashLight_10() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___flashLight_10)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_flashLight_10() const { return ___flashLight_10; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_flashLight_10() { return &___flashLight_10; }
	inline void set_flashLight_10(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___flashLight_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___flashLight_10), (void*)value);
	}

	inline static int32_t get_offset_of_ResultPanel_11() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___ResultPanel_11)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_ResultPanel_11() const { return ___ResultPanel_11; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_ResultPanel_11() { return &___ResultPanel_11; }
	inline void set_ResultPanel_11(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___ResultPanel_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___ResultPanel_11), (void*)value);
	}

	inline static int32_t get_offset_of_yourButton_12() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___yourButton_12)); }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * get_yourButton_12() const { return ___yourButton_12; }
	inline Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B ** get_address_of_yourButton_12() { return &___yourButton_12; }
	inline void set_yourButton_12(Button_t1203820000D5513FDCCE3D4BFF9C1C9CC755CC2B * value)
	{
		___yourButton_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___yourButton_12), (void*)value);
	}

	inline static int32_t get_offset_of_Random_13() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___Random_13)); }
	inline int32_t get_Random_13() const { return ___Random_13; }
	inline int32_t* get_address_of_Random_13() { return &___Random_13; }
	inline void set_Random_13(int32_t value)
	{
		___Random_13 = value;
	}

	inline static int32_t get_offset_of_Sound_14() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___Sound_14)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_Sound_14() const { return ___Sound_14; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_Sound_14() { return &___Sound_14; }
	inline void set_Sound_14(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___Sound_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Sound_14), (void*)value);
	}

	inline static int32_t get_offset_of_l_15() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___l_15)); }
	inline int32_t get_l_15() const { return ___l_15; }
	inline int32_t* get_address_of_l_15() { return &___l_15; }
	inline void set_l_15(int32_t value)
	{
		___l_15 = value;
	}

	inline static int32_t get_offset_of_t_16() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___t_16)); }
	inline int32_t get_t_16() const { return ___t_16; }
	inline int32_t* get_address_of_t_16() { return &___t_16; }
	inline void set_t_16(int32_t value)
	{
		___t_16 = value;
	}

	inline static int32_t get_offset_of_k_17() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___k_17)); }
	inline float get_k_17() const { return ___k_17; }
	inline float* get_address_of_k_17() { return &___k_17; }
	inline void set_k_17(float value)
	{
		___k_17 = value;
	}

	inline static int32_t get_offset_of_count_18() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___count_18)); }
	inline int32_t get_count_18() const { return ___count_18; }
	inline int32_t* get_address_of_count_18() { return &___count_18; }
	inline void set_count_18(int32_t value)
	{
		___count_18 = value;
	}

	inline static int32_t get_offset_of_count1_19() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___count1_19)); }
	inline bool get_count1_19() const { return ___count1_19; }
	inline bool* get_address_of_count1_19() { return &___count1_19; }
	inline void set_count1_19(bool value)
	{
		___count1_19 = value;
	}

	inline static int32_t get_offset_of_boi_20() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___boi_20)); }
	inline int32_t get_boi_20() const { return ___boi_20; }
	inline int32_t* get_address_of_boi_20() { return &___boi_20; }
	inline void set_boi_20(int32_t value)
	{
		___boi_20 = value;
	}

	inline static int32_t get_offset_of_DebugAngularVelocity_21() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___DebugAngularVelocity_21)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_DebugAngularVelocity_21() const { return ___DebugAngularVelocity_21; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_DebugAngularVelocity_21() { return &___DebugAngularVelocity_21; }
	inline void set_DebugAngularVelocity_21(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___DebugAngularVelocity_21 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___DebugAngularVelocity_21), (void*)value);
	}

	inline static int32_t get_offset_of_DebugAngular_22() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___DebugAngular_22)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_DebugAngular_22() const { return ___DebugAngular_22; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_DebugAngular_22() { return &___DebugAngular_22; }
	inline void set_DebugAngular_22(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___DebugAngular_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___DebugAngular_22), (void*)value);
	}

	inline static int32_t get_offset_of_x_23() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___x_23)); }
	inline int32_t get_x_23() const { return ___x_23; }
	inline int32_t* get_address_of_x_23() { return &___x_23; }
	inline void set_x_23(int32_t value)
	{
		___x_23 = value;
	}

	inline static int32_t get_offset_of_ll_24() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___ll_24)); }
	inline int32_t get_ll_24() const { return ___ll_24; }
	inline int32_t* get_address_of_ll_24() { return &___ll_24; }
	inline void set_ll_24(int32_t value)
	{
		___ll_24 = value;
	}

	inline static int32_t get_offset_of_eulerAngles_25() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___eulerAngles_25)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_eulerAngles_25() const { return ___eulerAngles_25; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_eulerAngles_25() { return &___eulerAngles_25; }
	inline void set_eulerAngles_25(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___eulerAngles_25 = value;
	}

	inline static int32_t get_offset_of_isFirstExplode_26() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___isFirstExplode_26)); }
	inline bool get_isFirstExplode_26() const { return ___isFirstExplode_26; }
	inline bool* get_address_of_isFirstExplode_26() { return &___isFirstExplode_26; }
	inline void set_isFirstExplode_26(bool value)
	{
		___isFirstExplode_26 = value;
	}

	inline static int32_t get_offset_of_isShowResult_27() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___isShowResult_27)); }
	inline bool get_isShowResult_27() const { return ___isShowResult_27; }
	inline bool* get_address_of_isShowResult_27() { return &___isShowResult_27; }
	inline void set_isShowResult_27(bool value)
	{
		___isShowResult_27 = value;
	}

	inline static int32_t get_offset_of_time_28() { return static_cast<int32_t>(offsetof(checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7, ___time_28)); }
	inline float get_time_28() const { return ___time_28; }
	inline float* get_address_of_time_28() { return &___time_28; }
	inline void set_time_28(float value)
	{
		___time_28 = value;
	}
};


// music
struct music_tF2D9FBB28EA016ED0FA9457F64175F4335101612  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.AudioSource music::source
	AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C * ___source_4;
	// UnityEngine.UI.Text music::m_MyText
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___m_MyText_5;
	// TMPro.TextMeshPro[] music::TargetText
	TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* ___TargetText_6;

public:
	inline static int32_t get_offset_of_source_4() { return static_cast<int32_t>(offsetof(music_tF2D9FBB28EA016ED0FA9457F64175F4335101612, ___source_4)); }
	inline AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C * get_source_4() const { return ___source_4; }
	inline AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C ** get_address_of_source_4() { return &___source_4; }
	inline void set_source_4(AudioSource_t5196F862B4E60F404613361C90D87FBDD041E93C * value)
	{
		___source_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___source_4), (void*)value);
	}

	inline static int32_t get_offset_of_m_MyText_5() { return static_cast<int32_t>(offsetof(music_tF2D9FBB28EA016ED0FA9457F64175F4335101612, ___m_MyText_5)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_m_MyText_5() const { return ___m_MyText_5; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_m_MyText_5() { return &___m_MyText_5; }
	inline void set_m_MyText_5(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___m_MyText_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___m_MyText_5), (void*)value);
	}

	inline static int32_t get_offset_of_TargetText_6() { return static_cast<int32_t>(offsetof(music_tF2D9FBB28EA016ED0FA9457F64175F4335101612, ___TargetText_6)); }
	inline TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* get_TargetText_6() const { return ___TargetText_6; }
	inline TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32** get_address_of_TargetText_6() { return &___TargetText_6; }
	inline void set_TargetText_6(TextMeshProU5BU5D_tF22BAC98563F87C7450682797DD9C2AC465C4E32* value)
	{
		___TargetText_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TargetText_6), (void*)value);
	}
};


// quayImage
struct quayImage_t185B700EEF044604F49697BCD93332985BF36EB7  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject quayImage::PanelsMenu
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___PanelsMenu_4;

public:
	inline static int32_t get_offset_of_PanelsMenu_4() { return static_cast<int32_t>(offsetof(quayImage_t185B700EEF044604F49697BCD93332985BF36EB7, ___PanelsMenu_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_PanelsMenu_4() const { return ___PanelsMenu_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_PanelsMenu_4() { return &___PanelsMenu_4; }
	inline void set_PanelsMenu_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___PanelsMenu_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PanelsMenu_4), (void*)value);
	}
};


// quayOb
struct quayOb_tB0C7D246393941C98CEAE2B2422B7A3A7C792117  : public MonoBehaviour_t4A60845CF505405AF8BE8C61CC07F75CADEF6429
{
public:
	// UnityEngine.GameObject quayOb::PanelsMenu
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___PanelsMenu_4;

public:
	inline static int32_t get_offset_of_PanelsMenu_4() { return static_cast<int32_t>(offsetof(quayOb_tB0C7D246393941C98CEAE2B2422B7A3A7C792117, ___PanelsMenu_4)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_PanelsMenu_4() const { return ___PanelsMenu_4; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_PanelsMenu_4() { return &___PanelsMenu_4; }
	inline void set_PanelsMenu_4(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___PanelsMenu_4 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PanelsMenu_4), (void*)value);
	}
};


// Gun
struct Gun_t3C15F78CD5A40BC92F130917A1AA4679FA5874FB  : public Item_t1FD274D610B07F7F6E6AA093A93FB9E32210D36E
{
public:
	// UnityEngine.GameObject Gun::bulletImpactPrefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___bulletImpactPrefab_6;

public:
	inline static int32_t get_offset_of_bulletImpactPrefab_6() { return static_cast<int32_t>(offsetof(Gun_t3C15F78CD5A40BC92F130917A1AA4679FA5874FB, ___bulletImpactPrefab_6)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_bulletImpactPrefab_6() const { return ___bulletImpactPrefab_6; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_bulletImpactPrefab_6() { return &___bulletImpactPrefab_6; }
	inline void set_bulletImpactPrefab_6(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___bulletImpactPrefab_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___bulletImpactPrefab_6), (void*)value);
	}
};


// OwnerShipTransfer
struct OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1  : public MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A
{
public:
	// System.Single OwnerShipTransfer::tiime
	float ___tiime_5;
	// System.Int32 OwnerShipTransfer::k
	int32_t ___k_6;
	// System.Single OwnerShipTransfer::kk
	float ___kk_7;
	// System.Single OwnerShipTransfer::k1
	float ___k1_8;
	// System.Single OwnerShipTransfer::k2
	float ___k2_9;
	// UnityEngine.UI.Text OwnerShipTransfer::My_Text
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___My_Text_10;
	// System.String OwnerShipTransfer::userNameInputText
	String_t* ___userNameInputText_11;
	// UnityEngine.GameObject OwnerShipTransfer::InputName_Panel
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___InputName_Panel_12;
	// UnityEngine.GameObject OwnerShipTransfer::InputCoverRotate_Panel
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___InputCoverRotate_Panel_13;
	// UnityEngine.GameObject OwnerShipTransfer::TapToTakeTurn
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___TapToTakeTurn_14;
	// UnityEngine.GameObject OwnerShipTransfer::CopyStatus
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___CopyStatus_15;
	// UnityEngine.GameObject OwnerShipTransfer::OwnerAgainsRotateBox
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___OwnerAgainsRotateBox_16;
	// System.String[] OwnerShipTransfer::name
	StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* ___name_17;
	// Photon.Realtime.Player OwnerShipTransfer::n
	Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * ___n_18;
	// System.Int32[] OwnerShipTransfer::Copy
	Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* ___Copy_19;
	// System.Boolean OwnerShipTransfer::status
	bool ___status_20;

public:
	inline static int32_t get_offset_of_tiime_5() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___tiime_5)); }
	inline float get_tiime_5() const { return ___tiime_5; }
	inline float* get_address_of_tiime_5() { return &___tiime_5; }
	inline void set_tiime_5(float value)
	{
		___tiime_5 = value;
	}

	inline static int32_t get_offset_of_k_6() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___k_6)); }
	inline int32_t get_k_6() const { return ___k_6; }
	inline int32_t* get_address_of_k_6() { return &___k_6; }
	inline void set_k_6(int32_t value)
	{
		___k_6 = value;
	}

	inline static int32_t get_offset_of_kk_7() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___kk_7)); }
	inline float get_kk_7() const { return ___kk_7; }
	inline float* get_address_of_kk_7() { return &___kk_7; }
	inline void set_kk_7(float value)
	{
		___kk_7 = value;
	}

	inline static int32_t get_offset_of_k1_8() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___k1_8)); }
	inline float get_k1_8() const { return ___k1_8; }
	inline float* get_address_of_k1_8() { return &___k1_8; }
	inline void set_k1_8(float value)
	{
		___k1_8 = value;
	}

	inline static int32_t get_offset_of_k2_9() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___k2_9)); }
	inline float get_k2_9() const { return ___k2_9; }
	inline float* get_address_of_k2_9() { return &___k2_9; }
	inline void set_k2_9(float value)
	{
		___k2_9 = value;
	}

	inline static int32_t get_offset_of_My_Text_10() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___My_Text_10)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_My_Text_10() const { return ___My_Text_10; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_My_Text_10() { return &___My_Text_10; }
	inline void set_My_Text_10(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___My_Text_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___My_Text_10), (void*)value);
	}

	inline static int32_t get_offset_of_userNameInputText_11() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___userNameInputText_11)); }
	inline String_t* get_userNameInputText_11() const { return ___userNameInputText_11; }
	inline String_t** get_address_of_userNameInputText_11() { return &___userNameInputText_11; }
	inline void set_userNameInputText_11(String_t* value)
	{
		___userNameInputText_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___userNameInputText_11), (void*)value);
	}

	inline static int32_t get_offset_of_InputName_Panel_12() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___InputName_Panel_12)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_InputName_Panel_12() const { return ___InputName_Panel_12; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_InputName_Panel_12() { return &___InputName_Panel_12; }
	inline void set_InputName_Panel_12(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___InputName_Panel_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___InputName_Panel_12), (void*)value);
	}

	inline static int32_t get_offset_of_InputCoverRotate_Panel_13() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___InputCoverRotate_Panel_13)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_InputCoverRotate_Panel_13() const { return ___InputCoverRotate_Panel_13; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_InputCoverRotate_Panel_13() { return &___InputCoverRotate_Panel_13; }
	inline void set_InputCoverRotate_Panel_13(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___InputCoverRotate_Panel_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___InputCoverRotate_Panel_13), (void*)value);
	}

	inline static int32_t get_offset_of_TapToTakeTurn_14() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___TapToTakeTurn_14)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_TapToTakeTurn_14() const { return ___TapToTakeTurn_14; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_TapToTakeTurn_14() { return &___TapToTakeTurn_14; }
	inline void set_TapToTakeTurn_14(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___TapToTakeTurn_14 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TapToTakeTurn_14), (void*)value);
	}

	inline static int32_t get_offset_of_CopyStatus_15() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___CopyStatus_15)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_CopyStatus_15() const { return ___CopyStatus_15; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_CopyStatus_15() { return &___CopyStatus_15; }
	inline void set_CopyStatus_15(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___CopyStatus_15 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___CopyStatus_15), (void*)value);
	}

	inline static int32_t get_offset_of_OwnerAgainsRotateBox_16() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___OwnerAgainsRotateBox_16)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_OwnerAgainsRotateBox_16() const { return ___OwnerAgainsRotateBox_16; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_OwnerAgainsRotateBox_16() { return &___OwnerAgainsRotateBox_16; }
	inline void set_OwnerAgainsRotateBox_16(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___OwnerAgainsRotateBox_16 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OwnerAgainsRotateBox_16), (void*)value);
	}

	inline static int32_t get_offset_of_name_17() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___name_17)); }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* get_name_17() const { return ___name_17; }
	inline StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E** get_address_of_name_17() { return &___name_17; }
	inline void set_name_17(StringU5BU5D_t933FB07893230EA91C40FF900D5400665E87B14E* value)
	{
		___name_17 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___name_17), (void*)value);
	}

	inline static int32_t get_offset_of_n_18() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___n_18)); }
	inline Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * get_n_18() const { return ___n_18; }
	inline Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 ** get_address_of_n_18() { return &___n_18; }
	inline void set_n_18(Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * value)
	{
		___n_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___n_18), (void*)value);
	}

	inline static int32_t get_offset_of_Copy_19() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___Copy_19)); }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* get_Copy_19() const { return ___Copy_19; }
	inline Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83** get_address_of_Copy_19() { return &___Copy_19; }
	inline void set_Copy_19(Int32U5BU5D_t2B9E4FDDDB9F0A00EC0AC631BA2DA915EB1ECF83* value)
	{
		___Copy_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Copy_19), (void*)value);
	}

	inline static int32_t get_offset_of_status_20() { return static_cast<int32_t>(offsetof(OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1, ___status_20)); }
	inline bool get_status_20() const { return ___status_20; }
	inline bool* get_address_of_status_20() { return &___status_20; }
	inline void set_status_20(bool value)
	{
		___status_20 = value;
	}
};


// Photon.Pun.MonoBehaviourPunCallbacks
struct MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D  : public MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A
{
public:

public:
};


// Photon.Pun.UtilityScripts.MoveByKeys
struct MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA  : public MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A
{
public:
	// System.Single Photon.Pun.UtilityScripts.MoveByKeys::Speed
	float ___Speed_5;
	// System.Single Photon.Pun.UtilityScripts.MoveByKeys::JumpForce
	float ___JumpForce_6;
	// System.Single Photon.Pun.UtilityScripts.MoveByKeys::JumpTimeout
	float ___JumpTimeout_7;
	// System.Boolean Photon.Pun.UtilityScripts.MoveByKeys::isSprite
	bool ___isSprite_8;
	// System.Single Photon.Pun.UtilityScripts.MoveByKeys::jumpingTime
	float ___jumpingTime_9;
	// UnityEngine.Rigidbody Photon.Pun.UtilityScripts.MoveByKeys::body
	Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * ___body_10;
	// UnityEngine.Rigidbody2D Photon.Pun.UtilityScripts.MoveByKeys::body2d
	Rigidbody2D_tBDC6900A76D3C47E291446FF008D02B817C81CDE * ___body2d_11;

public:
	inline static int32_t get_offset_of_Speed_5() { return static_cast<int32_t>(offsetof(MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA, ___Speed_5)); }
	inline float get_Speed_5() const { return ___Speed_5; }
	inline float* get_address_of_Speed_5() { return &___Speed_5; }
	inline void set_Speed_5(float value)
	{
		___Speed_5 = value;
	}

	inline static int32_t get_offset_of_JumpForce_6() { return static_cast<int32_t>(offsetof(MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA, ___JumpForce_6)); }
	inline float get_JumpForce_6() const { return ___JumpForce_6; }
	inline float* get_address_of_JumpForce_6() { return &___JumpForce_6; }
	inline void set_JumpForce_6(float value)
	{
		___JumpForce_6 = value;
	}

	inline static int32_t get_offset_of_JumpTimeout_7() { return static_cast<int32_t>(offsetof(MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA, ___JumpTimeout_7)); }
	inline float get_JumpTimeout_7() const { return ___JumpTimeout_7; }
	inline float* get_address_of_JumpTimeout_7() { return &___JumpTimeout_7; }
	inline void set_JumpTimeout_7(float value)
	{
		___JumpTimeout_7 = value;
	}

	inline static int32_t get_offset_of_isSprite_8() { return static_cast<int32_t>(offsetof(MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA, ___isSprite_8)); }
	inline bool get_isSprite_8() const { return ___isSprite_8; }
	inline bool* get_address_of_isSprite_8() { return &___isSprite_8; }
	inline void set_isSprite_8(bool value)
	{
		___isSprite_8 = value;
	}

	inline static int32_t get_offset_of_jumpingTime_9() { return static_cast<int32_t>(offsetof(MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA, ___jumpingTime_9)); }
	inline float get_jumpingTime_9() const { return ___jumpingTime_9; }
	inline float* get_address_of_jumpingTime_9() { return &___jumpingTime_9; }
	inline void set_jumpingTime_9(float value)
	{
		___jumpingTime_9 = value;
	}

	inline static int32_t get_offset_of_body_10() { return static_cast<int32_t>(offsetof(MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA, ___body_10)); }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * get_body_10() const { return ___body_10; }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 ** get_address_of_body_10() { return &___body_10; }
	inline void set_body_10(Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * value)
	{
		___body_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___body_10), (void*)value);
	}

	inline static int32_t get_offset_of_body2d_11() { return static_cast<int32_t>(offsetof(MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA, ___body2d_11)); }
	inline Rigidbody2D_tBDC6900A76D3C47E291446FF008D02B817C81CDE * get_body2d_11() const { return ___body2d_11; }
	inline Rigidbody2D_tBDC6900A76D3C47E291446FF008D02B817C81CDE ** get_address_of_body2d_11() { return &___body2d_11; }
	inline void set_body2d_11(Rigidbody2D_tBDC6900A76D3C47E291446FF008D02B817C81CDE * value)
	{
		___body2d_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___body2d_11), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.OnClickDestroy
struct OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D  : public MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A
{
public:
	// UnityEngine.EventSystems.PointerEventData/InputButton Photon.Pun.UtilityScripts.OnClickDestroy::Button
	int32_t ___Button_5;
	// UnityEngine.KeyCode Photon.Pun.UtilityScripts.OnClickDestroy::ModifierKey
	int32_t ___ModifierKey_6;
	// System.Boolean Photon.Pun.UtilityScripts.OnClickDestroy::DestroyByRpc
	bool ___DestroyByRpc_7;

public:
	inline static int32_t get_offset_of_Button_5() { return static_cast<int32_t>(offsetof(OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D, ___Button_5)); }
	inline int32_t get_Button_5() const { return ___Button_5; }
	inline int32_t* get_address_of_Button_5() { return &___Button_5; }
	inline void set_Button_5(int32_t value)
	{
		___Button_5 = value;
	}

	inline static int32_t get_offset_of_ModifierKey_6() { return static_cast<int32_t>(offsetof(OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D, ___ModifierKey_6)); }
	inline int32_t get_ModifierKey_6() const { return ___ModifierKey_6; }
	inline int32_t* get_address_of_ModifierKey_6() { return &___ModifierKey_6; }
	inline void set_ModifierKey_6(int32_t value)
	{
		___ModifierKey_6 = value;
	}

	inline static int32_t get_offset_of_DestroyByRpc_7() { return static_cast<int32_t>(offsetof(OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D, ___DestroyByRpc_7)); }
	inline bool get_DestroyByRpc_7() const { return ___DestroyByRpc_7; }
	inline bool* get_address_of_DestroyByRpc_7() { return &___DestroyByRpc_7; }
	inline void set_DestroyByRpc_7(bool value)
	{
		___DestroyByRpc_7 = value;
	}
};


// Photon.Pun.UtilityScripts.OnClickRpc
struct OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C  : public MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A
{
public:
	// UnityEngine.EventSystems.PointerEventData/InputButton Photon.Pun.UtilityScripts.OnClickRpc::Button
	int32_t ___Button_5;
	// UnityEngine.KeyCode Photon.Pun.UtilityScripts.OnClickRpc::ModifierKey
	int32_t ___ModifierKey_6;
	// Photon.Pun.RpcTarget Photon.Pun.UtilityScripts.OnClickRpc::Target
	int32_t ___Target_7;
	// UnityEngine.Material Photon.Pun.UtilityScripts.OnClickRpc::originalMaterial
	Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * ___originalMaterial_8;
	// UnityEngine.Color Photon.Pun.UtilityScripts.OnClickRpc::originalColor
	Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  ___originalColor_9;
	// System.Boolean Photon.Pun.UtilityScripts.OnClickRpc::isFlashing
	bool ___isFlashing_10;

public:
	inline static int32_t get_offset_of_Button_5() { return static_cast<int32_t>(offsetof(OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C, ___Button_5)); }
	inline int32_t get_Button_5() const { return ___Button_5; }
	inline int32_t* get_address_of_Button_5() { return &___Button_5; }
	inline void set_Button_5(int32_t value)
	{
		___Button_5 = value;
	}

	inline static int32_t get_offset_of_ModifierKey_6() { return static_cast<int32_t>(offsetof(OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C, ___ModifierKey_6)); }
	inline int32_t get_ModifierKey_6() const { return ___ModifierKey_6; }
	inline int32_t* get_address_of_ModifierKey_6() { return &___ModifierKey_6; }
	inline void set_ModifierKey_6(int32_t value)
	{
		___ModifierKey_6 = value;
	}

	inline static int32_t get_offset_of_Target_7() { return static_cast<int32_t>(offsetof(OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C, ___Target_7)); }
	inline int32_t get_Target_7() const { return ___Target_7; }
	inline int32_t* get_address_of_Target_7() { return &___Target_7; }
	inline void set_Target_7(int32_t value)
	{
		___Target_7 = value;
	}

	inline static int32_t get_offset_of_originalMaterial_8() { return static_cast<int32_t>(offsetof(OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C, ___originalMaterial_8)); }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * get_originalMaterial_8() const { return ___originalMaterial_8; }
	inline Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 ** get_address_of_originalMaterial_8() { return &___originalMaterial_8; }
	inline void set_originalMaterial_8(Material_tF7DB3BF0C24DEC2FE0CB51E5DF5053D5223C8598 * value)
	{
		___originalMaterial_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___originalMaterial_8), (void*)value);
	}

	inline static int32_t get_offset_of_originalColor_9() { return static_cast<int32_t>(offsetof(OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C, ___originalColor_9)); }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  get_originalColor_9() const { return ___originalColor_9; }
	inline Color_t119BCA590009762C7223FDD3AF9706653AC84ED2 * get_address_of_originalColor_9() { return &___originalColor_9; }
	inline void set_originalColor_9(Color_t119BCA590009762C7223FDD3AF9706653AC84ED2  value)
	{
		___originalColor_9 = value;
	}

	inline static int32_t get_offset_of_isFlashing_10() { return static_cast<int32_t>(offsetof(OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C, ___isFlashing_10)); }
	inline bool get_isFlashing_10() const { return ___isFlashing_10; }
	inline bool* get_address_of_isFlashing_10() { return &___isFlashing_10; }
	inline void set_isFlashing_10(bool value)
	{
		___isFlashing_10 = value;
	}
};


// Photon.Pun.UtilityScripts.SmoothSyncMovement
struct SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE  : public MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A
{
public:
	// System.Single Photon.Pun.UtilityScripts.SmoothSyncMovement::SmoothingDelay
	float ___SmoothingDelay_5;
	// UnityEngine.Vector3 Photon.Pun.UtilityScripts.SmoothSyncMovement::correctPlayerPos
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___correctPlayerPos_6;
	// UnityEngine.Quaternion Photon.Pun.UtilityScripts.SmoothSyncMovement::correctPlayerRot
	Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  ___correctPlayerRot_7;

public:
	inline static int32_t get_offset_of_SmoothingDelay_5() { return static_cast<int32_t>(offsetof(SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE, ___SmoothingDelay_5)); }
	inline float get_SmoothingDelay_5() const { return ___SmoothingDelay_5; }
	inline float* get_address_of_SmoothingDelay_5() { return &___SmoothingDelay_5; }
	inline void set_SmoothingDelay_5(float value)
	{
		___SmoothingDelay_5 = value;
	}

	inline static int32_t get_offset_of_correctPlayerPos_6() { return static_cast<int32_t>(offsetof(SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE, ___correctPlayerPos_6)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_correctPlayerPos_6() const { return ___correctPlayerPos_6; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_correctPlayerPos_6() { return &___correctPlayerPos_6; }
	inline void set_correctPlayerPos_6(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___correctPlayerPos_6 = value;
	}

	inline static int32_t get_offset_of_correctPlayerRot_7() { return static_cast<int32_t>(offsetof(SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE, ___correctPlayerRot_7)); }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  get_correctPlayerRot_7() const { return ___correctPlayerRot_7; }
	inline Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357 * get_address_of_correctPlayerRot_7() { return &___correctPlayerRot_7; }
	inline void set_correctPlayerRot_7(Quaternion_t319F3319A7D43FFA5D819AD6C0A98851F0095357  value)
	{
		___correctPlayerRot_7 = value;
	}
};


// requestOwner
struct requestOwner_tB94BC1702B623819A4DCAF93EF29B801909552C4  : public MonoBehaviourPun_t41335C3B2B6804088B520155103E3A0EEA4F814A
{
public:
	// Photon.Realtime.Player[] requestOwner::Play
	PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83* ___Play_5;

public:
	inline static int32_t get_offset_of_Play_5() { return static_cast<int32_t>(offsetof(requestOwner_tB94BC1702B623819A4DCAF93EF29B801909552C4, ___Play_5)); }
	inline PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83* get_Play_5() const { return ___Play_5; }
	inline PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83** get_address_of_Play_5() { return &___Play_5; }
	inline void set_Play_5(PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83* value)
	{
		___Play_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Play_5), (void*)value);
	}
};


// Launcher
struct Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:
	// TMPro.TMP_InputField Launcher::roomNameInputField
	TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB * ___roomNameInputField_6;
	// TMPro.TMP_Text Launcher::errorText
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___errorText_7;
	// TMPro.TMP_Text Launcher::roomNameText
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___roomNameText_8;
	// UnityEngine.Transform Launcher::roomListContent
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___roomListContent_9;
	// UnityEngine.GameObject Launcher::roomListItemPrefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___roomListItemPrefab_10;
	// UnityEngine.Transform Launcher::playerListContent
	Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * ___playerListContent_11;
	// UnityEngine.GameObject Launcher::PlayerListItemPrefab
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___PlayerListItemPrefab_12;
	// UnityEngine.GameObject Launcher::startGameButton
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___startGameButton_13;

public:
	inline static int32_t get_offset_of_roomNameInputField_6() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___roomNameInputField_6)); }
	inline TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB * get_roomNameInputField_6() const { return ___roomNameInputField_6; }
	inline TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB ** get_address_of_roomNameInputField_6() { return &___roomNameInputField_6; }
	inline void set_roomNameInputField_6(TMP_InputField_tC3C57E697A57232E8A855D39600CF06CFDA8F6CB * value)
	{
		___roomNameInputField_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___roomNameInputField_6), (void*)value);
	}

	inline static int32_t get_offset_of_errorText_7() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___errorText_7)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_errorText_7() const { return ___errorText_7; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_errorText_7() { return &___errorText_7; }
	inline void set_errorText_7(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___errorText_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___errorText_7), (void*)value);
	}

	inline static int32_t get_offset_of_roomNameText_8() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___roomNameText_8)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_roomNameText_8() const { return ___roomNameText_8; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_roomNameText_8() { return &___roomNameText_8; }
	inline void set_roomNameText_8(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___roomNameText_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___roomNameText_8), (void*)value);
	}

	inline static int32_t get_offset_of_roomListContent_9() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___roomListContent_9)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_roomListContent_9() const { return ___roomListContent_9; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_roomListContent_9() { return &___roomListContent_9; }
	inline void set_roomListContent_9(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___roomListContent_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___roomListContent_9), (void*)value);
	}

	inline static int32_t get_offset_of_roomListItemPrefab_10() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___roomListItemPrefab_10)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_roomListItemPrefab_10() const { return ___roomListItemPrefab_10; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_roomListItemPrefab_10() { return &___roomListItemPrefab_10; }
	inline void set_roomListItemPrefab_10(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___roomListItemPrefab_10 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___roomListItemPrefab_10), (void*)value);
	}

	inline static int32_t get_offset_of_playerListContent_11() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___playerListContent_11)); }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * get_playerListContent_11() const { return ___playerListContent_11; }
	inline Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA ** get_address_of_playerListContent_11() { return &___playerListContent_11; }
	inline void set_playerListContent_11(Transform_tBB9E78A2766C3C83599A8F66EDE7D1FCAFC66EDA * value)
	{
		___playerListContent_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___playerListContent_11), (void*)value);
	}

	inline static int32_t get_offset_of_PlayerListItemPrefab_12() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___PlayerListItemPrefab_12)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_PlayerListItemPrefab_12() const { return ___PlayerListItemPrefab_12; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_PlayerListItemPrefab_12() { return &___PlayerListItemPrefab_12; }
	inline void set_PlayerListItemPrefab_12(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___PlayerListItemPrefab_12 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlayerListItemPrefab_12), (void*)value);
	}

	inline static int32_t get_offset_of_startGameButton_13() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602, ___startGameButton_13)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_startGameButton_13() const { return ___startGameButton_13; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_startGameButton_13() { return &___startGameButton_13; }
	inline void set_startGameButton_13(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___startGameButton_13 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___startGameButton_13), (void*)value);
	}
};

struct Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602_StaticFields
{
public:
	// Launcher Launcher::Instance
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602 * ___Instance_5;

public:
	inline static int32_t get_offset_of_Instance_5() { return static_cast<int32_t>(offsetof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602_StaticFields, ___Instance_5)); }
	inline Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602 * get_Instance_5() const { return ___Instance_5; }
	inline Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602 ** get_address_of_Instance_5() { return &___Instance_5; }
	inline void set_Instance_5(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602 * value)
	{
		___Instance_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Instance_5), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.ConnectAndJoinRandom
struct ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:
	// System.Boolean Photon.Pun.UtilityScripts.ConnectAndJoinRandom::AutoConnect
	bool ___AutoConnect_5;
	// System.Byte Photon.Pun.UtilityScripts.ConnectAndJoinRandom::Version
	uint8_t ___Version_6;
	// System.Byte Photon.Pun.UtilityScripts.ConnectAndJoinRandom::MaxPlayers
	uint8_t ___MaxPlayers_7;

public:
	inline static int32_t get_offset_of_AutoConnect_5() { return static_cast<int32_t>(offsetof(ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51, ___AutoConnect_5)); }
	inline bool get_AutoConnect_5() const { return ___AutoConnect_5; }
	inline bool* get_address_of_AutoConnect_5() { return &___AutoConnect_5; }
	inline void set_AutoConnect_5(bool value)
	{
		___AutoConnect_5 = value;
	}

	inline static int32_t get_offset_of_Version_6() { return static_cast<int32_t>(offsetof(ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51, ___Version_6)); }
	inline uint8_t get_Version_6() const { return ___Version_6; }
	inline uint8_t* get_address_of_Version_6() { return &___Version_6; }
	inline void set_Version_6(uint8_t value)
	{
		___Version_6 = value;
	}

	inline static int32_t get_offset_of_MaxPlayers_7() { return static_cast<int32_t>(offsetof(ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51, ___MaxPlayers_7)); }
	inline uint8_t get_MaxPlayers_7() const { return ___MaxPlayers_7; }
	inline uint8_t* get_address_of_MaxPlayers_7() { return &___MaxPlayers_7; }
	inline void set_MaxPlayers_7(uint8_t value)
	{
		___MaxPlayers_7 = value;
	}
};


// Photon.Pun.UtilityScripts.CountdownTimer
struct CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:
	// System.Boolean Photon.Pun.UtilityScripts.CountdownTimer::isTimerRunning
	bool ___isTimerRunning_7;
	// System.Single Photon.Pun.UtilityScripts.CountdownTimer::startTime
	float ___startTime_8;
	// UnityEngine.UI.Text Photon.Pun.UtilityScripts.CountdownTimer::Text
	Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * ___Text_9;
	// System.Single Photon.Pun.UtilityScripts.CountdownTimer::Countdown
	float ___Countdown_10;

public:
	inline static int32_t get_offset_of_isTimerRunning_7() { return static_cast<int32_t>(offsetof(CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450, ___isTimerRunning_7)); }
	inline bool get_isTimerRunning_7() const { return ___isTimerRunning_7; }
	inline bool* get_address_of_isTimerRunning_7() { return &___isTimerRunning_7; }
	inline void set_isTimerRunning_7(bool value)
	{
		___isTimerRunning_7 = value;
	}

	inline static int32_t get_offset_of_startTime_8() { return static_cast<int32_t>(offsetof(CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450, ___startTime_8)); }
	inline float get_startTime_8() const { return ___startTime_8; }
	inline float* get_address_of_startTime_8() { return &___startTime_8; }
	inline void set_startTime_8(float value)
	{
		___startTime_8 = value;
	}

	inline static int32_t get_offset_of_Text_9() { return static_cast<int32_t>(offsetof(CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450, ___Text_9)); }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * get_Text_9() const { return ___Text_9; }
	inline Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 ** get_address_of_Text_9() { return &___Text_9; }
	inline void set_Text_9(Text_tE9317B57477F4B50AA4C16F460DE6F82DAD6D030 * value)
	{
		___Text_9 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Text_9), (void*)value);
	}

	inline static int32_t get_offset_of_Countdown_10() { return static_cast<int32_t>(offsetof(CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450, ___Countdown_10)); }
	inline float get_Countdown_10() const { return ___Countdown_10; }
	inline float* get_address_of_Countdown_10() { return &___Countdown_10; }
	inline void set_Countdown_10(float value)
	{
		___Countdown_10 = value;
	}
};

struct CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450_StaticFields
{
public:
	// Photon.Pun.UtilityScripts.CountdownTimer/CountdownTimerHasExpired Photon.Pun.UtilityScripts.CountdownTimer::OnCountdownTimerHasExpired
	CountdownTimerHasExpired_t1DA56DAFE29F4443C6A912DC7911E75B3409E4C4 * ___OnCountdownTimerHasExpired_6;

public:
	inline static int32_t get_offset_of_OnCountdownTimerHasExpired_6() { return static_cast<int32_t>(offsetof(CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450_StaticFields, ___OnCountdownTimerHasExpired_6)); }
	inline CountdownTimerHasExpired_t1DA56DAFE29F4443C6A912DC7911E75B3409E4C4 * get_OnCountdownTimerHasExpired_6() const { return ___OnCountdownTimerHasExpired_6; }
	inline CountdownTimerHasExpired_t1DA56DAFE29F4443C6A912DC7911E75B3409E4C4 ** get_address_of_OnCountdownTimerHasExpired_6() { return &___OnCountdownTimerHasExpired_6; }
	inline void set_OnCountdownTimerHasExpired_6(CountdownTimerHasExpired_t1DA56DAFE29F4443C6A912DC7911E75B3409E4C4 * value)
	{
		___OnCountdownTimerHasExpired_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OnCountdownTimerHasExpired_6), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.PlayerNumbering
struct PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:
	// System.Boolean Photon.Pun.UtilityScripts.PlayerNumbering::dontDestroyOnLoad
	bool ___dontDestroyOnLoad_9;

public:
	inline static int32_t get_offset_of_dontDestroyOnLoad_9() { return static_cast<int32_t>(offsetof(PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159, ___dontDestroyOnLoad_9)); }
	inline bool get_dontDestroyOnLoad_9() const { return ___dontDestroyOnLoad_9; }
	inline bool* get_address_of_dontDestroyOnLoad_9() { return &___dontDestroyOnLoad_9; }
	inline void set_dontDestroyOnLoad_9(bool value)
	{
		___dontDestroyOnLoad_9 = value;
	}
};

struct PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields
{
public:
	// Photon.Pun.UtilityScripts.PlayerNumbering Photon.Pun.UtilityScripts.PlayerNumbering::instance
	PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159 * ___instance_5;
	// Photon.Realtime.Player[] Photon.Pun.UtilityScripts.PlayerNumbering::SortedPlayers
	PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83* ___SortedPlayers_6;
	// Photon.Pun.UtilityScripts.PlayerNumbering/PlayerNumberingChanged Photon.Pun.UtilityScripts.PlayerNumbering::OnPlayerNumberingChanged
	PlayerNumberingChanged_tC8F930EF27ACA4ED253B2C3A489705780EF8DC10 * ___OnPlayerNumberingChanged_7;

public:
	inline static int32_t get_offset_of_instance_5() { return static_cast<int32_t>(offsetof(PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields, ___instance_5)); }
	inline PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159 * get_instance_5() const { return ___instance_5; }
	inline PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159 ** get_address_of_instance_5() { return &___instance_5; }
	inline void set_instance_5(PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159 * value)
	{
		___instance_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___instance_5), (void*)value);
	}

	inline static int32_t get_offset_of_SortedPlayers_6() { return static_cast<int32_t>(offsetof(PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields, ___SortedPlayers_6)); }
	inline PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83* get_SortedPlayers_6() const { return ___SortedPlayers_6; }
	inline PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83** get_address_of_SortedPlayers_6() { return &___SortedPlayers_6; }
	inline void set_SortedPlayers_6(PlayerU5BU5D_tF4C1F867A25BCC6BF1FDD3E88D8E63321371FB83* value)
	{
		___SortedPlayers_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___SortedPlayers_6), (void*)value);
	}

	inline static int32_t get_offset_of_OnPlayerNumberingChanged_7() { return static_cast<int32_t>(offsetof(PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields, ___OnPlayerNumberingChanged_7)); }
	inline PlayerNumberingChanged_tC8F930EF27ACA4ED253B2C3A489705780EF8DC10 * get_OnPlayerNumberingChanged_7() const { return ___OnPlayerNumberingChanged_7; }
	inline PlayerNumberingChanged_tC8F930EF27ACA4ED253B2C3A489705780EF8DC10 ** get_address_of_OnPlayerNumberingChanged_7() { return &___OnPlayerNumberingChanged_7; }
	inline void set_OnPlayerNumberingChanged_7(PlayerNumberingChanged_tC8F930EF27ACA4ED253B2C3A489705780EF8DC10 * value)
	{
		___OnPlayerNumberingChanged_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___OnPlayerNumberingChanged_7), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.PunTeams
struct PunTeams_t4050E2B25913CEC3594CD2191E5C6AA19F087C5D  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:

public:
};

struct PunTeams_t4050E2B25913CEC3594CD2191E5C6AA19F087C5D_StaticFields
{
public:
	// System.Collections.Generic.Dictionary`2<Photon.Pun.UtilityScripts.PunTeams/Team,System.Collections.Generic.List`1<Photon.Realtime.Player>> Photon.Pun.UtilityScripts.PunTeams::PlayersPerTeam
	Dictionary_2_t265BADF786877C363F2584FFEE180F6D578E4107 * ___PlayersPerTeam_5;

public:
	inline static int32_t get_offset_of_PlayersPerTeam_5() { return static_cast<int32_t>(offsetof(PunTeams_t4050E2B25913CEC3594CD2191E5C6AA19F087C5D_StaticFields, ___PlayersPerTeam_5)); }
	inline Dictionary_2_t265BADF786877C363F2584FFEE180F6D578E4107 * get_PlayersPerTeam_5() const { return ___PlayersPerTeam_5; }
	inline Dictionary_2_t265BADF786877C363F2584FFEE180F6D578E4107 ** get_address_of_PlayersPerTeam_5() { return &___PlayersPerTeam_5; }
	inline void set_PlayersPerTeam_5(Dictionary_2_t265BADF786877C363F2584FFEE180F6D578E4107 * value)
	{
		___PlayersPerTeam_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PlayersPerTeam_5), (void*)value);
	}
};


// Photon.Pun.UtilityScripts.PunTurnManager
struct PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:
	// Photon.Realtime.Player Photon.Pun.UtilityScripts.PunTurnManager::sender
	Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * ___sender_5;
	// System.Single Photon.Pun.UtilityScripts.PunTurnManager::TurnDuration
	float ___TurnDuration_6;
	// Photon.Pun.UtilityScripts.IPunTurnManagerCallbacks Photon.Pun.UtilityScripts.PunTurnManager::TurnManagerListener
	RuntimeObject* ___TurnManagerListener_7;
	// System.Collections.Generic.HashSet`1<Photon.Realtime.Player> Photon.Pun.UtilityScripts.PunTurnManager::finishedPlayers
	HashSet_1_t2A9A3CBCACFC556A37CB6FBF38DC5924158A4DA6 * ___finishedPlayers_8;
	// System.Boolean Photon.Pun.UtilityScripts.PunTurnManager::_isOverCallProcessed
	bool ____isOverCallProcessed_12;

public:
	inline static int32_t get_offset_of_sender_5() { return static_cast<int32_t>(offsetof(PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08, ___sender_5)); }
	inline Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * get_sender_5() const { return ___sender_5; }
	inline Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 ** get_address_of_sender_5() { return &___sender_5; }
	inline void set_sender_5(Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * value)
	{
		___sender_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___sender_5), (void*)value);
	}

	inline static int32_t get_offset_of_TurnDuration_6() { return static_cast<int32_t>(offsetof(PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08, ___TurnDuration_6)); }
	inline float get_TurnDuration_6() const { return ___TurnDuration_6; }
	inline float* get_address_of_TurnDuration_6() { return &___TurnDuration_6; }
	inline void set_TurnDuration_6(float value)
	{
		___TurnDuration_6 = value;
	}

	inline static int32_t get_offset_of_TurnManagerListener_7() { return static_cast<int32_t>(offsetof(PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08, ___TurnManagerListener_7)); }
	inline RuntimeObject* get_TurnManagerListener_7() const { return ___TurnManagerListener_7; }
	inline RuntimeObject** get_address_of_TurnManagerListener_7() { return &___TurnManagerListener_7; }
	inline void set_TurnManagerListener_7(RuntimeObject* value)
	{
		___TurnManagerListener_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___TurnManagerListener_7), (void*)value);
	}

	inline static int32_t get_offset_of_finishedPlayers_8() { return static_cast<int32_t>(offsetof(PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08, ___finishedPlayers_8)); }
	inline HashSet_1_t2A9A3CBCACFC556A37CB6FBF38DC5924158A4DA6 * get_finishedPlayers_8() const { return ___finishedPlayers_8; }
	inline HashSet_1_t2A9A3CBCACFC556A37CB6FBF38DC5924158A4DA6 ** get_address_of_finishedPlayers_8() { return &___finishedPlayers_8; }
	inline void set_finishedPlayers_8(HashSet_1_t2A9A3CBCACFC556A37CB6FBF38DC5924158A4DA6 * value)
	{
		___finishedPlayers_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___finishedPlayers_8), (void*)value);
	}

	inline static int32_t get_offset_of__isOverCallProcessed_12() { return static_cast<int32_t>(offsetof(PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08, ____isOverCallProcessed_12)); }
	inline bool get__isOverCallProcessed_12() const { return ____isOverCallProcessed_12; }
	inline bool* get_address_of__isOverCallProcessed_12() { return &____isOverCallProcessed_12; }
	inline void set__isOverCallProcessed_12(bool value)
	{
		____isOverCallProcessed_12 = value;
	}
};


// PlayerController
struct PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:
	// UnityEngine.GameObject PlayerController::cameraHolder
	GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * ___cameraHolder_5;
	// System.Single PlayerController::mouseSensitivity
	float ___mouseSensitivity_6;
	// System.Single PlayerController::sprintSpeed
	float ___sprintSpeed_7;
	// System.Single PlayerController::walkSpeed
	float ___walkSpeed_8;
	// System.Single PlayerController::jumpForce
	float ___jumpForce_9;
	// System.Single PlayerController::smoothTime
	float ___smoothTime_10;
	// Item[] PlayerController::items
	ItemU5BU5D_t9B2C2BF53C23D966ADDC0D8FC7F3C6AC27993AAD* ___items_11;
	// System.Int32 PlayerController::itemIndex
	int32_t ___itemIndex_12;
	// System.Int32 PlayerController::previousItemIndex
	int32_t ___previousItemIndex_13;
	// System.Single PlayerController::verticalLookRotation
	float ___verticalLookRotation_14;
	// System.Boolean PlayerController::grounded
	bool ___grounded_15;
	// UnityEngine.Vector3 PlayerController::smoothMoveVelocity
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___smoothMoveVelocity_16;
	// UnityEngine.Vector3 PlayerController::moveAmount
	Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  ___moveAmount_17;
	// UnityEngine.Rigidbody PlayerController::rb
	Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * ___rb_18;
	// Photon.Pun.PhotonView PlayerController::PV
	PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * ___PV_19;
	// System.Single PlayerController::currentHealth
	float ___currentHealth_21;
	// PlayerManager PlayerController::playerManager
	PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271 * ___playerManager_22;

public:
	inline static int32_t get_offset_of_cameraHolder_5() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___cameraHolder_5)); }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * get_cameraHolder_5() const { return ___cameraHolder_5; }
	inline GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F ** get_address_of_cameraHolder_5() { return &___cameraHolder_5; }
	inline void set_cameraHolder_5(GameObject_tBD1244AD56B4E59AAD76E5E7C9282EC5CE434F0F * value)
	{
		___cameraHolder_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cameraHolder_5), (void*)value);
	}

	inline static int32_t get_offset_of_mouseSensitivity_6() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___mouseSensitivity_6)); }
	inline float get_mouseSensitivity_6() const { return ___mouseSensitivity_6; }
	inline float* get_address_of_mouseSensitivity_6() { return &___mouseSensitivity_6; }
	inline void set_mouseSensitivity_6(float value)
	{
		___mouseSensitivity_6 = value;
	}

	inline static int32_t get_offset_of_sprintSpeed_7() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___sprintSpeed_7)); }
	inline float get_sprintSpeed_7() const { return ___sprintSpeed_7; }
	inline float* get_address_of_sprintSpeed_7() { return &___sprintSpeed_7; }
	inline void set_sprintSpeed_7(float value)
	{
		___sprintSpeed_7 = value;
	}

	inline static int32_t get_offset_of_walkSpeed_8() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___walkSpeed_8)); }
	inline float get_walkSpeed_8() const { return ___walkSpeed_8; }
	inline float* get_address_of_walkSpeed_8() { return &___walkSpeed_8; }
	inline void set_walkSpeed_8(float value)
	{
		___walkSpeed_8 = value;
	}

	inline static int32_t get_offset_of_jumpForce_9() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___jumpForce_9)); }
	inline float get_jumpForce_9() const { return ___jumpForce_9; }
	inline float* get_address_of_jumpForce_9() { return &___jumpForce_9; }
	inline void set_jumpForce_9(float value)
	{
		___jumpForce_9 = value;
	}

	inline static int32_t get_offset_of_smoothTime_10() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___smoothTime_10)); }
	inline float get_smoothTime_10() const { return ___smoothTime_10; }
	inline float* get_address_of_smoothTime_10() { return &___smoothTime_10; }
	inline void set_smoothTime_10(float value)
	{
		___smoothTime_10 = value;
	}

	inline static int32_t get_offset_of_items_11() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___items_11)); }
	inline ItemU5BU5D_t9B2C2BF53C23D966ADDC0D8FC7F3C6AC27993AAD* get_items_11() const { return ___items_11; }
	inline ItemU5BU5D_t9B2C2BF53C23D966ADDC0D8FC7F3C6AC27993AAD** get_address_of_items_11() { return &___items_11; }
	inline void set_items_11(ItemU5BU5D_t9B2C2BF53C23D966ADDC0D8FC7F3C6AC27993AAD* value)
	{
		___items_11 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___items_11), (void*)value);
	}

	inline static int32_t get_offset_of_itemIndex_12() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___itemIndex_12)); }
	inline int32_t get_itemIndex_12() const { return ___itemIndex_12; }
	inline int32_t* get_address_of_itemIndex_12() { return &___itemIndex_12; }
	inline void set_itemIndex_12(int32_t value)
	{
		___itemIndex_12 = value;
	}

	inline static int32_t get_offset_of_previousItemIndex_13() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___previousItemIndex_13)); }
	inline int32_t get_previousItemIndex_13() const { return ___previousItemIndex_13; }
	inline int32_t* get_address_of_previousItemIndex_13() { return &___previousItemIndex_13; }
	inline void set_previousItemIndex_13(int32_t value)
	{
		___previousItemIndex_13 = value;
	}

	inline static int32_t get_offset_of_verticalLookRotation_14() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___verticalLookRotation_14)); }
	inline float get_verticalLookRotation_14() const { return ___verticalLookRotation_14; }
	inline float* get_address_of_verticalLookRotation_14() { return &___verticalLookRotation_14; }
	inline void set_verticalLookRotation_14(float value)
	{
		___verticalLookRotation_14 = value;
	}

	inline static int32_t get_offset_of_grounded_15() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___grounded_15)); }
	inline bool get_grounded_15() const { return ___grounded_15; }
	inline bool* get_address_of_grounded_15() { return &___grounded_15; }
	inline void set_grounded_15(bool value)
	{
		___grounded_15 = value;
	}

	inline static int32_t get_offset_of_smoothMoveVelocity_16() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___smoothMoveVelocity_16)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_smoothMoveVelocity_16() const { return ___smoothMoveVelocity_16; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_smoothMoveVelocity_16() { return &___smoothMoveVelocity_16; }
	inline void set_smoothMoveVelocity_16(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___smoothMoveVelocity_16 = value;
	}

	inline static int32_t get_offset_of_moveAmount_17() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___moveAmount_17)); }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  get_moveAmount_17() const { return ___moveAmount_17; }
	inline Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720 * get_address_of_moveAmount_17() { return &___moveAmount_17; }
	inline void set_moveAmount_17(Vector3_tDCF05E21F632FE2BA260C06E0D10CA81513E6720  value)
	{
		___moveAmount_17 = value;
	}

	inline static int32_t get_offset_of_rb_18() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___rb_18)); }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * get_rb_18() const { return ___rb_18; }
	inline Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 ** get_address_of_rb_18() { return &___rb_18; }
	inline void set_rb_18(Rigidbody_tE0A58EE5A1F7DC908EFFB4F0D795AC9552A750A5 * value)
	{
		___rb_18 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___rb_18), (void*)value);
	}

	inline static int32_t get_offset_of_PV_19() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___PV_19)); }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * get_PV_19() const { return ___PV_19; }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B ** get_address_of_PV_19() { return &___PV_19; }
	inline void set_PV_19(PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * value)
	{
		___PV_19 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PV_19), (void*)value);
	}

	inline static int32_t get_offset_of_currentHealth_21() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___currentHealth_21)); }
	inline float get_currentHealth_21() const { return ___currentHealth_21; }
	inline float* get_address_of_currentHealth_21() { return &___currentHealth_21; }
	inline void set_currentHealth_21(float value)
	{
		___currentHealth_21 = value;
	}

	inline static int32_t get_offset_of_playerManager_22() { return static_cast<int32_t>(offsetof(PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85, ___playerManager_22)); }
	inline PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271 * get_playerManager_22() const { return ___playerManager_22; }
	inline PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271 ** get_address_of_playerManager_22() { return &___playerManager_22; }
	inline void set_playerManager_22(PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271 * value)
	{
		___playerManager_22 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___playerManager_22), (void*)value);
	}
};


// PlayerListItem
struct PlayerListItem_tA89DC5621BEFCFC28B4ACB3D258E2AC2CE60AABF  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:
	// TMPro.TMP_Text PlayerListItem::text
	TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * ___text_5;
	// Photon.Realtime.Player PlayerListItem::player
	Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * ___player_6;

public:
	inline static int32_t get_offset_of_text_5() { return static_cast<int32_t>(offsetof(PlayerListItem_tA89DC5621BEFCFC28B4ACB3D258E2AC2CE60AABF, ___text_5)); }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * get_text_5() const { return ___text_5; }
	inline TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 ** get_address_of_text_5() { return &___text_5; }
	inline void set_text_5(TMP_Text_t7BA5B6522651EBED2D8E2C92CBE3F17C14075CE7 * value)
	{
		___text_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___text_5), (void*)value);
	}

	inline static int32_t get_offset_of_player_6() { return static_cast<int32_t>(offsetof(PlayerListItem_tA89DC5621BEFCFC28B4ACB3D258E2AC2CE60AABF, ___player_6)); }
	inline Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * get_player_6() const { return ___player_6; }
	inline Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 ** get_address_of_player_6() { return &___player_6; }
	inline void set_player_6(Player_tFB06F12211DD89BEE90AD848E6C7BD9D889F1202 * value)
	{
		___player_6 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___player_6), (void*)value);
	}
};


// RoomManager
struct RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C  : public MonoBehaviourPunCallbacks_t1C6D230D24896A20359CB7016C7AD6E4654B885D
{
public:

public:
};

struct RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C_StaticFields
{
public:
	// RoomManager RoomManager::Instance
	RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C * ___Instance_5;

public:
	inline static int32_t get_offset_of_Instance_5() { return static_cast<int32_t>(offsetof(RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C_StaticFields, ___Instance_5)); }
	inline RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C * get_Instance_5() const { return ___Instance_5; }
	inline RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C ** get_address_of_Instance_5() { return &___Instance_5; }
	inline void set_Instance_5(RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C * value)
	{
		___Instance_5 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___Instance_5), (void*)value);
	}
};


// SingleShotGun
struct SingleShotGun_t1443AA8071BB952F93A782C69FC536C4A8EF04D2  : public Gun_t3C15F78CD5A40BC92F130917A1AA4679FA5874FB
{
public:
	// UnityEngine.Camera SingleShotGun::cam
	Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * ___cam_7;
	// Photon.Pun.PhotonView SingleShotGun::PV
	PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * ___PV_8;

public:
	inline static int32_t get_offset_of_cam_7() { return static_cast<int32_t>(offsetof(SingleShotGun_t1443AA8071BB952F93A782C69FC536C4A8EF04D2, ___cam_7)); }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * get_cam_7() const { return ___cam_7; }
	inline Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 ** get_address_of_cam_7() { return &___cam_7; }
	inline void set_cam_7(Camera_t48B2B9ECB3CE6108A98BF949A1CECF0FE3421F34 * value)
	{
		___cam_7 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___cam_7), (void*)value);
	}

	inline static int32_t get_offset_of_PV_8() { return static_cast<int32_t>(offsetof(SingleShotGun_t1443AA8071BB952F93A782C69FC536C4A8EF04D2, ___PV_8)); }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * get_PV_8() const { return ___PV_8; }
	inline PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B ** get_address_of_PV_8() { return &___PV_8; }
	inline void set_PV_8(PhotonView_t9781C6CA59BA006553D186D4FC011AECA4C9BE0B * value)
	{
		___PV_8 = value;
		Il2CppCodeGenWriteBarrier((void**)(&___PV_8), (void*)value);
	}
};

#ifdef __clang__
#pragma clang diagnostic pop
#endif




#ifdef __clang__
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Winvalid-offsetof"
#pragma clang diagnostic ignored "-Wunused-variable"
#endif
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3782;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3782 = { sizeof (PhotonTeam_t82EDE7A41D773DF04CAD2F1D688C52260708A21B), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3782[2] = 
{
	PhotonTeam_t82EDE7A41D773DF04CAD2F1D688C52260708A21B::get_offset_of_Name_0(),
	PhotonTeam_t82EDE7A41D773DF04CAD2F1D688C52260708A21B::get_offset_of_Code_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3783;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3783 = { sizeof (PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06), -1, sizeof(PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3783[8] = 
{
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06::get_offset_of_teamsList_4(),
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06::get_offset_of_teamsByCode_5(),
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06::get_offset_of_teamsByName_6(),
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06::get_offset_of_playersPerTeam_7(),
	0,
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields::get_offset_of_PlayerJoinedTeam_9(),
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields::get_offset_of_PlayerLeftTeam_10(),
	PhotonTeamsManager_t1FC0FE5DEEF220A73B4B468C2DC99C23EDB2DA06_StaticFields::get_offset_of_instance_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3784;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3784 = { sizeof (PhotonTeamExtensions_t52971230D9B85B8C81D134232EAA88786DC2870A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3785;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3785 = { sizeof (PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159), -1, sizeof(PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3785[5] = 
{
	PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields::get_offset_of_instance_5(),
	PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields::get_offset_of_SortedPlayers_6(),
	PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159_StaticFields::get_offset_of_OnPlayerNumberingChanged_7(),
	0,
	PlayerNumbering_t313AE68C9A422F9AAC790FA14E23EE00D273A159::get_offset_of_dontDestroyOnLoad_9(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3786;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3786 = { sizeof (PlayerNumberingChanged_tC8F930EF27ACA4ED253B2C3A489705780EF8DC10), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3787;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3787 = { sizeof (U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83), -1, sizeof(U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3787[4] = 
{
	U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields::get_offset_of_U3CU3E9_0(),
	U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields::get_offset_of_U3CU3E9__14_0_1(),
	U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields::get_offset_of_U3CU3E9__14_1_2(),
	U3CU3Ec_tE0234F468A121DF77A238E708F40CE95832AFD83_StaticFields::get_offset_of_U3CU3E9__14_2_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3788;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3788 = { sizeof (PlayerNumberingExtensions_t783B39081487EF9A853F9211FA63BD3C9712A035), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3789;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3789 = { sizeof (PunPlayerScores_tFD956FEE88DB4C0CCA3EB963F99BC67B8EE4BDE2), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3789[1] = 
{
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3790;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3790 = { sizeof (ScoreExtensions_t9B08173082BECE20110F1EC3ABDE3C29E297880C), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3791;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3791 = { sizeof (PunTeams_t4050E2B25913CEC3594CD2191E5C6AA19F087C5D), -1, sizeof(PunTeams_t4050E2B25913CEC3594CD2191E5C6AA19F087C5D_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3791[2] = 
{
	PunTeams_t4050E2B25913CEC3594CD2191E5C6AA19F087C5D_StaticFields::get_offset_of_PlayersPerTeam_5(),
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3792;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3792 = { sizeof (Team_t4FA690D794BEFB3DC83AB67A6FDC920EAA9CDA5F)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3792[4] = 
{
	Team_t4FA690D794BEFB3DC83AB67A6FDC920EAA9CDA5F::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3793;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3793 = { sizeof (TeamExtensions_t602E1A3772FA5E7EB9D67EF55A96F1AFCB8693A9), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3794;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3794 = { sizeof (SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3794[3] = 
{
	SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE::get_offset_of_SmoothingDelay_5(),
	SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE::get_offset_of_correctPlayerPos_6(),
	SmoothSyncMovement_tB1B39E3C4404EBF84E7B3CBBB86A8DB639F5DBBE::get_offset_of_correctPlayerRot_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3795;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3795 = { sizeof (ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3795[3] = 
{
	ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51::get_offset_of_AutoConnect_5(),
	ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51::get_offset_of_Version_6(),
	ConnectAndJoinRandom_t0EDE1854CB4711DAAF466201EEDFEA7011DF3A51::get_offset_of_MaxPlayers_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3796;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3796 = { sizeof (MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3796[7] = 
{
	MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA::get_offset_of_Speed_5(),
	MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA::get_offset_of_JumpForce_6(),
	MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA::get_offset_of_JumpTimeout_7(),
	MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA::get_offset_of_isSprite_8(),
	MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA::get_offset_of_jumpingTime_9(),
	MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA::get_offset_of_body_10(),
	MoveByKeys_tB02D95448BA9D130CCBC2204DE847908276537CA::get_offset_of_body2d_11(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3797;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3797 = { sizeof (OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3797[3] = 
{
	OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D::get_offset_of_Button_5(),
	OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D::get_offset_of_ModifierKey_6(),
	OnClickDestroy_tE98D293BC730055B219D5E123422AAF556AE299D::get_offset_of_DestroyByRpc_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3798;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3798 = { sizeof (U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3798[3] = 
{
	U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746::get_offset_of_U3CU3E1__state_0(),
	U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746::get_offset_of_U3CU3E2__current_1(),
	U3CDestroyRpcU3Ed__4_tB987CFF7AC6353A4A9301DFC3E0271DAE1B1C746::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3799;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3799 = { sizeof (OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3799[4] = 
{
	OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4::get_offset_of_Button_4(),
	OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4::get_offset_of_ModifierKey_5(),
	OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4::get_offset_of_Prefab_6(),
	OnClickInstantiate_tE3E617BE243F81684B36262773E849195D23DAA4::get_offset_of_InstantiateType_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3800;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3800 = { sizeof (InstantiateOption_t37A333580FB897EF03B46B8E7D42BAEFEF78167C)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3800[3] = 
{
	InstantiateOption_t37A333580FB897EF03B46B8E7D42BAEFEF78167C::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3801;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3801 = { sizeof (OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3801[6] = 
{
	OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C::get_offset_of_Button_5(),
	OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C::get_offset_of_ModifierKey_6(),
	OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C::get_offset_of_Target_7(),
	OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C::get_offset_of_originalMaterial_8(),
	OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C::get_offset_of_originalColor_9(),
	OnClickRpc_t8D2F271F8A30977C49B74A393E05A0D8E1461C4C::get_offset_of_isFlashing_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3802;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3802 = { sizeof (U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3802[6] = 
{
	U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A::get_offset_of_U3CU3E1__state_0(),
	U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A::get_offset_of_U3CU3E2__current_1(),
	U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A::get_offset_of_U3CU3E4__this_2(),
	U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A::get_offset_of_U3CwasEmissiveU3E5__1_3(),
	U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A::get_offset_of_U3CfU3E5__2_4(),
	U3CClickFlashU3Ed__8_tC1138490B221B783444ACEC1D7899C0F3275092A::get_offset_of_U3ClerpedU3E5__3_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3803;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3803 = { sizeof (OnEscapeQuit_tA10895B32C54F77B4DF1D2D2B731E8E746CE455B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3804;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3804 = { sizeof (OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3804[9] = 
{
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_SpawnPosition_4(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_Sequence_5(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_SpawnPoints_6(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_UseRandomOffset_7(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_RandomOffset_8(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_PrefabsToInstantiate_9(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_autoSpawnObjects_10(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_SpawnedObjects_11(),
	OnJoinedInstantiate_t180006A502FA949FA3CAB7259E9D6DF9BFE941A6::get_offset_of_lastUsedSpawnPointIndex_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3805;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3805 = { sizeof (SpawnSequence_t2ADF043110FA61B097A72B2286F14F12FFCBB540)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3805[4] = 
{
	SpawnSequence_t2ADF043110FA61B097A72B2286F14F12FFCBB540::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3806;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3806 = { sizeof (OnStartDelete_t642BD77F5CE819CEB868BD8DE327A124A3CDDEAE), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3807;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3807 = { sizeof (CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450), -1, sizeof(CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3807[6] = 
{
	0,
	CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450_StaticFields::get_offset_of_OnCountdownTimerHasExpired_6(),
	CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450::get_offset_of_isTimerRunning_7(),
	CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450::get_offset_of_startTime_8(),
	CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450::get_offset_of_Text_9(),
	CountdownTimer_t8EC4E361AAF260DAFE683F01310DE3688A758450::get_offset_of_Countdown_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3808;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3808 = { sizeof (CountdownTimerHasExpired_t1DA56DAFE29F4443C6A912DC7911E75B3409E4C4), sizeof(Il2CppMethodPointer), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3809;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3809 = { sizeof (PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3809[8] = 
{
	PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08::get_offset_of_sender_5(),
	PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08::get_offset_of_TurnDuration_6(),
	PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08::get_offset_of_TurnManagerListener_7(),
	PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08::get_offset_of_finishedPlayers_8(),
	0,
	0,
	0,
	PunTurnManager_tF6B541F3DE673C75BB6EDA6C40CBFAFBC77D6A08::get_offset_of__isOverCallProcessed_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3810;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3810 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3811;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3811 = { sizeof (TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0), -1, sizeof(TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3811[3] = 
{
	TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields::get_offset_of_TurnPropKey_0(),
	TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields::get_offset_of_TurnStartPropKey_1(),
	TurnExtensions_tEA2A976BE66F36369F8ED3706A63F8DD0704C0A0_StaticFields::get_offset_of_FinishedTurnPropKey_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3812;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3812 = { sizeof (ButtonInsideScrollList_t255DA2A0A1585550226BFFF4F314BBD685827CA8), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3812[1] = 
{
	ButtonInsideScrollList_t255DA2A0A1585550226BFFF4F314BBD685827CA8::get_offset_of_scrollRect_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3813;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3813 = { sizeof (EventSystemSpawner_t3AACFD4D822CE099002B524BFFA902E39CC634ED), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3814;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3814 = { sizeof (GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3814[7] = 
{
	GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433::get_offset_of_toggle_4(),
	GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433::get_offset_of__graphic_5(),
	GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433::get_offset_of_NormalOnColor_6(),
	GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433::get_offset_of_NormalOffColor_7(),
	GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433::get_offset_of_HoverOnColor_8(),
	GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433::get_offset_of_HoverOffColor_9(),
	GraphicToggleIsOnTransition_t94ECBEE7C7381D2A0AAC1895A510AE68BE796433::get_offset_of_isHover_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3815;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3815 = { sizeof (OnPointerOverTooltip_tBE4835AFC7D43B58F3514A1309456F3782680549), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3816;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3816 = { sizeof (TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3816[5] = 
{
	TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B::get_offset_of_ToggleGroup_4(),
	TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B::get_offset_of_Tabs_5(),
	TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B::get_offset_of_OnTabChanged_6(),
	TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B::get_offset_of_CurrentTab_7(),
	TabViewManager_tD8FB3F9FB219661D7541B3E15882F02D2409D92B::get_offset_of_Tab_lut_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3817;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3817 = { sizeof (TabChangeEvent_t0828873D6112CB183DE5B2EB5EB05DCDB7FFBD29), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3818;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3818 = { sizeof (Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3818[3] = 
{
	Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A::get_offset_of_ID_0(),
	Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A::get_offset_of_Toggle_1(),
	Tab_tFB7BEDAC9B6986165638E41A4963F0E5A7A1D44A::get_offset_of_View_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3819;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3819 = { sizeof (U3CU3Ec__DisplayClass7_0_t4488666C791C03BE6BCC095CD458EA7F2DE8610B), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3819[2] = 
{
	U3CU3Ec__DisplayClass7_0_t4488666C791C03BE6BCC095CD458EA7F2DE8610B::get_offset_of__tab_0(),
	U3CU3Ec__DisplayClass7_0_t4488666C791C03BE6BCC095CD458EA7F2DE8610B::get_offset_of_U3CU3E4__this_1(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3820;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3820 = { sizeof (TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3820[4] = 
{
	TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A::get_offset_of__text_4(),
	TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A::get_offset_of_Selectable_5(),
	TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A::get_offset_of_NormalColor_6(),
	TextButtonTransition_tC05949676EAB0E8D171999F968F04C3432C68E0A::get_offset_of_HoverColor_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3821;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3821 = { sizeof (TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3821[7] = 
{
	TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83::get_offset_of_toggle_4(),
	TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83::get_offset_of__text_5(),
	TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83::get_offset_of_NormalOnColor_6(),
	TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83::get_offset_of_NormalOffColor_7(),
	TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83::get_offset_of_HoverOnColor_8(),
	TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83::get_offset_of_HoverOffColor_9(),
	TextToggleIsOnTransition_t4B6992CE040220A43A4EA3DF54BE81D1173B6D83::get_offset_of_isHover_10(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3822;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3822 = { sizeof (U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1), -1, sizeof(U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3822[3] = 
{
	U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields::get_offset_of_U335FDBB6669F521B572D4AD71DD77E77F43C1B71B_0(),
	U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields::get_offset_of_U3739C505E9F0985CE1E08892BC46BE5E839FF061A_1(),
	U3CPrivateImplementationDetailsU3E_tFBED2247F0CBE892C69EC61F909C5DF9DC79F6A1_StaticFields::get_offset_of_U38658990BAD6546E619D8A5C4F90BCF3F089E0953_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3823;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3823 = { sizeof (__StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D16_tB84F2B8B6342E24832E04B833E36507203D35C0A ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3824;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3824 = { sizeof (__StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D32_t2DB83702343EC886ECD300FAE94A2F810F463937 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3825;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3825 = { sizeof (__StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D48_tE99346C888DCEDED77ED79D6DFEEEC86A4B68981 ), 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3826;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3826 = { sizeof (U3CModuleU3E_t2D35D876FED2BDD175BE36DB8283DBD59BA7B06E), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3827;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3827 = { sizeof (U3CModuleU3E_t6CDDDF959E7E18A6744E43B613F41CDAC780256A), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3828;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3828 = { sizeof (Actif_t2DF53FC0444467754E765E2F08C94CE2ACAAEFE8), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3828[2] = 
{
	Actif_t2DF53FC0444467754E765E2F08C94CE2ACAAEFE8::get_offset_of_ActiveObject_4(),
	Actif_t2DF53FC0444467754E765E2F08C94CE2ACAAEFE8::get_offset_of_CurenObject_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3829;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3829 = { sizeof (ConvertToLineMesh_tD6DEC04CC1271CEECEC3587122270D16FA7BD46A), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3829[1] = 
{
	ConvertToLineMesh_tD6DEC04CC1271CEECEC3587122270D16FA7BD46A::get_offset_of_mesh_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3830;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3830 = { sizeof (ConvertToPointMesh_t5FE8AE962B066A59AAAE16EB6FDE9426BB4E00FB), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3830[1] = 
{
	ConvertToPointMesh_t5FE8AE962B066A59AAAE16EB6FDE9426BB4E00FB::get_offset_of_mesh_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3831;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3831 = { sizeof (RotateTowardsCamera_t3A3F5E9CBC867A256FF2F93B164FC38ED142EB09), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3831[1] = 
{
	RotateTowardsCamera_t3A3F5E9CBC867A256FF2F93B164FC38ED142EB09::get_offset_of_cam_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3832;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3832 = { sizeof (ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3832[25] = 
{
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_WheelTextureTheme_4(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_ArrowTheme_5(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_GlowingTheme_6(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_BackgroundTheme_7(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_MenuButton_8(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_MenuBackgroundButton_9(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_PlanetTheme_10(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_PlanetTheme1_11(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_PlanetTheme2_12(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_PlanetTheme3_13(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_PlanetTheme4_14(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_PlanetTheme5_15(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_WheelTexture_16(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Arrow_17(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Glowing_18(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Background_19(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Menu_20(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_backgroundMenu_21(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Planet_22(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Planet1_23(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Planet2_24(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Planet3_25(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Planet4_26(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_Planet5_27(),
	ChangeTheme_t3E861D7174CAA28C4108189018E0A7B18484A5BF::get_offset_of_NumberOfPlanet_28(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3833;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3833 = { sizeof (DIDIDI_tAD03F2DE79252B98EF831C3E629BF14E915BBDBC), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3833[1] = 
{
	DIDIDI_tAD03F2DE79252B98EF831C3E629BF14E915BBDBC::get_offset_of_PanelMenu_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3834;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3834 = { sizeof (OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3834[16] = 
{
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_tiime_5(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_k_6(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_kk_7(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_k1_8(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_k2_9(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_My_Text_10(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_userNameInputText_11(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_InputName_Panel_12(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_InputCoverRotate_Panel_13(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_TapToTakeTurn_14(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_CopyStatus_15(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_OwnerAgainsRotateBox_16(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_name_17(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_n_18(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_Copy_19(),
	OwnerShipTransfer_t8D12593AAD17CFC223E93859C30F18DA2A5E1BD1::get_offset_of_status_20(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3835;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3835 = { sizeof (SimpleControl_t082F92BF5EC835071423AA0C555673621232E23B), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3836;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3836 = { sizeof (SimpleControl2_t5E025C38905F685A08A71FCC1FA23B7EAFE7D82F), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3837;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3837 = { sizeof (ADS_t19B0242A8A62416BCF9C927D76305A252DB69367), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3837[3] = 
{
	ADS_t19B0242A8A62416BCF9C927D76305A252DB69367::get_offset_of_GooglePlay_ID_4(),
	ADS_t19B0242A8A62416BCF9C927D76305A252DB69367::get_offset_of_placementId_5(),
	ADS_t19B0242A8A62416BCF9C927D76305A252DB69367::get_offset_of_testMode_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3838;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3838 = { sizeof (U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3838[3] = 
{
	U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43::get_offset_of_U3CU3E1__state_0(),
	U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43::get_offset_of_U3CU3E2__current_1(),
	U3CShowBannerWhenInitializedU3Ed__5_tE45BECFF823C6350124BFEF2F3EF53B2A1193B43::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3839;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3839 = { sizeof (AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3839[3] = 
{
	AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9::get_offset_of_RotateSpeed_4(),
	AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9::get_offset_of_Drag_5(),
	AddForce_tC0DE8CCC0A9A1C9F459B3B13F685C3F843C907B9::get_offset_of_rb_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3840;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3840 = { sizeof (Zoom_t880AFB749C3A75A781108A6A230D45E6B07952F0), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3840[1] = 
{
	Zoom_t880AFB749C3A75A781108A6A230D45E6B07952F0::get_offset_of_targetSize_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3841;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3841 = { sizeof (a_t843891B3C1396BC2023E082606A721962D84C3CB), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3841[3] = 
{
	a_t843891B3C1396BC2023E082606A721962D84C3CB::get_offset_of_gameId_4(),
	a_t843891B3C1396BC2023E082606A721962D84C3CB::get_offset_of_surfacingId_5(),
	a_t843891B3C1396BC2023E082606A721962D84C3CB::get_offset_of_testMode_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3842;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3842 = { sizeof (U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3842[3] = 
{
	U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13::get_offset_of_U3CU3E1__state_0(),
	U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13::get_offset_of_U3CU3E2__current_1(),
	U3CShowBannerWhenInitializedU3Ed__4_tAE066E611CC3C54C18A1185F356DB50E93323F13::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3843;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3843 = { sizeof (Gun_t3C15F78CD5A40BC92F130917A1AA4679FA5874FB), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3843[1] = 
{
	Gun_t3C15F78CD5A40BC92F130917A1AA4679FA5874FB::get_offset_of_bulletImpactPrefab_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3844;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3844 = { sizeof (GunInfo_t37CA1BBD2E470CE396A728413D958DC698770F81), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3844[1] = 
{
	GunInfo_t37CA1BBD2E470CE396A728413D958DC698770F81::get_offset_of_damage_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3845;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3845 = { 0, -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3846;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3846 = { sizeof (Item_t1FD274D610B07F7F6E6AA093A93FB9E32210D36E), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3846[2] = 
{
	Item_t1FD274D610B07F7F6E6AA093A93FB9E32210D36E::get_offset_of_itemInfo_4(),
	Item_t1FD274D610B07F7F6E6AA093A93FB9E32210D36E::get_offset_of_itemGameObject_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3847;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3847 = { sizeof (ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3847[1] = 
{
	ItemInfo_t17479EC7A5CAF915A5A62C2E4C77783252068974::get_offset_of_itemName_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3848;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3848 = { sizeof (Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602), -1, sizeof(Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3848[9] = 
{
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602_StaticFields::get_offset_of_Instance_5(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_roomNameInputField_6(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_errorText_7(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_roomNameText_8(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_roomListContent_9(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_roomListItemPrefab_10(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_playerListContent_11(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_PlayerListItemPrefab_12(),
	Launcher_t27DF47051ABB500108780CEA7ABCF602164A0602::get_offset_of_startGameButton_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3849;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3849 = { sizeof (Menu_t7D066A010AF240D53C2DDA2B05DF31FD0B5F3129), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3849[2] = 
{
	Menu_t7D066A010AF240D53C2DDA2B05DF31FD0B5F3129::get_offset_of_menuName_4(),
	Menu_t7D066A010AF240D53C2DDA2B05DF31FD0B5F3129::get_offset_of_open_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3850;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3850 = { sizeof (MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5), -1, sizeof(MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3850[2] = 
{
	MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5_StaticFields::get_offset_of_Instance_4(),
	MenuManager_t3B55ED77A8CDE421B93939B40D4EB4A93C8EE9E5::get_offset_of_menus_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3851;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3851 = { sizeof (PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3851[18] = 
{
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_cameraHolder_5(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_mouseSensitivity_6(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_sprintSpeed_7(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_walkSpeed_8(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_jumpForce_9(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_smoothTime_10(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_items_11(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_itemIndex_12(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_previousItemIndex_13(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_verticalLookRotation_14(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_grounded_15(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_smoothMoveVelocity_16(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_moveAmount_17(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_rb_18(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_PV_19(),
	0,
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_currentHealth_21(),
	PlayerController_t4CE339054014370D89B89922EDC0EA2766589C85::get_offset_of_playerManager_22(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3852;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3852 = { sizeof (PlayerGroundCheck_tD335E73FDC4816ABAB3617C1F7065F1E074FFA2B), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3852[1] = 
{
	PlayerGroundCheck_tD335E73FDC4816ABAB3617C1F7065F1E074FFA2B::get_offset_of_playerController_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3853;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3853 = { sizeof (PlayerListItem_tA89DC5621BEFCFC28B4ACB3D258E2AC2CE60AABF), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3853[2] = 
{
	PlayerListItem_tA89DC5621BEFCFC28B4ACB3D258E2AC2CE60AABF::get_offset_of_text_5(),
	PlayerListItem_tA89DC5621BEFCFC28B4ACB3D258E2AC2CE60AABF::get_offset_of_player_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3854;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3854 = { sizeof (PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3854[2] = 
{
	PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271::get_offset_of_PV_4(),
	PlayerManager_tB85102F27127EEDC95D916F7D3D47DA3AC2AA271::get_offset_of_controller_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3855;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3855 = { sizeof (RoomListItem_t9EB55F749CE65437078175747E9F6F1CDCF959C2), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3855[2] = 
{
	RoomListItem_t9EB55F749CE65437078175747E9F6F1CDCF959C2::get_offset_of_text_4(),
	RoomListItem_t9EB55F749CE65437078175747E9F6F1CDCF959C2::get_offset_of_info_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3856;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3856 = { sizeof (RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C), -1, sizeof(RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3856[1] = 
{
	RoomManager_tEC18A27501DBB8705A7CC7F1212B0CBF722A689C_StaticFields::get_offset_of_Instance_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3857;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3857 = { sizeof (SingleShotGun_t1443AA8071BB952F93A782C69FC536C4A8EF04D2), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3857[2] = 
{
	SingleShotGun_t1443AA8071BB952F93A782C69FC536C4A8EF04D2::get_offset_of_cam_7(),
	SingleShotGun_t1443AA8071BB952F93A782C69FC536C4A8EF04D2::get_offset_of_PV_8(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3858;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3858 = { sizeof (SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0), -1, sizeof(SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3858[2] = 
{
	SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0_StaticFields::get_offset_of_Instance_4(),
	SpawnManager_tA2B15EFBFF155DEEE0B8B5E22D767198D60346E0::get_offset_of_spawnpoints_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3859;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3859 = { sizeof (Spawnpoint_tF779AE5E6A6B8F72FC83205F1E42198307427C54), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3859[1] = 
{
	Spawnpoint_tF779AE5E6A6B8F72FC83205F1E42198307427C54::get_offset_of_graphics_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3860;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3860 = { sizeof (requestOwner_tB94BC1702B623819A4DCAF93EF29B801909552C4), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3860[1] = 
{
	requestOwner_tB94BC1702B623819A4DCAF93EF29B801909552C4::get_offset_of_Play_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3861;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3861 = { sizeof (SphereRotationCopy_tCE281B63A156B721CB832F196A1548EA9142A48D), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3861[1] = 
{
	SphereRotationCopy_tCE281B63A156B721CB832F196A1548EA9142A48D::get_offset_of_sphere_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3862;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3862 = { sizeof (TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3862[4] = 
{
	TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1::get_offset_of_ngaunhien_4(),
	TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1::get_offset_of_MyText_5(),
	TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1::get_offset_of_ThemeText_6(),
	TestScript_t292BEAEA5C665F1E649B7CCA16D364E5E836A4D1::get_offset_of_ThemeTextResult_7(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3863;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3863 = { sizeof (Try_t068DE3CDE93ECDCFD443751A0EE5CBF727782B31), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3863[2] = 
{
	Try_t068DE3CDE93ECDCFD443751A0EE5CBF727782B31::get_offset_of_speed_4(),
	Try_t068DE3CDE93ECDCFD443751A0EE5CBF727782B31::get_offset_of_target_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3864;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3864 = { sizeof (SliderMenuAnim_tB1725766011E165282E6E1419E09044AACA7686B), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3864[2] = 
{
	SliderMenuAnim_tB1725766011E165282E6E1419E09044AACA7686B::get_offset_of_PanelMenu_4(),
	SliderMenuAnim_tB1725766011E165282E6E1419E09044AACA7686B::get_offset_of_m_YourFirstButton_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3865;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3865 = { sizeof (UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3865[9] = 
{
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_but_4(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_mat_5(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_x_6(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_Ren_7(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_text_8(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_moveAnimObject_9(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_Planett_10(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_Planettt_11(),
	UIController_t06FB25185FB9B776EF16705D93C83EE95CE1D1EE::get_offset_of_Planetttt_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3866;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3866 = { sizeof (autoRotate_tE85101E00B3E6285EBEC40692C8D0319A9017ED4), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3866[2] = 
{
	autoRotate_tE85101E00B3E6285EBEC40692C8D0319A9017ED4::get_offset_of_cube1_4(),
	autoRotate_tE85101E00B3E6285EBEC40692C8D0319A9017ED4::get_offset_of_t_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3867;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3867 = { sizeof (checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3867[25] = 
{
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_m_MyText_4(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_WheelWeight_5(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_ButtonGroupOff_6(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_NonTouchingPanel_7(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_mmm_8(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_QuayGradient_9(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_flashLight_10(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_ResultPanel_11(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_yourButton_12(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_Random_13(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_Sound_14(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_l_15(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_t_16(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_k_17(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_count_18(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_count1_19(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_boi_20(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_DebugAngularVelocity_21(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_DebugAngular_22(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_x_23(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_ll_24(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_eulerAngles_25(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_isFirstExplode_26(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_isShowResult_27(),
	checkSpeed_tED95D4B88CC532FA582FF6E4E57CD94BE4EB2FF7::get_offset_of_time_28(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3868;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3868 = { sizeof (U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3868[3] = 
{
	U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551::get_offset_of_U3CU3E1__state_0(),
	U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551::get_offset_of_U3CU3E2__current_1(),
	U3CExampleCoroutineU3Ed__34_t9764DE100F38800F4F26FA72DFEBEDF7C78B5551::get_offset_of_U3CU3E4__this_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3869;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3869 = { sizeof (music_tF2D9FBB28EA016ED0FA9457F64175F4335101612), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3869[3] = 
{
	music_tF2D9FBB28EA016ED0FA9457F64175F4335101612::get_offset_of_source_4(),
	music_tF2D9FBB28EA016ED0FA9457F64175F4335101612::get_offset_of_m_MyText_5(),
	music_tF2D9FBB28EA016ED0FA9457F64175F4335101612::get_offset_of_TargetText_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3870;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3870 = { sizeof (quayImage_t185B700EEF044604F49697BCD93332985BF36EB7), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3870[1] = 
{
	quayImage_t185B700EEF044604F49697BCD93332985BF36EB7::get_offset_of_PanelsMenu_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3871;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3871 = { sizeof (quayOb_tB0C7D246393941C98CEAE2B2422B7A3A7C792117), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3871[1] = 
{
	quayOb_tB0C7D246393941C98CEAE2B2422B7A3A7C792117::get_offset_of_PanelsMenu_4(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3872;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3872 = { sizeof (TrailStyle_t1B607FC88EB81422CF2F6922B01A386B2197DD2D)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3872[7] = 
{
	TrailStyle_t1B607FC88EB81422CF2F6922B01A386B2197DD2D::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3873;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3873 = { sizeof (ColorSequence_tDD72DDB4E444AC507C979EDB66B54CDC4F8127C0)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3873[6] = 
{
	ColorSequence_tDD72DDB4E444AC507C979EDB66B54CDC4F8127C0::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3874;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3874 = { sizeof (PositionChangeRelative_t8CAD8FE50E488A3B20DB2B461B961B9CF82E4DAA)+ sizeof (RuntimeObject), sizeof(int32_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3874[3] = 
{
	PositionChangeRelative_t8CAD8FE50E488A3B20DB2B461B961B9CF82E4DAA::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3875;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3875 = { sizeof (TrailStyleProperties_tFD27699CF82CD7BB8EAEAD3DB46F1C04A565F1BC), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3876;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3876 = { sizeof (TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6), -1, sizeof(TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3876[99] = 
{
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_profile_4(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_profileSync_5(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_target_6(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of__active_7(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_executeInEditMode_8(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_ignoreFrames_9(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_duration_10(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_continuous_11(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_smooth_12(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_checkWorldPosition_13(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_minDistance_14(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_worldPositionRelativeOption_15(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_worldPositionRelativeTransform_16(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_checkScreenPosition_17(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_minPixelDistance_18(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_stepsBufferSize_19(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_maxStepsPerFrame_20(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_checkTime_21(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_timeInterval_22(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_checkCollisions_23(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_orientToSurface_24(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_ground_25(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_surfaceOffset_26(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_collisionLayerMask_27(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_drawBehind_28(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_cullMode_29(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_subMeshMask_30(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_colorOverTime_31(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_colorSequence_32(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_color_33(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_colorCycleDuration_34(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_pingPongSpeed_35(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_colorStartPalette_36(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_cam_37(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_effect_38(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_texture_39(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_scale_40(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_scaleStartRandomMin_41(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_scaleStartRandomMax_42(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_scaleOverTime_43(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_scaleUniform_44(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_localPositionRandomMin_45(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_localPositionRandomMax_46(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_laserBandWidth_47(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_laserIntensity_48(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_laserFlash_49(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_animationStates_50(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lookTarget_51(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lookToCamera_52(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_textureCutOff_53(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_normalThreshold_54(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_useLastAnimationState_55(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_maxBatches_56(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_meshPoolSize_57(),
	0,
	0,
	0,
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_trail_61(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_sortIndices_62(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_trailIndex_63(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_meshPool_64(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_meshPoolIndex_65(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_trailMask_66(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_trailClearMask_67(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_trailMaterial_68(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_propColorArrayId_69(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_theRenderer_70(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lastCornerMinPos_71(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lastCornerMaxPos_72(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lastPosition_73(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lastRandomizedPosition_74(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lastRelativePosition_75(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lastRotation_76(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_lastIntervalTimeCheck_77(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_properties_78(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_matrices_79(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_colors_80(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6_StaticFields::get_offset_of_globalRenderQueue_81(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_renderQueue_82(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_skinnedMeshRenderer_83(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_isSkinned_84(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_bakeTime_85(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_batchNumber_86(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_quadMesh_87(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_effectMaterials_88(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_orient_89(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_groundNormal_90(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_startFrameCount_91(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_smoothDuration_92(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_animator_93(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_isLimitedToAnimationStates_94(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_stateHashes_95(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_supportsGPUInstancing_96(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_propertyBlock_97(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_colorRandomAtStart_98(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_bakedColorOverTime_99(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_bakedColorStartPalette_100(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_bakedScaleOverTime_101(),
	TrailEffect_t8C6726000A1211384807F92A0529A780AB9100F6::get_offset_of_wasInactive_102(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3877;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3877 = { sizeof (SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C)+ sizeof (RuntimeObject), sizeof(SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C ), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3877[4] = 
{
	SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C::get_offset_of_matrix_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C::get_offset_of_time_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
	SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C::get_offset_of_meshIndex_2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	SnapshotTransform_t9417C2A64A6EEDF7132CBB7A9CE3D5210C9EBE5C::get_offset_of_color_3() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3878;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3878 = { sizeof (SnapshotIndex_t54E78E531BC3265078A39F96AFFF48944401C738)+ sizeof (RuntimeObject), sizeof(SnapshotIndex_t54E78E531BC3265078A39F96AFFF48944401C738 ), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3878[2] = 
{
	SnapshotIndex_t54E78E531BC3265078A39F96AFFF48944401C738::get_offset_of_t_0() + static_cast<int32_t>(sizeof(RuntimeObject)),
	SnapshotIndex_t54E78E531BC3265078A39F96AFFF48944401C738::get_offset_of_index_1() + static_cast<int32_t>(sizeof(RuntimeObject)),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3879;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3879 = { sizeof (TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3879[50] = 
{
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_profile_4(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_active_5(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_ignoreFrames_6(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_duration_7(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_continuous_8(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_smooth_9(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_checkWorldPosition_10(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_minDistance_11(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_worldPositionRelativeOption_12(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_worldPositionRelativeTransform_13(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_checkScreenPosition_14(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_minPixelDistance_15(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_maxStepsPerFrame_16(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_checkTime_17(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_timeInterval_18(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_checkCollisions_19(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_orientToSurface_20(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_ground_21(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_surfaceOffset_22(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_collisionLayerMask_23(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_drawBehind_24(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_subMeshMask_25(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_cullMode_26(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_colorOverTime_27(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_colorSequence_28(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_color_29(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_colorCycleDuration_30(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_pingPongSpeed_31(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_colorStartPalette_32(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_cam_33(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_effect_34(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_texture_35(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_scale_36(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_scaleStartRandomMin_37(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_scaleStartRandomMax_38(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_scaleOverTime_39(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_scaleUniform_40(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_localPositionRandomMin_41(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_localPositionRandomMax_42(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_laserBandWidth_43(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_laserIntensity_44(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_laserFlash_45(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_lookTarget_46(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_lookToCamera_47(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_textureCutOff_48(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_normalThreshold_49(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_useLastAnimationState_50(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_maxBatches_51(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_meshPoolSize_52(),
	TrailEffectProfile_tD2E5D472BA0DD20A2EAE09FE836B5DF0FD845444::get_offset_of_animationStates_53(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3880;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3880 = { sizeof (MoveObject_t5BDF6EB08C1B8AF546FF9281F5DCC196B32821CC), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3881;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3881 = { sizeof (RotateObject_t003EA34487C2C5EA234868B4B9A86E62CDED5FF1), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3881[2] = 
{
	RotateObject_t003EA34487C2C5EA234868B4B9A86E62CDED5FF1::get_offset_of_speed_4(),
	RotateObject_t003EA34487C2C5EA234868B4B9A86E62CDED5FF1::get_offset_of_eulerAngles_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3882;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3882 = { sizeof (Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3882[9] = 
{
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_timeInterval_4(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_bulletPrefabs_5(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_targetRot_6(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_lastTargetTime_7(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_lookAt_8(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_previousLookAt_9(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_bulletPool_10(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_poolIndex_11(),
	Shooter_t997FFA74DE90C26AB24D63FCBBC6DEB05BA9501C::get_offset_of_startPos_12(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3883;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3883 = { sizeof (quay_t9DD8EC457CF6D2BBCEEE306DDF28E6900F9F3A00), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3883[2] = 
{
	quay_t9DD8EC457CF6D2BBCEEE306DDF28E6900F9F3A00::get_offset_of_speed_4(),
	quay_t9DD8EC457CF6D2BBCEEE306DDF28E6900F9F3A00::get_offset_of_eulerAngles_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3884;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3884 = { sizeof (APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3884[3] = 
{
	APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6::get_offset_of_selectedTab_4(),
	APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6::get_offset_of_tabs_5(),
	APITester_t13BDFA1914EA72629C7FC76735880E7BB634EAB6::get_offset_of_currentFPSLevel_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3885;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3885 = { sizeof (AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54), -1, sizeof(AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3885[46] = 
{
	0,
	0,
	0,
	0,
	0,
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_fpsCounter_9(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_memoryCounter_10(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_deviceInfoCounter_11(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_hotKey_12(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_circleGesture_13(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_hotKeyCtrl_14(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_hotKeyShift_15(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_hotKeyAlt_16(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_keepAlive_17(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_canvas_18(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_canvasScaler_19(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_externalCanvas_20(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_labels_21(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_anchorsCount_22(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_cachedVSync_23(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_cachedFrameRate_24(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_inited_25(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_gesturePoints_26(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_gestureCount_27(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_operationMode_28(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_forceFrameRate_29(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_forcedFrameRate_30(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_background_31(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_backgroundColor_32(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_backgroundPadding_33(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_shadow_34(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_shadowColor_35(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_shadowDistance_36(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_outline_37(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_outlineColor_38(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_outlineDistance_39(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_autoScale_40(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_scaleFactor_41(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_labelsFont_42(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_fontSize_43(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_lineSpacing_44(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_countersSpacing_45(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_paddingOffset_46(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_pixelPerfect_47(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54::get_offset_of_sortingOrder_48(),
	AFPSCounter_t23721EBD676FB307CA9F9098938A99BBDE656D54_StaticFields::get_offset_of_U3CInstanceU3Ek__BackingField_49(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3886;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3886 = { sizeof (FPSLevel_t9C2930ABEBC10506FC5ED2E8847498EC2A8EDFB5)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3886[4] = 
{
	FPSLevel_t9C2930ABEBC10506FC5ED2E8847498EC2A8EDFB5::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3887;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3887 = { sizeof (OperationMode_tFB98614BAF7F495E5139E58682A9FBD080F0B050)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3887[4] = 
{
	OperationMode_tFB98614BAF7F495E5139E58682A9FBD080F0B050::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3888;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3888 = { sizeof (AFPSRenderRecorder_tAB8806BA73AA09300A7CF90219F9E7F1085A4E0F), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3888[2] = 
{
	AFPSRenderRecorder_tAB8806BA73AA09300A7CF90219F9E7F1085A4E0F::get_offset_of_recording_4(),
	AFPSRenderRecorder_tAB8806BA73AA09300A7CF90219F9E7F1085A4E0F::get_offset_of_renderTime_5(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3889;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3889 = { sizeof (CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331), -1, sizeof(CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3889[3] = 
{
	0,
	CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331_StaticFields::get_offset_of_cachedFloatDigits_1(),
	CachedNumbers_t9FFDE1FA390B7DE09A02AF7F9FFC13A363489331_StaticFields::get_offset_of_cachedIntegers_2(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3890;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3890 = { sizeof (UIUtils_t3561BA661DB2F7EFDDFCE453E1F0EDF9E2D59863), -1, 0, 0 };
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3891;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3891 = { sizeof (DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3891[20] = 
{
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_container_0(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_anchor_1(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_newText_2(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_dirty_3(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_labelGameObject_4(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_labelTransform_5(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_labelFitter_6(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_labelGroup_7(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_uiTextGameObject_8(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_uiText_9(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_font_10(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_fontSize_11(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_lineSpacing_12(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_pixelOffset_13(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_background_14(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_backgroundImage_15(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_shadow_16(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_shadowComponent_17(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_outline_18(),
	DrawableLabel_tED5D023ADF1B071920A0AE87C7DD5CCE3B2C9FF8::get_offset_of_outlineComponent_19(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3892;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3892 = { sizeof (LabelAnchor_t4F1B2E5EA381DF7209A2F60570E1162A6CB51A5F)+ sizeof (RuntimeObject), sizeof(uint8_t), 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3892[7] = 
{
	LabelAnchor_t4F1B2E5EA381DF7209A2F60570E1162A6CB51A5F::get_offset_of_value___2() + static_cast<int32_t>(sizeof(RuntimeObject)),
	0,
	0,
	0,
	0,
	0,
	0,
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3893;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3893 = { sizeof (LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3893[4] = 
{
	LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB::get_offset_of_enabled_0(),
	LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB::get_offset_of_color_1(),
	LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB::get_offset_of_distance_2(),
	LabelEffect_t8E8C1911E6A0DD44CB864CF2A50C1F2F512D78AB::get_offset_of_padding_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3894;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3894 = { sizeof (BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3894[14] = 
{
	0,
	0,
	0,
	0,
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_text_4(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_dirty_5(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_main_6(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_colorCached_7(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_inited_8(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_enabled_9(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_anchor_10(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_color_11(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_style_12(),
	BaseCounterData_tE261273F2FC67C7EE592F054BF18BACDE2BCB955::get_offset_of_extraText_13(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3895;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3895 = { sizeof (UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3895[2] = 
{
	UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E::get_offset_of_updateCoroutine_14(),
	UpdatableCounterData_tCE84420F35BA798D170E27F1D76E75EF06BDC79E::get_offset_of_updateInterval_15(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3896;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3896 = { sizeof (DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3896[16] = 
{
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_platform_14(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_cpuModel_15(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_cpuModelNewLine_16(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_gpuModel_17(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_gpuModelNewLine_18(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_gpuApi_19(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_gpuApiNewLine_20(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_gpuSpec_21(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_gpuSpecNewLine_22(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_ramSize_23(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_ramSizeNewLine_24(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_screenData_25(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_screenDataNewLine_26(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_deviceModel_27(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_deviceModelNewLine_28(),
	DeviceInfoCounterData_t670E0553CE76F440C090C993980B75A037F4400F::get_offset_of_U3CLastValueU3Ek__BackingField_29(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3897;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3897 = { sizeof (FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3897[63] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_warningLevelValue_25(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_criticalLevelValue_26(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_resetAverageOnNewScene_27(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_resetMinMaxOnNewScene_28(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_minMaxIntervalsToSkip_29(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_OnFPSLevelChange_30(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_newValue_31(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCachedMs_32(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCachedMin_33(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCachedMax_34(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCachedAvg_35(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCachedRender_36(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorWarningCached_37(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorWarningCachedMs_38(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorWarningCachedMin_39(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorWarningCachedMax_40(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorWarningCachedAvg_41(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCriticalCached_42(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCriticalCachedMs_43(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCriticalCachedMin_44(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCriticalCachedMax_45(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCriticalCachedAvg_46(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_currentAverageSamples_47(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_currentAverageRaw_48(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_accumulatedAverageSamples_49(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_minMaxIntervalsSkipped_50(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_renderTimeBank_51(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_previousFrameCount_52(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_realtimeFPS_53(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_milliseconds_54(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_average_55(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_averageMilliseconds_56(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_averageNewLine_57(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_averageSamples_58(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_minMax_59(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_minMaxMilliseconds_60(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_minMaxNewLine_61(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_minMaxTwoLines_62(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_render_63(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_renderNewLine_64(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_renderAutoAdd_65(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorWarning_66(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorCritical_67(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_colorRender_68(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastValueU3Ek__BackingField_69(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastMillisecondsValueU3Ek__BackingField_70(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastRenderValueU3Ek__BackingField_71(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastAverageValueU3Ek__BackingField_72(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastAverageMillisecondsValueU3Ek__BackingField_73(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastMinimumValueU3Ek__BackingField_74(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastMaximumValueU3Ek__BackingField_75(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastMinMillisecondsValueU3Ek__BackingField_76(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CLastMaxMillisecondsValueU3Ek__BackingField_77(),
	FPSCounterData_t632935A9A2A9B55255AB06918A3B0FE51567C8CD::get_offset_of_U3CCurrentFpsLevelU3Ek__BackingField_78(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3898;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3898 = { sizeof (U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3898[7] = 
{
	U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7::get_offset_of_U3CU3E1__state_0(),
	U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7::get_offset_of_U3CU3E2__current_1(),
	U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7::get_offset_of_U3CU3E4__this_2(),
	U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7::get_offset_of_U3CpreviousUpdateTimeU3E5__1_3(),
	U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7::get_offset_of_U3CpreviousUpdateFramesU3E5__2_4(),
	U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7::get_offset_of_U3CtimeElapsedU3E5__3_5(),
	U3CUpdateCounterU3Ed__151_tAE4BEBCF7571B6BE9C45BCF8486696AE5B8E4EE7::get_offset_of_U3CframesChangedU3E5__4_6(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3899;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3899 = { sizeof (MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3899[17] = 
{
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	0,
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_precise_24(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_total_25(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_allocated_26(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_monoUsage_27(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_gfx_28(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_U3CLastTotalValueU3Ek__BackingField_29(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_U3CLastAllocatedValueU3Ek__BackingField_30(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_U3CLastMonoValueU3Ek__BackingField_31(),
	MemoryCounterData_t214ADBF409551E8ED11FD12AE95ACA6BA6F06AB6::get_offset_of_U3CLastGfxValueU3Ek__BackingField_32(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3900;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3900 = { sizeof (U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7), -1, 0, 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3900[4] = 
{
	U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7::get_offset_of_U3CU3E1__state_0(),
	U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7::get_offset_of_U3CU3E2__current_1(),
	U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7::get_offset_of_U3CU3E4__this_2(),
	U3CUpdateCounterU3Ed__48_t65ADF1B10A08CE76DCE4427A26A61C941C012BD7::get_offset_of_U3CpreviousUpdateTimeU3E5__1_3(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3901;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3901 = { sizeof (U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A), -1, sizeof(U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields), 0 };
IL2CPP_EXTERN_C const int32_t g_FieldOffsetTable3901[1] = 
{
	U3CPrivateImplementationDetailsU3E_t4846F3E0DC61BBD6AE249FF1EAAC4CB64097DE4A_StaticFields::get_offset_of_U31B287FBF8016A1357E0FA5B7B88403B0659ECE97_0(),
};
extern const Il2CppTypeDefinitionSizes g_typeDefinitionSize3902;
const Il2CppTypeDefinitionSizes g_typeDefinitionSize3902 = { sizeof (__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34)+ sizeof (RuntimeObject), sizeof(__StaticArrayInitTypeSizeU3D24_t0186834C621050282F5EF637E836A6E1DC934A34 ), 0, 0 };
#ifdef __clang__
#pragma clang diagnostic pop
#endif
