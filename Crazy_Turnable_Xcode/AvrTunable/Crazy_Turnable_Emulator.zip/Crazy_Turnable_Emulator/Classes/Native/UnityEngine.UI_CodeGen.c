﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.String UnityEngine.UI.AnimationTriggers::get_normalTrigger()
extern void AnimationTriggers_get_normalTrigger_m523D4A64E6677159ED80FC7E30E08F33658B3FE0 (void);
// 0x00000002 System.Void UnityEngine.UI.AnimationTriggers::set_normalTrigger(System.String)
extern void AnimationTriggers_set_normalTrigger_m8B1A7D283B031722F56F893F89578D4E14936A45 (void);
// 0x00000003 System.String UnityEngine.UI.AnimationTriggers::get_highlightedTrigger()
extern void AnimationTriggers_get_highlightedTrigger_mA272B91B74330469F5732B2DE8624A62F5085B98 (void);
// 0x00000004 System.Void UnityEngine.UI.AnimationTriggers::set_highlightedTrigger(System.String)
extern void AnimationTriggers_set_highlightedTrigger_m4DECB61F087B3DA559E97FE431E44ECA8A466609 (void);
// 0x00000005 System.String UnityEngine.UI.AnimationTriggers::get_pressedTrigger()
extern void AnimationTriggers_get_pressedTrigger_m8D440CAC69B9DE329DA046D324BD61E3ED55FCD7 (void);
// 0x00000006 System.Void UnityEngine.UI.AnimationTriggers::set_pressedTrigger(System.String)
extern void AnimationTriggers_set_pressedTrigger_mB627531FBBC50BE9E3EA2B9EFE1A7C941F5942FB (void);
// 0x00000007 System.String UnityEngine.UI.AnimationTriggers::get_selectedTrigger()
extern void AnimationTriggers_get_selectedTrigger_mCD9621B82B7E2AA88D2734C58BC6B07664BC976B (void);
// 0x00000008 System.Void UnityEngine.UI.AnimationTriggers::set_selectedTrigger(System.String)
extern void AnimationTriggers_set_selectedTrigger_m9FB5C4728FA04DA1E22F2B55A2A4453481A6F501 (void);
// 0x00000009 System.String UnityEngine.UI.AnimationTriggers::get_disabledTrigger()
extern void AnimationTriggers_get_disabledTrigger_mC796C6111FDFF4DF411920AF82A95908D4E60A50 (void);
// 0x0000000A System.Void UnityEngine.UI.AnimationTriggers::set_disabledTrigger(System.String)
extern void AnimationTriggers_set_disabledTrigger_m7F08D71BAC1A9D9A4F61E429A023141AC4293DBE (void);
// 0x0000000B System.Void UnityEngine.UI.AnimationTriggers::.ctor()
extern void AnimationTriggers__ctor_mF0F35FC53FA65A88FEF8D4F52006FE957981C246 (void);
// 0x0000000C System.Void UnityEngine.UI.Button::.ctor()
extern void Button__ctor_m51451154939F30BAA6EB8B005BD480E2E20540CB (void);
// 0x0000000D UnityEngine.UI.Button/ButtonClickedEvent UnityEngine.UI.Button::get_onClick()
extern void Button_get_onClick_m77E8CA6917881760CC7900930F4C789F3E2F8817 (void);
// 0x0000000E System.Void UnityEngine.UI.Button::set_onClick(UnityEngine.UI.Button/ButtonClickedEvent)
extern void Button_set_onClick_m007C337F4A5B1B2A48CAF3636F87FBFB62271BB9 (void);
// 0x0000000F System.Void UnityEngine.UI.Button::Press()
extern void Button_Press_m58210E36B74902AC4667E5A75B4ADB891D1596C2 (void);
// 0x00000010 System.Void UnityEngine.UI.Button::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Button_OnPointerClick_m33A14004B5EA59CBF8D0247CC9001CFD9D3CEFEC (void);
// 0x00000011 System.Void UnityEngine.UI.Button::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Button_OnSubmit_m9004AD829B9FE03D54DF1BF7F796530A966F9A2E (void);
// 0x00000012 System.Collections.IEnumerator UnityEngine.UI.Button::OnFinishSubmit()
extern void Button_OnFinishSubmit_m89D3F073EF025FE5DE11FAC04E41025685AAE20F (void);
// 0x00000013 System.Void UnityEngine.UI.ICanvasElement::Rebuild(UnityEngine.UI.CanvasUpdate)
// 0x00000014 UnityEngine.Transform UnityEngine.UI.ICanvasElement::get_transform()
// 0x00000015 System.Void UnityEngine.UI.ICanvasElement::LayoutComplete()
// 0x00000016 System.Void UnityEngine.UI.ICanvasElement::GraphicUpdateComplete()
// 0x00000017 System.Boolean UnityEngine.UI.ICanvasElement::IsDestroyed()
// 0x00000018 System.Void UnityEngine.UI.CanvasUpdateRegistry::.ctor()
extern void CanvasUpdateRegistry__ctor_m86AC7F2BD30DF9ABEA5CA8C74BA28367D5325E9A (void);
// 0x00000019 UnityEngine.UI.CanvasUpdateRegistry UnityEngine.UI.CanvasUpdateRegistry::get_instance()
extern void CanvasUpdateRegistry_get_instance_m6A2150EA4C8C74AF18E53B3CF22BF6EAF70FF927 (void);
// 0x0000001A System.Boolean UnityEngine.UI.CanvasUpdateRegistry::ObjectValidForUpdate(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_ObjectValidForUpdate_m0A572FA254D152E92FD6D6DC63B4B0FA66B88250 (void);
// 0x0000001B System.Void UnityEngine.UI.CanvasUpdateRegistry::CleanInvalidItems()
extern void CanvasUpdateRegistry_CleanInvalidItems_m033AB2A5652116F351F3287C37E0910AE78506D0 (void);
// 0x0000001C System.Void UnityEngine.UI.CanvasUpdateRegistry::PerformUpdate()
extern void CanvasUpdateRegistry_PerformUpdate_m6C0C51EBC871BFD67FEE7403B0A4D8FC99AAE93E (void);
// 0x0000001D System.Int32 UnityEngine.UI.CanvasUpdateRegistry::ParentCount(UnityEngine.Transform)
extern void CanvasUpdateRegistry_ParentCount_m41ED796F144AF2FF40F97F45687086942FE09776 (void);
// 0x0000001E System.Int32 UnityEngine.UI.CanvasUpdateRegistry::SortLayoutList(UnityEngine.UI.ICanvasElement,UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_SortLayoutList_mB2F2B63B28CC722E5AA645835963DD3678FC08BA (void);
// 0x0000001F System.Void UnityEngine.UI.CanvasUpdateRegistry::RegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_RegisterCanvasElementForLayoutRebuild_mD64DEDFC14F5B52DE3A685CD1B132907A784D70D (void);
// 0x00000020 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::TryRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_TryRegisterCanvasElementForLayoutRebuild_m4D405FFBB41D68D0D1A260DBFBC196257EC95898 (void);
// 0x00000021 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::InternalRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalRegisterCanvasElementForLayoutRebuild_m4B27D53D884E8281D102493C216A85402702B02B (void);
// 0x00000022 System.Void UnityEngine.UI.CanvasUpdateRegistry::RegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_RegisterCanvasElementForGraphicRebuild_m78F01AB29AC2F8BA889E0D0A67CD150BE0006508 (void);
// 0x00000023 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::TryRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_TryRegisterCanvasElementForGraphicRebuild_mF9026CA6334F6B484FC243F0C1BFAE15EDBDEB11 (void);
// 0x00000024 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::InternalRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalRegisterCanvasElementForGraphicRebuild_m21F2CD6F08EA106A9B7CB61836836E67D9AD014A (void);
// 0x00000025 System.Void UnityEngine.UI.CanvasUpdateRegistry::UnRegisterCanvasElementForRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_UnRegisterCanvasElementForRebuild_m65BE77E918ACF3C08D0C2651B3120120AC7A5FD0 (void);
// 0x00000026 System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalUnRegisterCanvasElementForLayoutRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalUnRegisterCanvasElementForLayoutRebuild_m257D195226FDF05E9A9723745094408E556A165E (void);
// 0x00000027 System.Void UnityEngine.UI.CanvasUpdateRegistry::InternalUnRegisterCanvasElementForGraphicRebuild(UnityEngine.UI.ICanvasElement)
extern void CanvasUpdateRegistry_InternalUnRegisterCanvasElementForGraphicRebuild_mE9C5DB7632C213651671F55119B385984FDA52BB (void);
// 0x00000028 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::IsRebuildingLayout()
extern void CanvasUpdateRegistry_IsRebuildingLayout_m067422BB24431C94CE3DC7FB25760351B3015D80 (void);
// 0x00000029 System.Boolean UnityEngine.UI.CanvasUpdateRegistry::IsRebuildingGraphics()
extern void CanvasUpdateRegistry_IsRebuildingGraphics_m9675CE4A1FED3F73C3B0EDCD1DA90BB390EE2A03 (void);
// 0x0000002A System.Void UnityEngine.UI.CanvasUpdateRegistry::.cctor()
extern void CanvasUpdateRegistry__cctor_m4816A252A4E24967FBEF0AD749DDE9B3F8D5FB44 (void);
// 0x0000002B UnityEngine.Color UnityEngine.UI.ColorBlock::get_normalColor()
extern void ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905 (void);
// 0x0000002C System.Void UnityEngine.UI.ColorBlock::set_normalColor(UnityEngine.Color)
extern void ColorBlock_set_normalColor_mF36865F66914F3902ACAF7E64B3E6C664EA81911 (void);
// 0x0000002D UnityEngine.Color UnityEngine.UI.ColorBlock::get_highlightedColor()
extern void ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF (void);
// 0x0000002E System.Void UnityEngine.UI.ColorBlock::set_highlightedColor(UnityEngine.Color)
extern void ColorBlock_set_highlightedColor_mAE0BF4A697744D841048D8BE9A0C8963226B4B3A (void);
// 0x0000002F UnityEngine.Color UnityEngine.UI.ColorBlock::get_pressedColor()
extern void ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5 (void);
// 0x00000030 System.Void UnityEngine.UI.ColorBlock::set_pressedColor(UnityEngine.Color)
extern void ColorBlock_set_pressedColor_mAE69CAEBA8CA45E089F6C7CA2F1B8C530705E70B (void);
// 0x00000031 UnityEngine.Color UnityEngine.UI.ColorBlock::get_selectedColor()
extern void ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D (void);
// 0x00000032 System.Void UnityEngine.UI.ColorBlock::set_selectedColor(UnityEngine.Color)
extern void ColorBlock_set_selectedColor_mA8B032467C571D28563D91766B0E956FB265ACC9 (void);
// 0x00000033 UnityEngine.Color UnityEngine.UI.ColorBlock::get_disabledColor()
extern void ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8 (void);
// 0x00000034 System.Void UnityEngine.UI.ColorBlock::set_disabledColor(UnityEngine.Color)
extern void ColorBlock_set_disabledColor_m530D0573E0257BAB82F2FFEA0E22C743911B4588 (void);
// 0x00000035 System.Single UnityEngine.UI.ColorBlock::get_colorMultiplier()
extern void ColorBlock_get_colorMultiplier_m8B3021855566FCCBD41100EB2B70B18172064DC5 (void);
// 0x00000036 System.Void UnityEngine.UI.ColorBlock::set_colorMultiplier(System.Single)
extern void ColorBlock_set_colorMultiplier_m815DE55D842A1480A11D1051D559D9B63EE34672 (void);
// 0x00000037 System.Single UnityEngine.UI.ColorBlock::get_fadeDuration()
extern void ColorBlock_get_fadeDuration_mD5EA922E1FA90C1BA224652C1DFC25FEE93830D5 (void);
// 0x00000038 System.Void UnityEngine.UI.ColorBlock::set_fadeDuration(System.Single)
extern void ColorBlock_set_fadeDuration_mE31362D1331C613F27505EB7581A734A2E58C917 (void);
// 0x00000039 UnityEngine.UI.ColorBlock UnityEngine.UI.ColorBlock::get_defaultColorBlock()
extern void ColorBlock_get_defaultColorBlock_mD3AEFDABCF5F714D81FB2047A744930650EC223E (void);
// 0x0000003A System.Boolean UnityEngine.UI.ColorBlock::Equals(System.Object)
extern void ColorBlock_Equals_mCA2055CA21C85A585504A447B3B048480BB7AB21 (void);
// 0x0000003B System.Boolean UnityEngine.UI.ColorBlock::Equals(UnityEngine.UI.ColorBlock)
extern void ColorBlock_Equals_m3768CE3E85F9FD55FCA305EA20FF33983B4DB26C (void);
// 0x0000003C System.Boolean UnityEngine.UI.ColorBlock::op_Equality(UnityEngine.UI.ColorBlock,UnityEngine.UI.ColorBlock)
extern void ColorBlock_op_Equality_m63592FF29309D3AF64710205FD9797D2E4AF4E3C (void);
// 0x0000003D System.Boolean UnityEngine.UI.ColorBlock::op_Inequality(UnityEngine.UI.ColorBlock,UnityEngine.UI.ColorBlock)
extern void ColorBlock_op_Inequality_mEC2D35C789210F1825B114A5E224B0FB6975C1A0 (void);
// 0x0000003E System.Int32 UnityEngine.UI.ColorBlock::GetHashCode()
extern void ColorBlock_GetHashCode_m1F4A5EC52681DEE9C205F4A5C5A60051DAF71111 (void);
// 0x0000003F System.Void UnityEngine.UI.ClipperRegistry::.ctor()
extern void ClipperRegistry__ctor_mBE6A18696846AD82B4C069BEA3C4318777A59521 (void);
// 0x00000040 UnityEngine.UI.ClipperRegistry UnityEngine.UI.ClipperRegistry::get_instance()
extern void ClipperRegistry_get_instance_mE4E214237577A08B2A6C8AF9DD7CDAE1B75E387B (void);
// 0x00000041 System.Void UnityEngine.UI.ClipperRegistry::Cull()
extern void ClipperRegistry_Cull_mBCB5139DD0FBCC6436ABA8F014E455DF219ADB18 (void);
// 0x00000042 System.Void UnityEngine.UI.ClipperRegistry::Register(UnityEngine.UI.IClipper)
extern void ClipperRegistry_Register_m3D9ADBB2F45433ABA125ADC70834A188BE5BB486 (void);
// 0x00000043 System.Void UnityEngine.UI.ClipperRegistry::Unregister(UnityEngine.UI.IClipper)
extern void ClipperRegistry_Unregister_mA09C34BE5C5BC681695DA6F638C3CA585B236467 (void);
// 0x00000044 UnityEngine.Rect UnityEngine.UI.Clipping::FindCullAndClipWorldRect(System.Collections.Generic.List`1<UnityEngine.UI.RectMask2D>,System.Boolean&)
extern void Clipping_FindCullAndClipWorldRect_mF3B79EF5BE61C8D2FCF12B428EA38A55FE1CA31A (void);
// 0x00000045 System.Void UnityEngine.UI.IClipper::PerformClipping()
// 0x00000046 UnityEngine.GameObject UnityEngine.UI.IClippable::get_gameObject()
// 0x00000047 System.Void UnityEngine.UI.IClippable::RecalculateClipping()
// 0x00000048 UnityEngine.RectTransform UnityEngine.UI.IClippable::get_rectTransform()
// 0x00000049 System.Void UnityEngine.UI.IClippable::Cull(UnityEngine.Rect,System.Boolean)
// 0x0000004A System.Void UnityEngine.UI.IClippable::SetClipRect(UnityEngine.Rect,System.Boolean)
// 0x0000004B System.Void UnityEngine.UI.IClippable::SetClipSoftness(UnityEngine.Vector2)
// 0x0000004C UnityEngine.Rect UnityEngine.UI.RectangularVertexClipper::GetCanvasRect(UnityEngine.RectTransform,UnityEngine.Canvas)
extern void RectangularVertexClipper_GetCanvasRect_m3A009069CB93F6A0D61221B26FD7BACD6A57533F (void);
// 0x0000004D System.Void UnityEngine.UI.RectangularVertexClipper::.ctor()
extern void RectangularVertexClipper__ctor_m8627116751067B7124D26CF075DB1DB7AB21F37F (void);
// 0x0000004E UnityEngine.UI.DefaultControls/IFactoryControls UnityEngine.UI.DefaultControls::get_factory()
extern void DefaultControls_get_factory_m616056407908402EFF7E24BC02D0A1B0CDED98B2 (void);
// 0x0000004F UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateUIElementRoot(System.String,UnityEngine.Vector2,System.Type[])
extern void DefaultControls_CreateUIElementRoot_m6B5271F0FD59538B62BD2A81C972F919A8F2F184 (void);
// 0x00000050 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateUIObject(System.String,UnityEngine.GameObject,System.Type[])
extern void DefaultControls_CreateUIObject_m40EAC1469CBFAFB6162127C38E148719A986C988 (void);
// 0x00000051 System.Void UnityEngine.UI.DefaultControls::SetDefaultTextValues(UnityEngine.UI.Text)
extern void DefaultControls_SetDefaultTextValues_mA1638BD65C2A72207A3E3EA7D1D8A8485D108A1A (void);
// 0x00000052 System.Void UnityEngine.UI.DefaultControls::SetDefaultColorTransitionValues(UnityEngine.UI.Selectable)
extern void DefaultControls_SetDefaultColorTransitionValues_mA5D98948B9EB25EFC8EB302A63EDA5FC239F9B02 (void);
// 0x00000053 System.Void UnityEngine.UI.DefaultControls::SetParentAndAlign(UnityEngine.GameObject,UnityEngine.GameObject)
extern void DefaultControls_SetParentAndAlign_m4176E84A699CD8A68747888300DC651B765A512A (void);
// 0x00000054 System.Void UnityEngine.UI.DefaultControls::SetLayerRecursively(UnityEngine.GameObject,System.Int32)
extern void DefaultControls_SetLayerRecursively_m090900DE7A3FFC976E3DBE9B54C11769EE126BF1 (void);
// 0x00000055 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreatePanel(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreatePanel_m6CC4319B8D81426FC2A4E94CA836AB4F0ECA0205 (void);
// 0x00000056 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateButton(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateButton_m73704B2DEB6F80CF622B31A7B14BBEC3A24737C2 (void);
// 0x00000057 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateText(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateText_mB0CA319F4BF0C8EC8773075885BD67D78A4582FE (void);
// 0x00000058 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateImage(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateImage_m5A948ACE15B86771B6F3EB7A8A74EBE938CEB3E6 (void);
// 0x00000059 UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateRawImage(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateRawImage_m3704C3F2E829FBCFEEDA34F27668000B1E6E5A02 (void);
// 0x0000005A UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateSlider(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateSlider_m2AF0A50D2FF4EB21A68A5DBF92076C8DB6D50C5B (void);
// 0x0000005B UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateScrollbar(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateScrollbar_m876785B77922E7A0918137096FE9CEEC4BBCA1C6 (void);
// 0x0000005C UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateToggle(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateToggle_m9F0611E37F71C5C077EB3D64D998A7117C830B7F (void);
// 0x0000005D UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateInputField(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateInputField_mDF85B76D7CDE06E5E49F537EA5FDD8192DA5E65A (void);
// 0x0000005E UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateDropdown(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateDropdown_m00FF9DE1B54D5EA9B22EECC23EAB2D465538C0B2 (void);
// 0x0000005F UnityEngine.GameObject UnityEngine.UI.DefaultControls::CreateScrollView(UnityEngine.UI.DefaultControls/Resources)
extern void DefaultControls_CreateScrollView_m18E2B79533E8C63917A90B112C7861D8777FAB89 (void);
// 0x00000060 System.Void UnityEngine.UI.DefaultControls::.cctor()
extern void DefaultControls__cctor_m2CFE7925A4D7254130F760EBE94A377BB86417A9 (void);
// 0x00000061 UnityEngine.RectTransform UnityEngine.UI.Dropdown::get_template()
extern void Dropdown_get_template_m9C83BB0CFD2BA72F08ACC8B0FA9A274FAD0FC9C4 (void);
// 0x00000062 System.Void UnityEngine.UI.Dropdown::set_template(UnityEngine.RectTransform)
extern void Dropdown_set_template_m2B92A6B03345CAFB7C987C648B6FC075420DF85A (void);
// 0x00000063 UnityEngine.UI.Text UnityEngine.UI.Dropdown::get_captionText()
extern void Dropdown_get_captionText_m3E3FF20006F7EC8A8FD7ABBB7F9F723A0E3CD5FF (void);
// 0x00000064 System.Void UnityEngine.UI.Dropdown::set_captionText(UnityEngine.UI.Text)
extern void Dropdown_set_captionText_mFF1957B5BFA13D2295B54A092E863D0F582A3054 (void);
// 0x00000065 UnityEngine.UI.Image UnityEngine.UI.Dropdown::get_captionImage()
extern void Dropdown_get_captionImage_mB846CCDC2F81DEC05EFC9FA1E38505409B428253 (void);
// 0x00000066 System.Void UnityEngine.UI.Dropdown::set_captionImage(UnityEngine.UI.Image)
extern void Dropdown_set_captionImage_mE671828EC16733683973D78B53EAAD8BF928C3FB (void);
// 0x00000067 UnityEngine.UI.Text UnityEngine.UI.Dropdown::get_itemText()
extern void Dropdown_get_itemText_m1AEEFE1ACF751CD3483659F5E5B703239C28C7D5 (void);
// 0x00000068 System.Void UnityEngine.UI.Dropdown::set_itemText(UnityEngine.UI.Text)
extern void Dropdown_set_itemText_m3FA2FA21BFB8D097F11F642B4061544FE97A250D (void);
// 0x00000069 UnityEngine.UI.Image UnityEngine.UI.Dropdown::get_itemImage()
extern void Dropdown_get_itemImage_m3B115ACA023FC279CAE1757FD4AB0DF91242BA50 (void);
// 0x0000006A System.Void UnityEngine.UI.Dropdown::set_itemImage(UnityEngine.UI.Image)
extern void Dropdown_set_itemImage_mF609D2C91FC45643A9F61E1F651BA1FC9DA4DF45 (void);
// 0x0000006B System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData> UnityEngine.UI.Dropdown::get_options()
extern void Dropdown_get_options_mE95E87D4EA905E9769CE8AC1CD1D9DB86A34F823 (void);
// 0x0000006C System.Void UnityEngine.UI.Dropdown::set_options(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void Dropdown_set_options_m6606D7A610BA8B07CE330099250482F230B41CAB (void);
// 0x0000006D UnityEngine.UI.Dropdown/DropdownEvent UnityEngine.UI.Dropdown::get_onValueChanged()
extern void Dropdown_get_onValueChanged_m4EE82DC9AE8618C52CECA362EBDE6284F41E88FE (void);
// 0x0000006E System.Void UnityEngine.UI.Dropdown::set_onValueChanged(UnityEngine.UI.Dropdown/DropdownEvent)
extern void Dropdown_set_onValueChanged_m5933FE1D9A345810C095C9152A5A3FDE97132C59 (void);
// 0x0000006F System.Single UnityEngine.UI.Dropdown::get_alphaFadeSpeed()
extern void Dropdown_get_alphaFadeSpeed_m6622DC342399634C72CE480D339380EDDFB41CBD (void);
// 0x00000070 System.Void UnityEngine.UI.Dropdown::set_alphaFadeSpeed(System.Single)
extern void Dropdown_set_alphaFadeSpeed_m8B30DC0B7FE44FBAFD99455204B6EA904A903107 (void);
// 0x00000071 System.Int32 UnityEngine.UI.Dropdown::get_value()
extern void Dropdown_get_value_mF388FA389F2A050264AA87E61D4F9AFC41F48873 (void);
// 0x00000072 System.Void UnityEngine.UI.Dropdown::set_value(System.Int32)
extern void Dropdown_set_value_m155A45649AB62AC1B7AB10213EA556F22E8E91F3 (void);
// 0x00000073 System.Void UnityEngine.UI.Dropdown::SetValueWithoutNotify(System.Int32)
extern void Dropdown_SetValueWithoutNotify_m6D653006F090CE272709B7A777589C338AE81362 (void);
// 0x00000074 System.Void UnityEngine.UI.Dropdown::Set(System.Int32,System.Boolean)
extern void Dropdown_Set_mB556E466A427314DC78F38EA38DB4462672B2A49 (void);
// 0x00000075 System.Void UnityEngine.UI.Dropdown::.ctor()
extern void Dropdown__ctor_m441023FADC43E0D5215546260F0230D92439AA9C (void);
// 0x00000076 System.Void UnityEngine.UI.Dropdown::Awake()
extern void Dropdown_Awake_mDEFE3A3991573E2C6942EF866CC4D2350481322E (void);
// 0x00000077 System.Void UnityEngine.UI.Dropdown::Start()
extern void Dropdown_Start_m32F9113294B5F5EB5EFE41F9D2B6C49A516182E5 (void);
// 0x00000078 System.Void UnityEngine.UI.Dropdown::OnDisable()
extern void Dropdown_OnDisable_m7CBB6617F6557D89C1E92EC5A7433426AADCF53C (void);
// 0x00000079 System.Void UnityEngine.UI.Dropdown::RefreshShownValue()
extern void Dropdown_RefreshShownValue_m310DF4ABCFE31C74153AAE3874B40DDF3D6959E1 (void);
// 0x0000007A System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void Dropdown_AddOptions_m00D0E094A726D9E20E42CDE57430879266456ABB (void);
// 0x0000007B System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<System.String>)
extern void Dropdown_AddOptions_m1F55A888671D01E7933300CEFF571556EE717AC8 (void);
// 0x0000007C System.Void UnityEngine.UI.Dropdown::AddOptions(System.Collections.Generic.List`1<UnityEngine.Sprite>)
extern void Dropdown_AddOptions_m07425DFFE48698B71FFAA7A88EA4EB9191A0A20D (void);
// 0x0000007D System.Void UnityEngine.UI.Dropdown::ClearOptions()
extern void Dropdown_ClearOptions_mC20522EBB5C22EFC938740AB7A2524EF8CCCDD0D (void);
// 0x0000007E System.Void UnityEngine.UI.Dropdown::SetupTemplate()
extern void Dropdown_SetupTemplate_m3F4C22ABEF75FEC05E3D42D277EF2299A7934E0C (void);
// 0x0000007F T UnityEngine.UI.Dropdown::GetOrAddComponent(UnityEngine.GameObject)
// 0x00000080 System.Void UnityEngine.UI.Dropdown::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Dropdown_OnPointerClick_m2D739C0E96E848C4384C7BFEF289259717593B3A (void);
// 0x00000081 System.Void UnityEngine.UI.Dropdown::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Dropdown_OnSubmit_m51215780EC68329BEE4F305748A1EFBB501EDE6B (void);
// 0x00000082 System.Void UnityEngine.UI.Dropdown::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void Dropdown_OnCancel_mCB303E40BF5CA8862F28F6E377C74AD618C6A54B (void);
// 0x00000083 System.Void UnityEngine.UI.Dropdown::Show()
extern void Dropdown_Show_m996910C935BA7D778E35EBAA55F1AC7299A0B3D9 (void);
// 0x00000084 UnityEngine.GameObject UnityEngine.UI.Dropdown::CreateBlocker(UnityEngine.Canvas)
extern void Dropdown_CreateBlocker_m036190311A5551395BC6DD3807D909F851AC8075 (void);
// 0x00000085 System.Void UnityEngine.UI.Dropdown::DestroyBlocker(UnityEngine.GameObject)
extern void Dropdown_DestroyBlocker_mEF1CA103B452EBED15714974CEE056CB44C17A58 (void);
// 0x00000086 UnityEngine.GameObject UnityEngine.UI.Dropdown::CreateDropdownList(UnityEngine.GameObject)
extern void Dropdown_CreateDropdownList_m4C38DE76864D27BBA2033CD5DD72A88B1D2896A9 (void);
// 0x00000087 System.Void UnityEngine.UI.Dropdown::DestroyDropdownList(UnityEngine.GameObject)
extern void Dropdown_DestroyDropdownList_m1049B8618DF9EFDC6504F4CF29F240252BCAC0A5 (void);
// 0x00000088 UnityEngine.UI.Dropdown/DropdownItem UnityEngine.UI.Dropdown::CreateItem(UnityEngine.UI.Dropdown/DropdownItem)
extern void Dropdown_CreateItem_m591B3B4546D13786893F9930BE702F3A9AAE3CDC (void);
// 0x00000089 System.Void UnityEngine.UI.Dropdown::DestroyItem(UnityEngine.UI.Dropdown/DropdownItem)
extern void Dropdown_DestroyItem_mC2B1258A6EF53D30D7C7693BB62B63B12E3283AB (void);
// 0x0000008A UnityEngine.UI.Dropdown/DropdownItem UnityEngine.UI.Dropdown::AddItem(UnityEngine.UI.Dropdown/OptionData,System.Boolean,UnityEngine.UI.Dropdown/DropdownItem,System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/DropdownItem>)
extern void Dropdown_AddItem_m0E0D9C4C7C73622BC2E7AC785BD4CEA48FE952EF (void);
// 0x0000008B System.Void UnityEngine.UI.Dropdown::AlphaFadeList(System.Single,System.Single)
extern void Dropdown_AlphaFadeList_m7E0D67E3ED4F3578B5850B47E4A6F9CFF19A49BB (void);
// 0x0000008C System.Void UnityEngine.UI.Dropdown::AlphaFadeList(System.Single,System.Single,System.Single)
extern void Dropdown_AlphaFadeList_m86254B5CBD02903E1D9AF108EB1E86234DCE45E2 (void);
// 0x0000008D System.Void UnityEngine.UI.Dropdown::SetAlpha(System.Single)
extern void Dropdown_SetAlpha_mEFF1F7A014A6A66AEFFA937DA3EE8591B7F2336D (void);
// 0x0000008E System.Void UnityEngine.UI.Dropdown::Hide()
extern void Dropdown_Hide_m396A627BAA21433514959C71BD8B13A31B7B99A8 (void);
// 0x0000008F System.Collections.IEnumerator UnityEngine.UI.Dropdown::DelayedDestroyDropdownList(System.Single)
extern void Dropdown_DelayedDestroyDropdownList_m09235010EDBDA0A0341350E1D34BC0BA9A326CBF (void);
// 0x00000090 System.Void UnityEngine.UI.Dropdown::ImmediateDestroyDropdownList()
extern void Dropdown_ImmediateDestroyDropdownList_mB3CE7E1B2B95662433A48B5BA20A51755AAE677E (void);
// 0x00000091 System.Void UnityEngine.UI.Dropdown::OnSelectItem(UnityEngine.UI.Toggle)
extern void Dropdown_OnSelectItem_m28AC73C405708C623F4EE5C42E61D5C8D2ECC011 (void);
// 0x00000092 System.Void UnityEngine.UI.Dropdown::.cctor()
extern void Dropdown__cctor_mC1DD8DB000D6E2DCA6CD41C429DDF120B6535442 (void);
// 0x00000093 UnityEngine.UI.FontData UnityEngine.UI.FontData::get_defaultFontData()
extern void FontData_get_defaultFontData_m395A2BA13B11A53C4BD4E8F1B7D97E9E278D6063 (void);
// 0x00000094 UnityEngine.Font UnityEngine.UI.FontData::get_font()
extern void FontData_get_font_m63A03245926CD05B461E00C281724370C8B7D0F4 (void);
// 0x00000095 System.Void UnityEngine.UI.FontData::set_font(UnityEngine.Font)
extern void FontData_set_font_m6FC9FE436E4EE72CD5039010DA60F922F0B34F93 (void);
// 0x00000096 System.Int32 UnityEngine.UI.FontData::get_fontSize()
extern void FontData_get_fontSize_mF53526AF53B326BFA253A65D36891015F3F3AC08 (void);
// 0x00000097 System.Void UnityEngine.UI.FontData::set_fontSize(System.Int32)
extern void FontData_set_fontSize_mC3225A125A316DB700496872EF33829A1736AF9E (void);
// 0x00000098 UnityEngine.FontStyle UnityEngine.UI.FontData::get_fontStyle()
extern void FontData_get_fontStyle_m463803A5ED384064EC9B03549BA921BEAAC8A4A6 (void);
// 0x00000099 System.Void UnityEngine.UI.FontData::set_fontStyle(UnityEngine.FontStyle)
extern void FontData_set_fontStyle_m16F9715D8679E8CD51D3E4B9755DBAD86A28E20A (void);
// 0x0000009A System.Boolean UnityEngine.UI.FontData::get_bestFit()
extern void FontData_get_bestFit_m9B677268C0B0AC07DF39509A6EFA74D057C5D96C (void);
// 0x0000009B System.Void UnityEngine.UI.FontData::set_bestFit(System.Boolean)
extern void FontData_set_bestFit_m8F31CB420AC3F76FB80964A4990F4F79C64BCC00 (void);
// 0x0000009C System.Int32 UnityEngine.UI.FontData::get_minSize()
extern void FontData_get_minSize_m963639D175365AF4A04B256EA11CDA29C73654F9 (void);
// 0x0000009D System.Void UnityEngine.UI.FontData::set_minSize(System.Int32)
extern void FontData_set_minSize_m7C66291B2D46DBB85BE699C63BE84835D7F20965 (void);
// 0x0000009E System.Int32 UnityEngine.UI.FontData::get_maxSize()
extern void FontData_get_maxSize_m22DBD85840A55249A019D97A3480CFE515F613E2 (void);
// 0x0000009F System.Void UnityEngine.UI.FontData::set_maxSize(System.Int32)
extern void FontData_set_maxSize_m681E9215562EB7A3F0DF1D8EAD6818E064E76DE6 (void);
// 0x000000A0 UnityEngine.TextAnchor UnityEngine.UI.FontData::get_alignment()
extern void FontData_get_alignment_m2492DD0F8619041BD0426388DFFE2DA4634DF095 (void);
// 0x000000A1 System.Void UnityEngine.UI.FontData::set_alignment(UnityEngine.TextAnchor)
extern void FontData_set_alignment_m531F891C8FDB722FAAEADAE288FD3A6759C8100D (void);
// 0x000000A2 System.Boolean UnityEngine.UI.FontData::get_alignByGeometry()
extern void FontData_get_alignByGeometry_m847BD1E3B34CAFF67EE1E7983D1DFC02BDFA1F10 (void);
// 0x000000A3 System.Void UnityEngine.UI.FontData::set_alignByGeometry(System.Boolean)
extern void FontData_set_alignByGeometry_m490803F52D6C14BAE33AC20013A14DFAD6C0493C (void);
// 0x000000A4 System.Boolean UnityEngine.UI.FontData::get_richText()
extern void FontData_get_richText_mEF4FF744C13484BFD1AADE759229DD339333840D (void);
// 0x000000A5 System.Void UnityEngine.UI.FontData::set_richText(System.Boolean)
extern void FontData_set_richText_m155CBB2B6901849428D2561277DE44792A0AFA36 (void);
// 0x000000A6 UnityEngine.HorizontalWrapMode UnityEngine.UI.FontData::get_horizontalOverflow()
extern void FontData_get_horizontalOverflow_mD9704C9760A72DF3123CD12CF2C801424B43F9B8 (void);
// 0x000000A7 System.Void UnityEngine.UI.FontData::set_horizontalOverflow(UnityEngine.HorizontalWrapMode)
extern void FontData_set_horizontalOverflow_m0BE81B30BED3A1B575BA3DCC5FDDAC7BDCC92B4B (void);
// 0x000000A8 UnityEngine.VerticalWrapMode UnityEngine.UI.FontData::get_verticalOverflow()
extern void FontData_get_verticalOverflow_m42B923B1137DAEA0D1846C81B659284A5B93D2F0 (void);
// 0x000000A9 System.Void UnityEngine.UI.FontData::set_verticalOverflow(UnityEngine.VerticalWrapMode)
extern void FontData_set_verticalOverflow_m4779DAE6C93E455842499EB2CA08BA5E59D7B68E (void);
// 0x000000AA System.Single UnityEngine.UI.FontData::get_lineSpacing()
extern void FontData_get_lineSpacing_m82401018033F25E3FA5623ED10AF9841FEABF71D (void);
// 0x000000AB System.Void UnityEngine.UI.FontData::set_lineSpacing(System.Single)
extern void FontData_set_lineSpacing_m035AE14D0ED7CA6022A28E886905297572A074AD (void);
// 0x000000AC System.Void UnityEngine.UI.FontData::UnityEngine.ISerializationCallbackReceiver.OnBeforeSerialize()
extern void FontData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m4A4A8DB0EB7A584EBBD00EA62FCA8029FAEDA475 (void);
// 0x000000AD System.Void UnityEngine.UI.FontData::UnityEngine.ISerializationCallbackReceiver.OnAfterDeserialize()
extern void FontData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_mF2B6D9180E6CAA5FC1AE9624C1A46877EC82EBC5 (void);
// 0x000000AE System.Void UnityEngine.UI.FontData::.ctor()
extern void FontData__ctor_m239C5208D7A9C11EF178B2C5400B9DD5671F98BE (void);
// 0x000000AF System.Void UnityEngine.UI.FontUpdateTracker::TrackText(UnityEngine.UI.Text)
extern void FontUpdateTracker_TrackText_m776156E82157345895376EBF8AE4E3EFB0C1C05C (void);
// 0x000000B0 System.Void UnityEngine.UI.FontUpdateTracker::RebuildForFont(UnityEngine.Font)
extern void FontUpdateTracker_RebuildForFont_m306DBA9E9C76DB32E297271E80C1BA1E828B9739 (void);
// 0x000000B1 System.Void UnityEngine.UI.FontUpdateTracker::UntrackText(UnityEngine.UI.Text)
extern void FontUpdateTracker_UntrackText_m97ABD557B35113C06A75DB24FBE91B0E247AC389 (void);
// 0x000000B2 System.Void UnityEngine.UI.FontUpdateTracker::.cctor()
extern void FontUpdateTracker__cctor_mE571B978C1362843C745826F1812DC32EED6E4FF (void);
// 0x000000B3 UnityEngine.Material UnityEngine.UI.Graphic::get_defaultGraphicMaterial()
extern void Graphic_get_defaultGraphicMaterial_m4CE20290CB9C10C4761280434B5C0DD703FAF5E9 (void);
// 0x000000B4 UnityEngine.Color UnityEngine.UI.Graphic::get_color()
extern void Graphic_get_color_m41096F123C41440AEBA4DFA9895C200D6A57E3BB (void);
// 0x000000B5 System.Void UnityEngine.UI.Graphic::set_color(UnityEngine.Color)
extern void Graphic_set_color_m71963C0A0B8A3BB3FD6D5FC2642C9637089478BC (void);
// 0x000000B6 System.Boolean UnityEngine.UI.Graphic::get_raycastTarget()
extern void Graphic_get_raycastTarget_mBC5D939562DDB05CEB992ED35D1A05FEDF05D9EB (void);
// 0x000000B7 System.Void UnityEngine.UI.Graphic::set_raycastTarget(System.Boolean)
extern void Graphic_set_raycastTarget_m713EA4933B2B56078033A25C2983F26D2147694E (void);
// 0x000000B8 System.Boolean UnityEngine.UI.Graphic::get_useLegacyMeshGeneration()
extern void Graphic_get_useLegacyMeshGeneration_mA54E7D6F19996CB7BCDF204AB7AD55073B8B0A11 (void);
// 0x000000B9 System.Void UnityEngine.UI.Graphic::set_useLegacyMeshGeneration(System.Boolean)
extern void Graphic_set_useLegacyMeshGeneration_m4C7B26FE354E1779C95E292C4446F6FF1D0398B8 (void);
// 0x000000BA System.Void UnityEngine.UI.Graphic::.ctor()
extern void Graphic__ctor_m262586AFB0BB8853AC7A4279B287733828881D77 (void);
// 0x000000BB System.Void UnityEngine.UI.Graphic::SetAllDirty()
extern void Graphic_SetAllDirty_mEFF3891228950806F6EA0CF37A3C19D14429412B (void);
// 0x000000BC System.Void UnityEngine.UI.Graphic::SetLayoutDirty()
extern void Graphic_SetLayoutDirty_mA05AE94955A2F3CBA01E4A8AB9BACAB4DCC102DC (void);
// 0x000000BD System.Void UnityEngine.UI.Graphic::SetVerticesDirty()
extern void Graphic_SetVerticesDirty_mBDCBB4E44DB03F2884478306C9FF03300A1BA438 (void);
// 0x000000BE System.Void UnityEngine.UI.Graphic::SetMaterialDirty()
extern void Graphic_SetMaterialDirty_m6D540F0423275B213FA2F4C63DEF2E3346884BF6 (void);
// 0x000000BF System.Void UnityEngine.UI.Graphic::OnRectTransformDimensionsChange()
extern void Graphic_OnRectTransformDimensionsChange_mC7D63E3E33151C9944DCFEAD3B16B6E872A28FC9 (void);
// 0x000000C0 System.Void UnityEngine.UI.Graphic::OnBeforeTransformParentChanged()
extern void Graphic_OnBeforeTransformParentChanged_m3709CA120490D6F743C4F5F1CCF6D35D37691349 (void);
// 0x000000C1 System.Void UnityEngine.UI.Graphic::OnTransformParentChanged()
extern void Graphic_OnTransformParentChanged_mED19B74977B75B60876BFDAD79B440FC8CE8733D (void);
// 0x000000C2 System.Int32 UnityEngine.UI.Graphic::get_depth()
extern void Graphic_get_depth_m9FDE7D38AD015374E84E4A0319309507B02C044F (void);
// 0x000000C3 UnityEngine.RectTransform UnityEngine.UI.Graphic::get_rectTransform()
extern void Graphic_get_rectTransform_m025371162D3A3FCD6D4692B43D0BD80602D0AFC4 (void);
// 0x000000C4 UnityEngine.Canvas UnityEngine.UI.Graphic::get_canvas()
extern void Graphic_get_canvas_mE278CED637619008522EF95A32071868DD6F028C (void);
// 0x000000C5 System.Void UnityEngine.UI.Graphic::CacheCanvas()
extern void Graphic_CacheCanvas_m61373C8047EBCD9C150E785F1AD5E58E71B82000 (void);
// 0x000000C6 UnityEngine.CanvasRenderer UnityEngine.UI.Graphic::get_canvasRenderer()
extern void Graphic_get_canvasRenderer_mB3E532BE19116A3F0D6ADC1CD29D242428EAE8AA (void);
// 0x000000C7 UnityEngine.Material UnityEngine.UI.Graphic::get_defaultMaterial()
extern void Graphic_get_defaultMaterial_m0A1AF379749391DF306119369BC47E422B7E5AA8 (void);
// 0x000000C8 UnityEngine.Material UnityEngine.UI.Graphic::get_material()
extern void Graphic_get_material_m009A329611244894C6F51FA7D72E7945074B1F66 (void);
// 0x000000C9 System.Void UnityEngine.UI.Graphic::set_material(UnityEngine.Material)
extern void Graphic_set_material_m4DC45A89DE40E6414FA349FC31957D9F8A69535E (void);
// 0x000000CA UnityEngine.Material UnityEngine.UI.Graphic::get_materialForRendering()
extern void Graphic_get_materialForRendering_m0FE5B8462BCE184C19D7C7991AB00733E499B168 (void);
// 0x000000CB UnityEngine.Texture UnityEngine.UI.Graphic::get_mainTexture()
extern void Graphic_get_mainTexture_m8ADD95545D4FAB8D218C028196DCB9758C47B3E5 (void);
// 0x000000CC System.Void UnityEngine.UI.Graphic::OnEnable()
extern void Graphic_OnEnable_m7882C581C61D2AC215A551E80CFC55EDFCAE2815 (void);
// 0x000000CD System.Void UnityEngine.UI.Graphic::OnDisable()
extern void Graphic_OnDisable_m7E1C19B12C0F40015B8CEBAE7858CC00292A94AE (void);
// 0x000000CE System.Void UnityEngine.UI.Graphic::OnDestroy()
extern void Graphic_OnDestroy_m269B2622D286DF6A08C3507A52A1ED97ECAF4159 (void);
// 0x000000CF System.Void UnityEngine.UI.Graphic::OnCanvasHierarchyChanged()
extern void Graphic_OnCanvasHierarchyChanged_m3B0022243DF53BB7C80573FCEB28305252A1EBEF (void);
// 0x000000D0 System.Void UnityEngine.UI.Graphic::OnCullingChanged()
extern void Graphic_OnCullingChanged_mD08B893C020E4FB67F825DD8B0CA2A870A5FB19F (void);
// 0x000000D1 System.Void UnityEngine.UI.Graphic::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Graphic_Rebuild_m691F66108929ADB2174644118215EFD7891E21A4 (void);
// 0x000000D2 System.Void UnityEngine.UI.Graphic::LayoutComplete()
extern void Graphic_LayoutComplete_mED506490B167B80D7225F1952B808B5DD6090317 (void);
// 0x000000D3 System.Void UnityEngine.UI.Graphic::GraphicUpdateComplete()
extern void Graphic_GraphicUpdateComplete_mF961E7FEB231A71A2E53C40C130DD18430B8AA12 (void);
// 0x000000D4 System.Void UnityEngine.UI.Graphic::UpdateMaterial()
extern void Graphic_UpdateMaterial_mBB750492DC6787FF92DB7EA1E15C7D74967C33E6 (void);
// 0x000000D5 System.Void UnityEngine.UI.Graphic::UpdateGeometry()
extern void Graphic_UpdateGeometry_m1EA57D6BB10A2ADD33BA385ACEDDAB205839853C (void);
// 0x000000D6 System.Void UnityEngine.UI.Graphic::DoMeshGeneration()
extern void Graphic_DoMeshGeneration_m7BF07EEAF0B97B4EB48DF41D55C52282C3F938B4 (void);
// 0x000000D7 System.Void UnityEngine.UI.Graphic::DoLegacyMeshGeneration()
extern void Graphic_DoLegacyMeshGeneration_m0209A9D02FEFA8BBBF0C403CB2F3FCC7D1C67196 (void);
// 0x000000D8 UnityEngine.Mesh UnityEngine.UI.Graphic::get_workerMesh()
extern void Graphic_get_workerMesh_m44288E0C1A3F7208C2F0C845C66D97CC243DA8F3 (void);
// 0x000000D9 System.Void UnityEngine.UI.Graphic::OnFillVBO(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void Graphic_OnFillVBO_m2F10FF0E7D1635058230F47F4C235F4D619D2210 (void);
// 0x000000DA System.Void UnityEngine.UI.Graphic::OnPopulateMesh(UnityEngine.Mesh)
extern void Graphic_OnPopulateMesh_m68CFA054D095A5A8526A37CB57E76149BC222F13 (void);
// 0x000000DB System.Void UnityEngine.UI.Graphic::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Graphic_OnPopulateMesh_m5FBF47A58773160BFAD6E08F11911ECBD25B49FE (void);
// 0x000000DC System.Void UnityEngine.UI.Graphic::OnDidApplyAnimationProperties()
extern void Graphic_OnDidApplyAnimationProperties_m183738197A547E50A740F2868A10E518D3855181 (void);
// 0x000000DD System.Void UnityEngine.UI.Graphic::SetNativeSize()
extern void Graphic_SetNativeSize_mF93C864996EC62D9531D332E79B6589705354846 (void);
// 0x000000DE System.Boolean UnityEngine.UI.Graphic::Raycast(UnityEngine.Vector2,UnityEngine.Camera)
extern void Graphic_Raycast_mB1E3E0D9B2C72901DB727DEA666C693330525F38 (void);
// 0x000000DF UnityEngine.Vector2 UnityEngine.UI.Graphic::PixelAdjustPoint(UnityEngine.Vector2)
extern void Graphic_PixelAdjustPoint_m6A06D04F7D6B6D946407ECBD984AB2E9B2EF2DCF (void);
// 0x000000E0 UnityEngine.Rect UnityEngine.UI.Graphic::GetPixelAdjustedRect()
extern void Graphic_GetPixelAdjustedRect_m324344D38946D6F976CD487B493B8D9787DE891B (void);
// 0x000000E1 System.Void UnityEngine.UI.Graphic::CrossFadeColor(UnityEngine.Color,System.Single,System.Boolean,System.Boolean)
extern void Graphic_CrossFadeColor_mCF4CE369216048F08E314393B53F6EC870E925E2 (void);
// 0x000000E2 System.Void UnityEngine.UI.Graphic::CrossFadeColor(UnityEngine.Color,System.Single,System.Boolean,System.Boolean,System.Boolean)
extern void Graphic_CrossFadeColor_m77BFABC485B2DDEBDC7EF44D8485032122D000DE (void);
// 0x000000E3 UnityEngine.Color UnityEngine.UI.Graphic::CreateColorFromAlpha(System.Single)
extern void Graphic_CreateColorFromAlpha_mE5F922504327278097F1D089BE82469FED89EF79 (void);
// 0x000000E4 System.Void UnityEngine.UI.Graphic::CrossFadeAlpha(System.Single,System.Single,System.Boolean)
extern void Graphic_CrossFadeAlpha_m00EA1A85E402BDD8F423ED453C3D0BB91F1DB7F2 (void);
// 0x000000E5 System.Void UnityEngine.UI.Graphic::RegisterDirtyLayoutCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyLayoutCallback_mE78A94DE6CFBC38EBE7F12E7D43E6AF1DEAA0910 (void);
// 0x000000E6 System.Void UnityEngine.UI.Graphic::UnregisterDirtyLayoutCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyLayoutCallback_m6200AE0A0119212754E6D42C4F5EA6B103767D66 (void);
// 0x000000E7 System.Void UnityEngine.UI.Graphic::RegisterDirtyVerticesCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyVerticesCallback_mFD6FB14CE29384C3FBC04E536EEF6AAC11A9D830 (void);
// 0x000000E8 System.Void UnityEngine.UI.Graphic::UnregisterDirtyVerticesCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyVerticesCallback_m0B6927F51F8CB55029D63C291CD3441187F23C15 (void);
// 0x000000E9 System.Void UnityEngine.UI.Graphic::RegisterDirtyMaterialCallback(UnityEngine.Events.UnityAction)
extern void Graphic_RegisterDirtyMaterialCallback_mE0A605A0AAAE76C1AA11E3CB16F01AB452D8C389 (void);
// 0x000000EA System.Void UnityEngine.UI.Graphic::UnregisterDirtyMaterialCallback(UnityEngine.Events.UnityAction)
extern void Graphic_UnregisterDirtyMaterialCallback_mD8CEC569308463DFE42C65DACF7AB42FDC3BDE2F (void);
// 0x000000EB System.Void UnityEngine.UI.Graphic::.cctor()
extern void Graphic__cctor_mAC1D29B9EC43A606C75C9D72D49CA11EF5CE8781 (void);
// 0x000000EC UnityEngine.Transform UnityEngine.UI.Graphic::UnityEngine.UI.ICanvasElement.get_transform()
extern void Graphic_UnityEngine_UI_ICanvasElement_get_transform_mCCB04E0F0F285EA97EDF6D033919593677F6A0DD (void);
// 0x000000ED System.Int32 UnityEngine.UI.GraphicRaycaster::get_sortOrderPriority()
extern void GraphicRaycaster_get_sortOrderPriority_m166C43A27A3C0AF761DED746D800560D01F5F608 (void);
// 0x000000EE System.Int32 UnityEngine.UI.GraphicRaycaster::get_renderOrderPriority()
extern void GraphicRaycaster_get_renderOrderPriority_mD247B2065095F9AA83C77AA744548BD44E1F8FFF (void);
// 0x000000EF System.Boolean UnityEngine.UI.GraphicRaycaster::get_ignoreReversedGraphics()
extern void GraphicRaycaster_get_ignoreReversedGraphics_m01C42ECDC73F4282FBC94416246B851E7F2CA45D (void);
// 0x000000F0 System.Void UnityEngine.UI.GraphicRaycaster::set_ignoreReversedGraphics(System.Boolean)
extern void GraphicRaycaster_set_ignoreReversedGraphics_m38DC6947B4DE23FFEC12E8B45DC15AE7AAE06533 (void);
// 0x000000F1 UnityEngine.UI.GraphicRaycaster/BlockingObjects UnityEngine.UI.GraphicRaycaster::get_blockingObjects()
extern void GraphicRaycaster_get_blockingObjects_m65760F738BEBB63000DD47E0E5E1FF8BA0AE49AF (void);
// 0x000000F2 System.Void UnityEngine.UI.GraphicRaycaster::set_blockingObjects(UnityEngine.UI.GraphicRaycaster/BlockingObjects)
extern void GraphicRaycaster_set_blockingObjects_m19ABE0A1C77456D6DA4E2FA33D21649273AFCCC4 (void);
// 0x000000F3 System.Void UnityEngine.UI.GraphicRaycaster::.ctor()
extern void GraphicRaycaster__ctor_mF6A9D603EA95EB8170A4E34A5EB5C93757B4014F (void);
// 0x000000F4 UnityEngine.Canvas UnityEngine.UI.GraphicRaycaster::get_canvas()
extern void GraphicRaycaster_get_canvas_m74BF579BA6B90DA2BB40CC35A4593891751D5CCA (void);
// 0x000000F5 System.Void UnityEngine.UI.GraphicRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void GraphicRaycaster_Raycast_m383268A8AB2D43501C7EB3F63759856325B108EB (void);
// 0x000000F6 UnityEngine.Camera UnityEngine.UI.GraphicRaycaster::get_eventCamera()
extern void GraphicRaycaster_get_eventCamera_m9A3A721CBF84A96629E4BC1733BBB6A45FF9059D (void);
// 0x000000F7 System.Void UnityEngine.UI.GraphicRaycaster::Raycast(UnityEngine.Canvas,UnityEngine.Camera,UnityEngine.Vector2,System.Collections.Generic.IList`1<UnityEngine.UI.Graphic>,System.Collections.Generic.List`1<UnityEngine.UI.Graphic>)
extern void GraphicRaycaster_Raycast_m552267A5FF8C7D636A1D94C8667F943B5B7DFEDF (void);
// 0x000000F8 System.Void UnityEngine.UI.GraphicRaycaster::.cctor()
extern void GraphicRaycaster__cctor_m284F55D2EB48C602FAA815235EED41A80A7828BB (void);
// 0x000000F9 System.Void UnityEngine.UI.GraphicRegistry::.ctor()
extern void GraphicRegistry__ctor_mAB3A1033E0246E6DD01A842A71A7E85DF199358B (void);
// 0x000000FA UnityEngine.UI.GraphicRegistry UnityEngine.UI.GraphicRegistry::get_instance()
extern void GraphicRegistry_get_instance_mC44355C0B339CE448FE227149CEE9E1469DEA198 (void);
// 0x000000FB System.Void UnityEngine.UI.GraphicRegistry::RegisterGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_RegisterGraphicForCanvas_mAE18F217BAC37B8BB219905B3BD0A3D891DD9C21 (void);
// 0x000000FC System.Void UnityEngine.UI.GraphicRegistry::UnregisterGraphicForCanvas(UnityEngine.Canvas,UnityEngine.UI.Graphic)
extern void GraphicRegistry_UnregisterGraphicForCanvas_mAEE5A2BF640ACA60440944931F48C515DEF91898 (void);
// 0x000000FD System.Collections.Generic.IList`1<UnityEngine.UI.Graphic> UnityEngine.UI.GraphicRegistry::GetGraphicsForCanvas(UnityEngine.Canvas)
extern void GraphicRegistry_GetGraphicsForCanvas_mAF4E2A47FE07E729F25D7324F46E8FB2E2785DB3 (void);
// 0x000000FE System.Void UnityEngine.UI.GraphicRegistry::.cctor()
extern void GraphicRegistry__cctor_m6E3EA95E443870B63C123D9BE7FCFDA764B79FF8 (void);
// 0x000000FF System.Void UnityEngine.UI.IGraphicEnabledDisabled::OnSiblingGraphicEnabledDisabled()
// 0x00000100 System.Boolean UnityEngine.UI.IMask::Enabled()
// 0x00000101 UnityEngine.RectTransform UnityEngine.UI.IMask::get_rectTransform()
// 0x00000102 System.Void UnityEngine.UI.IMaskable::RecalculateMasking()
// 0x00000103 UnityEngine.Sprite UnityEngine.UI.Image::get_sprite()
extern void Image_get_sprite_m642D753672A8CBCEB67950914B44EF34C62DD137 (void);
// 0x00000104 System.Void UnityEngine.UI.Image::set_sprite(UnityEngine.Sprite)
extern void Image_set_sprite_m77F8D681D4EE6D58F4F235AFF704C3EB165A9646 (void);
// 0x00000105 System.Void UnityEngine.UI.Image::DisableSpriteOptimizations()
extern void Image_DisableSpriteOptimizations_mF68C6A1BB8729F6F5CFF13D2320BD0A8F7ADBEBA (void);
// 0x00000106 UnityEngine.Sprite UnityEngine.UI.Image::get_overrideSprite()
extern void Image_get_overrideSprite_mE32E3D384CA6220B81702E9E3051FF83C4232FF0 (void);
// 0x00000107 System.Void UnityEngine.UI.Image::set_overrideSprite(UnityEngine.Sprite)
extern void Image_set_overrideSprite_m8714253751BEE8BE9A36E225D259BF68E88DE1A9 (void);
// 0x00000108 UnityEngine.Sprite UnityEngine.UI.Image::get_activeSprite()
extern void Image_get_activeSprite_mF8F075992BC21B86E47F76D5F8018524DA045A88 (void);
// 0x00000109 UnityEngine.UI.Image/Type UnityEngine.UI.Image::get_type()
extern void Image_get_type_mBF4695569A2C6FEBCDE60AB80A386F39D5708D6A (void);
// 0x0000010A System.Void UnityEngine.UI.Image::set_type(UnityEngine.UI.Image/Type)
extern void Image_set_type_mB5B2391926DA2F7326A98B2A847877C6CB8F0E2B (void);
// 0x0000010B System.Boolean UnityEngine.UI.Image::get_preserveAspect()
extern void Image_get_preserveAspect_m75FB3091416F2A7B02AE9FD88457FF5F18364BAF (void);
// 0x0000010C System.Void UnityEngine.UI.Image::set_preserveAspect(System.Boolean)
extern void Image_set_preserveAspect_m9019A1737AB408F545503F1B6A8ACE48F85D8668 (void);
// 0x0000010D System.Boolean UnityEngine.UI.Image::get_fillCenter()
extern void Image_get_fillCenter_mA68592BF9F9ABB0B9D0A7BBE87751D6353FEF16C (void);
// 0x0000010E System.Void UnityEngine.UI.Image::set_fillCenter(System.Boolean)
extern void Image_set_fillCenter_mB27E08D8E2CBAE31419006E77FAB76D535E3A750 (void);
// 0x0000010F UnityEngine.UI.Image/FillMethod UnityEngine.UI.Image::get_fillMethod()
extern void Image_get_fillMethod_m0F319641FE800193CB9FC939F4A4767D230D23F3 (void);
// 0x00000110 System.Void UnityEngine.UI.Image::set_fillMethod(UnityEngine.UI.Image/FillMethod)
extern void Image_set_fillMethod_mD7470E1F35FBF8B7A27A704C002969690B723A5F (void);
// 0x00000111 System.Single UnityEngine.UI.Image::get_fillAmount()
extern void Image_get_fillAmount_m5FF6EE8DB33C4A219B3677FB24F50A6E5CCF44F0 (void);
// 0x00000112 System.Void UnityEngine.UI.Image::set_fillAmount(System.Single)
extern void Image_set_fillAmount_m613B7AC920F2EA886AF0D931005C6CD13F89A160 (void);
// 0x00000113 System.Boolean UnityEngine.UI.Image::get_fillClockwise()
extern void Image_get_fillClockwise_mD0AB41F20B5AAD8775C944C752D45F7CEAABC1F3 (void);
// 0x00000114 System.Void UnityEngine.UI.Image::set_fillClockwise(System.Boolean)
extern void Image_set_fillClockwise_mDDF4F5499EE8DDB33855B9A6ECAC17D642F9CCDA (void);
// 0x00000115 System.Int32 UnityEngine.UI.Image::get_fillOrigin()
extern void Image_get_fillOrigin_m28266DE26D26E943BA893971EE1FB83132655920 (void);
// 0x00000116 System.Void UnityEngine.UI.Image::set_fillOrigin(System.Int32)
extern void Image_set_fillOrigin_m17D79352C290760B275F1B5A198F0CE5C1293E79 (void);
// 0x00000117 System.Single UnityEngine.UI.Image::get_eventAlphaThreshold()
extern void Image_get_eventAlphaThreshold_m1286AAA5CE0BBE17E125DD5FE02139649F0369D4 (void);
// 0x00000118 System.Void UnityEngine.UI.Image::set_eventAlphaThreshold(System.Single)
extern void Image_set_eventAlphaThreshold_m1EB7D592AA13B9BEEACA3C2FC6DF97159282D071 (void);
// 0x00000119 System.Single UnityEngine.UI.Image::get_alphaHitTestMinimumThreshold()
extern void Image_get_alphaHitTestMinimumThreshold_mA90C5ADE6E119ADF2B483F8239A1C66C3A2E3E2E (void);
// 0x0000011A System.Void UnityEngine.UI.Image::set_alphaHitTestMinimumThreshold(System.Single)
extern void Image_set_alphaHitTestMinimumThreshold_mBF21EA4ECF7EF080B7CF64C2D2DBA98C4BDE360C (void);
// 0x0000011B System.Boolean UnityEngine.UI.Image::get_useSpriteMesh()
extern void Image_get_useSpriteMesh_m36A6D1A2FF7C0DFCA3E0AE2DA79FA339335BDA55 (void);
// 0x0000011C System.Void UnityEngine.UI.Image::set_useSpriteMesh(System.Boolean)
extern void Image_set_useSpriteMesh_m1B7EB82514B9F94A94D45E2654327F235C8EF58E (void);
// 0x0000011D System.Void UnityEngine.UI.Image::.ctor()
extern void Image__ctor_m107392C55619451EAF98F5CF71E6449E8E2AF1D7 (void);
// 0x0000011E UnityEngine.Material UnityEngine.UI.Image::get_defaultETC1GraphicMaterial()
extern void Image_get_defaultETC1GraphicMaterial_m471CA72CC6141A7F71D521C366E04D728F0F66A0 (void);
// 0x0000011F UnityEngine.Texture UnityEngine.UI.Image::get_mainTexture()
extern void Image_get_mainTexture_mB257690C040998ECFC1BE091374B54B181823D27 (void);
// 0x00000120 System.Boolean UnityEngine.UI.Image::get_hasBorder()
extern void Image_get_hasBorder_m5633A7D963D07F709BC44C45499EAC2B91996BF8 (void);
// 0x00000121 System.Single UnityEngine.UI.Image::get_pixelsPerUnitMultiplier()
extern void Image_get_pixelsPerUnitMultiplier_mC9DC2AFDADC2CF3B81BE6913661216D958D72153 (void);
// 0x00000122 System.Void UnityEngine.UI.Image::set_pixelsPerUnitMultiplier(System.Single)
extern void Image_set_pixelsPerUnitMultiplier_m8775619FBA98B1E657A2421CBDD707CCB58A7C75 (void);
// 0x00000123 System.Single UnityEngine.UI.Image::get_pixelsPerUnit()
extern void Image_get_pixelsPerUnit_m4E763A10D3BA64B0AA5CE0474A42A6B8B4C0F990 (void);
// 0x00000124 System.Single UnityEngine.UI.Image::get_multipliedPixelsPerUnit()
extern void Image_get_multipliedPixelsPerUnit_m336435DCB82AA41DA8C79AC24F3102D90CD92A28 (void);
// 0x00000125 UnityEngine.Material UnityEngine.UI.Image::get_material()
extern void Image_get_material_m75690B58C80538290BEECC5E1D145FB19158ACCA (void);
// 0x00000126 System.Void UnityEngine.UI.Image::set_material(UnityEngine.Material)
extern void Image_set_material_m972B05F260CCA585187416B416F6BE227589C6DE (void);
// 0x00000127 System.Void UnityEngine.UI.Image::OnBeforeSerialize()
extern void Image_OnBeforeSerialize_m2C27418FB79FF38445F2B998BC6027990FAB1AE3 (void);
// 0x00000128 System.Void UnityEngine.UI.Image::OnAfterDeserialize()
extern void Image_OnAfterDeserialize_m3A6ECD0D548C102C460D0FC63E885791781AD35B (void);
// 0x00000129 System.Void UnityEngine.UI.Image::PreserveSpriteAspectRatio(UnityEngine.Rect&,UnityEngine.Vector2)
extern void Image_PreserveSpriteAspectRatio_mBC0E31CEB88E7C6BE29234193B954ABD84A48F1C (void);
// 0x0000012A UnityEngine.Vector4 UnityEngine.UI.Image::GetDrawingDimensions(System.Boolean)
extern void Image_GetDrawingDimensions_mC16B4DC39F042073D15F8A98D8B1594C70BD27A8 (void);
// 0x0000012B System.Void UnityEngine.UI.Image::SetNativeSize()
extern void Image_SetNativeSize_m226D9782963DE3740563978C9CEF135D3724BAA5 (void);
// 0x0000012C System.Void UnityEngine.UI.Image::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Image_OnPopulateMesh_m9CAE895CE1CCF9E950684C0EC9A7036A1AF735CF (void);
// 0x0000012D System.Void UnityEngine.UI.Image::TrackSprite()
extern void Image_TrackSprite_m97B866E177E385BA1E4651B934FFE35552B8AC71 (void);
// 0x0000012E System.Void UnityEngine.UI.Image::OnEnable()
extern void Image_OnEnable_m33696C9050F3C0686FBCD9C79E7B77C5828A4881 (void);
// 0x0000012F System.Void UnityEngine.UI.Image::OnDisable()
extern void Image_OnDisable_m1BB9055E8C7EE894D196761AEAB37E321A3766B2 (void);
// 0x00000130 System.Void UnityEngine.UI.Image::UpdateMaterial()
extern void Image_UpdateMaterial_m546E64701AE4B936C898238357945BFFCE6D290C (void);
// 0x00000131 System.Void UnityEngine.UI.Image::OnCanvasHierarchyChanged()
extern void Image_OnCanvasHierarchyChanged_m1B834FEE18F11EEEB71E30FD8B6E4D3B6FE767DD (void);
// 0x00000132 System.Void UnityEngine.UI.Image::GenerateSimpleSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateSimpleSprite_m7076714628A1AFC168192050332FF5DD6BB2E16F (void);
// 0x00000133 System.Void UnityEngine.UI.Image::GenerateSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateSprite_mAB424DB0484CD040E0A3B5E061306FF2F8831C7D (void);
// 0x00000134 System.Void UnityEngine.UI.Image::GenerateSlicedSprite(UnityEngine.UI.VertexHelper)
extern void Image_GenerateSlicedSprite_m921AE8C58315EEEC06A6C9412A7056166B1FF4ED (void);
// 0x00000135 System.Void UnityEngine.UI.Image::GenerateTiledSprite(UnityEngine.UI.VertexHelper)
extern void Image_GenerateTiledSprite_mEDC93862A3A37EBF5D425E27DF9B3D3A6D31BB6C (void);
// 0x00000136 System.Void UnityEngine.UI.Image::AddQuad(UnityEngine.UI.VertexHelper,UnityEngine.Vector3[],UnityEngine.Color32,UnityEngine.Vector3[])
extern void Image_AddQuad_m9AC07E2C127F3195B0E6E3EA47CDF71A62016AC5 (void);
// 0x00000137 System.Void UnityEngine.UI.Image::AddQuad(UnityEngine.UI.VertexHelper,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Color32,UnityEngine.Vector2,UnityEngine.Vector2)
extern void Image_AddQuad_m52DD32636BA84FA0BF9D2420FD70A85BEB2843F0 (void);
// 0x00000138 UnityEngine.Vector4 UnityEngine.UI.Image::GetAdjustedBorders(UnityEngine.Vector4,UnityEngine.Rect)
extern void Image_GetAdjustedBorders_mCF8A75527B652B1EE38AA901633CB4ECAD52AB89 (void);
// 0x00000139 System.Void UnityEngine.UI.Image::GenerateFilledSprite(UnityEngine.UI.VertexHelper,System.Boolean)
extern void Image_GenerateFilledSprite_mB5C23FAF9510592B583DB495396E710242848093 (void);
// 0x0000013A System.Boolean UnityEngine.UI.Image::RadialCut(UnityEngine.Vector3[],UnityEngine.Vector3[],System.Single,System.Boolean,System.Int32)
extern void Image_RadialCut_m80B9F9BADD0E0808A1761C794BD56649B64FD7FC (void);
// 0x0000013B System.Void UnityEngine.UI.Image::RadialCut(UnityEngine.Vector3[],System.Single,System.Single,System.Boolean,System.Int32)
extern void Image_RadialCut_mAA0ABBAEF18371501B3A6BAD624CA32949F485E9 (void);
// 0x0000013C System.Void UnityEngine.UI.Image::CalculateLayoutInputHorizontal()
extern void Image_CalculateLayoutInputHorizontal_m8BB12172013052DA3440EFF710A429C8BF2BFEC9 (void);
// 0x0000013D System.Void UnityEngine.UI.Image::CalculateLayoutInputVertical()
extern void Image_CalculateLayoutInputVertical_m3E85E197B85895E6248FE25BE4D65E4FD507E8A5 (void);
// 0x0000013E System.Single UnityEngine.UI.Image::get_minWidth()
extern void Image_get_minWidth_m5DF43F172E23E902CABB2D69FB67F5D6CB241317 (void);
// 0x0000013F System.Single UnityEngine.UI.Image::get_preferredWidth()
extern void Image_get_preferredWidth_m489AFD0929A50D0A681F828115FF6A0FBBAE17AD (void);
// 0x00000140 System.Single UnityEngine.UI.Image::get_flexibleWidth()
extern void Image_get_flexibleWidth_mEC388A0703E9F11DBE52E0824FF2E8B9DADB4B7D (void);
// 0x00000141 System.Single UnityEngine.UI.Image::get_minHeight()
extern void Image_get_minHeight_m7CD99A4954247FDDA404AD53732F9787C46B12EC (void);
// 0x00000142 System.Single UnityEngine.UI.Image::get_preferredHeight()
extern void Image_get_preferredHeight_m1840628A58BD9839D18E389342223101345E3334 (void);
// 0x00000143 System.Single UnityEngine.UI.Image::get_flexibleHeight()
extern void Image_get_flexibleHeight_m784DE68069CA731F4D134A6DB88E2E9B87415C8F (void);
// 0x00000144 System.Int32 UnityEngine.UI.Image::get_layoutPriority()
extern void Image_get_layoutPriority_mE1DA3C23A995D1644C9E32E6D4D6F5B343CE9C89 (void);
// 0x00000145 System.Boolean UnityEngine.UI.Image::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void Image_IsRaycastLocationValid_m160CE24D1C865615BF6020950EACD52306D1A0DD (void);
// 0x00000146 UnityEngine.Vector2 UnityEngine.UI.Image::MapCoordinate(UnityEngine.Vector2,UnityEngine.Rect)
extern void Image_MapCoordinate_m90184DC8DE94E172E71287F95A400EE4C5EF464C (void);
// 0x00000147 System.Void UnityEngine.UI.Image::RebuildImage(UnityEngine.U2D.SpriteAtlas)
extern void Image_RebuildImage_m1C0BD1F567C7F1616033BAAFDF36CD90D12B6E4E (void);
// 0x00000148 System.Void UnityEngine.UI.Image::TrackImage(UnityEngine.UI.Image)
extern void Image_TrackImage_mF542664453B48FAA6BA7656FF4B776596493F43C (void);
// 0x00000149 System.Void UnityEngine.UI.Image::UnTrackImage(UnityEngine.UI.Image)
extern void Image_UnTrackImage_mADD4B39F262A992CCDE99E7668504F4A963E6769 (void);
// 0x0000014A System.Void UnityEngine.UI.Image::OnDidApplyAnimationProperties()
extern void Image_OnDidApplyAnimationProperties_m0638444390B79CB555DB3D0A32EB81FD4255EE6C (void);
// 0x0000014B System.Void UnityEngine.UI.Image::.cctor()
extern void Image__cctor_m8A33A91F993F21D61579B9096ECCBFB8AE85AD1B (void);
// 0x0000014C UnityEngine.EventSystems.BaseInput UnityEngine.UI.InputField::get_input()
extern void InputField_get_input_mAF4210F766099F23FA8695F12CA970CC8E5CA80A (void);
// 0x0000014D System.String UnityEngine.UI.InputField::get_compositionString()
extern void InputField_get_compositionString_m023139DE6EF012E022F61934667F47505DC0C767 (void);
// 0x0000014E System.Void UnityEngine.UI.InputField::.ctor()
extern void InputField__ctor_m092A4C9CFF5530E3091767467F078A79FDFC33D5 (void);
// 0x0000014F UnityEngine.Mesh UnityEngine.UI.InputField::get_mesh()
extern void InputField_get_mesh_m6546FECF63F4A23B1A3C8B58B0BFE294106BAE7A (void);
// 0x00000150 UnityEngine.TextGenerator UnityEngine.UI.InputField::get_cachedInputTextGenerator()
extern void InputField_get_cachedInputTextGenerator_m6E2FFA43D0AE993D930B4763184F248AE1915CA0 (void);
// 0x00000151 System.Void UnityEngine.UI.InputField::set_shouldHideMobileInput(System.Boolean)
extern void InputField_set_shouldHideMobileInput_m9F2CAA3714EFEA7137E7B88589BE987B2104E594 (void);
// 0x00000152 System.Boolean UnityEngine.UI.InputField::get_shouldHideMobileInput()
extern void InputField_get_shouldHideMobileInput_m0187F216F281D2CF39293E56F46E408C894BA4B9 (void);
// 0x00000153 System.Void UnityEngine.UI.InputField::set_shouldActivateOnSelect(System.Boolean)
extern void InputField_set_shouldActivateOnSelect_m9B19AA526E57756B3B2E25F1D5469062AA0089C9 (void);
// 0x00000154 System.Boolean UnityEngine.UI.InputField::get_shouldActivateOnSelect()
extern void InputField_get_shouldActivateOnSelect_mC1914B9D456B836B094A8C2ADBD47962D257F229 (void);
// 0x00000155 System.String UnityEngine.UI.InputField::get_text()
extern void InputField_get_text_m5FA1E757563597DE4B57559A9E68D645FF2CC461 (void);
// 0x00000156 System.Void UnityEngine.UI.InputField::set_text(System.String)
extern void InputField_set_text_m172924B88B50056001C94A68403D06B8A3922602 (void);
// 0x00000157 System.Void UnityEngine.UI.InputField::SetTextWithoutNotify(System.String)
extern void InputField_SetTextWithoutNotify_mF83F442F931F51BB4D2DC44E10AD6D868C4751C4 (void);
// 0x00000158 System.Void UnityEngine.UI.InputField::SetText(System.String,System.Boolean)
extern void InputField_SetText_mF04EC7C40C0A5CF1B305173F8879A7C977D733C1 (void);
// 0x00000159 System.Boolean UnityEngine.UI.InputField::get_isFocused()
extern void InputField_get_isFocused_m96F65188C4517CE6F2A818F717CE23BD565E43A2 (void);
// 0x0000015A System.Single UnityEngine.UI.InputField::get_caretBlinkRate()
extern void InputField_get_caretBlinkRate_m90B21829D909134FE51C38B3DFC44369504B1DAC (void);
// 0x0000015B System.Void UnityEngine.UI.InputField::set_caretBlinkRate(System.Single)
extern void InputField_set_caretBlinkRate_m294E75C38336F482E6F5577ABF08CA77D58D7C6E (void);
// 0x0000015C System.Int32 UnityEngine.UI.InputField::get_caretWidth()
extern void InputField_get_caretWidth_m3F8ADE9650CAF8E2DAA3859CA79BB78B832A0076 (void);
// 0x0000015D System.Void UnityEngine.UI.InputField::set_caretWidth(System.Int32)
extern void InputField_set_caretWidth_mF41505CA56ED0518E2E64CF5D6806896D97A13E2 (void);
// 0x0000015E UnityEngine.UI.Text UnityEngine.UI.InputField::get_textComponent()
extern void InputField_get_textComponent_mC1FC063C41D84947A3B0BE349C6E937EDF0EB19E (void);
// 0x0000015F System.Void UnityEngine.UI.InputField::set_textComponent(UnityEngine.UI.Text)
extern void InputField_set_textComponent_m6706EFF9E1F112E923041792E86515FB0E9A0661 (void);
// 0x00000160 UnityEngine.UI.Graphic UnityEngine.UI.InputField::get_placeholder()
extern void InputField_get_placeholder_mBDB090222F665AE8A1C96F1F375732346F177EEB (void);
// 0x00000161 System.Void UnityEngine.UI.InputField::set_placeholder(UnityEngine.UI.Graphic)
extern void InputField_set_placeholder_m1DBBD3A9F82F0660B33CE7B08CE62BD2CCA5E859 (void);
// 0x00000162 UnityEngine.Color UnityEngine.UI.InputField::get_caretColor()
extern void InputField_get_caretColor_m9CC9FE92EE010A1F980A2838A41B4C081D2FDA3A (void);
// 0x00000163 System.Void UnityEngine.UI.InputField::set_caretColor(UnityEngine.Color)
extern void InputField_set_caretColor_mA948529F9562298217DED4DEB399D203300E3723 (void);
// 0x00000164 System.Boolean UnityEngine.UI.InputField::get_customCaretColor()
extern void InputField_get_customCaretColor_m2A443DD5624262216DCF1E2E71D07F36E176C69D (void);
// 0x00000165 System.Void UnityEngine.UI.InputField::set_customCaretColor(System.Boolean)
extern void InputField_set_customCaretColor_mCE05E6BA5569DDC65984F569E5495C8204BA1A1B (void);
// 0x00000166 UnityEngine.Color UnityEngine.UI.InputField::get_selectionColor()
extern void InputField_get_selectionColor_mA49DCB951B526D232C0E090783433304261D4D1C (void);
// 0x00000167 System.Void UnityEngine.UI.InputField::set_selectionColor(UnityEngine.Color)
extern void InputField_set_selectionColor_mB4D275506E3BF3962B0F6470F8F1C84DFE526CF6 (void);
// 0x00000168 UnityEngine.UI.InputField/SubmitEvent UnityEngine.UI.InputField::get_onEndEdit()
extern void InputField_get_onEndEdit_m912D9CA48D579EE1A68544EA58EF5EEB633148C1 (void);
// 0x00000169 System.Void UnityEngine.UI.InputField::set_onEndEdit(UnityEngine.UI.InputField/SubmitEvent)
extern void InputField_set_onEndEdit_m7F8734F533100D371BC3980661A3021D86A0C49B (void);
// 0x0000016A UnityEngine.UI.InputField/OnChangeEvent UnityEngine.UI.InputField::get_onValueChange()
extern void InputField_get_onValueChange_mC6364A9208DD2811E7DFF5F0A1225246A278BCD7 (void);
// 0x0000016B System.Void UnityEngine.UI.InputField::set_onValueChange(UnityEngine.UI.InputField/OnChangeEvent)
extern void InputField_set_onValueChange_mA6AA9EF96B0AC2DF68CFC4827B1FC4CE03D98B0E (void);
// 0x0000016C UnityEngine.UI.InputField/OnChangeEvent UnityEngine.UI.InputField::get_onValueChanged()
extern void InputField_get_onValueChanged_m1AE46D57FF8D96F53F2039722DE9CDDB6AB58CA1 (void);
// 0x0000016D System.Void UnityEngine.UI.InputField::set_onValueChanged(UnityEngine.UI.InputField/OnChangeEvent)
extern void InputField_set_onValueChanged_m140035DE99534F06D4E02DF2C9ED8ACE7DE471BB (void);
// 0x0000016E UnityEngine.UI.InputField/OnValidateInput UnityEngine.UI.InputField::get_onValidateInput()
extern void InputField_get_onValidateInput_mCF04910E2F6920903CD095B86C1D61DA4C01B553 (void);
// 0x0000016F System.Void UnityEngine.UI.InputField::set_onValidateInput(UnityEngine.UI.InputField/OnValidateInput)
extern void InputField_set_onValidateInput_m3CA787E084564B5313C29B41A3C8F660CBB0ABD0 (void);
// 0x00000170 System.Int32 UnityEngine.UI.InputField::get_characterLimit()
extern void InputField_get_characterLimit_mA047A0B080E33B75C9F6F10E4344D3E00BB82832 (void);
// 0x00000171 System.Void UnityEngine.UI.InputField::set_characterLimit(System.Int32)
extern void InputField_set_characterLimit_m9D5AB377A2B229A6909D55B5BBC4BD50EE3C8E25 (void);
// 0x00000172 UnityEngine.UI.InputField/ContentType UnityEngine.UI.InputField::get_contentType()
extern void InputField_get_contentType_mBDEC121EFB7451BE3F56D8A2F68BF78FC28D2329 (void);
// 0x00000173 System.Void UnityEngine.UI.InputField::set_contentType(UnityEngine.UI.InputField/ContentType)
extern void InputField_set_contentType_m9A0923CA1A61F3A401DD81C3FFA95199AD928392 (void);
// 0x00000174 UnityEngine.UI.InputField/LineType UnityEngine.UI.InputField::get_lineType()
extern void InputField_get_lineType_mAFC713A8DC2FABB2FFC6902A767DAE2932A5BDBE (void);
// 0x00000175 System.Void UnityEngine.UI.InputField::set_lineType(UnityEngine.UI.InputField/LineType)
extern void InputField_set_lineType_m134CFEC1C04BC47E15A9B4748A5A9AE7CF7FAC2A (void);
// 0x00000176 UnityEngine.UI.InputField/InputType UnityEngine.UI.InputField::get_inputType()
extern void InputField_get_inputType_m1B9C2C98A32BBD27759C950DC4C65F0FD69329CF (void);
// 0x00000177 System.Void UnityEngine.UI.InputField::set_inputType(UnityEngine.UI.InputField/InputType)
extern void InputField_set_inputType_m5EDCC3EF52E67D192DFF47907CB8794E6D6A7C49 (void);
// 0x00000178 UnityEngine.TouchScreenKeyboard UnityEngine.UI.InputField::get_touchScreenKeyboard()
extern void InputField_get_touchScreenKeyboard_m6C45EACFFF50802976ADF0025CEAE8741153CB1E (void);
// 0x00000179 UnityEngine.TouchScreenKeyboardType UnityEngine.UI.InputField::get_keyboardType()
extern void InputField_get_keyboardType_m9837579BEE93CA6EEA8314AF9CE3074F39D8E661 (void);
// 0x0000017A System.Void UnityEngine.UI.InputField::set_keyboardType(UnityEngine.TouchScreenKeyboardType)
extern void InputField_set_keyboardType_mB1C977510496B883E5FB0ED519577B624963C0B0 (void);
// 0x0000017B UnityEngine.UI.InputField/CharacterValidation UnityEngine.UI.InputField::get_characterValidation()
extern void InputField_get_characterValidation_m3BA91CE0FC3845B40E1D43D6F0E36C5DB1D3EC29 (void);
// 0x0000017C System.Void UnityEngine.UI.InputField::set_characterValidation(UnityEngine.UI.InputField/CharacterValidation)
extern void InputField_set_characterValidation_m9337FC9604B586365B61B96A673FA0C2F6A4F336 (void);
// 0x0000017D System.Boolean UnityEngine.UI.InputField::get_readOnly()
extern void InputField_get_readOnly_m88449A161BC0C32E5DB56D6043E8BF09E41AF879 (void);
// 0x0000017E System.Void UnityEngine.UI.InputField::set_readOnly(System.Boolean)
extern void InputField_set_readOnly_m4ACF8C2FE1C219DA88F776CF1697EE4BBD99938D (void);
// 0x0000017F System.Boolean UnityEngine.UI.InputField::get_multiLine()
extern void InputField_get_multiLine_mE74D2E2E2B1B715CF8F2DDD068AA3E7CB270A6FF (void);
// 0x00000180 System.Char UnityEngine.UI.InputField::get_asteriskChar()
extern void InputField_get_asteriskChar_mAECFBAC3E3B2455CFF6FCDA2C1278B5F604975BC (void);
// 0x00000181 System.Void UnityEngine.UI.InputField::set_asteriskChar(System.Char)
extern void InputField_set_asteriskChar_m86FC12F2F6BFBBE4124C1B9C7579C894696E0FEB (void);
// 0x00000182 System.Boolean UnityEngine.UI.InputField::get_wasCanceled()
extern void InputField_get_wasCanceled_m7264DBE00BEAF36F065295F2FBC50B8566BE0371 (void);
// 0x00000183 System.Void UnityEngine.UI.InputField::ClampPos(System.Int32&)
extern void InputField_ClampPos_m689A5F00064B74687B8239042F9B68F1F849BFA9 (void);
// 0x00000184 System.Int32 UnityEngine.UI.InputField::get_caretPositionInternal()
extern void InputField_get_caretPositionInternal_mEC8598C831864F6A91793DB28C771D209A424D20 (void);
// 0x00000185 System.Void UnityEngine.UI.InputField::set_caretPositionInternal(System.Int32)
extern void InputField_set_caretPositionInternal_mE4B5E92558EE35A7FAF16AA47BC251A82457E9E6 (void);
// 0x00000186 System.Int32 UnityEngine.UI.InputField::get_caretSelectPositionInternal()
extern void InputField_get_caretSelectPositionInternal_mB352D3D787F61AE057ADF532829E4611D6653535 (void);
// 0x00000187 System.Void UnityEngine.UI.InputField::set_caretSelectPositionInternal(System.Int32)
extern void InputField_set_caretSelectPositionInternal_m6798CB1CBC2B865DCAE6F34E86DD2BAA5E342865 (void);
// 0x00000188 System.Boolean UnityEngine.UI.InputField::get_hasSelection()
extern void InputField_get_hasSelection_m6F4401A7C105A9F98CB30CC20701D32EADDD065D (void);
// 0x00000189 System.Int32 UnityEngine.UI.InputField::get_caretPosition()
extern void InputField_get_caretPosition_m469B2760743F458AC3E0572D3BC2AAB527FFB83F (void);
// 0x0000018A System.Void UnityEngine.UI.InputField::set_caretPosition(System.Int32)
extern void InputField_set_caretPosition_mF3087396BFF28DD18DDF4748CBB63FE612A79D3E (void);
// 0x0000018B System.Int32 UnityEngine.UI.InputField::get_selectionAnchorPosition()
extern void InputField_get_selectionAnchorPosition_m97767BE40A46C125D9870756E4811C96D5A69ED2 (void);
// 0x0000018C System.Void UnityEngine.UI.InputField::set_selectionAnchorPosition(System.Int32)
extern void InputField_set_selectionAnchorPosition_mEBBF06150FAD599FBA198DE2DDDA16A4458BD690 (void);
// 0x0000018D System.Int32 UnityEngine.UI.InputField::get_selectionFocusPosition()
extern void InputField_get_selectionFocusPosition_m857CA86FB5E4E5CAC82D2470C25EB2DB956B6F83 (void);
// 0x0000018E System.Void UnityEngine.UI.InputField::set_selectionFocusPosition(System.Int32)
extern void InputField_set_selectionFocusPosition_mA955354B576532237D0613025B962A4E901AADAF (void);
// 0x0000018F System.Void UnityEngine.UI.InputField::OnEnable()
extern void InputField_OnEnable_mBC45E0F8CB32D800C14DFDDE11C54E50E7104CCA (void);
// 0x00000190 System.Void UnityEngine.UI.InputField::OnDisable()
extern void InputField_OnDisable_mBF996F6B4C54639764A5F820FBEB190CAEBB268E (void);
// 0x00000191 System.Collections.IEnumerator UnityEngine.UI.InputField::CaretBlink()
extern void InputField_CaretBlink_mB6FA4368435DD2EA04B11D65DD56952C7A5D6E9F (void);
// 0x00000192 System.Void UnityEngine.UI.InputField::SetCaretVisible()
extern void InputField_SetCaretVisible_m0A6E0FEC73CA9ECABDB88B7A661A981C89EFD1B1 (void);
// 0x00000193 System.Void UnityEngine.UI.InputField::SetCaretActive()
extern void InputField_SetCaretActive_m068E9440B67305ADFAA15948398C98BB0CABAC0D (void);
// 0x00000194 System.Void UnityEngine.UI.InputField::UpdateCaretMaterial()
extern void InputField_UpdateCaretMaterial_m4282444657DE957E095074C778C0DCDDBEF889EC (void);
// 0x00000195 System.Void UnityEngine.UI.InputField::OnFocus()
extern void InputField_OnFocus_m7E5AE4E065E548BA17D615864A50467DABE4AD3E (void);
// 0x00000196 System.Void UnityEngine.UI.InputField::SelectAll()
extern void InputField_SelectAll_m624A39430E584572EC6FF74DDFA7B5CE30291B5B (void);
// 0x00000197 System.Void UnityEngine.UI.InputField::MoveTextEnd(System.Boolean)
extern void InputField_MoveTextEnd_mB10C0A3193CC68DED56B462D94A2F87DC5B1E199 (void);
// 0x00000198 System.Void UnityEngine.UI.InputField::MoveTextStart(System.Boolean)
extern void InputField_MoveTextStart_m7EE5E3C883FDF3DE228133D18E02DC5BCA75613D (void);
// 0x00000199 System.String UnityEngine.UI.InputField::get_clipboard()
extern void InputField_get_clipboard_mC542B7C4955906AD2FBA0A67F2731F2F83DBF18B (void);
// 0x0000019A System.Void UnityEngine.UI.InputField::set_clipboard(System.String)
extern void InputField_set_clipboard_m4688C2642B87778FE818C27FABEEA887B206A99E (void);
// 0x0000019B System.Boolean UnityEngine.UI.InputField::InPlaceEditing()
extern void InputField_InPlaceEditing_m09B0693FF30033E3A32E2B1DAF56A689F5ACE87D (void);
// 0x0000019C System.Void UnityEngine.UI.InputField::UpdateCaretFromKeyboard()
extern void InputField_UpdateCaretFromKeyboard_m2182C0A903DD164C19F68CD790B142179B61295C (void);
// 0x0000019D System.Void UnityEngine.UI.InputField::LateUpdate()
extern void InputField_LateUpdate_m927226704A65F0D5917161263D51673D1CEADF3E (void);
// 0x0000019E UnityEngine.Vector2 UnityEngine.UI.InputField::ScreenToLocal(UnityEngine.Vector2)
extern void InputField_ScreenToLocal_m4B659514B174BA0738ECB4D1D6BE5DCB9A75665D (void);
// 0x0000019F System.Int32 UnityEngine.UI.InputField::GetUnclampedCharacterLineFromPosition(UnityEngine.Vector2,UnityEngine.TextGenerator)
extern void InputField_GetUnclampedCharacterLineFromPosition_m4B258917A2B47C3D458F1444405C44B4BFF54C3D (void);
// 0x000001A0 System.Int32 UnityEngine.UI.InputField::GetCharacterIndexFromPosition(UnityEngine.Vector2)
extern void InputField_GetCharacterIndexFromPosition_mC1C7C2FF61BCDEB174078C8C0A14DDB52856C594 (void);
// 0x000001A1 System.Boolean UnityEngine.UI.InputField::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_MayDrag_m6263CAC380EDE95E47E4DDF90FE26E9124C57551 (void);
// 0x000001A2 System.Void UnityEngine.UI.InputField::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnBeginDrag_m1F28DFB7583238E43B92E7AD5289DECD1C5A1A02 (void);
// 0x000001A3 System.Void UnityEngine.UI.InputField::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnDrag_m5CF3D5BD094B3CE1B50CA1A1205E21BEBEAA7CFB (void);
// 0x000001A4 System.Collections.IEnumerator UnityEngine.UI.InputField::MouseDragOutsideRect(UnityEngine.EventSystems.PointerEventData)
extern void InputField_MouseDragOutsideRect_m1562ADF5A78C0E7DC6CD4A59A85D07CD5B730BF9 (void);
// 0x000001A5 System.Void UnityEngine.UI.InputField::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnEndDrag_mDB2BBF4256853A7D9B4AAFB37E18BBFADC276D6D (void);
// 0x000001A6 System.Void UnityEngine.UI.InputField::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnPointerDown_mB8464546C064051BA93907C26B0DDCD78D5EE270 (void);
// 0x000001A7 UnityEngine.UI.InputField/EditState UnityEngine.UI.InputField::KeyPressed(UnityEngine.Event)
extern void InputField_KeyPressed_mEA9D60091DBDFCC1F62B626C119A1618DB2395E4 (void);
// 0x000001A8 System.Boolean UnityEngine.UI.InputField::IsValidChar(System.Char)
extern void InputField_IsValidChar_m838CF42058EEF5524DD8A21D850032713A1BCB79 (void);
// 0x000001A9 System.Void UnityEngine.UI.InputField::ProcessEvent(UnityEngine.Event)
extern void InputField_ProcessEvent_m8857A03013CDF861BFA943227EE6FC50E22ABEEE (void);
// 0x000001AA System.Void UnityEngine.UI.InputField::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnUpdateSelected_m2BE044B17738BCF0BE2B0CB2913D2488A722D965 (void);
// 0x000001AB System.String UnityEngine.UI.InputField::GetSelectedString()
extern void InputField_GetSelectedString_mA40FFB2E340E8329F265BA04BEA4308290351691 (void);
// 0x000001AC System.Int32 UnityEngine.UI.InputField::FindtNextWordBegin()
extern void InputField_FindtNextWordBegin_m20A12396AC506CE580C1D76907E9DD4DB418724F (void);
// 0x000001AD System.Void UnityEngine.UI.InputField::MoveRight(System.Boolean,System.Boolean)
extern void InputField_MoveRight_m0C722FF6835D9658387A5A8197D2C6AE91167007 (void);
// 0x000001AE System.Int32 UnityEngine.UI.InputField::FindtPrevWordBegin()
extern void InputField_FindtPrevWordBegin_m86D6EA31B6DFB7E00BB65DF44B2BFB174C76B779 (void);
// 0x000001AF System.Void UnityEngine.UI.InputField::MoveLeft(System.Boolean,System.Boolean)
extern void InputField_MoveLeft_mB7649E1BB71E08918FA75129504637E5993BE9C9 (void);
// 0x000001B0 System.Int32 UnityEngine.UI.InputField::DetermineCharacterLine(System.Int32,UnityEngine.TextGenerator)
extern void InputField_DetermineCharacterLine_mC6268169D371E4E9E4F53FE7328467D198900E2A (void);
// 0x000001B1 System.Int32 UnityEngine.UI.InputField::LineUpCharacterPosition(System.Int32,System.Boolean)
extern void InputField_LineUpCharacterPosition_m8A576AC1B875A888FEDC82321C9AE31DA81AA7D9 (void);
// 0x000001B2 System.Int32 UnityEngine.UI.InputField::LineDownCharacterPosition(System.Int32,System.Boolean)
extern void InputField_LineDownCharacterPosition_m939685CBD14BAFA5A567816BA45169ED8D44163A (void);
// 0x000001B3 System.Void UnityEngine.UI.InputField::MoveDown(System.Boolean)
extern void InputField_MoveDown_m2645944F4CDCD56B539B1A26147F105BD77C90BE (void);
// 0x000001B4 System.Void UnityEngine.UI.InputField::MoveDown(System.Boolean,System.Boolean)
extern void InputField_MoveDown_mECF02ABCDDA5BF6C6CE4E697ED528F8DD1F08E09 (void);
// 0x000001B5 System.Void UnityEngine.UI.InputField::MoveUp(System.Boolean)
extern void InputField_MoveUp_m0AEA4013B6F62617843F78A8CA28C7789FE17390 (void);
// 0x000001B6 System.Void UnityEngine.UI.InputField::MoveUp(System.Boolean,System.Boolean)
extern void InputField_MoveUp_mCBE40CD7F6C7D69B70747F7C21100FCEA9529A79 (void);
// 0x000001B7 System.Void UnityEngine.UI.InputField::Delete()
extern void InputField_Delete_m0B2140554D2DDE9D0FCE3CE31BAB0BA2DB5E117A (void);
// 0x000001B8 System.Void UnityEngine.UI.InputField::ForwardSpace()
extern void InputField_ForwardSpace_m2244ECD6B4F4FBC516C3DFF98C26AD7232923672 (void);
// 0x000001B9 System.Void UnityEngine.UI.InputField::Backspace()
extern void InputField_Backspace_mDB2818F556D60FAC307837C43B658B85E2CDAC54 (void);
// 0x000001BA System.Void UnityEngine.UI.InputField::Insert(System.Char)
extern void InputField_Insert_m21CF9A3F16E052701E5EF653ACF2A6292543A00C (void);
// 0x000001BB System.Void UnityEngine.UI.InputField::UpdateTouchKeyboardFromEditChanges()
extern void InputField_UpdateTouchKeyboardFromEditChanges_m30BC6AF6EDEE51BC7841BDB359559841983E0F66 (void);
// 0x000001BC System.Void UnityEngine.UI.InputField::SendOnValueChangedAndUpdateLabel()
extern void InputField_SendOnValueChangedAndUpdateLabel_mB41A9F9492E1E9CB804FD776F8DF0C184AFAF8C3 (void);
// 0x000001BD System.Void UnityEngine.UI.InputField::SendOnValueChanged()
extern void InputField_SendOnValueChanged_mF963DEFC41C615416425F340491E9683542E824F (void);
// 0x000001BE System.Void UnityEngine.UI.InputField::SendOnSubmit()
extern void InputField_SendOnSubmit_m308F5B06A977B56339C2A04DFCE76980A060D029 (void);
// 0x000001BF System.Void UnityEngine.UI.InputField::Append(System.String)
extern void InputField_Append_m50F5FFDCBB6DE549E0AB02A18EFF3C6C330C1920 (void);
// 0x000001C0 System.Void UnityEngine.UI.InputField::Append(System.Char)
extern void InputField_Append_mC02A5BBA8C791725783C71A0690EFAE9B30E5843 (void);
// 0x000001C1 System.Void UnityEngine.UI.InputField::UpdateLabel()
extern void InputField_UpdateLabel_m712626C2AA5BAACB64354E3A47FDB7D6A08B3540 (void);
// 0x000001C2 System.Boolean UnityEngine.UI.InputField::IsSelectionVisible()
extern void InputField_IsSelectionVisible_mBB46CED5BB481A103E2F451807796BC62F7412D1 (void);
// 0x000001C3 System.Int32 UnityEngine.UI.InputField::GetLineStartPosition(UnityEngine.TextGenerator,System.Int32)
extern void InputField_GetLineStartPosition_m32048C5BC96D90A8A643C7574D1DB15855A91B02 (void);
// 0x000001C4 System.Int32 UnityEngine.UI.InputField::GetLineEndPosition(UnityEngine.TextGenerator,System.Int32)
extern void InputField_GetLineEndPosition_m6E72CC73B8CECDFABDEB91B2C16FAAB8DD4D8410 (void);
// 0x000001C5 System.Void UnityEngine.UI.InputField::SetDrawRangeToContainCaretPosition(System.Int32)
extern void InputField_SetDrawRangeToContainCaretPosition_mC1C84B1E904F4E85E302B2C01C485541FD3C855A (void);
// 0x000001C6 System.Void UnityEngine.UI.InputField::ForceLabelUpdate()
extern void InputField_ForceLabelUpdate_mE56AAD54AA9A4EB94E6F2488686164EE5470EC3A (void);
// 0x000001C7 System.Void UnityEngine.UI.InputField::MarkGeometryAsDirty()
extern void InputField_MarkGeometryAsDirty_m955A5B6E775E18ECCDD4DC231F3962AC678C63B7 (void);
// 0x000001C8 System.Void UnityEngine.UI.InputField::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void InputField_Rebuild_mCB5DCC1F18118169973384D5E1D2B4CA81E9D505 (void);
// 0x000001C9 System.Void UnityEngine.UI.InputField::LayoutComplete()
extern void InputField_LayoutComplete_mA6A49786196656DB139F8BC45951453E9131577F (void);
// 0x000001CA System.Void UnityEngine.UI.InputField::GraphicUpdateComplete()
extern void InputField_GraphicUpdateComplete_mE6D545372C45ABDEE746269DFBCC8902F1200FFC (void);
// 0x000001CB System.Void UnityEngine.UI.InputField::UpdateGeometry()
extern void InputField_UpdateGeometry_mEECCF310C7D3393A7DDA08F3B83D90000E218985 (void);
// 0x000001CC System.Void UnityEngine.UI.InputField::AssignPositioningIfNeeded()
extern void InputField_AssignPositioningIfNeeded_mE8FEF64ACBED85DDCF0DAA8DA6F3EEF148C12E15 (void);
// 0x000001CD System.Void UnityEngine.UI.InputField::OnFillVBO(UnityEngine.Mesh)
extern void InputField_OnFillVBO_m87FE3DEAA2F942B54E9584A90A3B33FAEEE148C7 (void);
// 0x000001CE System.Void UnityEngine.UI.InputField::GenerateCaret(UnityEngine.UI.VertexHelper,UnityEngine.Vector2)
extern void InputField_GenerateCaret_mF8725BE2F3B7E70E1E0B0EFD29E7C4ADC52FF5F1 (void);
// 0x000001CF System.Void UnityEngine.UI.InputField::CreateCursorVerts()
extern void InputField_CreateCursorVerts_m86F38ABBC9B6E0D1772EC65497B6CD54EACB3D24 (void);
// 0x000001D0 System.Void UnityEngine.UI.InputField::GenerateHighlight(UnityEngine.UI.VertexHelper,UnityEngine.Vector2)
extern void InputField_GenerateHighlight_m5C0CA7EFFD52B7E21A308D1BEAFEA7EDE1C3E1EA (void);
// 0x000001D1 System.Char UnityEngine.UI.InputField::Validate(System.String,System.Int32,System.Char)
extern void InputField_Validate_mB9125CCC24144FC5B3DD29FE985E87F62869DFAB (void);
// 0x000001D2 System.Void UnityEngine.UI.InputField::ActivateInputField()
extern void InputField_ActivateInputField_mAAA204298664775BB3A7A2D5569B998BE2E93034 (void);
// 0x000001D3 System.Void UnityEngine.UI.InputField::ActivateInputFieldInternal()
extern void InputField_ActivateInputFieldInternal_m1D5C71983027899BC648ABE4056DFD9A07D5022B (void);
// 0x000001D4 System.Void UnityEngine.UI.InputField::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnSelect_mA97FBA3324F22D4FCFAECD870C87982476BD7538 (void);
// 0x000001D5 System.Void UnityEngine.UI.InputField::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void InputField_OnPointerClick_m0E8E33963FDF4764C05268FAA9CFD7C8DAA4A7D3 (void);
// 0x000001D6 System.Void UnityEngine.UI.InputField::DeactivateInputField()
extern void InputField_DeactivateInputField_m6302C815A2363039468EFE763DB58EC6C4433B12 (void);
// 0x000001D7 System.Void UnityEngine.UI.InputField::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnDeselect_m0B418A98AD504283D5151EF93DF853F651C82A5B (void);
// 0x000001D8 System.Void UnityEngine.UI.InputField::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void InputField_OnSubmit_mA55A52599C8D0073D78993E23F5AC79D73741508 (void);
// 0x000001D9 System.Void UnityEngine.UI.InputField::EnforceContentType()
extern void InputField_EnforceContentType_m735408B4D205AF1FC3D36B518DDA640F86A88A0B (void);
// 0x000001DA System.Void UnityEngine.UI.InputField::EnforceTextHOverflow()
extern void InputField_EnforceTextHOverflow_mEF2E66E0DC46C7AECCE7C5B990FBF802AA28306C (void);
// 0x000001DB System.Void UnityEngine.UI.InputField::SetToCustomIfContentTypeIsNot(UnityEngine.UI.InputField/ContentType[])
extern void InputField_SetToCustomIfContentTypeIsNot_m7555D5C16577D1FBE9DA7ACBB6D6505735AC6050 (void);
// 0x000001DC System.Void UnityEngine.UI.InputField::SetToCustom()
extern void InputField_SetToCustom_m3C3E73F1BD3DD5F83F5CC335604D017E4FC8B62B (void);
// 0x000001DD System.Void UnityEngine.UI.InputField::DoStateTransition(UnityEngine.UI.Selectable/SelectionState,System.Boolean)
extern void InputField_DoStateTransition_mECA873FA9210DFA03C164B554FC74A72B91955B2 (void);
// 0x000001DE System.Void UnityEngine.UI.InputField::CalculateLayoutInputHorizontal()
extern void InputField_CalculateLayoutInputHorizontal_mD9DC3557122AF0F1120D7B254E461CF49663C603 (void);
// 0x000001DF System.Void UnityEngine.UI.InputField::CalculateLayoutInputVertical()
extern void InputField_CalculateLayoutInputVertical_mFA809A45E5C5552D0F3CFB733EEAFB3A613BBC6C (void);
// 0x000001E0 System.Single UnityEngine.UI.InputField::get_minWidth()
extern void InputField_get_minWidth_mAE0C5234BB329079A707CE4DBF9E5749D3138CE0 (void);
// 0x000001E1 System.Single UnityEngine.UI.InputField::get_preferredWidth()
extern void InputField_get_preferredWidth_mBF8E829F1B2A29346BCB0ADA620181C72C68AE5A (void);
// 0x000001E2 System.Single UnityEngine.UI.InputField::get_flexibleWidth()
extern void InputField_get_flexibleWidth_m3BB11CF1846542B95CCE88E50EA2C4895DFE9DF3 (void);
// 0x000001E3 System.Single UnityEngine.UI.InputField::get_minHeight()
extern void InputField_get_minHeight_m1AF6A8396567A7FD26A1F278D2A106D86A2DD0BA (void);
// 0x000001E4 System.Single UnityEngine.UI.InputField::get_preferredHeight()
extern void InputField_get_preferredHeight_mEF8661384E11AB11AE6FDBD4CC22D6BEF5DFEFA6 (void);
// 0x000001E5 System.Single UnityEngine.UI.InputField::get_flexibleHeight()
extern void InputField_get_flexibleHeight_m61212D0FF1ABA904E329D2C9F6AA092A85E0228F (void);
// 0x000001E6 System.Int32 UnityEngine.UI.InputField::get_layoutPriority()
extern void InputField_get_layoutPriority_mA7FA21CE021992A6BAED68EC6ED314507E47A5B3 (void);
// 0x000001E7 System.Void UnityEngine.UI.InputField::.cctor()
extern void InputField__cctor_mB8D2F31A004D010ADE0789E0FA5914448E2672A0 (void);
// 0x000001E8 UnityEngine.Transform UnityEngine.UI.InputField::UnityEngine.UI.ICanvasElement.get_transform()
extern void InputField_UnityEngine_UI_ICanvasElement_get_transform_mA04C52C3E8831E49F2D5ED03E7A1B532E83D0C28 (void);
// 0x000001E9 UnityEngine.UI.AspectRatioFitter/AspectMode UnityEngine.UI.AspectRatioFitter::get_aspectMode()
extern void AspectRatioFitter_get_aspectMode_m9DC7F64E9AB97AAB413EEF9931EDEDF90ACE0B75 (void);
// 0x000001EA System.Void UnityEngine.UI.AspectRatioFitter::set_aspectMode(UnityEngine.UI.AspectRatioFitter/AspectMode)
extern void AspectRatioFitter_set_aspectMode_mDF90DA2FC20507B35EC237C91C93A3DBB3CB4322 (void);
// 0x000001EB System.Single UnityEngine.UI.AspectRatioFitter::get_aspectRatio()
extern void AspectRatioFitter_get_aspectRatio_mCA6B68F9D4FB640574390BF43ACF3DC8D42AEF99 (void);
// 0x000001EC System.Void UnityEngine.UI.AspectRatioFitter::set_aspectRatio(System.Single)
extern void AspectRatioFitter_set_aspectRatio_m3E56408CB25114762687C9C5398E34BBCBE8DB01 (void);
// 0x000001ED UnityEngine.RectTransform UnityEngine.UI.AspectRatioFitter::get_rectTransform()
extern void AspectRatioFitter_get_rectTransform_m10762C918EB094ED7335B938446F6537EF9E7F26 (void);
// 0x000001EE System.Void UnityEngine.UI.AspectRatioFitter::.ctor()
extern void AspectRatioFitter__ctor_m2AC759B3A6146540893D7540C4FED29B4BF26CD9 (void);
// 0x000001EF System.Void UnityEngine.UI.AspectRatioFitter::OnEnable()
extern void AspectRatioFitter_OnEnable_m40B817004571F69A96776F46D000E6F24D21B08A (void);
// 0x000001F0 System.Void UnityEngine.UI.AspectRatioFitter::OnDisable()
extern void AspectRatioFitter_OnDisable_m82534D7AD69F406A0A90A9E912B05658E7AD9A88 (void);
// 0x000001F1 System.Void UnityEngine.UI.AspectRatioFitter::Update()
extern void AspectRatioFitter_Update_mA54B4CE8AE14353C5936E26AFD7797E42AB073F8 (void);
// 0x000001F2 System.Void UnityEngine.UI.AspectRatioFitter::OnRectTransformDimensionsChange()
extern void AspectRatioFitter_OnRectTransformDimensionsChange_m221F31DD8F2247C30B942904590D71C0E018D973 (void);
// 0x000001F3 System.Void UnityEngine.UI.AspectRatioFitter::UpdateRect()
extern void AspectRatioFitter_UpdateRect_m9C9311A3A55D5C3175E80C87944B0035DD9084E0 (void);
// 0x000001F4 System.Single UnityEngine.UI.AspectRatioFitter::GetSizeDeltaToProduceSize(System.Single,System.Int32)
extern void AspectRatioFitter_GetSizeDeltaToProduceSize_mCDD7A3B13A26729FD9ACE0D7AAAAD0714F4FE9AC (void);
// 0x000001F5 UnityEngine.Vector2 UnityEngine.UI.AspectRatioFitter::GetParentSize()
extern void AspectRatioFitter_GetParentSize_m5AA652B731F6930CA9C9B342C93354D73EFB6874 (void);
// 0x000001F6 System.Void UnityEngine.UI.AspectRatioFitter::SetLayoutHorizontal()
extern void AspectRatioFitter_SetLayoutHorizontal_m5B37DEF0AD6FD781A4B42FE51695709EFF139290 (void);
// 0x000001F7 System.Void UnityEngine.UI.AspectRatioFitter::SetLayoutVertical()
extern void AspectRatioFitter_SetLayoutVertical_m515415507DB485E9A58CF0583DCD20CC655A9374 (void);
// 0x000001F8 System.Void UnityEngine.UI.AspectRatioFitter::SetDirty()
extern void AspectRatioFitter_SetDirty_mFB1E634E75B793DD239BC6E236001B6A794B1D78 (void);
// 0x000001F9 UnityEngine.UI.CanvasScaler/ScaleMode UnityEngine.UI.CanvasScaler::get_uiScaleMode()
extern void CanvasScaler_get_uiScaleMode_m8D75124B20A8598DFEF27665EBE9C5925CB25301 (void);
// 0x000001FA System.Void UnityEngine.UI.CanvasScaler::set_uiScaleMode(UnityEngine.UI.CanvasScaler/ScaleMode)
extern void CanvasScaler_set_uiScaleMode_m27A14E550C83FC847435C85081D912276730B467 (void);
// 0x000001FB System.Single UnityEngine.UI.CanvasScaler::get_referencePixelsPerUnit()
extern void CanvasScaler_get_referencePixelsPerUnit_m74D7EF4EB4D71E99A30C975BFAFDAD8CACA73A57 (void);
// 0x000001FC System.Void UnityEngine.UI.CanvasScaler::set_referencePixelsPerUnit(System.Single)
extern void CanvasScaler_set_referencePixelsPerUnit_m71C00FD0516FC9E580C828E684788ACAA60EAD28 (void);
// 0x000001FD System.Single UnityEngine.UI.CanvasScaler::get_scaleFactor()
extern void CanvasScaler_get_scaleFactor_m79BDE0DCD960EF17AF645344664F6C91A5519CAE (void);
// 0x000001FE System.Void UnityEngine.UI.CanvasScaler::set_scaleFactor(System.Single)
extern void CanvasScaler_set_scaleFactor_mDA73D373B6D69FCD255C7784576B93079F2A6CC0 (void);
// 0x000001FF UnityEngine.Vector2 UnityEngine.UI.CanvasScaler::get_referenceResolution()
extern void CanvasScaler_get_referenceResolution_m8CB18ECD76532AD9FAFA92D9D395AB1070730A8C (void);
// 0x00000200 System.Void UnityEngine.UI.CanvasScaler::set_referenceResolution(UnityEngine.Vector2)
extern void CanvasScaler_set_referenceResolution_m816A6770562B655C056B255757993A589C1DFA4B (void);
// 0x00000201 UnityEngine.UI.CanvasScaler/ScreenMatchMode UnityEngine.UI.CanvasScaler::get_screenMatchMode()
extern void CanvasScaler_get_screenMatchMode_mD1444EF5D606499AE030E88AEACD0D4319C394F2 (void);
// 0x00000202 System.Void UnityEngine.UI.CanvasScaler::set_screenMatchMode(UnityEngine.UI.CanvasScaler/ScreenMatchMode)
extern void CanvasScaler_set_screenMatchMode_m48F770842F9333E077F5F57726F5074B140C43E9 (void);
// 0x00000203 System.Single UnityEngine.UI.CanvasScaler::get_matchWidthOrHeight()
extern void CanvasScaler_get_matchWidthOrHeight_m7CF35A053967D576A0519D156E491D7D77AF363D (void);
// 0x00000204 System.Void UnityEngine.UI.CanvasScaler::set_matchWidthOrHeight(System.Single)
extern void CanvasScaler_set_matchWidthOrHeight_m3A1FAAE9A6CA76AF4484C002AA8ED0B9C100F5BE (void);
// 0x00000205 UnityEngine.UI.CanvasScaler/Unit UnityEngine.UI.CanvasScaler::get_physicalUnit()
extern void CanvasScaler_get_physicalUnit_m2F6DD4DFDDA3DE8652A5F295C1E66060D0D8E94A (void);
// 0x00000206 System.Void UnityEngine.UI.CanvasScaler::set_physicalUnit(UnityEngine.UI.CanvasScaler/Unit)
extern void CanvasScaler_set_physicalUnit_mC60DC2F6DC43C15C1EEB1EF64A653BF64DA7C06A (void);
// 0x00000207 System.Single UnityEngine.UI.CanvasScaler::get_fallbackScreenDPI()
extern void CanvasScaler_get_fallbackScreenDPI_mB24A47CA5792781C10AE198C2EE6988CCB9AB635 (void);
// 0x00000208 System.Void UnityEngine.UI.CanvasScaler::set_fallbackScreenDPI(System.Single)
extern void CanvasScaler_set_fallbackScreenDPI_m4D32B6C619E00682EB8D0DE0F6D71BE6139250EF (void);
// 0x00000209 System.Single UnityEngine.UI.CanvasScaler::get_defaultSpriteDPI()
extern void CanvasScaler_get_defaultSpriteDPI_m670E425C6F635BDC28B2C2B5C71C65353A1E82FF (void);
// 0x0000020A System.Void UnityEngine.UI.CanvasScaler::set_defaultSpriteDPI(System.Single)
extern void CanvasScaler_set_defaultSpriteDPI_m7509D86B586D726E29D2C21A2CB4E0C567BFF65A (void);
// 0x0000020B System.Single UnityEngine.UI.CanvasScaler::get_dynamicPixelsPerUnit()
extern void CanvasScaler_get_dynamicPixelsPerUnit_m1D1058E155B70C06DD98C7C39B630848E803E155 (void);
// 0x0000020C System.Void UnityEngine.UI.CanvasScaler::set_dynamicPixelsPerUnit(System.Single)
extern void CanvasScaler_set_dynamicPixelsPerUnit_m4D7A2EE8F92EAF2EC58886C851D828111FC34494 (void);
// 0x0000020D System.Void UnityEngine.UI.CanvasScaler::.ctor()
extern void CanvasScaler__ctor_mBF6E3BBA137405C93E27640EF7E53F6B2808A8D6 (void);
// 0x0000020E System.Void UnityEngine.UI.CanvasScaler::OnEnable()
extern void CanvasScaler_OnEnable_m4FDFAD573E34C335F6EBCC5CB0625353AF189E64 (void);
// 0x0000020F System.Void UnityEngine.UI.CanvasScaler::Canvas_preWillRenderCanvases()
extern void CanvasScaler_Canvas_preWillRenderCanvases_m33AF90619C3CE3A826F5EB55843A457B23EA5052 (void);
// 0x00000210 System.Void UnityEngine.UI.CanvasScaler::OnDisable()
extern void CanvasScaler_OnDisable_mC2B96434A71E3BCAE8C03B54D6BA51E22327F070 (void);
// 0x00000211 System.Void UnityEngine.UI.CanvasScaler::Handle()
extern void CanvasScaler_Handle_m867273F56329565834F7793E05C970D8E32DA4B6 (void);
// 0x00000212 System.Void UnityEngine.UI.CanvasScaler::HandleWorldCanvas()
extern void CanvasScaler_HandleWorldCanvas_m0F9D6A0089798542BC7BD4772D782C00FBF643A2 (void);
// 0x00000213 System.Void UnityEngine.UI.CanvasScaler::HandleConstantPixelSize()
extern void CanvasScaler_HandleConstantPixelSize_m2FBD457CCC6225DFB1C3B7A5C737C45E5CBAEB39 (void);
// 0x00000214 System.Void UnityEngine.UI.CanvasScaler::HandleScaleWithScreenSize()
extern void CanvasScaler_HandleScaleWithScreenSize_mB3430B5FD262C0826FF228EDC80AD0144F7826F6 (void);
// 0x00000215 System.Void UnityEngine.UI.CanvasScaler::HandleConstantPhysicalSize()
extern void CanvasScaler_HandleConstantPhysicalSize_mE2459900B0F585298C659A103393011B42F721E9 (void);
// 0x00000216 System.Void UnityEngine.UI.CanvasScaler::SetScaleFactor(System.Single)
extern void CanvasScaler_SetScaleFactor_m2FA24C807078ECFCCA188F8C92B3B5E11409151B (void);
// 0x00000217 System.Void UnityEngine.UI.CanvasScaler::SetReferencePixelsPerUnit(System.Single)
extern void CanvasScaler_SetReferencePixelsPerUnit_m2C7B8AB6515B8B3CFB22B7511907F0063163212A (void);
// 0x00000218 UnityEngine.UI.ContentSizeFitter/FitMode UnityEngine.UI.ContentSizeFitter::get_horizontalFit()
extern void ContentSizeFitter_get_horizontalFit_mB775F652AC10946108F7D44BB52C57413086F524 (void);
// 0x00000219 System.Void UnityEngine.UI.ContentSizeFitter::set_horizontalFit(UnityEngine.UI.ContentSizeFitter/FitMode)
extern void ContentSizeFitter_set_horizontalFit_m38BB1F91ECB19CA55395886DE04404293568DE53 (void);
// 0x0000021A UnityEngine.UI.ContentSizeFitter/FitMode UnityEngine.UI.ContentSizeFitter::get_verticalFit()
extern void ContentSizeFitter_get_verticalFit_m937F784A1D950E72A561B7DF96206ADA5F1FC490 (void);
// 0x0000021B System.Void UnityEngine.UI.ContentSizeFitter::set_verticalFit(UnityEngine.UI.ContentSizeFitter/FitMode)
extern void ContentSizeFitter_set_verticalFit_mFE092A2EA456864549B62369A11A711230C181EF (void);
// 0x0000021C UnityEngine.RectTransform UnityEngine.UI.ContentSizeFitter::get_rectTransform()
extern void ContentSizeFitter_get_rectTransform_mE7FD5F977E954B6D54B9C1CCD112A4A70840CF56 (void);
// 0x0000021D System.Void UnityEngine.UI.ContentSizeFitter::.ctor()
extern void ContentSizeFitter__ctor_mBEE0AF95BB3FAFA553708EBC870D4FE2E3443B65 (void);
// 0x0000021E System.Void UnityEngine.UI.ContentSizeFitter::OnEnable()
extern void ContentSizeFitter_OnEnable_m13D8C85D4331DD5890A140523A57221153FE2657 (void);
// 0x0000021F System.Void UnityEngine.UI.ContentSizeFitter::OnDisable()
extern void ContentSizeFitter_OnDisable_m1E5A38232518EDD43A9B2265B2EB496F91C9DEB8 (void);
// 0x00000220 System.Void UnityEngine.UI.ContentSizeFitter::OnRectTransformDimensionsChange()
extern void ContentSizeFitter_OnRectTransformDimensionsChange_m42E361EACC44809C1FFC876582163D1E2D5FE0AC (void);
// 0x00000221 System.Void UnityEngine.UI.ContentSizeFitter::HandleSelfFittingAlongAxis(System.Int32)
extern void ContentSizeFitter_HandleSelfFittingAlongAxis_m6CB47EDA5C86EB609586AC0EA09289063A5E8E21 (void);
// 0x00000222 System.Void UnityEngine.UI.ContentSizeFitter::SetLayoutHorizontal()
extern void ContentSizeFitter_SetLayoutHorizontal_m7A86741FD35792D94D3ECD29F258EDB2C1C0E821 (void);
// 0x00000223 System.Void UnityEngine.UI.ContentSizeFitter::SetLayoutVertical()
extern void ContentSizeFitter_SetLayoutVertical_m32994803FA0364E902848414EE2A906C4A540C7E (void);
// 0x00000224 System.Void UnityEngine.UI.ContentSizeFitter::SetDirty()
extern void ContentSizeFitter_SetDirty_m018F67222A9B6CB351DB14625794E9508A153670 (void);
// 0x00000225 UnityEngine.UI.GridLayoutGroup/Corner UnityEngine.UI.GridLayoutGroup::get_startCorner()
extern void GridLayoutGroup_get_startCorner_m8D842137857E7AD45EE6AC346E0413A8F392729F (void);
// 0x00000226 System.Void UnityEngine.UI.GridLayoutGroup::set_startCorner(UnityEngine.UI.GridLayoutGroup/Corner)
extern void GridLayoutGroup_set_startCorner_mFCF40F8B8DB31E37C69FD9AFFDE72A86EF2BCCDD (void);
// 0x00000227 UnityEngine.UI.GridLayoutGroup/Axis UnityEngine.UI.GridLayoutGroup::get_startAxis()
extern void GridLayoutGroup_get_startAxis_mAA66BAC768514A784F891AF3771952CFDE713E7D (void);
// 0x00000228 System.Void UnityEngine.UI.GridLayoutGroup::set_startAxis(UnityEngine.UI.GridLayoutGroup/Axis)
extern void GridLayoutGroup_set_startAxis_m0274E444A5EA78193D8F6A1863D6FA4A04B59E76 (void);
// 0x00000229 UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::get_cellSize()
extern void GridLayoutGroup_get_cellSize_mC5817788B1279F0ED4FA8E97D64B705FB782FCAA (void);
// 0x0000022A System.Void UnityEngine.UI.GridLayoutGroup::set_cellSize(UnityEngine.Vector2)
extern void GridLayoutGroup_set_cellSize_m55D9E33312D320F223797A150AC3FC5A377B1EDC (void);
// 0x0000022B UnityEngine.Vector2 UnityEngine.UI.GridLayoutGroup::get_spacing()
extern void GridLayoutGroup_get_spacing_m4E066AD77C47D776D142944838AA592DCDBFB1F1 (void);
// 0x0000022C System.Void UnityEngine.UI.GridLayoutGroup::set_spacing(UnityEngine.Vector2)
extern void GridLayoutGroup_set_spacing_mB478EF4E026982009F548F99DD715981EDDDEC63 (void);
// 0x0000022D UnityEngine.UI.GridLayoutGroup/Constraint UnityEngine.UI.GridLayoutGroup::get_constraint()
extern void GridLayoutGroup_get_constraint_mD3C4128F573301158661CC38EB13105D2A3CD0F8 (void);
// 0x0000022E System.Void UnityEngine.UI.GridLayoutGroup::set_constraint(UnityEngine.UI.GridLayoutGroup/Constraint)
extern void GridLayoutGroup_set_constraint_mA9572E37898BA95574F79A1233FC2542F013B804 (void);
// 0x0000022F System.Int32 UnityEngine.UI.GridLayoutGroup::get_constraintCount()
extern void GridLayoutGroup_get_constraintCount_m21913887C313155C2623C66EF614076D89154E55 (void);
// 0x00000230 System.Void UnityEngine.UI.GridLayoutGroup::set_constraintCount(System.Int32)
extern void GridLayoutGroup_set_constraintCount_m543F39FB71E239F6C22E793645B662E04D2B383D (void);
// 0x00000231 System.Void UnityEngine.UI.GridLayoutGroup::.ctor()
extern void GridLayoutGroup__ctor_m821D85B183D0948FD6754FDE7A307D139AFCF354 (void);
// 0x00000232 System.Void UnityEngine.UI.GridLayoutGroup::CalculateLayoutInputHorizontal()
extern void GridLayoutGroup_CalculateLayoutInputHorizontal_mCC205DFC6F928A51D0E1DF2BDBF0C9F335633DE8 (void);
// 0x00000233 System.Void UnityEngine.UI.GridLayoutGroup::CalculateLayoutInputVertical()
extern void GridLayoutGroup_CalculateLayoutInputVertical_mB9245498EF2C8DD7E2B85B295F2E50B86AA1DFCA (void);
// 0x00000234 System.Void UnityEngine.UI.GridLayoutGroup::SetLayoutHorizontal()
extern void GridLayoutGroup_SetLayoutHorizontal_mED9E07022D040F404F806BF059AAA114E6D54BC2 (void);
// 0x00000235 System.Void UnityEngine.UI.GridLayoutGroup::SetLayoutVertical()
extern void GridLayoutGroup_SetLayoutVertical_m27268A990F1DE734666CD987B0CD87782A4D080F (void);
// 0x00000236 System.Void UnityEngine.UI.GridLayoutGroup::SetCellsAlongAxis(System.Int32)
extern void GridLayoutGroup_SetCellsAlongAxis_m43BBA8EA7D65D65119E8D49C304F2DBE3B5AA574 (void);
// 0x00000237 System.Void UnityEngine.UI.HorizontalLayoutGroup::.ctor()
extern void HorizontalLayoutGroup__ctor_m5303C6DCDF90E5B49EFAC8C1C1690ACF199A0433 (void);
// 0x00000238 System.Void UnityEngine.UI.HorizontalLayoutGroup::CalculateLayoutInputHorizontal()
extern void HorizontalLayoutGroup_CalculateLayoutInputHorizontal_m696524F96532846E5976722B848EE600E99ECB24 (void);
// 0x00000239 System.Void UnityEngine.UI.HorizontalLayoutGroup::CalculateLayoutInputVertical()
extern void HorizontalLayoutGroup_CalculateLayoutInputVertical_mFCC3059D6992DFACE01B00B5111862EDEEDF39ED (void);
// 0x0000023A System.Void UnityEngine.UI.HorizontalLayoutGroup::SetLayoutHorizontal()
extern void HorizontalLayoutGroup_SetLayoutHorizontal_m3750F103E00A49D3617AEBE708B248F0E3120A66 (void);
// 0x0000023B System.Void UnityEngine.UI.HorizontalLayoutGroup::SetLayoutVertical()
extern void HorizontalLayoutGroup_SetLayoutVertical_m566231E37D3A0FB2430817654FF8C9A548D71593 (void);
// 0x0000023C System.Single UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_spacing()
extern void HorizontalOrVerticalLayoutGroup_get_spacing_mCE7919753288D05C02592FD55069875A08DDF19A (void);
// 0x0000023D System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_spacing(System.Single)
extern void HorizontalOrVerticalLayoutGroup_set_spacing_mA147719DAEC6BD5E9F3AA4E3B08C0AB5DA222596 (void);
// 0x0000023E System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childForceExpandWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childForceExpandWidth_mA1C3F9419088A02B32A59137EA87936FAF327279 (void);
// 0x0000023F System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childForceExpandWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childForceExpandWidth_m11D946155AAE60441705178AE0592ACB29B1A9FC (void);
// 0x00000240 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childForceExpandHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childForceExpandHeight_m63750DDE1224118C83C84A5BA565604DD987147B (void);
// 0x00000241 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childForceExpandHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childForceExpandHeight_m73E01EADA63CFB3A693BC3AB2E54330A97E43F35 (void);
// 0x00000242 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childControlWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childControlWidth_mF6647BC3ADB7632354D117FE8B1D78C634090A2F (void);
// 0x00000243 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childControlWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childControlWidth_m366D5679DF396FB4F74485D2392B3868B5897EED (void);
// 0x00000244 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childControlHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childControlHeight_m47B013D1CC0A957A8E090F9CEF448B3448EB0A3C (void);
// 0x00000245 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childControlHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childControlHeight_mA5DA8F5FFDC9757177A75052C8275ED220090E30 (void);
// 0x00000246 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childScaleWidth()
extern void HorizontalOrVerticalLayoutGroup_get_childScaleWidth_mD6EC6A7D07F464FDA669A69712195E364161F8D1 (void);
// 0x00000247 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childScaleWidth(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childScaleWidth_mB71709DD594BD6972720F31FC7EB2A2F5E2F2A85 (void);
// 0x00000248 System.Boolean UnityEngine.UI.HorizontalOrVerticalLayoutGroup::get_childScaleHeight()
extern void HorizontalOrVerticalLayoutGroup_get_childScaleHeight_m0683A5239FE33AE4639ED0175541C168CC2152A5 (void);
// 0x00000249 System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::set_childScaleHeight(System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_set_childScaleHeight_m57453CB7D1D422B3E41E4E5714ECA2B174D23808 (void);
// 0x0000024A System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::CalcAlongAxis(System.Int32,System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_CalcAlongAxis_mAE030B65D045B1901FDD7330152569A29F1D2AC8 (void);
// 0x0000024B System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::SetChildrenAlongAxis(System.Int32,System.Boolean)
extern void HorizontalOrVerticalLayoutGroup_SetChildrenAlongAxis_m2F3057C3C3BD96B7B5C69298EA9709BD456FE640 (void);
// 0x0000024C System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::GetChildSizes(UnityEngine.RectTransform,System.Int32,System.Boolean,System.Boolean,System.Single&,System.Single&,System.Single&)
extern void HorizontalOrVerticalLayoutGroup_GetChildSizes_mEB4BECA34FE89481D75F422445090FBB0D9BB3C1 (void);
// 0x0000024D System.Void UnityEngine.UI.HorizontalOrVerticalLayoutGroup::.ctor()
extern void HorizontalOrVerticalLayoutGroup__ctor_m2051FBB8D92638A863519B168AB243A5C91A5FE3 (void);
// 0x0000024E System.Void UnityEngine.UI.ILayoutElement::CalculateLayoutInputHorizontal()
// 0x0000024F System.Void UnityEngine.UI.ILayoutElement::CalculateLayoutInputVertical()
// 0x00000250 System.Single UnityEngine.UI.ILayoutElement::get_minWidth()
// 0x00000251 System.Single UnityEngine.UI.ILayoutElement::get_preferredWidth()
// 0x00000252 System.Single UnityEngine.UI.ILayoutElement::get_flexibleWidth()
// 0x00000253 System.Single UnityEngine.UI.ILayoutElement::get_minHeight()
// 0x00000254 System.Single UnityEngine.UI.ILayoutElement::get_preferredHeight()
// 0x00000255 System.Single UnityEngine.UI.ILayoutElement::get_flexibleHeight()
// 0x00000256 System.Int32 UnityEngine.UI.ILayoutElement::get_layoutPriority()
// 0x00000257 System.Void UnityEngine.UI.ILayoutController::SetLayoutHorizontal()
// 0x00000258 System.Void UnityEngine.UI.ILayoutController::SetLayoutVertical()
// 0x00000259 System.Boolean UnityEngine.UI.ILayoutIgnorer::get_ignoreLayout()
// 0x0000025A System.Boolean UnityEngine.UI.LayoutElement::get_ignoreLayout()
extern void LayoutElement_get_ignoreLayout_m76A33CF6EDC8B31FB599FC1B29D3A181B54A1316 (void);
// 0x0000025B System.Void UnityEngine.UI.LayoutElement::set_ignoreLayout(System.Boolean)
extern void LayoutElement_set_ignoreLayout_mB1FB05BBE439A1D837419CE6052C54D9997E9A91 (void);
// 0x0000025C System.Void UnityEngine.UI.LayoutElement::CalculateLayoutInputHorizontal()
extern void LayoutElement_CalculateLayoutInputHorizontal_mBB97174653148BCE26DB38BDE270149F5D6B66B1 (void);
// 0x0000025D System.Void UnityEngine.UI.LayoutElement::CalculateLayoutInputVertical()
extern void LayoutElement_CalculateLayoutInputVertical_mB16DE5998CCF9F0A86248792EF11ADA58CDD1D01 (void);
// 0x0000025E System.Single UnityEngine.UI.LayoutElement::get_minWidth()
extern void LayoutElement_get_minWidth_mC37C09DA0557739757F314A9DB76BD9CDADB1CEA (void);
// 0x0000025F System.Void UnityEngine.UI.LayoutElement::set_minWidth(System.Single)
extern void LayoutElement_set_minWidth_m13DFE770E642FE52C5BC1D6528FCB66CDB497C46 (void);
// 0x00000260 System.Single UnityEngine.UI.LayoutElement::get_minHeight()
extern void LayoutElement_get_minHeight_m4593A898277D5663C0664664F9DF2D52A00FE320 (void);
// 0x00000261 System.Void UnityEngine.UI.LayoutElement::set_minHeight(System.Single)
extern void LayoutElement_set_minHeight_m482EB19B529540E06F43BA319BC01F7DE7015A46 (void);
// 0x00000262 System.Single UnityEngine.UI.LayoutElement::get_preferredWidth()
extern void LayoutElement_get_preferredWidth_m3681B308EC2A341CDBBC6C48DF5729BB29BA2B82 (void);
// 0x00000263 System.Void UnityEngine.UI.LayoutElement::set_preferredWidth(System.Single)
extern void LayoutElement_set_preferredWidth_m717CCB1C45A1586871E47E66FB0DD6A9E56EFC25 (void);
// 0x00000264 System.Single UnityEngine.UI.LayoutElement::get_preferredHeight()
extern void LayoutElement_get_preferredHeight_m4520ED06B8806DD4759E07989DC8C7E7EB52BA4E (void);
// 0x00000265 System.Void UnityEngine.UI.LayoutElement::set_preferredHeight(System.Single)
extern void LayoutElement_set_preferredHeight_mF09A4D8DF6AC50C997136C961793F5EE55182933 (void);
// 0x00000266 System.Single UnityEngine.UI.LayoutElement::get_flexibleWidth()
extern void LayoutElement_get_flexibleWidth_m6B083FC777D575170153035E7CB0D8D24EB2993F (void);
// 0x00000267 System.Void UnityEngine.UI.LayoutElement::set_flexibleWidth(System.Single)
extern void LayoutElement_set_flexibleWidth_mE083E617E101B01130B578749186123C8B730778 (void);
// 0x00000268 System.Single UnityEngine.UI.LayoutElement::get_flexibleHeight()
extern void LayoutElement_get_flexibleHeight_mB27ABAC0E8C2D3AFEF4B2626F9024BDF8634B213 (void);
// 0x00000269 System.Void UnityEngine.UI.LayoutElement::set_flexibleHeight(System.Single)
extern void LayoutElement_set_flexibleHeight_m374C189D99D8DD2CE2CBB98CAC0072ADA5A60A7F (void);
// 0x0000026A System.Int32 UnityEngine.UI.LayoutElement::get_layoutPriority()
extern void LayoutElement_get_layoutPriority_mB107040D948E21E4B4B955BDD9D92CA22BC56A26 (void);
// 0x0000026B System.Void UnityEngine.UI.LayoutElement::set_layoutPriority(System.Int32)
extern void LayoutElement_set_layoutPriority_m4EF6C474731A4273DFCFCA67C49418CD797411BD (void);
// 0x0000026C System.Void UnityEngine.UI.LayoutElement::.ctor()
extern void LayoutElement__ctor_mD5313205D44DAD8CACE3E8E52DC9A41FAB4E2383 (void);
// 0x0000026D System.Void UnityEngine.UI.LayoutElement::OnEnable()
extern void LayoutElement_OnEnable_m839B2DCFCFE90FCA8B222C0572D3011DC39629B2 (void);
// 0x0000026E System.Void UnityEngine.UI.LayoutElement::OnTransformParentChanged()
extern void LayoutElement_OnTransformParentChanged_m95A3CE5064623EEE62669FD7DF5D5AC904F948F8 (void);
// 0x0000026F System.Void UnityEngine.UI.LayoutElement::OnDisable()
extern void LayoutElement_OnDisable_m1346841458ED38340601C8B27FCAC21CDD0B11A9 (void);
// 0x00000270 System.Void UnityEngine.UI.LayoutElement::OnDidApplyAnimationProperties()
extern void LayoutElement_OnDidApplyAnimationProperties_m5E355B394104A04D09F00DCE99F3DE07A69CCA2E (void);
// 0x00000271 System.Void UnityEngine.UI.LayoutElement::OnBeforeTransformParentChanged()
extern void LayoutElement_OnBeforeTransformParentChanged_mA809983BB6D9F1A1F0B33A59EF8211BD3184C7A9 (void);
// 0x00000272 System.Void UnityEngine.UI.LayoutElement::SetDirty()
extern void LayoutElement_SetDirty_m14EE2C04CACB76A50F23CCA7A92726C2B25163FE (void);
// 0x00000273 UnityEngine.RectOffset UnityEngine.UI.LayoutGroup::get_padding()
extern void LayoutGroup_get_padding_m7C98F5699A1F144A3CD754094159DD61EDEA6D18 (void);
// 0x00000274 System.Void UnityEngine.UI.LayoutGroup::set_padding(UnityEngine.RectOffset)
extern void LayoutGroup_set_padding_m946C7A5D562DAB48575119599768D5AC58A5CC39 (void);
// 0x00000275 UnityEngine.TextAnchor UnityEngine.UI.LayoutGroup::get_childAlignment()
extern void LayoutGroup_get_childAlignment_mC2E6A497C4BCAEF50E46CB271EA4FB48EF345826 (void);
// 0x00000276 System.Void UnityEngine.UI.LayoutGroup::set_childAlignment(UnityEngine.TextAnchor)
extern void LayoutGroup_set_childAlignment_mABF0882AFCFE117F4C3DDBA21EA9AF324EAAFD87 (void);
// 0x00000277 UnityEngine.RectTransform UnityEngine.UI.LayoutGroup::get_rectTransform()
extern void LayoutGroup_get_rectTransform_mBA2164F608E800F4C819611E721EA825995BA9B8 (void);
// 0x00000278 System.Collections.Generic.List`1<UnityEngine.RectTransform> UnityEngine.UI.LayoutGroup::get_rectChildren()
extern void LayoutGroup_get_rectChildren_mE1363B47FF118F2E5DD3ADA17FC5A47ADAD1D3E7 (void);
// 0x00000279 System.Void UnityEngine.UI.LayoutGroup::CalculateLayoutInputHorizontal()
extern void LayoutGroup_CalculateLayoutInputHorizontal_m70721CBFED66DA145C6B04D966AA5C3E367238F0 (void);
// 0x0000027A System.Void UnityEngine.UI.LayoutGroup::CalculateLayoutInputVertical()
// 0x0000027B System.Single UnityEngine.UI.LayoutGroup::get_minWidth()
extern void LayoutGroup_get_minWidth_mDB9DA90E62CB48DA4ACFFA412FA31A0ED19ECED1 (void);
// 0x0000027C System.Single UnityEngine.UI.LayoutGroup::get_preferredWidth()
extern void LayoutGroup_get_preferredWidth_m4A3AFC14DC765C8706EE5C0F9B7CDDD1B9C70293 (void);
// 0x0000027D System.Single UnityEngine.UI.LayoutGroup::get_flexibleWidth()
extern void LayoutGroup_get_flexibleWidth_m8F081F140F0161484ADB59E48E482CF40DCA8F52 (void);
// 0x0000027E System.Single UnityEngine.UI.LayoutGroup::get_minHeight()
extern void LayoutGroup_get_minHeight_m80D0D817E7F73A66A4F235D579C87B2134AAB10B (void);
// 0x0000027F System.Single UnityEngine.UI.LayoutGroup::get_preferredHeight()
extern void LayoutGroup_get_preferredHeight_mF2F6C67C5DB339A75D1400842443215A83E3E4C7 (void);
// 0x00000280 System.Single UnityEngine.UI.LayoutGroup::get_flexibleHeight()
extern void LayoutGroup_get_flexibleHeight_m59E16B746E1A0B6BB6DACFC8D6152BF579FCCD5D (void);
// 0x00000281 System.Int32 UnityEngine.UI.LayoutGroup::get_layoutPriority()
extern void LayoutGroup_get_layoutPriority_mAD4B8787F1A48D790AE512ED665F38341E15EA13 (void);
// 0x00000282 System.Void UnityEngine.UI.LayoutGroup::SetLayoutHorizontal()
// 0x00000283 System.Void UnityEngine.UI.LayoutGroup::SetLayoutVertical()
// 0x00000284 System.Void UnityEngine.UI.LayoutGroup::.ctor()
extern void LayoutGroup__ctor_m2C5C490F181E3F50BA80CC50925CA350B9FD3606 (void);
// 0x00000285 System.Void UnityEngine.UI.LayoutGroup::OnEnable()
extern void LayoutGroup_OnEnable_m7E8EB5898A5FDFAD1961A3E187BDEC7AEB19C8D0 (void);
// 0x00000286 System.Void UnityEngine.UI.LayoutGroup::OnDisable()
extern void LayoutGroup_OnDisable_mCBBAA98E2608635DE371E69143109F6F3EF7B1E2 (void);
// 0x00000287 System.Void UnityEngine.UI.LayoutGroup::OnDidApplyAnimationProperties()
extern void LayoutGroup_OnDidApplyAnimationProperties_m9E692318A31C3C10F7624B5074D4B370E610545F (void);
// 0x00000288 System.Single UnityEngine.UI.LayoutGroup::GetTotalMinSize(System.Int32)
extern void LayoutGroup_GetTotalMinSize_m02F81DE9ED57CCBD6610D08AA52CB4483A14D6C4 (void);
// 0x00000289 System.Single UnityEngine.UI.LayoutGroup::GetTotalPreferredSize(System.Int32)
extern void LayoutGroup_GetTotalPreferredSize_m26A75A466512570E3416211F5820D19E5C334041 (void);
// 0x0000028A System.Single UnityEngine.UI.LayoutGroup::GetTotalFlexibleSize(System.Int32)
extern void LayoutGroup_GetTotalFlexibleSize_m2DD1DC991BB246FC1BECB613E4581C26EEC3A5C2 (void);
// 0x0000028B System.Single UnityEngine.UI.LayoutGroup::GetStartOffset(System.Int32,System.Single)
extern void LayoutGroup_GetStartOffset_mA584346FF8D8CDA081C5218D9A8B8CE5C32D49F3 (void);
// 0x0000028C System.Single UnityEngine.UI.LayoutGroup::GetAlignmentOnAxis(System.Int32)
extern void LayoutGroup_GetAlignmentOnAxis_m5A480C265D82670D4E55F497D62193DEEE83185D (void);
// 0x0000028D System.Void UnityEngine.UI.LayoutGroup::SetLayoutInputForAxis(System.Single,System.Single,System.Single,System.Int32)
extern void LayoutGroup_SetLayoutInputForAxis_m1CFF9123134CD5524FD85132A1F3BC2906CC0B3D (void);
// 0x0000028E System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxis(UnityEngine.RectTransform,System.Int32,System.Single)
extern void LayoutGroup_SetChildAlongAxis_mB027128152BE0E28E93FEEE4832742DF12053D29 (void);
// 0x0000028F System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxisWithScale(UnityEngine.RectTransform,System.Int32,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxisWithScale_mAC805B74A9ED9D6E60B4D2B1F5C8F90B58018977 (void);
// 0x00000290 System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxis(UnityEngine.RectTransform,System.Int32,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxis_mEB8A7D3F5151D0CABAD9ADDBEDA28E6BC950D95E (void);
// 0x00000291 System.Void UnityEngine.UI.LayoutGroup::SetChildAlongAxisWithScale(UnityEngine.RectTransform,System.Int32,System.Single,System.Single,System.Single)
extern void LayoutGroup_SetChildAlongAxisWithScale_mCE45E4D84779E88D4B6D733B37E2F9D08BAB183E (void);
// 0x00000292 System.Boolean UnityEngine.UI.LayoutGroup::get_isRootLayoutGroup()
extern void LayoutGroup_get_isRootLayoutGroup_m11B6FC2BA36E3D1E3156BFB6FC0A49964AEC0624 (void);
// 0x00000293 System.Void UnityEngine.UI.LayoutGroup::OnRectTransformDimensionsChange()
extern void LayoutGroup_OnRectTransformDimensionsChange_m571418DF9E3FE2876D8ED083017B51899DA69027 (void);
// 0x00000294 System.Void UnityEngine.UI.LayoutGroup::OnTransformChildrenChanged()
extern void LayoutGroup_OnTransformChildrenChanged_m808102C3FCB5D1536191BD1B25228CCF2A736694 (void);
// 0x00000295 System.Void UnityEngine.UI.LayoutGroup::SetProperty(T&,T)
// 0x00000296 System.Void UnityEngine.UI.LayoutGroup::SetDirty()
extern void LayoutGroup_SetDirty_m645D3182781863DCF43C794556AFE0A7B5342D2A (void);
// 0x00000297 System.Collections.IEnumerator UnityEngine.UI.LayoutGroup::DelayedSetDirty(UnityEngine.RectTransform)
extern void LayoutGroup_DelayedSetDirty_m3FC471D3FEAE926C5BF4FB9FE86048BEE4ADE7D3 (void);
// 0x00000298 System.Void UnityEngine.UI.LayoutRebuilder::Initialize(UnityEngine.RectTransform)
extern void LayoutRebuilder_Initialize_mED8FA1C15C499B1CF164C8410C7EC7AA1193E639 (void);
// 0x00000299 System.Void UnityEngine.UI.LayoutRebuilder::Clear()
extern void LayoutRebuilder_Clear_mD62901890B7A04550D68F469D30A69A10A3ECA8E (void);
// 0x0000029A System.Void UnityEngine.UI.LayoutRebuilder::.cctor()
extern void LayoutRebuilder__cctor_m59F750AAC5A8255D5E91C85D730BD21DC47A2439 (void);
// 0x0000029B System.Void UnityEngine.UI.LayoutRebuilder::ReapplyDrivenProperties(UnityEngine.RectTransform)
extern void LayoutRebuilder_ReapplyDrivenProperties_m1F244863563056F136E31CE9CD1F9007787D7BB1 (void);
// 0x0000029C UnityEngine.Transform UnityEngine.UI.LayoutRebuilder::get_transform()
extern void LayoutRebuilder_get_transform_mE890ECF65A84FF10C7EE33BBC73D01503908D090 (void);
// 0x0000029D System.Boolean UnityEngine.UI.LayoutRebuilder::IsDestroyed()
extern void LayoutRebuilder_IsDestroyed_m7F48C198D7E6EAFB29195BFEAFB00500D9BB2392 (void);
// 0x0000029E System.Void UnityEngine.UI.LayoutRebuilder::StripDisabledBehavioursFromList(System.Collections.Generic.List`1<UnityEngine.Component>)
extern void LayoutRebuilder_StripDisabledBehavioursFromList_mC658A39EF2EAA28CACE766C50A4FE65DDEE8C290 (void);
// 0x0000029F System.Void UnityEngine.UI.LayoutRebuilder::ForceRebuildLayoutImmediate(UnityEngine.RectTransform)
extern void LayoutRebuilder_ForceRebuildLayoutImmediate_m376EFAB3B8D5C86A085DCFEECA0538B8BA03B732 (void);
// 0x000002A0 System.Void UnityEngine.UI.LayoutRebuilder::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void LayoutRebuilder_Rebuild_mC1C4D6DD8BDF52780C68301A56F5E8448ADEC9EB (void);
// 0x000002A1 System.Void UnityEngine.UI.LayoutRebuilder::PerformLayoutControl(UnityEngine.RectTransform,UnityEngine.Events.UnityAction`1<UnityEngine.Component>)
extern void LayoutRebuilder_PerformLayoutControl_m70054B6DA220D54A47D2FF6F7C96B36C1D315D7F (void);
// 0x000002A2 System.Void UnityEngine.UI.LayoutRebuilder::PerformLayoutCalculation(UnityEngine.RectTransform,UnityEngine.Events.UnityAction`1<UnityEngine.Component>)
extern void LayoutRebuilder_PerformLayoutCalculation_m224DE892AF29C076175A728D28B996A45E178A6A (void);
// 0x000002A3 System.Void UnityEngine.UI.LayoutRebuilder::MarkLayoutForRebuild(UnityEngine.RectTransform)
extern void LayoutRebuilder_MarkLayoutForRebuild_m09DF1D1C1BFD83B8D9181E982D745F26D891343A (void);
// 0x000002A4 System.Boolean UnityEngine.UI.LayoutRebuilder::ValidController(UnityEngine.RectTransform,System.Collections.Generic.List`1<UnityEngine.Component>)
extern void LayoutRebuilder_ValidController_m64AEE496D31C069A7CB33947B450AC8241F49823 (void);
// 0x000002A5 System.Void UnityEngine.UI.LayoutRebuilder::MarkLayoutRootForRebuild(UnityEngine.RectTransform)
extern void LayoutRebuilder_MarkLayoutRootForRebuild_m78BC85D18FDF71D66D6D05BA5D2D6C6D06F202D3 (void);
// 0x000002A6 System.Void UnityEngine.UI.LayoutRebuilder::LayoutComplete()
extern void LayoutRebuilder_LayoutComplete_mEB05ECB1C59C036E473A9F2ACDF677573503174B (void);
// 0x000002A7 System.Void UnityEngine.UI.LayoutRebuilder::GraphicUpdateComplete()
extern void LayoutRebuilder_GraphicUpdateComplete_mCB905F4C297FF55213084D38A15EBCBBB0ADDF25 (void);
// 0x000002A8 System.Int32 UnityEngine.UI.LayoutRebuilder::GetHashCode()
extern void LayoutRebuilder_GetHashCode_mA5573A92ACEB8458B044C8672510A81B0610B886 (void);
// 0x000002A9 System.Boolean UnityEngine.UI.LayoutRebuilder::Equals(System.Object)
extern void LayoutRebuilder_Equals_m09E017404762129F3FBC3AF56CFA3DD3C0BDA123 (void);
// 0x000002AA System.String UnityEngine.UI.LayoutRebuilder::ToString()
extern void LayoutRebuilder_ToString_mB41A4B211755A589013385975FE15C99B5253F13 (void);
// 0x000002AB System.Void UnityEngine.UI.LayoutRebuilder::.ctor()
extern void LayoutRebuilder__ctor_m4067180E573DA57B9FB140E2E69B8D3A683F351E (void);
// 0x000002AC System.Single UnityEngine.UI.LayoutUtility::GetMinSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetMinSize_m8A7CF1EB3F3D1CDC9FFA33F34761322F42701CB3 (void);
// 0x000002AD System.Single UnityEngine.UI.LayoutUtility::GetPreferredSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetPreferredSize_mC035133B1A561870CB8FE14212D8E71BFF1742F6 (void);
// 0x000002AE System.Single UnityEngine.UI.LayoutUtility::GetFlexibleSize(UnityEngine.RectTransform,System.Int32)
extern void LayoutUtility_GetFlexibleSize_m8BFABBB6A7B83002524740DB6AD822E9569F6D3D (void);
// 0x000002AF System.Single UnityEngine.UI.LayoutUtility::GetMinWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetMinWidth_m0A249DB81847B782C7C353BF71B5B7640E9E9170 (void);
// 0x000002B0 System.Single UnityEngine.UI.LayoutUtility::GetPreferredWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetPreferredWidth_m8195172DCEFB387447F1C79FAA4BE820E6FA7DAF (void);
// 0x000002B1 System.Single UnityEngine.UI.LayoutUtility::GetFlexibleWidth(UnityEngine.RectTransform)
extern void LayoutUtility_GetFlexibleWidth_m76471A259115F8DB090C6CC1D2635D86B11E6667 (void);
// 0x000002B2 System.Single UnityEngine.UI.LayoutUtility::GetMinHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetMinHeight_m84472A7D150C6C97225CD75391ABF26191B46B89 (void);
// 0x000002B3 System.Single UnityEngine.UI.LayoutUtility::GetPreferredHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetPreferredHeight_m9CCEAD3F208DDB5449BE5F6A9586AFC53182FEF3 (void);
// 0x000002B4 System.Single UnityEngine.UI.LayoutUtility::GetFlexibleHeight(UnityEngine.RectTransform)
extern void LayoutUtility_GetFlexibleHeight_m9233B5C740407532073977D64E59B1BB879515BC (void);
// 0x000002B5 System.Single UnityEngine.UI.LayoutUtility::GetLayoutProperty(UnityEngine.RectTransform,System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>,System.Single)
extern void LayoutUtility_GetLayoutProperty_m9CFFE5E3F3D739D5C675B2B33522ABC0275005A8 (void);
// 0x000002B6 System.Single UnityEngine.UI.LayoutUtility::GetLayoutProperty(UnityEngine.RectTransform,System.Func`2<UnityEngine.UI.ILayoutElement,System.Single>,System.Single,UnityEngine.UI.ILayoutElement&)
extern void LayoutUtility_GetLayoutProperty_m1A6AF4D756528EB97FC81880079431766DC28F38 (void);
// 0x000002B7 System.Void UnityEngine.UI.VerticalLayoutGroup::.ctor()
extern void VerticalLayoutGroup__ctor_m8305F2E2D8759A1F113865FAF45A9534B7102A1E (void);
// 0x000002B8 System.Void UnityEngine.UI.VerticalLayoutGroup::CalculateLayoutInputHorizontal()
extern void VerticalLayoutGroup_CalculateLayoutInputHorizontal_mC9BF7EF4A3236F05DCBB1B2F2A23C6EC2ED0C672 (void);
// 0x000002B9 System.Void UnityEngine.UI.VerticalLayoutGroup::CalculateLayoutInputVertical()
extern void VerticalLayoutGroup_CalculateLayoutInputVertical_m0F339BFE5894A745EC7A47D238BC1CEA0264A807 (void);
// 0x000002BA System.Void UnityEngine.UI.VerticalLayoutGroup::SetLayoutHorizontal()
extern void VerticalLayoutGroup_SetLayoutHorizontal_m943B5CB7CC5ED5053E69CA7297E2DB5F23E0BE7D (void);
// 0x000002BB System.Void UnityEngine.UI.VerticalLayoutGroup::SetLayoutVertical()
extern void VerticalLayoutGroup_SetLayoutVertical_m5731A6B9245778C72AFC45863D04DC7CA0735EF7 (void);
// 0x000002BC UnityEngine.RectTransform UnityEngine.UI.Mask::get_rectTransform()
extern void Mask_get_rectTransform_m9D5D4775C23D46D7ED977FE1E00424A2E592B0FC (void);
// 0x000002BD System.Boolean UnityEngine.UI.Mask::get_showMaskGraphic()
extern void Mask_get_showMaskGraphic_m8D7850F726E5E2786B594B426E581B396DC4E707 (void);
// 0x000002BE System.Void UnityEngine.UI.Mask::set_showMaskGraphic(System.Boolean)
extern void Mask_set_showMaskGraphic_m26E107B60ECE971C8EC07A92755F3DB5308CF568 (void);
// 0x000002BF UnityEngine.UI.Graphic UnityEngine.UI.Mask::get_graphic()
extern void Mask_get_graphic_m5B49E746A9E93A4D1BAAFD83F9ACB7C90633B5B3 (void);
// 0x000002C0 System.Void UnityEngine.UI.Mask::.ctor()
extern void Mask__ctor_mDB0377FD085C92709863EBD1ADD669613A72492B (void);
// 0x000002C1 System.Boolean UnityEngine.UI.Mask::MaskEnabled()
extern void Mask_MaskEnabled_m7AFB8DA19DCF7C660BB22AE523EE5EF986F1A699 (void);
// 0x000002C2 System.Void UnityEngine.UI.Mask::OnSiblingGraphicEnabledDisabled()
extern void Mask_OnSiblingGraphicEnabledDisabled_m919DBB6316B2A3DF8825C82E66B1AC01F28F97B4 (void);
// 0x000002C3 System.Void UnityEngine.UI.Mask::OnEnable()
extern void Mask_OnEnable_m63EE8B765F07480CF68C4E92A09A87EBAC751B89 (void);
// 0x000002C4 System.Void UnityEngine.UI.Mask::OnDisable()
extern void Mask_OnDisable_m78F7F27003EE6C0B47A1FA35C64AE15321D1A4D7 (void);
// 0x000002C5 System.Boolean UnityEngine.UI.Mask::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void Mask_IsRaycastLocationValid_mA814C1B406D968DB92C90B9698C521FE7716663D (void);
// 0x000002C6 UnityEngine.Material UnityEngine.UI.Mask::GetModifiedMaterial(UnityEngine.Material)
extern void Mask_GetModifiedMaterial_m708D77F5312C3DA4B3E2D5D71046393BE533DDEF (void);
// 0x000002C7 System.Void UnityEngine.UI.MaskUtilities::Notify2DMaskStateChanged(UnityEngine.Component)
extern void MaskUtilities_Notify2DMaskStateChanged_m103B0AF2E08CF02F93FE1F273BF757F72CA17FFC (void);
// 0x000002C8 System.Void UnityEngine.UI.MaskUtilities::NotifyStencilStateChanged(UnityEngine.Component)
extern void MaskUtilities_NotifyStencilStateChanged_mC41DE843E662F1DF71008DCC7F241DAF46955DE5 (void);
// 0x000002C9 UnityEngine.Transform UnityEngine.UI.MaskUtilities::FindRootSortOverrideCanvas(UnityEngine.Transform)
extern void MaskUtilities_FindRootSortOverrideCanvas_m7E303D29D22F86212DD023C8854211C525629FDD (void);
// 0x000002CA System.Int32 UnityEngine.UI.MaskUtilities::GetStencilDepth(UnityEngine.Transform,UnityEngine.Transform)
extern void MaskUtilities_GetStencilDepth_m44DDA4B7EA65CE2648B4585602B9761C369FA8F1 (void);
// 0x000002CB System.Boolean UnityEngine.UI.MaskUtilities::IsDescendantOrSelf(UnityEngine.Transform,UnityEngine.Transform)
extern void MaskUtilities_IsDescendantOrSelf_m63215BDD8B4DBE2A94AF5C65C6500A3157211195 (void);
// 0x000002CC UnityEngine.UI.RectMask2D UnityEngine.UI.MaskUtilities::GetRectMaskForClippable(UnityEngine.UI.IClippable)
extern void MaskUtilities_GetRectMaskForClippable_mA22FA75F79D98E00CF0B0A41DFBD0FC2D4DC2F28 (void);
// 0x000002CD System.Void UnityEngine.UI.MaskUtilities::GetRectMasksForClip(UnityEngine.UI.RectMask2D,System.Collections.Generic.List`1<UnityEngine.UI.RectMask2D>)
extern void MaskUtilities_GetRectMasksForClip_mD205C0800E173F71E21F1DEDE40D8FE643E1536F (void);
// 0x000002CE System.Void UnityEngine.UI.MaskUtilities::.ctor()
extern void MaskUtilities__ctor_m35905E18A945C6E943BE796B62D79382982F902A (void);
// 0x000002CF UnityEngine.UI.MaskableGraphic/CullStateChangedEvent UnityEngine.UI.MaskableGraphic::get_onCullStateChanged()
extern void MaskableGraphic_get_onCullStateChanged_m9CF82537F28EEEC73E48B437DF49EA0B2312BDE8 (void);
// 0x000002D0 System.Void UnityEngine.UI.MaskableGraphic::set_onCullStateChanged(UnityEngine.UI.MaskableGraphic/CullStateChangedEvent)
extern void MaskableGraphic_set_onCullStateChanged_m20FDC3099975522E7B72995B688D21AF99A77504 (void);
// 0x000002D1 System.Boolean UnityEngine.UI.MaskableGraphic::get_maskable()
extern void MaskableGraphic_get_maskable_mFC2D6219D6A2BBB98989FA5EC7DA6E970142F422 (void);
// 0x000002D2 System.Void UnityEngine.UI.MaskableGraphic::set_maskable(System.Boolean)
extern void MaskableGraphic_set_maskable_mF9E02A4A578C16D988B076E290A162443A4BDEB8 (void);
// 0x000002D3 System.Boolean UnityEngine.UI.MaskableGraphic::get_isMaskingGraphic()
extern void MaskableGraphic_get_isMaskingGraphic_mAB10CA54042B113C62DB1982BFEB289F73A19868 (void);
// 0x000002D4 System.Void UnityEngine.UI.MaskableGraphic::set_isMaskingGraphic(System.Boolean)
extern void MaskableGraphic_set_isMaskingGraphic_m9AC52E85DAD1BA0064883224CB408DF0B45E3BA4 (void);
// 0x000002D5 UnityEngine.Material UnityEngine.UI.MaskableGraphic::GetModifiedMaterial(UnityEngine.Material)
extern void MaskableGraphic_GetModifiedMaterial_m8FCD645EF28C3D0E9C40DE6CA88C4A6FA9D1DC31 (void);
// 0x000002D6 System.Void UnityEngine.UI.MaskableGraphic::Cull(UnityEngine.Rect,System.Boolean)
extern void MaskableGraphic_Cull_mF00BD574B73F921345341DFDCCD90C76914325F9 (void);
// 0x000002D7 System.Void UnityEngine.UI.MaskableGraphic::UpdateCull(System.Boolean)
extern void MaskableGraphic_UpdateCull_m2DCD0726782AE0782A49EE46F409C270F769865B (void);
// 0x000002D8 System.Void UnityEngine.UI.MaskableGraphic::SetClipRect(UnityEngine.Rect,System.Boolean)
extern void MaskableGraphic_SetClipRect_mE9B8DBF437AE3A64C7083F93E846255D51D914B4 (void);
// 0x000002D9 System.Void UnityEngine.UI.MaskableGraphic::SetClipSoftness(UnityEngine.Vector2)
extern void MaskableGraphic_SetClipSoftness_m1B840B94309647C54C47E635BD6A4596995D0E47 (void);
// 0x000002DA System.Void UnityEngine.UI.MaskableGraphic::OnEnable()
extern void MaskableGraphic_OnEnable_m1C4621EF4156EA27E72335253F9270C7FCD7E42B (void);
// 0x000002DB System.Void UnityEngine.UI.MaskableGraphic::OnDisable()
extern void MaskableGraphic_OnDisable_m4DD5B717F92C2ECD7F0B9589A2E9EE020D977E9A (void);
// 0x000002DC System.Void UnityEngine.UI.MaskableGraphic::OnTransformParentChanged()
extern void MaskableGraphic_OnTransformParentChanged_mCD5C5C91E934480A384615A511DDD7D439FDB1CB (void);
// 0x000002DD System.Void UnityEngine.UI.MaskableGraphic::ParentMaskStateChanged()
extern void MaskableGraphic_ParentMaskStateChanged_m694F5C7651E14953B42F4B6B0AC5C08B01FCDF03 (void);
// 0x000002DE System.Void UnityEngine.UI.MaskableGraphic::OnCanvasHierarchyChanged()
extern void MaskableGraphic_OnCanvasHierarchyChanged_m4CFDF1C4903CAE89DAB4ED5A789182FABCE2E14E (void);
// 0x000002DF UnityEngine.Rect UnityEngine.UI.MaskableGraphic::get_rootCanvasRect()
extern void MaskableGraphic_get_rootCanvasRect_m2751607479FE02BDA964AF973CDD19B62B208DA4 (void);
// 0x000002E0 System.Void UnityEngine.UI.MaskableGraphic::UpdateClipParent()
extern void MaskableGraphic_UpdateClipParent_m5073282E1101E9ACBFF214505B37C945BC013FFC (void);
// 0x000002E1 System.Void UnityEngine.UI.MaskableGraphic::RecalculateClipping()
extern void MaskableGraphic_RecalculateClipping_m51967B70B3A54B811F3E2FAEC8CB68A1E36E97AD (void);
// 0x000002E2 System.Void UnityEngine.UI.MaskableGraphic::RecalculateMasking()
extern void MaskableGraphic_RecalculateMasking_m798019D3372397B5F0E09E0DCE64DC415CABE672 (void);
// 0x000002E3 System.Void UnityEngine.UI.MaskableGraphic::.ctor()
extern void MaskableGraphic__ctor_mFB0B016448AB894C802C279ED045DB1E4DE5D8FC (void);
// 0x000002E4 UnityEngine.GameObject UnityEngine.UI.MaskableGraphic::UnityEngine.UI.IClippable.get_gameObject()
extern void MaskableGraphic_UnityEngine_UI_IClippable_get_gameObject_m68A7FD1C35B1E5A0A1FFF135F89A62F4F1521DB8 (void);
// 0x000002E5 UnityEngine.Material UnityEngine.UI.IMaterialModifier::GetModifiedMaterial(UnityEngine.Material)
// 0x000002E6 System.Void UnityEngine.UI.Misc::Destroy(UnityEngine.Object)
extern void Misc_Destroy_m1CD11D22DBCAE5B55367EAD70A946B1AD3043EFF (void);
// 0x000002E7 System.Void UnityEngine.UI.Misc::DestroyImmediate(UnityEngine.Object)
extern void Misc_DestroyImmediate_mC8B94565596867AE4C03E38C6C1DD0CF82C429A5 (void);
// 0x000002E8 System.Boolean UnityEngine.UI.MultipleDisplayUtilities::GetRelativeMousePositionForDrag(UnityEngine.EventSystems.PointerEventData,UnityEngine.Vector2&)
extern void MultipleDisplayUtilities_GetRelativeMousePositionForDrag_mDA78E1728A60D2B05F5225EB8B77BF03B81A0D5A (void);
// 0x000002E9 UnityEngine.Vector2 UnityEngine.UI.MultipleDisplayUtilities::GetMousePositionRelativeToMainDisplayResolution()
extern void MultipleDisplayUtilities_GetMousePositionRelativeToMainDisplayResolution_m2D3CB08174B28122E201011E77C0A1BE762C948C (void);
// 0x000002EA UnityEngine.UI.Navigation/Mode UnityEngine.UI.Navigation::get_mode()
extern void Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E (void);
// 0x000002EB System.Void UnityEngine.UI.Navigation::set_mode(UnityEngine.UI.Navigation/Mode)
extern void Navigation_set_mode_m35D711F016E4F41230C710882696279BA04399D2 (void);
// 0x000002EC UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnUp()
extern void Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E (void);
// 0x000002ED System.Void UnityEngine.UI.Navigation::set_selectOnUp(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnUp_mB61F72B8B577FB9424150F42EC57767A8F3B4453 (void);
// 0x000002EE UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnDown()
extern void Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398 (void);
// 0x000002EF System.Void UnityEngine.UI.Navigation::set_selectOnDown(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnDown_m0EEC959195918EDDBF71B0D640D42BB85061D0A5 (void);
// 0x000002F0 UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnLeft()
extern void Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA (void);
// 0x000002F1 System.Void UnityEngine.UI.Navigation::set_selectOnLeft(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnLeft_m51D5BC3AE8C05E4233269B961ADA98BB3FBF9D53 (void);
// 0x000002F2 UnityEngine.UI.Selectable UnityEngine.UI.Navigation::get_selectOnRight()
extern void Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328 (void);
// 0x000002F3 System.Void UnityEngine.UI.Navigation::set_selectOnRight(UnityEngine.UI.Selectable)
extern void Navigation_set_selectOnRight_m3429A471ECA0295B871C161960FB3F8C1D1D3571 (void);
// 0x000002F4 UnityEngine.UI.Navigation UnityEngine.UI.Navigation::get_defaultNavigation()
extern void Navigation_get_defaultNavigation_m00087A1157696556EB1D34E20D7324DE4788F6C6 (void);
// 0x000002F5 System.Boolean UnityEngine.UI.Navigation::Equals(UnityEngine.UI.Navigation)
extern void Navigation_Equals_mBAEC72440C03A77E0981AD0FEFDFF823984B7CE0 (void);
// 0x000002F6 System.Void UnityEngine.UI.RawImage::.ctor()
extern void RawImage__ctor_mF23F5B56BE2C19DDD001D183C7DD1FBA2C7AF6D4 (void);
// 0x000002F7 UnityEngine.Texture UnityEngine.UI.RawImage::get_mainTexture()
extern void RawImage_get_mainTexture_mAC899EE3026C3BD076E21B43D840D05162F56E29 (void);
// 0x000002F8 UnityEngine.Texture UnityEngine.UI.RawImage::get_texture()
extern void RawImage_get_texture_m992AF81884D22B9ADC97A800AB931DCB4140954E (void);
// 0x000002F9 System.Void UnityEngine.UI.RawImage::set_texture(UnityEngine.Texture)
extern void RawImage_set_texture_m63BC52D3B64A3BFD0EC182034FDD51E9A46F99F9 (void);
// 0x000002FA UnityEngine.Rect UnityEngine.UI.RawImage::get_uvRect()
extern void RawImage_get_uvRect_m3BE55AF17D17143B9F084B1FA4689C5A52A0F530 (void);
// 0x000002FB System.Void UnityEngine.UI.RawImage::set_uvRect(UnityEngine.Rect)
extern void RawImage_set_uvRect_m843AD44101EA0FB2C7E684095BDAFDCA579935AE (void);
// 0x000002FC System.Void UnityEngine.UI.RawImage::SetNativeSize()
extern void RawImage_SetNativeSize_m531E57A3BEF08985C084AB73117CFB0F9B2417AC (void);
// 0x000002FD System.Void UnityEngine.UI.RawImage::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void RawImage_OnPopulateMesh_m816B08ED2C7E33CA0A7CF767C66E4223F0DAEBE1 (void);
// 0x000002FE System.Void UnityEngine.UI.RawImage::OnDidApplyAnimationProperties()
extern void RawImage_OnDidApplyAnimationProperties_m003499201735E7AF73A5F31113DD6323778A4BCE (void);
// 0x000002FF UnityEngine.Vector4 UnityEngine.UI.RectMask2D::get_padding()
extern void RectMask2D_get_padding_mAE70AF9C0ABD28AD225A2BFD4965C45883B31E20 (void);
// 0x00000300 System.Void UnityEngine.UI.RectMask2D::set_padding(UnityEngine.Vector4)
extern void RectMask2D_set_padding_m199BEF4609F76B4E68DC99B1D531E0E13A551F66 (void);
// 0x00000301 UnityEngine.Vector2Int UnityEngine.UI.RectMask2D::get_softness()
extern void RectMask2D_get_softness_m67F6E132A98566FC2191856462BAB6F7080884C8 (void);
// 0x00000302 System.Void UnityEngine.UI.RectMask2D::set_softness(UnityEngine.Vector2Int)
extern void RectMask2D_set_softness_m2B1C4456CD59EEAD639EBE76EE4BC34BFDA1B8B4 (void);
// 0x00000303 UnityEngine.Canvas UnityEngine.UI.RectMask2D::get_Canvas()
extern void RectMask2D_get_Canvas_m67059D0D1FF1530F8AA8B5D94F1A27D559C25C41 (void);
// 0x00000304 UnityEngine.Rect UnityEngine.UI.RectMask2D::get_canvasRect()
extern void RectMask2D_get_canvasRect_m2CFEAC92FBAE3C1E500CAD0BDB3D6CDD263558BA (void);
// 0x00000305 UnityEngine.RectTransform UnityEngine.UI.RectMask2D::get_rectTransform()
extern void RectMask2D_get_rectTransform_m2EE1645888FCF5638B9B59EE4087B96FB53574AC (void);
// 0x00000306 System.Void UnityEngine.UI.RectMask2D::.ctor()
extern void RectMask2D__ctor_m9BB0431D7C6969736E453CCC924EFA770DCF0F7F (void);
// 0x00000307 System.Void UnityEngine.UI.RectMask2D::OnEnable()
extern void RectMask2D_OnEnable_m4FF369F853F32C62E211DC69F27A599AC61E35AF (void);
// 0x00000308 System.Void UnityEngine.UI.RectMask2D::OnDisable()
extern void RectMask2D_OnDisable_m4EF6F587CD9090C18F353C7E914E3292B40401B0 (void);
// 0x00000309 System.Boolean UnityEngine.UI.RectMask2D::IsRaycastLocationValid(UnityEngine.Vector2,UnityEngine.Camera)
extern void RectMask2D_IsRaycastLocationValid_m139090CB5B0299545AAC8E223A9E86A91452E445 (void);
// 0x0000030A UnityEngine.Rect UnityEngine.UI.RectMask2D::get_rootCanvasRect()
extern void RectMask2D_get_rootCanvasRect_m17D93FBA715A10CB270CE52C794B1FB687DD5431 (void);
// 0x0000030B System.Void UnityEngine.UI.RectMask2D::PerformClipping()
extern void RectMask2D_PerformClipping_m69EEBDE9F0F74FB6C5CCE8DCDA316AC277429EE7 (void);
// 0x0000030C System.Void UnityEngine.UI.RectMask2D::UpdateClipSoftness()
extern void RectMask2D_UpdateClipSoftness_mCD3F4A7BB0E8F82614A971404C60B10B9771665C (void);
// 0x0000030D System.Void UnityEngine.UI.RectMask2D::AddClippable(UnityEngine.UI.IClippable)
extern void RectMask2D_AddClippable_m6DCAA0D7BF3FEE0E6CBE627ABDB764EA8822B761 (void);
// 0x0000030E System.Void UnityEngine.UI.RectMask2D::RemoveClippable(UnityEngine.UI.IClippable)
extern void RectMask2D_RemoveClippable_m65177F56AAD85127135142626833817B5A427B76 (void);
// 0x0000030F System.Void UnityEngine.UI.RectMask2D::OnTransformParentChanged()
extern void RectMask2D_OnTransformParentChanged_m4ECFFB298A62E01AE2FB50ED9F5E7E6EF7531E00 (void);
// 0x00000310 System.Void UnityEngine.UI.RectMask2D::OnCanvasHierarchyChanged()
extern void RectMask2D_OnCanvasHierarchyChanged_mE447313B871CBE3B97E680BA7B6790B1C6489C72 (void);
// 0x00000311 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_content()
extern void ScrollRect_get_content_m7F3FC07991CE67DFBEE4068D6E14ED0A1E26B526 (void);
// 0x00000312 System.Void UnityEngine.UI.ScrollRect::set_content(UnityEngine.RectTransform)
extern void ScrollRect_set_content_m1D59059E32D0563BDF511A547978965B2C4F81F7 (void);
// 0x00000313 System.Boolean UnityEngine.UI.ScrollRect::get_horizontal()
extern void ScrollRect_get_horizontal_mCD2647148C80355520AEE9A171E2DDFFD007D6C4 (void);
// 0x00000314 System.Void UnityEngine.UI.ScrollRect::set_horizontal(System.Boolean)
extern void ScrollRect_set_horizontal_m62275F56268C9EF22F5E71F68BC8026779A60B7E (void);
// 0x00000315 System.Boolean UnityEngine.UI.ScrollRect::get_vertical()
extern void ScrollRect_get_vertical_mEF9A7604052858643BCDF9A76BE2086E0AAC085B (void);
// 0x00000316 System.Void UnityEngine.UI.ScrollRect::set_vertical(System.Boolean)
extern void ScrollRect_set_vertical_m635C296C6E8CD7B41AF22296D51E34D3C1BEF850 (void);
// 0x00000317 UnityEngine.UI.ScrollRect/MovementType UnityEngine.UI.ScrollRect::get_movementType()
extern void ScrollRect_get_movementType_m96D7F76863CD4288A6E36481A9ED3028EA37CFFC (void);
// 0x00000318 System.Void UnityEngine.UI.ScrollRect::set_movementType(UnityEngine.UI.ScrollRect/MovementType)
extern void ScrollRect_set_movementType_m2953F8BC5ABFDD067D5DDC54AE15953DBD754942 (void);
// 0x00000319 System.Single UnityEngine.UI.ScrollRect::get_elasticity()
extern void ScrollRect_get_elasticity_m34D19B22AA11D0ECC4B348639594CEDF35018B85 (void);
// 0x0000031A System.Void UnityEngine.UI.ScrollRect::set_elasticity(System.Single)
extern void ScrollRect_set_elasticity_mB1C87653D202F8BA28EC911B782791FBB8C494B8 (void);
// 0x0000031B System.Boolean UnityEngine.UI.ScrollRect::get_inertia()
extern void ScrollRect_get_inertia_m20D064DAB868538A30848F8078A5437B6D62FF73 (void);
// 0x0000031C System.Void UnityEngine.UI.ScrollRect::set_inertia(System.Boolean)
extern void ScrollRect_set_inertia_m10EE4253B2F07D743197089F42B3AEE3C25BC9FF (void);
// 0x0000031D System.Single UnityEngine.UI.ScrollRect::get_decelerationRate()
extern void ScrollRect_get_decelerationRate_m353068153F2D59EEB1AEBD2BC79DDEB680F5CF3D (void);
// 0x0000031E System.Void UnityEngine.UI.ScrollRect::set_decelerationRate(System.Single)
extern void ScrollRect_set_decelerationRate_m3A4F636EDD5C1196B065B16DAD9BCB8B6BF97F20 (void);
// 0x0000031F System.Single UnityEngine.UI.ScrollRect::get_scrollSensitivity()
extern void ScrollRect_get_scrollSensitivity_m8A671FB9A7C6E4F52DD3E572BCC01C04FA7FA806 (void);
// 0x00000320 System.Void UnityEngine.UI.ScrollRect::set_scrollSensitivity(System.Single)
extern void ScrollRect_set_scrollSensitivity_mE55DE672446762A94155115BE9D2FD5702F86A46 (void);
// 0x00000321 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_viewport()
extern void ScrollRect_get_viewport_mD3C6CD4F782A5FC7F886BA1CC4DB6CF250DF164D (void);
// 0x00000322 System.Void UnityEngine.UI.ScrollRect::set_viewport(UnityEngine.RectTransform)
extern void ScrollRect_set_viewport_mBBD71C770D85A0C3B131B919255CEE568EA48506 (void);
// 0x00000323 UnityEngine.UI.Scrollbar UnityEngine.UI.ScrollRect::get_horizontalScrollbar()
extern void ScrollRect_get_horizontalScrollbar_m258E5BA6988FD113301575E1107A37D506515273 (void);
// 0x00000324 System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbar(UnityEngine.UI.Scrollbar)
extern void ScrollRect_set_horizontalScrollbar_mA67D54C0D2CE7E492F6E58190EE00BB1A46BFC3A (void);
// 0x00000325 UnityEngine.UI.Scrollbar UnityEngine.UI.ScrollRect::get_verticalScrollbar()
extern void ScrollRect_get_verticalScrollbar_m0A9EBD87C90FBC567C11D37ECEBD2E6A7218BD0E (void);
// 0x00000326 System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbar(UnityEngine.UI.Scrollbar)
extern void ScrollRect_set_verticalScrollbar_mF02C8BDC24D4FB53A5B25ACFC61B9134BC5ABB61 (void);
// 0x00000327 UnityEngine.UI.ScrollRect/ScrollbarVisibility UnityEngine.UI.ScrollRect::get_horizontalScrollbarVisibility()
extern void ScrollRect_get_horizontalScrollbarVisibility_mC43D0E4908D8876D399B15F36A8D98B827C77DDC (void);
// 0x00000328 System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbarVisibility(UnityEngine.UI.ScrollRect/ScrollbarVisibility)
extern void ScrollRect_set_horizontalScrollbarVisibility_m2D6DB4D340121E55942254C331B5EA343D0ED082 (void);
// 0x00000329 UnityEngine.UI.ScrollRect/ScrollbarVisibility UnityEngine.UI.ScrollRect::get_verticalScrollbarVisibility()
extern void ScrollRect_get_verticalScrollbarVisibility_m8D671BA3821D2F3F263DAC0C7FE1487333326DA9 (void);
// 0x0000032A System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbarVisibility(UnityEngine.UI.ScrollRect/ScrollbarVisibility)
extern void ScrollRect_set_verticalScrollbarVisibility_m20B34375553122E7EEA5BEEDBFD80E87E18177F6 (void);
// 0x0000032B System.Single UnityEngine.UI.ScrollRect::get_horizontalScrollbarSpacing()
extern void ScrollRect_get_horizontalScrollbarSpacing_m4418B98A218392087300D54F085ECEB8FE54E9A3 (void);
// 0x0000032C System.Void UnityEngine.UI.ScrollRect::set_horizontalScrollbarSpacing(System.Single)
extern void ScrollRect_set_horizontalScrollbarSpacing_m22675D0F7497561D02FC4171023BD297688D445F (void);
// 0x0000032D System.Single UnityEngine.UI.ScrollRect::get_verticalScrollbarSpacing()
extern void ScrollRect_get_verticalScrollbarSpacing_m611F47D7B342D1649DF95FF20BF6B1846CC6961C (void);
// 0x0000032E System.Void UnityEngine.UI.ScrollRect::set_verticalScrollbarSpacing(System.Single)
extern void ScrollRect_set_verticalScrollbarSpacing_m782C4FC20B2D4C50D151344F6E501BD03BBBD8B5 (void);
// 0x0000032F UnityEngine.UI.ScrollRect/ScrollRectEvent UnityEngine.UI.ScrollRect::get_onValueChanged()
extern void ScrollRect_get_onValueChanged_mB59CCC8D8CD14BEB23018EDEE69EDB1EEE32C08B (void);
// 0x00000330 System.Void UnityEngine.UI.ScrollRect::set_onValueChanged(UnityEngine.UI.ScrollRect/ScrollRectEvent)
extern void ScrollRect_set_onValueChanged_m56C696AD9D6D36B5A1A702B72D21B44365CB24CC (void);
// 0x00000331 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_viewRect()
extern void ScrollRect_get_viewRect_m4CAAF3A523BAB284A6DA9D5EC45057D7EE51D89A (void);
// 0x00000332 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::get_velocity()
extern void ScrollRect_get_velocity_m44CA563C38ED997693167D354904EF8139C0C9D9 (void);
// 0x00000333 System.Void UnityEngine.UI.ScrollRect::set_velocity(UnityEngine.Vector2)
extern void ScrollRect_set_velocity_mF149AD6C33EDC6F469B2A572A21751A6420EDB4E (void);
// 0x00000334 UnityEngine.RectTransform UnityEngine.UI.ScrollRect::get_rectTransform()
extern void ScrollRect_get_rectTransform_m8DB7B0810D6E5D34C973716FCAC50C5B259DA3FE (void);
// 0x00000335 System.Void UnityEngine.UI.ScrollRect::.ctor()
extern void ScrollRect__ctor_mBBD973627D003DFD7A55474B678F70BFC02E4B99 (void);
// 0x00000336 System.Void UnityEngine.UI.ScrollRect::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void ScrollRect_Rebuild_mD3D65CBBA3547A87A73EFF2D5516C9558C9D7694 (void);
// 0x00000337 System.Void UnityEngine.UI.ScrollRect::LayoutComplete()
extern void ScrollRect_LayoutComplete_mB2EB41711791810DE2C5A219F54084DFD1C9C8A8 (void);
// 0x00000338 System.Void UnityEngine.UI.ScrollRect::GraphicUpdateComplete()
extern void ScrollRect_GraphicUpdateComplete_m99BDEBF15E0912DBFA651B23347D298F6A2D95A7 (void);
// 0x00000339 System.Void UnityEngine.UI.ScrollRect::UpdateCachedData()
extern void ScrollRect_UpdateCachedData_m08E0AC380D5C5DD2BA5072C465E13690AFAD1AE6 (void);
// 0x0000033A System.Void UnityEngine.UI.ScrollRect::OnEnable()
extern void ScrollRect_OnEnable_m6B32C0F1789C68F8BB0CE74544F064E4F4D0C4F4 (void);
// 0x0000033B System.Void UnityEngine.UI.ScrollRect::OnDisable()
extern void ScrollRect_OnDisable_m73602C6393005CB74565608201F6E95AA184C9AE (void);
// 0x0000033C System.Boolean UnityEngine.UI.ScrollRect::IsActive()
extern void ScrollRect_IsActive_mBA755BC1C46E74199B97A7101E6949D6DFAFA2EF (void);
// 0x0000033D System.Void UnityEngine.UI.ScrollRect::EnsureLayoutHasRebuilt()
extern void ScrollRect_EnsureLayoutHasRebuilt_mD2A10A4F2E6B8F7964203FD8EFFB316E0C1F0F05 (void);
// 0x0000033E System.Void UnityEngine.UI.ScrollRect::StopMovement()
extern void ScrollRect_StopMovement_m1F488BEC0F7EA905CE7EAD421BCD1933E2CF2E55 (void);
// 0x0000033F System.Void UnityEngine.UI.ScrollRect::OnScroll(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnScroll_m2614593B93CCC14C6BF84EC3362D0F873CA5F70D (void);
// 0x00000340 System.Void UnityEngine.UI.ScrollRect::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnInitializePotentialDrag_m0D6B75E40AB0952544DC5ED2A6E551DECBD783B1 (void);
// 0x00000341 System.Void UnityEngine.UI.ScrollRect::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnBeginDrag_m3F388158339494482D1B6C87F07AF7F340B9C2A3 (void);
// 0x00000342 System.Void UnityEngine.UI.ScrollRect::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnEndDrag_m14F35F7B13EBEFC3EDF8F4F339D6BD17015EA27C (void);
// 0x00000343 System.Void UnityEngine.UI.ScrollRect::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void ScrollRect_OnDrag_mDF40D32B4403B7D7CF2D59BAE04D8CE7824DFDA3 (void);
// 0x00000344 System.Void UnityEngine.UI.ScrollRect::SetContentAnchoredPosition(UnityEngine.Vector2)
extern void ScrollRect_SetContentAnchoredPosition_mBA6FAAA668D7F15508B2CEC7765CDEE525516A45 (void);
// 0x00000345 System.Void UnityEngine.UI.ScrollRect::LateUpdate()
extern void ScrollRect_LateUpdate_m5799552B786F3CFF3AD972E5CCCA834850CB9612 (void);
// 0x00000346 System.Void UnityEngine.UI.ScrollRect::UpdatePrevData()
extern void ScrollRect_UpdatePrevData_m2DCB69FE758212196471BE93B26BB5BBF8D1F227 (void);
// 0x00000347 System.Void UnityEngine.UI.ScrollRect::UpdateScrollbars(UnityEngine.Vector2)
extern void ScrollRect_UpdateScrollbars_m9070717C80898346C4044011C497023BB14C1669 (void);
// 0x00000348 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::get_normalizedPosition()
extern void ScrollRect_get_normalizedPosition_m064ABEFDFBCD4B9E01A01A9802297827AA5C8B5E (void);
// 0x00000349 System.Void UnityEngine.UI.ScrollRect::set_normalizedPosition(UnityEngine.Vector2)
extern void ScrollRect_set_normalizedPosition_mB1DB78D03B3ACF444E9F05944A482DEB9BC52EFD (void);
// 0x0000034A System.Single UnityEngine.UI.ScrollRect::get_horizontalNormalizedPosition()
extern void ScrollRect_get_horizontalNormalizedPosition_m9DAB8C7B610E7608DF2A4E37F6592EA805B2AFFB (void);
// 0x0000034B System.Void UnityEngine.UI.ScrollRect::set_horizontalNormalizedPosition(System.Single)
extern void ScrollRect_set_horizontalNormalizedPosition_m6E4EE949EFDB63389929D10A6EA484B7A67A510C (void);
// 0x0000034C System.Single UnityEngine.UI.ScrollRect::get_verticalNormalizedPosition()
extern void ScrollRect_get_verticalNormalizedPosition_m2610419B87DC4D38682C49457CDCF0D7993039A1 (void);
// 0x0000034D System.Void UnityEngine.UI.ScrollRect::set_verticalNormalizedPosition(System.Single)
extern void ScrollRect_set_verticalNormalizedPosition_m5224C3751F3C93C4F6BAD63AD439DB1D1C9FB405 (void);
// 0x0000034E System.Void UnityEngine.UI.ScrollRect::SetHorizontalNormalizedPosition(System.Single)
extern void ScrollRect_SetHorizontalNormalizedPosition_m5C1BA3A7C9E76C637A30778244EFD61A09686B56 (void);
// 0x0000034F System.Void UnityEngine.UI.ScrollRect::SetVerticalNormalizedPosition(System.Single)
extern void ScrollRect_SetVerticalNormalizedPosition_m6F7EA0650DE73E6066794040A851A6616CF70816 (void);
// 0x00000350 System.Void UnityEngine.UI.ScrollRect::SetNormalizedPosition(System.Single,System.Int32)
extern void ScrollRect_SetNormalizedPosition_mDE21FF15D57B81231447F4123C8385DDA66F5939 (void);
// 0x00000351 System.Single UnityEngine.UI.ScrollRect::RubberDelta(System.Single,System.Single)
extern void ScrollRect_RubberDelta_m1FF0368AD83A2E0398713D9B6C1E1959C600FC9A (void);
// 0x00000352 System.Void UnityEngine.UI.ScrollRect::OnRectTransformDimensionsChange()
extern void ScrollRect_OnRectTransformDimensionsChange_mB4B86CCC66F0BB23FCA325D510D6619B9885FF92 (void);
// 0x00000353 System.Boolean UnityEngine.UI.ScrollRect::get_hScrollingNeeded()
extern void ScrollRect_get_hScrollingNeeded_mA906B60373FBF3980BADE84D2554668ACF580E77 (void);
// 0x00000354 System.Boolean UnityEngine.UI.ScrollRect::get_vScrollingNeeded()
extern void ScrollRect_get_vScrollingNeeded_mD9953600A5FBB510E37884A9B85E7E249487FA85 (void);
// 0x00000355 System.Void UnityEngine.UI.ScrollRect::CalculateLayoutInputHorizontal()
extern void ScrollRect_CalculateLayoutInputHorizontal_mA15641491BB2B1A14470F27EA9A6D5A679B6F331 (void);
// 0x00000356 System.Void UnityEngine.UI.ScrollRect::CalculateLayoutInputVertical()
extern void ScrollRect_CalculateLayoutInputVertical_m90C18A8168305E5E7266B6C9FBC0633F8455ECD4 (void);
// 0x00000357 System.Single UnityEngine.UI.ScrollRect::get_minWidth()
extern void ScrollRect_get_minWidth_mACC47A71B6DE98E83968950C10E4CBDA4BE8235E (void);
// 0x00000358 System.Single UnityEngine.UI.ScrollRect::get_preferredWidth()
extern void ScrollRect_get_preferredWidth_mA942CC4D2620ADA96B52C85D85DDC44CEABA0245 (void);
// 0x00000359 System.Single UnityEngine.UI.ScrollRect::get_flexibleWidth()
extern void ScrollRect_get_flexibleWidth_m3CCB92FBADE66795DE7C7E88AAB0FABB94002624 (void);
// 0x0000035A System.Single UnityEngine.UI.ScrollRect::get_minHeight()
extern void ScrollRect_get_minHeight_m06D03D93A566C4B1C40127A013793C63FFEBBB34 (void);
// 0x0000035B System.Single UnityEngine.UI.ScrollRect::get_preferredHeight()
extern void ScrollRect_get_preferredHeight_m137F08C4E69F195E882100587331DB539ABBB3BC (void);
// 0x0000035C System.Single UnityEngine.UI.ScrollRect::get_flexibleHeight()
extern void ScrollRect_get_flexibleHeight_mFA28B6541E9BA06727D530C77F2456309DFC8A94 (void);
// 0x0000035D System.Int32 UnityEngine.UI.ScrollRect::get_layoutPriority()
extern void ScrollRect_get_layoutPriority_m821763E3D87C3A8EAE8A19A0DD42FD6B3C1EB110 (void);
// 0x0000035E System.Void UnityEngine.UI.ScrollRect::SetLayoutHorizontal()
extern void ScrollRect_SetLayoutHorizontal_m8BA1A9251684C54F3285C57E3E50A51C8AA6382C (void);
// 0x0000035F System.Void UnityEngine.UI.ScrollRect::SetLayoutVertical()
extern void ScrollRect_SetLayoutVertical_m734054404869720AEBEB189A7EE81A77BCB595E8 (void);
// 0x00000360 System.Void UnityEngine.UI.ScrollRect::UpdateScrollbarVisibility()
extern void ScrollRect_UpdateScrollbarVisibility_m25A602E7A418DADCF59D0AE019EA22724B886E5C (void);
// 0x00000361 System.Void UnityEngine.UI.ScrollRect::UpdateOneScrollbarVisibility(System.Boolean,System.Boolean,UnityEngine.UI.ScrollRect/ScrollbarVisibility,UnityEngine.UI.Scrollbar)
extern void ScrollRect_UpdateOneScrollbarVisibility_m5D467DDD4182171886FFB73962BBFEF965A6E361 (void);
// 0x00000362 System.Void UnityEngine.UI.ScrollRect::UpdateScrollbarLayout()
extern void ScrollRect_UpdateScrollbarLayout_mB93549D9A2CA6B6CEA6C6361E58D1804C9B19B96 (void);
// 0x00000363 System.Void UnityEngine.UI.ScrollRect::UpdateBounds()
extern void ScrollRect_UpdateBounds_m4CAA83FD9B50E62152FB5EF32614FCFC2E9B5F4B (void);
// 0x00000364 System.Void UnityEngine.UI.ScrollRect::AdjustBounds(UnityEngine.Bounds&,UnityEngine.Vector2&,UnityEngine.Vector3&,UnityEngine.Vector3&)
extern void ScrollRect_AdjustBounds_mDEFEA53E51AF1299C7A5DBA5897E7CEB78CE1485 (void);
// 0x00000365 UnityEngine.Bounds UnityEngine.UI.ScrollRect::GetBounds()
extern void ScrollRect_GetBounds_m4E34C67E606612B3B541AC10CABD1A8DD60BFB51 (void);
// 0x00000366 UnityEngine.Bounds UnityEngine.UI.ScrollRect::InternalGetBounds(UnityEngine.Vector3[],UnityEngine.Matrix4x4&)
extern void ScrollRect_InternalGetBounds_m57F907604A74BB8C930F0E8E83643B58B4F70EF4 (void);
// 0x00000367 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::CalculateOffset(UnityEngine.Vector2)
extern void ScrollRect_CalculateOffset_m198A2DD190E762F54FFDF9ADB4F9D09C3C72C49D (void);
// 0x00000368 UnityEngine.Vector2 UnityEngine.UI.ScrollRect::InternalCalculateOffset(UnityEngine.Bounds&,UnityEngine.Bounds&,System.Boolean,System.Boolean,UnityEngine.UI.ScrollRect/MovementType,UnityEngine.Vector2&)
extern void ScrollRect_InternalCalculateOffset_mBD16E2DE166034B7CA7DDC2DBD22D7C2AF0E699C (void);
// 0x00000369 System.Void UnityEngine.UI.ScrollRect::SetDirty()
extern void ScrollRect_SetDirty_m5B4DB26D806EBDE5054538B78DCD848D244EE16A (void);
// 0x0000036A System.Void UnityEngine.UI.ScrollRect::SetDirtyCaching()
extern void ScrollRect_SetDirtyCaching_mEC7A66F35782EDAC92076CDF249DA9E77E2511F1 (void);
// 0x0000036B UnityEngine.Transform UnityEngine.UI.ScrollRect::UnityEngine.UI.ICanvasElement.get_transform()
extern void ScrollRect_UnityEngine_UI_ICanvasElement_get_transform_m5BCD58D5BF9AF3D8FB743417F783A815344B38B0 (void);
// 0x0000036C UnityEngine.RectTransform UnityEngine.UI.Scrollbar::get_handleRect()
extern void Scrollbar_get_handleRect_m104FE0AF1CA77701926B9247530BBDE16CD03421 (void);
// 0x0000036D System.Void UnityEngine.UI.Scrollbar::set_handleRect(UnityEngine.RectTransform)
extern void Scrollbar_set_handleRect_mF48210CE73FD1F67BAC1CAD76FA07132FDBA5C40 (void);
// 0x0000036E UnityEngine.UI.Scrollbar/Direction UnityEngine.UI.Scrollbar::get_direction()
extern void Scrollbar_get_direction_m9DE22D72DE14200D3B7F70410865872034DB3C26 (void);
// 0x0000036F System.Void UnityEngine.UI.Scrollbar::set_direction(UnityEngine.UI.Scrollbar/Direction)
extern void Scrollbar_set_direction_mF62CEE52EFDA9D19B07DB3E4B14F8A202DBEB38E (void);
// 0x00000370 System.Void UnityEngine.UI.Scrollbar::.ctor()
extern void Scrollbar__ctor_mB9ED51581883273DDE3E80BB5843177CF391A973 (void);
// 0x00000371 System.Single UnityEngine.UI.Scrollbar::get_value()
extern void Scrollbar_get_value_mB50146DF84D5A824370AEB1E41336B3034D3D7A0 (void);
// 0x00000372 System.Void UnityEngine.UI.Scrollbar::set_value(System.Single)
extern void Scrollbar_set_value_mC653E9457FC7D581904F1F854495BF82D1048C4F (void);
// 0x00000373 System.Void UnityEngine.UI.Scrollbar::SetValueWithoutNotify(System.Single)
extern void Scrollbar_SetValueWithoutNotify_mBA3A6C8E4E46C9D2292EE1C63342641F24FDFB65 (void);
// 0x00000374 System.Single UnityEngine.UI.Scrollbar::get_size()
extern void Scrollbar_get_size_m86928300A01FD31035162D85AB3FD2EF2609E53B (void);
// 0x00000375 System.Void UnityEngine.UI.Scrollbar::set_size(System.Single)
extern void Scrollbar_set_size_mD67D27E3E45E4E68157685A71E4CAC070FFF2919 (void);
// 0x00000376 System.Int32 UnityEngine.UI.Scrollbar::get_numberOfSteps()
extern void Scrollbar_get_numberOfSteps_m714B1DCD3B8F7BB16F0888BA96717A24022AEC79 (void);
// 0x00000377 System.Void UnityEngine.UI.Scrollbar::set_numberOfSteps(System.Int32)
extern void Scrollbar_set_numberOfSteps_m7064A8877F8963A27E36BAB31AA0635B5FA6FF73 (void);
// 0x00000378 UnityEngine.UI.Scrollbar/ScrollEvent UnityEngine.UI.Scrollbar::get_onValueChanged()
extern void Scrollbar_get_onValueChanged_mC58EA55182B24E42CEBC360FBA3F0533B3CF0FF8 (void);
// 0x00000379 System.Void UnityEngine.UI.Scrollbar::set_onValueChanged(UnityEngine.UI.Scrollbar/ScrollEvent)
extern void Scrollbar_set_onValueChanged_mF3ACFCE81E88851377F3DF12328FF6EAC75519D7 (void);
// 0x0000037A System.Single UnityEngine.UI.Scrollbar::get_stepSize()
extern void Scrollbar_get_stepSize_mDBAC88FA8AC842435BBED92163F0D4FB7F74620E (void);
// 0x0000037B System.Void UnityEngine.UI.Scrollbar::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Scrollbar_Rebuild_m7E265DB3E505F59959D76F974128B950BDCD8D34 (void);
// 0x0000037C System.Void UnityEngine.UI.Scrollbar::LayoutComplete()
extern void Scrollbar_LayoutComplete_mBC4100641697FCD54B4A09588E65C556D2AE6780 (void);
// 0x0000037D System.Void UnityEngine.UI.Scrollbar::GraphicUpdateComplete()
extern void Scrollbar_GraphicUpdateComplete_m53FC1F514861C873B1D4FC4DEA2A23AFD96317F5 (void);
// 0x0000037E System.Void UnityEngine.UI.Scrollbar::OnEnable()
extern void Scrollbar_OnEnable_m085DDBA4B1B49C44F25D4B46DF7E2A68D015DFA0 (void);
// 0x0000037F System.Void UnityEngine.UI.Scrollbar::OnDisable()
extern void Scrollbar_OnDisable_m32660E3BFE2FAC5696A39CBD51FFD90126884D97 (void);
// 0x00000380 System.Void UnityEngine.UI.Scrollbar::Update()
extern void Scrollbar_Update_m7D470599F3F1877F3149649C638D99E6761D1F0B (void);
// 0x00000381 System.Void UnityEngine.UI.Scrollbar::UpdateCachedReferences()
extern void Scrollbar_UpdateCachedReferences_m887202A953CD6A96434A026857CCD2E343220F4F (void);
// 0x00000382 System.Void UnityEngine.UI.Scrollbar::Set(System.Single,System.Boolean)
extern void Scrollbar_Set_m5954E234014C71EE954348B9829868226C727669 (void);
// 0x00000383 System.Void UnityEngine.UI.Scrollbar::OnRectTransformDimensionsChange()
extern void Scrollbar_OnRectTransformDimensionsChange_m9223B26A4F446E33771DE873A1C97E6C47AFAD0F (void);
// 0x00000384 UnityEngine.UI.Scrollbar/Axis UnityEngine.UI.Scrollbar::get_axis()
extern void Scrollbar_get_axis_m45122AD4E1A73A6555181B4A6A9C86DE2EE07EE3 (void);
// 0x00000385 System.Boolean UnityEngine.UI.Scrollbar::get_reverseValue()
extern void Scrollbar_get_reverseValue_m71865B3B46FC42B226BA85FFDBFA97E01144519D (void);
// 0x00000386 System.Void UnityEngine.UI.Scrollbar::UpdateVisuals()
extern void Scrollbar_UpdateVisuals_m4461DBA1BE6D20450162164D1A16D738551B289D (void);
// 0x00000387 System.Void UnityEngine.UI.Scrollbar::UpdateDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_UpdateDrag_m4054447E0018CAE8A27BB8FE06CB29DAFA233BD6 (void);
// 0x00000388 System.Void UnityEngine.UI.Scrollbar::DoUpdateDrag(UnityEngine.Vector2,System.Single)
extern void Scrollbar_DoUpdateDrag_m35075A4C4F34F88BF08B5556DD0BF6EF2C681950 (void);
// 0x00000389 System.Boolean UnityEngine.UI.Scrollbar::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_MayDrag_m6E73F2C637DC75313CB95CC09A7620E7E261CB53 (void);
// 0x0000038A System.Void UnityEngine.UI.Scrollbar::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnBeginDrag_m9A65BCF26559DBA675E4510309833A01200AF72E (void);
// 0x0000038B System.Void UnityEngine.UI.Scrollbar::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnDrag_mE070D6E80D00BCB2537E1F27E31E48B68B4D5616 (void);
// 0x0000038C System.Void UnityEngine.UI.Scrollbar::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnPointerDown_m51D30F596D1BF64484960370BE045DD986B558F1 (void);
// 0x0000038D System.Collections.IEnumerator UnityEngine.UI.Scrollbar::ClickRepeat(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_ClickRepeat_mFF5D7554F28B24960944E2CB6B1E61597706B0FA (void);
// 0x0000038E System.Collections.IEnumerator UnityEngine.UI.Scrollbar::ClickRepeat(UnityEngine.Vector2,UnityEngine.Camera)
extern void Scrollbar_ClickRepeat_mE4895549A915C1D6255EC52CAAA50D7D93FAC24B (void);
// 0x0000038F System.Void UnityEngine.UI.Scrollbar::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnPointerUp_m6B451E29A019186FB0D0BD8135CD055D61583D75 (void);
// 0x00000390 System.Void UnityEngine.UI.Scrollbar::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Scrollbar_OnMove_m478ED366B5461D37FB215820D0C6BCD5EBC01B6D (void);
// 0x00000391 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnLeft()
extern void Scrollbar_FindSelectableOnLeft_m374B5705442CC40C149835019C9EAB55C079F6BB (void);
// 0x00000392 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnRight()
extern void Scrollbar_FindSelectableOnRight_mC2CAC3EB7EA1FC16155EF3E90B6E088B5E09FD5B (void);
// 0x00000393 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnUp()
extern void Scrollbar_FindSelectableOnUp_m9ADBB11544C5D9D09414A397C4B22B19E60C252F (void);
// 0x00000394 UnityEngine.UI.Selectable UnityEngine.UI.Scrollbar::FindSelectableOnDown()
extern void Scrollbar_FindSelectableOnDown_m3A2776AE65F7CDFE6F3AF88B607F06A39B35C7D2 (void);
// 0x00000395 System.Void UnityEngine.UI.Scrollbar::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void Scrollbar_OnInitializePotentialDrag_m45B071544234C35AD0DD56A9CED8507EA07D21EB (void);
// 0x00000396 System.Void UnityEngine.UI.Scrollbar::SetDirection(UnityEngine.UI.Scrollbar/Direction,System.Boolean)
extern void Scrollbar_SetDirection_mA9024B104537EDF63AFF1C437A8F0D193CA562F8 (void);
// 0x00000397 UnityEngine.Transform UnityEngine.UI.Scrollbar::UnityEngine.UI.ICanvasElement.get_transform()
extern void Scrollbar_UnityEngine_UI_ICanvasElement_get_transform_m582D531E9319A901C4C02AB8BE873C0F286AAC11 (void);
// 0x00000398 UnityEngine.UI.Selectable[] UnityEngine.UI.Selectable::get_allSelectablesArray()
extern void Selectable_get_allSelectablesArray_m04E41DC3D73950382018953096CCCB4666D75D78 (void);
// 0x00000399 System.Int32 UnityEngine.UI.Selectable::get_allSelectableCount()
extern void Selectable_get_allSelectableCount_mB446CA731CCC10DF19C4337BD7BF51BE9F6B0DEA (void);
// 0x0000039A System.Collections.Generic.List`1<UnityEngine.UI.Selectable> UnityEngine.UI.Selectable::get_allSelectables()
extern void Selectable_get_allSelectables_m54D3FAA34B85B657086A45FC0D535A92D2AB8597 (void);
// 0x0000039B System.Int32 UnityEngine.UI.Selectable::AllSelectablesNoAlloc(UnityEngine.UI.Selectable[])
extern void Selectable_AllSelectablesNoAlloc_mE78AA8943AAE64691E36C0663F137D115A81F825 (void);
// 0x0000039C UnityEngine.UI.Navigation UnityEngine.UI.Selectable::get_navigation()
extern void Selectable_get_navigation_mE0FE811B11269EFDEE21C98701059F786580FB50 (void);
// 0x0000039D System.Void UnityEngine.UI.Selectable::set_navigation(UnityEngine.UI.Navigation)
extern void Selectable_set_navigation_m9680DCFEEBF25F70A64BF24B5890A429CB389029 (void);
// 0x0000039E UnityEngine.UI.Selectable/Transition UnityEngine.UI.Selectable::get_transition()
extern void Selectable_get_transition_mC5883DD4A0EC4A58F41285A8684B018309041D9E (void);
// 0x0000039F System.Void UnityEngine.UI.Selectable::set_transition(UnityEngine.UI.Selectable/Transition)
extern void Selectable_set_transition_mDED891CACA218179385815C92CD5CC931C588FB0 (void);
// 0x000003A0 UnityEngine.UI.ColorBlock UnityEngine.UI.Selectable::get_colors()
extern void Selectable_get_colors_m9E63E13A7B6C40CB0F20414FFBE15873BE5F3E4E (void);
// 0x000003A1 System.Void UnityEngine.UI.Selectable::set_colors(UnityEngine.UI.ColorBlock)
extern void Selectable_set_colors_m7A8172ACD89481DC904523D216A7C7D42BE50DF7 (void);
// 0x000003A2 UnityEngine.UI.SpriteState UnityEngine.UI.Selectable::get_spriteState()
extern void Selectable_get_spriteState_m0A341E18A903DAEF82259637F2D09B1CEC4DFD85 (void);
// 0x000003A3 System.Void UnityEngine.UI.Selectable::set_spriteState(UnityEngine.UI.SpriteState)
extern void Selectable_set_spriteState_mE6E733B21046B975C3F73C594D7B726F19AD8B90 (void);
// 0x000003A4 UnityEngine.UI.AnimationTriggers UnityEngine.UI.Selectable::get_animationTriggers()
extern void Selectable_get_animationTriggers_m6F8F01A53FACD447624E24686E89F05EBEBF64E3 (void);
// 0x000003A5 System.Void UnityEngine.UI.Selectable::set_animationTriggers(UnityEngine.UI.AnimationTriggers)
extern void Selectable_set_animationTriggers_m725D39C037387AEBE4F0DFD4426426D1B0629ED1 (void);
// 0x000003A6 UnityEngine.UI.Graphic UnityEngine.UI.Selectable::get_targetGraphic()
extern void Selectable_get_targetGraphic_mB12CA26D04922ADB483397992561CA3941E78F92 (void);
// 0x000003A7 System.Void UnityEngine.UI.Selectable::set_targetGraphic(UnityEngine.UI.Graphic)
extern void Selectable_set_targetGraphic_m69C71056F05A767EC0D2ED14E80ABCA15B5E2FDE (void);
// 0x000003A8 System.Boolean UnityEngine.UI.Selectable::get_interactable()
extern void Selectable_get_interactable_m4A788C1B797A434D9033539514D5E20610E2664F (void);
// 0x000003A9 System.Void UnityEngine.UI.Selectable::set_interactable(System.Boolean)
extern void Selectable_set_interactable_mF0897CD627B603DE1F3714FFD8B121AB694E0B6B (void);
// 0x000003AA System.Boolean UnityEngine.UI.Selectable::get_isPointerInside()
extern void Selectable_get_isPointerInside_m18E62C81578321F6B3B232F2F1668FF46AC1B96A (void);
// 0x000003AB System.Void UnityEngine.UI.Selectable::set_isPointerInside(System.Boolean)
extern void Selectable_set_isPointerInside_mCCB1EE89C56C75E08A2D3F0F6125F0F0278EC281 (void);
// 0x000003AC System.Boolean UnityEngine.UI.Selectable::get_isPointerDown()
extern void Selectable_get_isPointerDown_m89F51DDA55A4613A0647C1EFC8BB892E02DADDC6 (void);
// 0x000003AD System.Void UnityEngine.UI.Selectable::set_isPointerDown(System.Boolean)
extern void Selectable_set_isPointerDown_m5F89C05475A68DFF2AB2144462D361F9DF9BD812 (void);
// 0x000003AE System.Boolean UnityEngine.UI.Selectable::get_hasSelection()
extern void Selectable_get_hasSelection_mDC9AB6128F5289F7CCA06C7AFE5C69B90EC8E051 (void);
// 0x000003AF System.Void UnityEngine.UI.Selectable::set_hasSelection(System.Boolean)
extern void Selectable_set_hasSelection_m104FB1A00B8F942EEE8FC5309760CE7AC2276FE7 (void);
// 0x000003B0 System.Void UnityEngine.UI.Selectable::.ctor()
extern void Selectable__ctor_mDADF3659E1B861470987564058F1D0B89FF3660A (void);
// 0x000003B1 UnityEngine.UI.Image UnityEngine.UI.Selectable::get_image()
extern void Selectable_get_image_m74FFCB0802A2E8380B33314F53A9748370D1C9F7 (void);
// 0x000003B2 System.Void UnityEngine.UI.Selectable::set_image(UnityEngine.UI.Image)
extern void Selectable_set_image_m0E818601F5B5959AB91259DAB7385FAD9B0210BB (void);
// 0x000003B3 UnityEngine.Animator UnityEngine.UI.Selectable::get_animator()
extern void Selectable_get_animator_m6117A378EE32B632B32C7441887BABF3ABA1C9A8 (void);
// 0x000003B4 System.Void UnityEngine.UI.Selectable::Awake()
extern void Selectable_Awake_m9902C8912907C8E252F066B80E46C002DFCC94E5 (void);
// 0x000003B5 System.Void UnityEngine.UI.Selectable::OnCanvasGroupChanged()
extern void Selectable_OnCanvasGroupChanged_m9D61A1DF7A7D0DE90B027D635DA023F2AE92D59E (void);
// 0x000003B6 System.Boolean UnityEngine.UI.Selectable::IsInteractable()
extern void Selectable_IsInteractable_mEA20244501979E1CF199CA93406348CD690FCC0C (void);
// 0x000003B7 System.Void UnityEngine.UI.Selectable::OnDidApplyAnimationProperties()
extern void Selectable_OnDidApplyAnimationProperties_mB8D3432A68D0AD88E707EDF0005FD493F8F2DCE4 (void);
// 0x000003B8 System.Void UnityEngine.UI.Selectable::OnEnable()
extern void Selectable_OnEnable_mA3FFC8965134ECD3B5A2E4028CACBEFAAB80315F (void);
// 0x000003B9 System.Void UnityEngine.UI.Selectable::OnTransformParentChanged()
extern void Selectable_OnTransformParentChanged_m4B01503ED75E5F209858B78E20BAE3F87D2EC131 (void);
// 0x000003BA System.Void UnityEngine.UI.Selectable::OnSetProperty()
extern void Selectable_OnSetProperty_mFAB235B05A20A34BE15ABE7190E8EDC1B6E616EA (void);
// 0x000003BB System.Void UnityEngine.UI.Selectable::OnDisable()
extern void Selectable_OnDisable_m258B5CEC8D2EA2F2FF1225CB76970EF089BF6349 (void);
// 0x000003BC UnityEngine.UI.Selectable/SelectionState UnityEngine.UI.Selectable::get_currentSelectionState()
extern void Selectable_get_currentSelectionState_m37B79D51884A49924B92D1AE1BAA354C55CA1FD0 (void);
// 0x000003BD System.Void UnityEngine.UI.Selectable::InstantClearState()
extern void Selectable_InstantClearState_mEAC746472F389A3CF194938147F01CBD1120B587 (void);
// 0x000003BE System.Void UnityEngine.UI.Selectable::DoStateTransition(UnityEngine.UI.Selectable/SelectionState,System.Boolean)
extern void Selectable_DoStateTransition_m927C2A16FA000A1E2BD57B157F9C230FA235ED68 (void);
// 0x000003BF UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectable(UnityEngine.Vector3)
extern void Selectable_FindSelectable_m7197D69C5F25246DD57F86B660218D9F64F4902A (void);
// 0x000003C0 UnityEngine.Vector3 UnityEngine.UI.Selectable::GetPointOnRectEdge(UnityEngine.RectTransform,UnityEngine.Vector2)
extern void Selectable_GetPointOnRectEdge_mD500D4CD3E1541B610D04181241091241A0F5A28 (void);
// 0x000003C1 System.Void UnityEngine.UI.Selectable::Navigate(UnityEngine.EventSystems.AxisEventData,UnityEngine.UI.Selectable)
extern void Selectable_Navigate_m96B635DBE276C394922162C4C7B927CEB5AA16CF (void);
// 0x000003C2 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnLeft()
extern void Selectable_FindSelectableOnLeft_m501FD2B988BBFFDAD318800A4D164FB21F1AE315 (void);
// 0x000003C3 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnRight()
extern void Selectable_FindSelectableOnRight_mA5550ED566545FF1E5113E935F4F57B63F3760FA (void);
// 0x000003C4 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnUp()
extern void Selectable_FindSelectableOnUp_m26D12F3EBE3D07C4D69C639DE4D219B40886E8FA (void);
// 0x000003C5 UnityEngine.UI.Selectable UnityEngine.UI.Selectable::FindSelectableOnDown()
extern void Selectable_FindSelectableOnDown_m2EC533E6757FC29A2FABAB68A5E8D56394FE2637 (void);
// 0x000003C6 System.Void UnityEngine.UI.Selectable::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Selectable_OnMove_m5046BFC32450CE2F2EAF1B717A8BC07093B82697 (void);
// 0x000003C7 System.Void UnityEngine.UI.Selectable::StartColorTween(UnityEngine.Color,System.Boolean)
extern void Selectable_StartColorTween_m12987AE49EB48CCB154EEC150976A4D7C0E4368D (void);
// 0x000003C8 System.Void UnityEngine.UI.Selectable::DoSpriteSwap(UnityEngine.Sprite)
extern void Selectable_DoSpriteSwap_m0E056EA93743ADF5125CE102F87A73C5937E5852 (void);
// 0x000003C9 System.Void UnityEngine.UI.Selectable::TriggerAnimation(System.String)
extern void Selectable_TriggerAnimation_m2CDED21669A18BD20770EFED1319A9573CFA31EF (void);
// 0x000003CA System.Boolean UnityEngine.UI.Selectable::IsHighlighted()
extern void Selectable_IsHighlighted_mA816817EA9CD76759031AC0310E6925DE4E5C8BA (void);
// 0x000003CB System.Boolean UnityEngine.UI.Selectable::IsPressed()
extern void Selectable_IsPressed_m9605FD46CED6FB525E7CE95C0D1341D9FB2946C8 (void);
// 0x000003CC System.Void UnityEngine.UI.Selectable::EvaluateAndTransitionToSelectionState()
extern void Selectable_EvaluateAndTransitionToSelectionState_m70A67F91AFB94FAC63CF9C9551F2E81B852896EE (void);
// 0x000003CD System.Void UnityEngine.UI.Selectable::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerDown_m061689C2799399DCDAA05A08DCE26D087B46A840 (void);
// 0x000003CE System.Void UnityEngine.UI.Selectable::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerUp_m2D9280DBBFB84904DD468B6A231BFA5F493E8300 (void);
// 0x000003CF System.Void UnityEngine.UI.Selectable::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerEnter_mF67D44F4E9CA340034DAA3FE58674183DA2DF157 (void);
// 0x000003D0 System.Void UnityEngine.UI.Selectable::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void Selectable_OnPointerExit_m74266715C60B43A8DC6640C90E8FE55965294220 (void);
// 0x000003D1 System.Void UnityEngine.UI.Selectable::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void Selectable_OnSelect_mA9D63C2B429DC2ED93158B1109F99467542C24DE (void);
// 0x000003D2 System.Void UnityEngine.UI.Selectable::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void Selectable_OnDeselect_mEE6A5BF7CF1D34D0E94E9F5B22AB8223081DC643 (void);
// 0x000003D3 System.Void UnityEngine.UI.Selectable::Select()
extern void Selectable_Select_mF1D3E4BEF6C795B709FDC441930074ED9088A31D (void);
// 0x000003D4 System.Void UnityEngine.UI.Selectable::.cctor()
extern void Selectable__cctor_m06CFEB59AFEDFD37552B7D4D172711EDC24FD86E (void);
// 0x000003D5 System.Boolean UnityEngine.UI.SetPropertyUtility::SetColor(UnityEngine.Color&,UnityEngine.Color)
extern void SetPropertyUtility_SetColor_mB5174CC6EF9515E83B9FD7F2066ABEBA52B165B3 (void);
// 0x000003D6 System.Boolean UnityEngine.UI.SetPropertyUtility::SetStruct(T&,T)
// 0x000003D7 System.Boolean UnityEngine.UI.SetPropertyUtility::SetClass(T&,T)
// 0x000003D8 UnityEngine.RectTransform UnityEngine.UI.Slider::get_fillRect()
extern void Slider_get_fillRect_mEDD45CFE2E622B61B82469DBA18B52FC3C3C279D (void);
// 0x000003D9 System.Void UnityEngine.UI.Slider::set_fillRect(UnityEngine.RectTransform)
extern void Slider_set_fillRect_m7055CC8682DDB328A754116BDAE0AF6DFFF437AF (void);
// 0x000003DA UnityEngine.RectTransform UnityEngine.UI.Slider::get_handleRect()
extern void Slider_get_handleRect_m2EFF3788BEBE513F7C5CCD3E494F37C153F2AAD8 (void);
// 0x000003DB System.Void UnityEngine.UI.Slider::set_handleRect(UnityEngine.RectTransform)
extern void Slider_set_handleRect_m25A60ED142D621A5243E48AEDE097986FA3B2E10 (void);
// 0x000003DC UnityEngine.UI.Slider/Direction UnityEngine.UI.Slider::get_direction()
extern void Slider_get_direction_mE9A02803187D68D400284913BC6F93F587610022 (void);
// 0x000003DD System.Void UnityEngine.UI.Slider::set_direction(UnityEngine.UI.Slider/Direction)
extern void Slider_set_direction_m804216132A017C3D68832C8941B49B4038B5A72E (void);
// 0x000003DE System.Single UnityEngine.UI.Slider::get_minValue()
extern void Slider_get_minValue_m1C1AF023D40CD9C4816CA83C1216BDC0177BB3C4 (void);
// 0x000003DF System.Void UnityEngine.UI.Slider::set_minValue(System.Single)
extern void Slider_set_minValue_m9531D4EC6314F28CB1B2778862FC44E6109781B3 (void);
// 0x000003E0 System.Single UnityEngine.UI.Slider::get_maxValue()
extern void Slider_get_maxValue_m0066E03DC62047617783B6EB3589344CB57B3349 (void);
// 0x000003E1 System.Void UnityEngine.UI.Slider::set_maxValue(System.Single)
extern void Slider_set_maxValue_m45561A3731F4EB48C10715E062856824B5AEF20B (void);
// 0x000003E2 System.Boolean UnityEngine.UI.Slider::get_wholeNumbers()
extern void Slider_get_wholeNumbers_m8D2011D5DC11FAF8E24B3547683B0EF6B9F3936F (void);
// 0x000003E3 System.Void UnityEngine.UI.Slider::set_wholeNumbers(System.Boolean)
extern void Slider_set_wholeNumbers_m54BF44BC60EA3DB739F3DE35B1AE7B498ADC1036 (void);
// 0x000003E4 System.Single UnityEngine.UI.Slider::get_value()
extern void Slider_get_value_mA3B6A0E422E6FAB3013AAC6807DD4244D98B563D (void);
// 0x000003E5 System.Void UnityEngine.UI.Slider::set_value(System.Single)
extern void Slider_set_value_mCEA86111DBC0BCB1361B8E96EFCBAA7AF801F66C (void);
// 0x000003E6 System.Void UnityEngine.UI.Slider::SetValueWithoutNotify(System.Single)
extern void Slider_SetValueWithoutNotify_m061B64AFCE6AC1F281A89784C8567C450B76217A (void);
// 0x000003E7 System.Single UnityEngine.UI.Slider::get_normalizedValue()
extern void Slider_get_normalizedValue_mEE13F0582A3A980C74804DA1E57D083DA30F4C09 (void);
// 0x000003E8 System.Void UnityEngine.UI.Slider::set_normalizedValue(System.Single)
extern void Slider_set_normalizedValue_mFF773CA2C18C7DC7003F731A738B6D845D19045D (void);
// 0x000003E9 UnityEngine.UI.Slider/SliderEvent UnityEngine.UI.Slider::get_onValueChanged()
extern void Slider_get_onValueChanged_m9D9177CDBF349783372AABF032F2D2B3178A84D6 (void);
// 0x000003EA System.Void UnityEngine.UI.Slider::set_onValueChanged(UnityEngine.UI.Slider/SliderEvent)
extern void Slider_set_onValueChanged_mDAEDCF0C4BAAC1D0610BE850E4563F1677511EEE (void);
// 0x000003EB System.Single UnityEngine.UI.Slider::get_stepSize()
extern void Slider_get_stepSize_m46A0B4FAD8DAACE6523D2B50D51955443482E226 (void);
// 0x000003EC System.Void UnityEngine.UI.Slider::.ctor()
extern void Slider__ctor_mAB7240B4FBB6B6428C5426AA0628AFCB99968411 (void);
// 0x000003ED System.Void UnityEngine.UI.Slider::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Slider_Rebuild_m20AD0C4E7EE5F2C1E75718298E8414F896415A9B (void);
// 0x000003EE System.Void UnityEngine.UI.Slider::LayoutComplete()
extern void Slider_LayoutComplete_m1D1C1486B1F457F35CDADD47D0C429CAD176AE9F (void);
// 0x000003EF System.Void UnityEngine.UI.Slider::GraphicUpdateComplete()
extern void Slider_GraphicUpdateComplete_mE44527ACA522A1F9A87C4B4063ADA4CF5D25F9F4 (void);
// 0x000003F0 System.Void UnityEngine.UI.Slider::OnEnable()
extern void Slider_OnEnable_mBC3CEE93CCFDC04B6C275B837A32BD45CD8A578C (void);
// 0x000003F1 System.Void UnityEngine.UI.Slider::OnDisable()
extern void Slider_OnDisable_m4D0E6DFD5E0EC3F78F779A35404968EDC7E374D2 (void);
// 0x000003F2 System.Void UnityEngine.UI.Slider::Update()
extern void Slider_Update_m40FCCCDE2D7C13639A653129171E0557ACAF494F (void);
// 0x000003F3 System.Void UnityEngine.UI.Slider::OnDidApplyAnimationProperties()
extern void Slider_OnDidApplyAnimationProperties_mE0AF1A75688D285E36D47B4569967C27B72E339A (void);
// 0x000003F4 System.Void UnityEngine.UI.Slider::UpdateCachedReferences()
extern void Slider_UpdateCachedReferences_m5683DC0B59751B8A436CE6C4F321F19CFC2F295D (void);
// 0x000003F5 System.Single UnityEngine.UI.Slider::ClampValue(System.Single)
extern void Slider_ClampValue_m424D036945D298F14F6EA66C8AF19A669BCEB8D7 (void);
// 0x000003F6 System.Void UnityEngine.UI.Slider::Set(System.Single,System.Boolean)
extern void Slider_Set_mB34DDC06242DB0E6FFB5C8C0C4F332E9E5CE01B4 (void);
// 0x000003F7 System.Void UnityEngine.UI.Slider::OnRectTransformDimensionsChange()
extern void Slider_OnRectTransformDimensionsChange_m7CD43EAC6B8A9EC0D8CB51AC69579EEE981E9AEA (void);
// 0x000003F8 UnityEngine.UI.Slider/Axis UnityEngine.UI.Slider::get_axis()
extern void Slider_get_axis_m9F710E0C68A9BB669EEAEC975162175F7739EB0D (void);
// 0x000003F9 System.Boolean UnityEngine.UI.Slider::get_reverseValue()
extern void Slider_get_reverseValue_mB5AF7FF5484376E3CEB96C032D0A7D623CBFA441 (void);
// 0x000003FA System.Void UnityEngine.UI.Slider::UpdateVisuals()
extern void Slider_UpdateVisuals_m4DB93A792742A44468481C914A4D14066B577A51 (void);
// 0x000003FB System.Void UnityEngine.UI.Slider::UpdateDrag(UnityEngine.EventSystems.PointerEventData,UnityEngine.Camera)
extern void Slider_UpdateDrag_m7755A3B37FA9D65D845B21D182803408EECB97FE (void);
// 0x000003FC System.Boolean UnityEngine.UI.Slider::MayDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_MayDrag_m40FE0F769073CA0C4FBF91313C8FEF6C73E58CB0 (void);
// 0x000003FD System.Void UnityEngine.UI.Slider::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnPointerDown_m790F1E28A4C17345262D27FCCB4022188F832686 (void);
// 0x000003FE System.Void UnityEngine.UI.Slider::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnDrag_mD2D5B8F1AC180999FAB55174ACE782235D157AB1 (void);
// 0x000003FF System.Void UnityEngine.UI.Slider::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void Slider_OnMove_m44D7E1C1F1CA184BA5F10F1E18E8DD97B2EDAE0D (void);
// 0x00000400 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnLeft()
extern void Slider_FindSelectableOnLeft_m1712ADA199F792D4C30D0094AA9A43D3441C7471 (void);
// 0x00000401 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnRight()
extern void Slider_FindSelectableOnRight_m42B9D352422ABEB7719BD3F63821A6166261C646 (void);
// 0x00000402 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnUp()
extern void Slider_FindSelectableOnUp_mC66B25E4FB7290FCF82048F6AA857F0C6ECC3FA7 (void);
// 0x00000403 UnityEngine.UI.Selectable UnityEngine.UI.Slider::FindSelectableOnDown()
extern void Slider_FindSelectableOnDown_mD2F38D581CB5AFA849AFE901EA512579A2799E6D (void);
// 0x00000404 System.Void UnityEngine.UI.Slider::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void Slider_OnInitializePotentialDrag_m0EF05021FE0CFA44BCA7BC359641F2F521AA383C (void);
// 0x00000405 System.Void UnityEngine.UI.Slider::SetDirection(UnityEngine.UI.Slider/Direction,System.Boolean)
extern void Slider_SetDirection_m2140588E77F45546866468171FD83E475C1731BF (void);
// 0x00000406 UnityEngine.Transform UnityEngine.UI.Slider::UnityEngine.UI.ICanvasElement.get_transform()
extern void Slider_UnityEngine_UI_ICanvasElement_get_transform_m47384BECFD0D74507A4118F086EFA66216799287 (void);
// 0x00000407 UnityEngine.Sprite UnityEngine.UI.SpriteState::get_highlightedSprite()
extern void SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0 (void);
// 0x00000408 System.Void UnityEngine.UI.SpriteState::set_highlightedSprite(UnityEngine.Sprite)
extern void SpriteState_set_highlightedSprite_mC897DA30106251AC1865FD7FD26BD987AC3EFE83 (void);
// 0x00000409 UnityEngine.Sprite UnityEngine.UI.SpriteState::get_pressedSprite()
extern void SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB (void);
// 0x0000040A System.Void UnityEngine.UI.SpriteState::set_pressedSprite(UnityEngine.Sprite)
extern void SpriteState_set_pressedSprite_m29B2F72FB74B08A85E99BAB26A73C18C96CEEE6C (void);
// 0x0000040B UnityEngine.Sprite UnityEngine.UI.SpriteState::get_selectedSprite()
extern void SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B (void);
// 0x0000040C System.Void UnityEngine.UI.SpriteState::set_selectedSprite(UnityEngine.Sprite)
extern void SpriteState_set_selectedSprite_m5A23CA415AF8956BC3507C8DD7FEE57C3EB34951 (void);
// 0x0000040D UnityEngine.Sprite UnityEngine.UI.SpriteState::get_disabledSprite()
extern void SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57 (void);
// 0x0000040E System.Void UnityEngine.UI.SpriteState::set_disabledSprite(UnityEngine.Sprite)
extern void SpriteState_set_disabledSprite_m57C60F8DAF18851169F170BE37787FC3EEDF23D2 (void);
// 0x0000040F System.Boolean UnityEngine.UI.SpriteState::Equals(UnityEngine.UI.SpriteState)
extern void SpriteState_Equals_mD9E480FA2D996155ED689F6BA29917273DF036E2 (void);
// 0x00000410 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32)
extern void StencilMaterial_Add_m5A9FE4FB6F7D51DA0DC3A8AFDBB24E48E38B3F67 (void);
// 0x00000411 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.ColorWriteMask)
extern void StencilMaterial_Add_mD64708D42FA5E0A4B99042A43C0DAA9E0B4F8345 (void);
// 0x00000412 UnityEngine.Material UnityEngine.UI.StencilMaterial::Add(UnityEngine.Material,System.Int32,UnityEngine.Rendering.StencilOp,UnityEngine.Rendering.CompareFunction,UnityEngine.Rendering.ColorWriteMask,System.Int32,System.Int32)
extern void StencilMaterial_Add_mF73CF843BED16D1C9FCF82F1F3B5AA79DFC08B55 (void);
// 0x00000413 System.Void UnityEngine.UI.StencilMaterial::Remove(UnityEngine.Material)
extern void StencilMaterial_Remove_m21C1F511B591FD641E85F691893FC148DDC09093 (void);
// 0x00000414 System.Void UnityEngine.UI.StencilMaterial::ClearAll()
extern void StencilMaterial_ClearAll_m0B45EE641BF07278CBAB5401E441338674856874 (void);
// 0x00000415 System.Void UnityEngine.UI.StencilMaterial::.cctor()
extern void StencilMaterial__cctor_m97D7B30D3189DDAF637E592A24CEE556E93C131A (void);
// 0x00000416 System.Void UnityEngine.UI.Text::.ctor()
extern void Text__ctor_m46DA95EE5FCBDECA991B74008C4CEB29D7EC381D (void);
// 0x00000417 UnityEngine.TextGenerator UnityEngine.UI.Text::get_cachedTextGenerator()
extern void Text_get_cachedTextGenerator_mC2FED5B2D9A7BF6D4372FDC993D0B7F0EA3C1DA8 (void);
// 0x00000418 UnityEngine.TextGenerator UnityEngine.UI.Text::get_cachedTextGeneratorForLayout()
extern void Text_get_cachedTextGeneratorForLayout_m0F227772707238FF803F6A14F7B06B17D87A8BC5 (void);
// 0x00000419 UnityEngine.Texture UnityEngine.UI.Text::get_mainTexture()
extern void Text_get_mainTexture_m2DB4BB9E001F9251B8B95887CC17CA78DAEB5C45 (void);
// 0x0000041A System.Void UnityEngine.UI.Text::FontTextureChanged()
extern void Text_FontTextureChanged_m4C40032BB34A17CCA489805DCB6C37980BB83E0E (void);
// 0x0000041B UnityEngine.Font UnityEngine.UI.Text::get_font()
extern void Text_get_font_mC5492E71F03FA7CD2B9C42672B662FF2383A7919 (void);
// 0x0000041C System.Void UnityEngine.UI.Text::set_font(UnityEngine.Font)
extern void Text_set_font_m26FF2D1FF6581C2F82F17A632FE34B7CCD497078 (void);
// 0x0000041D System.String UnityEngine.UI.Text::get_text()
extern void Text_get_text_m0E3C7440DD7BF5921F47D8E6A7EFFBB650F43497 (void);
// 0x0000041E System.Void UnityEngine.UI.Text::set_text(System.String)
extern void Text_set_text_m452D7963AADBC94DF661C34AFCC1522E22E3C37C (void);
// 0x0000041F System.Boolean UnityEngine.UI.Text::get_supportRichText()
extern void Text_get_supportRichText_m8AB4EDE9827A90CA8988FE0B9CB84D0E87C961AF (void);
// 0x00000420 System.Void UnityEngine.UI.Text::set_supportRichText(System.Boolean)
extern void Text_set_supportRichText_mE34FE6932EE7B93912E760AB30DC5F48DD8F98FB (void);
// 0x00000421 System.Boolean UnityEngine.UI.Text::get_resizeTextForBestFit()
extern void Text_get_resizeTextForBestFit_mED7D33409B61524487134F08A49DE2612427EF63 (void);
// 0x00000422 System.Void UnityEngine.UI.Text::set_resizeTextForBestFit(System.Boolean)
extern void Text_set_resizeTextForBestFit_m9D5758B61D60016E11E2C672993D506983E92A3C (void);
// 0x00000423 System.Int32 UnityEngine.UI.Text::get_resizeTextMinSize()
extern void Text_get_resizeTextMinSize_m737CB8B5C096414C48B5F54C8C4D19528BD334D6 (void);
// 0x00000424 System.Void UnityEngine.UI.Text::set_resizeTextMinSize(System.Int32)
extern void Text_set_resizeTextMinSize_mD5D212EBAE999E7EB60083AEF1D64B636897B2F4 (void);
// 0x00000425 System.Int32 UnityEngine.UI.Text::get_resizeTextMaxSize()
extern void Text_get_resizeTextMaxSize_m6DCE61E88700B8DAC601E85304C29A1291DC03C6 (void);
// 0x00000426 System.Void UnityEngine.UI.Text::set_resizeTextMaxSize(System.Int32)
extern void Text_set_resizeTextMaxSize_m187DF8AC98B2079BD97B5FB0CA3EB6F97021C057 (void);
// 0x00000427 UnityEngine.TextAnchor UnityEngine.UI.Text::get_alignment()
extern void Text_get_alignment_m764224AECDEEF22CCC70D507944D753FBCF58D97 (void);
// 0x00000428 System.Void UnityEngine.UI.Text::set_alignment(UnityEngine.TextAnchor)
extern void Text_set_alignment_m7C6F240D274640BFBCDAEDACB08684939900CB29 (void);
// 0x00000429 System.Boolean UnityEngine.UI.Text::get_alignByGeometry()
extern void Text_get_alignByGeometry_mD43B4AC1B70CFF2816FEDD9AC3A54A43B6AA5595 (void);
// 0x0000042A System.Void UnityEngine.UI.Text::set_alignByGeometry(System.Boolean)
extern void Text_set_alignByGeometry_m34037C4F97257BA940A34A109795E9F9A13AECA9 (void);
// 0x0000042B System.Int32 UnityEngine.UI.Text::get_fontSize()
extern void Text_get_fontSize_mF35590920019224B052DA5BC93E8D8F13CEF767A (void);
// 0x0000042C System.Void UnityEngine.UI.Text::set_fontSize(System.Int32)
extern void Text_set_fontSize_mA2E192AAB4668CE91F02762DDE558FC59C1EBE0C (void);
// 0x0000042D UnityEngine.HorizontalWrapMode UnityEngine.UI.Text::get_horizontalOverflow()
extern void Text_get_horizontalOverflow_mEBD747C7A0B0DEF7AEC55307A8EDA6DD1ECCC5B2 (void);
// 0x0000042E System.Void UnityEngine.UI.Text::set_horizontalOverflow(UnityEngine.HorizontalWrapMode)
extern void Text_set_horizontalOverflow_mD27CA8D9A4E883A0ECA5D3D94E11C28E2084C96F (void);
// 0x0000042F UnityEngine.VerticalWrapMode UnityEngine.UI.Text::get_verticalOverflow()
extern void Text_get_verticalOverflow_mA8582227054F2DB4071BDC70204103C98C1D7D79 (void);
// 0x00000430 System.Void UnityEngine.UI.Text::set_verticalOverflow(UnityEngine.VerticalWrapMode)
extern void Text_set_verticalOverflow_m033685FF5F3B8FBB7B2D4BEDB42FB4822A13B9A1 (void);
// 0x00000431 System.Single UnityEngine.UI.Text::get_lineSpacing()
extern void Text_get_lineSpacing_mAB4E9E2BEC7F2DD5BD426E72B3A34859914D6C4A (void);
// 0x00000432 System.Void UnityEngine.UI.Text::set_lineSpacing(System.Single)
extern void Text_set_lineSpacing_m2CB64D3EEB4A4AC1B50D9870BC0272EC2933E40F (void);
// 0x00000433 UnityEngine.FontStyle UnityEngine.UI.Text::get_fontStyle()
extern void Text_get_fontStyle_mA223DF2A20DDBB2755624498CFD8C99E22A981CA (void);
// 0x00000434 System.Void UnityEngine.UI.Text::set_fontStyle(UnityEngine.FontStyle)
extern void Text_set_fontStyle_mF63C76D954DB1E7BC689FE3BE02E14FABECAADF1 (void);
// 0x00000435 System.Single UnityEngine.UI.Text::get_pixelsPerUnit()
extern void Text_get_pixelsPerUnit_mFD570EA1798CC83C73320FDA714FC5049C6AF40D (void);
// 0x00000436 System.Void UnityEngine.UI.Text::OnEnable()
extern void Text_OnEnable_m3F57EFFF42BA830FC4AE96E5AEE71562793C9AA6 (void);
// 0x00000437 System.Void UnityEngine.UI.Text::OnDisable()
extern void Text_OnDisable_m3C2B587F41523C9641AFCB45FC7EA1B76C897027 (void);
// 0x00000438 System.Void UnityEngine.UI.Text::UpdateGeometry()
extern void Text_UpdateGeometry_m015733C848B7644CA6C4FD167CB843ED362BDAB4 (void);
// 0x00000439 System.Void UnityEngine.UI.Text::AssignDefaultFont()
extern void Text_AssignDefaultFont_m6667512908BFA6FCAF388E44993574590990212A (void);
// 0x0000043A UnityEngine.TextGenerationSettings UnityEngine.UI.Text::GetGenerationSettings(UnityEngine.Vector2)
extern void Text_GetGenerationSettings_m601D90FFD85B04F8DD7DA4D701080AAB77F2FAAD (void);
// 0x0000043B UnityEngine.Vector2 UnityEngine.UI.Text::GetTextAnchorPivot(UnityEngine.TextAnchor)
extern void Text_GetTextAnchorPivot_m46E0F5CDDA2E0366DBB463A2D46F3F334FC1D058 (void);
// 0x0000043C System.Void UnityEngine.UI.Text::OnPopulateMesh(UnityEngine.UI.VertexHelper)
extern void Text_OnPopulateMesh_mE2F50C5115FA0B46BDAE39EA77CD7FADFA58E5D3 (void);
// 0x0000043D System.Void UnityEngine.UI.Text::CalculateLayoutInputHorizontal()
extern void Text_CalculateLayoutInputHorizontal_mD8A4D4E919FF27E2DB64C9A1A038C0AAC7D1DC25 (void);
// 0x0000043E System.Void UnityEngine.UI.Text::CalculateLayoutInputVertical()
extern void Text_CalculateLayoutInputVertical_mD42D7A1B5B4529CD5AD80102A88C44C532107CD7 (void);
// 0x0000043F System.Single UnityEngine.UI.Text::get_minWidth()
extern void Text_get_minWidth_m23E3C5FD8C144437DE9E1663CE948E6F0083B6AA (void);
// 0x00000440 System.Single UnityEngine.UI.Text::get_preferredWidth()
extern void Text_get_preferredWidth_m35CA8F0051CA8BBD14009ACEF86FB46C1D0CE524 (void);
// 0x00000441 System.Single UnityEngine.UI.Text::get_flexibleWidth()
extern void Text_get_flexibleWidth_mA5F51D5CA16FF84C16967F0C122298623B93BF8F (void);
// 0x00000442 System.Single UnityEngine.UI.Text::get_minHeight()
extern void Text_get_minHeight_mEE716E96B81DF651C5214979DEAD3F9177DD744B (void);
// 0x00000443 System.Single UnityEngine.UI.Text::get_preferredHeight()
extern void Text_get_preferredHeight_m8E624602FE9ABCBB826F9AD8C0508439EAB3D852 (void);
// 0x00000444 System.Single UnityEngine.UI.Text::get_flexibleHeight()
extern void Text_get_flexibleHeight_mFBA5F23377F02C40B26E5F48E3084BA0E5ACF04B (void);
// 0x00000445 System.Int32 UnityEngine.UI.Text::get_layoutPriority()
extern void Text_get_layoutPriority_m3A1931C3D8472EB3CCDCD73EDB2EE87C27E1765B (void);
// 0x00000446 System.Void UnityEngine.UI.Text::.cctor()
extern void Text__cctor_m24B54815C6098811B83EBABFAC08719B1266F11F (void);
// 0x00000447 UnityEngine.UI.ToggleGroup UnityEngine.UI.Toggle::get_group()
extern void Toggle_get_group_m8A53B9EF413E699F639789C84035237AA9E6F614 (void);
// 0x00000448 System.Void UnityEngine.UI.Toggle::set_group(UnityEngine.UI.ToggleGroup)
extern void Toggle_set_group_mCFE13F6C93FE5841351DA36A6C0D4E4C7A4B9467 (void);
// 0x00000449 System.Void UnityEngine.UI.Toggle::.ctor()
extern void Toggle__ctor_mFAEB14B18423E0515EC8DA11C92F3CC78EC51FB6 (void);
// 0x0000044A System.Void UnityEngine.UI.Toggle::Rebuild(UnityEngine.UI.CanvasUpdate)
extern void Toggle_Rebuild_mA0FFFC2EA5EFA1658DB2878E10829359E76D380E (void);
// 0x0000044B System.Void UnityEngine.UI.Toggle::LayoutComplete()
extern void Toggle_LayoutComplete_mEB02EAC95ADA7B004AC8C11AFE1F455CCF2C3D99 (void);
// 0x0000044C System.Void UnityEngine.UI.Toggle::GraphicUpdateComplete()
extern void Toggle_GraphicUpdateComplete_mD2A9EDDDDCB17A3B8318048BFB0B1ED50D166F8B (void);
// 0x0000044D System.Void UnityEngine.UI.Toggle::OnDestroy()
extern void Toggle_OnDestroy_mC713CA5908C52B2690ED67A0D811DA985CD01E45 (void);
// 0x0000044E System.Void UnityEngine.UI.Toggle::OnEnable()
extern void Toggle_OnEnable_m650977B1A65F13B453BFEFACD0A056036ED31C50 (void);
// 0x0000044F System.Void UnityEngine.UI.Toggle::OnDisable()
extern void Toggle_OnDisable_m527A9265B820301574BF6007F3E3DAAE2A1E38D6 (void);
// 0x00000450 System.Void UnityEngine.UI.Toggle::OnDidApplyAnimationProperties()
extern void Toggle_OnDidApplyAnimationProperties_mBA919980714BDAF57FE75D38593A9F12326D683F (void);
// 0x00000451 System.Void UnityEngine.UI.Toggle::SetToggleGroup(UnityEngine.UI.ToggleGroup,System.Boolean)
extern void Toggle_SetToggleGroup_mEEB6E7080982AC3BC3AB6EE2C5D7A65F5B9520CC (void);
// 0x00000452 System.Boolean UnityEngine.UI.Toggle::get_isOn()
extern void Toggle_get_isOn_mA34B03BED48C7189F0AB8498F986485B4CD6B44A (void);
// 0x00000453 System.Void UnityEngine.UI.Toggle::set_isOn(System.Boolean)
extern void Toggle_set_isOn_mCAA660F49688DBA29E896B961E0054154C42EA2B (void);
// 0x00000454 System.Void UnityEngine.UI.Toggle::SetIsOnWithoutNotify(System.Boolean)
extern void Toggle_SetIsOnWithoutNotify_m13F5DDCC4283536BDEEEA62954321DD89DE6E3B9 (void);
// 0x00000455 System.Void UnityEngine.UI.Toggle::Set(System.Boolean,System.Boolean)
extern void Toggle_Set_mA5D5E91124E529711683D367EBC3E086774A4A71 (void);
// 0x00000456 System.Void UnityEngine.UI.Toggle::PlayEffect(System.Boolean)
extern void Toggle_PlayEffect_m2E1C2401C14A7F0176F9276E6A6AF61F70D8415C (void);
// 0x00000457 System.Void UnityEngine.UI.Toggle::Start()
extern void Toggle_Start_mE2D13390AB45E4C86C36562578C73AE55D5098D6 (void);
// 0x00000458 System.Void UnityEngine.UI.Toggle::InternalToggle()
extern void Toggle_InternalToggle_m133D399909D2110A37AB166F5A317F46800C77D7 (void);
// 0x00000459 System.Void UnityEngine.UI.Toggle::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void Toggle_OnPointerClick_m7BD5D04DEB667723AD5399A1D19B81669DA765BE (void);
// 0x0000045A System.Void UnityEngine.UI.Toggle::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void Toggle_OnSubmit_m9D1C9C60F248DD59DF6BB83A901B64BB37E34326 (void);
// 0x0000045B UnityEngine.Transform UnityEngine.UI.Toggle::UnityEngine.UI.ICanvasElement.get_transform()
extern void Toggle_UnityEngine_UI_ICanvasElement_get_transform_m0C71617F839B3BCEEA765EF98476562CF609835D (void);
// 0x0000045C System.Boolean UnityEngine.UI.ToggleGroup::get_allowSwitchOff()
extern void ToggleGroup_get_allowSwitchOff_mDBD76826D07767C85BD645688EDC2D9746AFEBF6 (void);
// 0x0000045D System.Void UnityEngine.UI.ToggleGroup::set_allowSwitchOff(System.Boolean)
extern void ToggleGroup_set_allowSwitchOff_mDF772934D4B93710533DAB1DCF22F73594AB9715 (void);
// 0x0000045E System.Void UnityEngine.UI.ToggleGroup::.ctor()
extern void ToggleGroup__ctor_m67056DE0B68BC307E7F5FDC8F355376A1A95F834 (void);
// 0x0000045F System.Void UnityEngine.UI.ToggleGroup::Start()
extern void ToggleGroup_Start_m4D27D8D0A1960B592F615ABFBF127CE2AF93DC05 (void);
// 0x00000460 System.Void UnityEngine.UI.ToggleGroup::ValidateToggleIsInGroup(UnityEngine.UI.Toggle)
extern void ToggleGroup_ValidateToggleIsInGroup_m1550241F81F555678D89C16D069D536521558CFE (void);
// 0x00000461 System.Void UnityEngine.UI.ToggleGroup::NotifyToggleOn(UnityEngine.UI.Toggle,System.Boolean)
extern void ToggleGroup_NotifyToggleOn_m8F3C60481CF0B2ACB0C1CDB3CEFC34758AE9E546 (void);
// 0x00000462 System.Void UnityEngine.UI.ToggleGroup::UnregisterToggle(UnityEngine.UI.Toggle)
extern void ToggleGroup_UnregisterToggle_mC42CA055A43CB304512A1DC5553528DD5ACC2615 (void);
// 0x00000463 System.Void UnityEngine.UI.ToggleGroup::RegisterToggle(UnityEngine.UI.Toggle)
extern void ToggleGroup_RegisterToggle_mBD20EAFCD962FA19414504CE7B67A3B18108BE71 (void);
// 0x00000464 System.Void UnityEngine.UI.ToggleGroup::EnsureValidState()
extern void ToggleGroup_EnsureValidState_m78912EAC0B48EDC37DFE5E5E50A32631EEEB65A6 (void);
// 0x00000465 System.Boolean UnityEngine.UI.ToggleGroup::AnyTogglesOn()
extern void ToggleGroup_AnyTogglesOn_mA4DD200C568F21DEF7062CEBD93140FF74693360 (void);
// 0x00000466 System.Collections.Generic.IEnumerable`1<UnityEngine.UI.Toggle> UnityEngine.UI.ToggleGroup::ActiveToggles()
extern void ToggleGroup_ActiveToggles_m33CE32ED560C9721E5A370A11BF6D9071F3D28CC (void);
// 0x00000467 System.Void UnityEngine.UI.ToggleGroup::SetAllTogglesOff(System.Boolean)
extern void ToggleGroup_SetAllTogglesOff_mD22DFABD24A486723AEB3823EBE0CEF573FE1A07 (void);
// 0x00000468 System.Void UnityEngine.UI.ListPool`1::Clear(System.Collections.Generic.List`1<T>)
// 0x00000469 System.Collections.Generic.List`1<T> UnityEngine.UI.ListPool`1::Get()
// 0x0000046A System.Void UnityEngine.UI.ListPool`1::Release(System.Collections.Generic.List`1<T>)
// 0x0000046B System.Void UnityEngine.UI.ListPool`1::.cctor()
// 0x0000046C System.Int32 UnityEngine.UI.ObjectPool`1::get_countAll()
// 0x0000046D System.Void UnityEngine.UI.ObjectPool`1::set_countAll(System.Int32)
// 0x0000046E System.Int32 UnityEngine.UI.ObjectPool`1::get_countActive()
// 0x0000046F System.Int32 UnityEngine.UI.ObjectPool`1::get_countInactive()
// 0x00000470 System.Void UnityEngine.UI.ObjectPool`1::.ctor(UnityEngine.Events.UnityAction`1<T>,UnityEngine.Events.UnityAction`1<T>)
// 0x00000471 T UnityEngine.UI.ObjectPool`1::Get()
// 0x00000472 System.Void UnityEngine.UI.ObjectPool`1::Release(T)
// 0x00000473 System.Void UnityEngine.UI.ReflectionMethodsCache::.ctor()
extern void ReflectionMethodsCache__ctor_m3FB6C9DCD567D5F7C37B0A4BA07E639B49D38D34 (void);
// 0x00000474 UnityEngine.UI.ReflectionMethodsCache UnityEngine.UI.ReflectionMethodsCache::get_Singleton()
extern void ReflectionMethodsCache_get_Singleton_m6C50C55DEEA425161B73545918267BB90B7FCB9B (void);
// 0x00000475 System.Void UnityEngine.UI.ReflectionMethodsCache::.cctor()
extern void ReflectionMethodsCache__cctor_m250D2D715E326ECFC950FF368C2B709F064F6338 (void);
// 0x00000476 System.Void UnityEngine.UI.VertexHelper::.ctor()
extern void VertexHelper__ctor_m43D3D0D2AFD14CBAF624E434A6D55295B76A3C29 (void);
// 0x00000477 System.Void UnityEngine.UI.VertexHelper::.ctor(UnityEngine.Mesh)
extern void VertexHelper__ctor_m798A4537737219B31DC65597A980514488DB1C76 (void);
// 0x00000478 System.Void UnityEngine.UI.VertexHelper::InitializeListIfRequired()
extern void VertexHelper_InitializeListIfRequired_mCB55977EEF771AA4E31A9678D5AA17B46F3E1C89 (void);
// 0x00000479 System.Void UnityEngine.UI.VertexHelper::Dispose()
extern void VertexHelper_Dispose_m41D8B361DB5C7323EFCE24F5555CE9D5D7F30F9F (void);
// 0x0000047A System.Void UnityEngine.UI.VertexHelper::Clear()
extern void VertexHelper_Clear_mB5B07793D0ED50C7993E3D2ECC9A18FFD6DC5425 (void);
// 0x0000047B System.Int32 UnityEngine.UI.VertexHelper::get_currentVertCount()
extern void VertexHelper_get_currentVertCount_m82BFAF1788809C0CFBF468CE70606D61730D83ED (void);
// 0x0000047C System.Int32 UnityEngine.UI.VertexHelper::get_currentIndexCount()
extern void VertexHelper_get_currentIndexCount_mD5FAED86A961FFD9C5EF41A0EA69EE123C72F920 (void);
// 0x0000047D System.Void UnityEngine.UI.VertexHelper::PopulateUIVertex(UnityEngine.UIVertex&,System.Int32)
extern void VertexHelper_PopulateUIVertex_m86AC68C02173081B1C0B7C0F9AE6624031E65B7C (void);
// 0x0000047E System.Void UnityEngine.UI.VertexHelper::SetUIVertex(UnityEngine.UIVertex,System.Int32)
extern void VertexHelper_SetUIVertex_m41470CE62983973DA57AF3D2C4165869816B6F6D (void);
// 0x0000047F System.Void UnityEngine.UI.VertexHelper::FillMesh(UnityEngine.Mesh)
extern void VertexHelper_FillMesh_m42F81894DE19863AC187F06DFB7922A71BC29247 (void);
// 0x00000480 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector3,UnityEngine.Vector4)
extern void VertexHelper_AddVert_m652DF4ABCDB6CE6AE29F81EF90674DDDCF31BB9B (void);
// 0x00000481 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector2,UnityEngine.Vector2,UnityEngine.Vector3,UnityEngine.Vector4)
extern void VertexHelper_AddVert_mD859215DD00E2B617B47488EF5389C9D4EFCF5BB (void);
// 0x00000482 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.Vector3,UnityEngine.Color32,UnityEngine.Vector2)
extern void VertexHelper_AddVert_m2A24026B8B4DAA44EB873B380B3EC60861A26CCF (void);
// 0x00000483 System.Void UnityEngine.UI.VertexHelper::AddVert(UnityEngine.UIVertex)
extern void VertexHelper_AddVert_m68BE4AFF505B1175210A6874DD9FC1D3611A200A (void);
// 0x00000484 System.Void UnityEngine.UI.VertexHelper::AddTriangle(System.Int32,System.Int32,System.Int32)
extern void VertexHelper_AddTriangle_mD69A46AC22FC94799173320ED5F4144A883F44F4 (void);
// 0x00000485 System.Void UnityEngine.UI.VertexHelper::AddUIVertexQuad(UnityEngine.UIVertex[])
extern void VertexHelper_AddUIVertexQuad_mFD743F0DAF7F30C352D19C0F4B1619DA9463099A (void);
// 0x00000486 System.Void UnityEngine.UI.VertexHelper::AddUIVertexStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>,System.Collections.Generic.List`1<System.Int32>)
extern void VertexHelper_AddUIVertexStream_mC5E2CED3AEEA13EAB65E99F5EEF4528132C8D644 (void);
// 0x00000487 System.Void UnityEngine.UI.VertexHelper::AddUIVertexTriangleStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void VertexHelper_AddUIVertexTriangleStream_m83D0E84141AAC0D349E9D754ACFA57D0E05BCA01 (void);
// 0x00000488 System.Void UnityEngine.UI.VertexHelper::GetUIVertexStream(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
extern void VertexHelper_GetUIVertexStream_mE3869FC59400C59FA179ED769002E1098B6585F7 (void);
// 0x00000489 System.Void UnityEngine.UI.VertexHelper::.cctor()
extern void VertexHelper__cctor_m739422D4F325E4EF35B301477B98A90A8E8FCB61 (void);
// 0x0000048A System.Void UnityEngine.UI.BaseVertexEffect::ModifyVertices(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
// 0x0000048B System.Void UnityEngine.UI.BaseVertexEffect::.ctor()
extern void BaseVertexEffect__ctor_mA9DBADF41E794B1F6254174E99F4EAC83EDD8E54 (void);
// 0x0000048C UnityEngine.UI.Graphic UnityEngine.UI.BaseMeshEffect::get_graphic()
extern void BaseMeshEffect_get_graphic_mDD7D8CD6F220B9DE656145A1346EA9799255BE21 (void);
// 0x0000048D System.Void UnityEngine.UI.BaseMeshEffect::OnEnable()
extern void BaseMeshEffect_OnEnable_m34959EE194208A72A3D64460D0232CAD04398CAA (void);
// 0x0000048E System.Void UnityEngine.UI.BaseMeshEffect::OnDisable()
extern void BaseMeshEffect_OnDisable_mE6A5C8C62463E34A982933C7A77B2E2ECB91C8F1 (void);
// 0x0000048F System.Void UnityEngine.UI.BaseMeshEffect::OnDidApplyAnimationProperties()
extern void BaseMeshEffect_OnDidApplyAnimationProperties_mBAC052B0C5723BBFD501BA63F93C74BE3667B144 (void);
// 0x00000490 System.Void UnityEngine.UI.BaseMeshEffect::ModifyMesh(UnityEngine.Mesh)
extern void BaseMeshEffect_ModifyMesh_m1E691826E2BD65C3D2B76E991842BC5671A3B295 (void);
// 0x00000491 System.Void UnityEngine.UI.BaseMeshEffect::ModifyMesh(UnityEngine.UI.VertexHelper)
// 0x00000492 System.Void UnityEngine.UI.BaseMeshEffect::.ctor()
extern void BaseMeshEffect__ctor_m12D1C94ABAD84C1F86D70908CAAAD9754372C09F (void);
// 0x00000493 System.Void UnityEngine.UI.IVertexModifier::ModifyVertices(System.Collections.Generic.List`1<UnityEngine.UIVertex>)
// 0x00000494 System.Void UnityEngine.UI.IMeshModifier::ModifyMesh(UnityEngine.Mesh)
// 0x00000495 System.Void UnityEngine.UI.IMeshModifier::ModifyMesh(UnityEngine.UI.VertexHelper)
// 0x00000496 System.Void UnityEngine.UI.Outline::.ctor()
extern void Outline__ctor_m8D766B20697B73B37C4FD3D1706C6013BB6E6DA6 (void);
// 0x00000497 System.Void UnityEngine.UI.Outline::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void Outline_ModifyMesh_mD6753C5F2B9F57A504255A5EC5050FDC8B6A0053 (void);
// 0x00000498 System.Void UnityEngine.UI.PositionAsUV1::.ctor()
extern void PositionAsUV1__ctor_m10DEF955BF4DF33573F54FD0120682EB557BBFD8 (void);
// 0x00000499 System.Void UnityEngine.UI.PositionAsUV1::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void PositionAsUV1_ModifyMesh_m76222DEA6713B3A2FFA9CC6D2EF1EC85869684FA (void);
// 0x0000049A System.Void UnityEngine.UI.Shadow::.ctor()
extern void Shadow__ctor_mC030EE1625435DDA0030F43F992685B4AFD2FF3E (void);
// 0x0000049B UnityEngine.Color UnityEngine.UI.Shadow::get_effectColor()
extern void Shadow_get_effectColor_mC7BF6CDDEC9998A03E993ED9216092782C66EC16 (void);
// 0x0000049C System.Void UnityEngine.UI.Shadow::set_effectColor(UnityEngine.Color)
extern void Shadow_set_effectColor_m1197327C64A5D9F15AA10F93876EA267D3975D0F (void);
// 0x0000049D UnityEngine.Vector2 UnityEngine.UI.Shadow::get_effectDistance()
extern void Shadow_get_effectDistance_m4B496C7CE07930847630E0E636E3C255D78B08BB (void);
// 0x0000049E System.Void UnityEngine.UI.Shadow::set_effectDistance(UnityEngine.Vector2)
extern void Shadow_set_effectDistance_m644CE2DCAFF42F908630094DA68A3D8EBB8C09B5 (void);
// 0x0000049F System.Boolean UnityEngine.UI.Shadow::get_useGraphicAlpha()
extern void Shadow_get_useGraphicAlpha_m459DB69C3A786929E371818BBA990DC2C0B7A38E (void);
// 0x000004A0 System.Void UnityEngine.UI.Shadow::set_useGraphicAlpha(System.Boolean)
extern void Shadow_set_useGraphicAlpha_mE71F14530C25BC6C1363D12AF6D4862762B06216 (void);
// 0x000004A1 System.Void UnityEngine.UI.Shadow::ApplyShadowZeroAlloc(System.Collections.Generic.List`1<UnityEngine.UIVertex>,UnityEngine.Color32,System.Int32,System.Int32,System.Single,System.Single)
extern void Shadow_ApplyShadowZeroAlloc_m523BB704A795039F8B796603F1B06542C6AA52EC (void);
// 0x000004A2 System.Void UnityEngine.UI.Shadow::ApplyShadow(System.Collections.Generic.List`1<UnityEngine.UIVertex>,UnityEngine.Color32,System.Int32,System.Int32,System.Single,System.Single)
extern void Shadow_ApplyShadow_mC556C084C1DC87748C6C3385383416F5D36CB1F5 (void);
// 0x000004A3 System.Void UnityEngine.UI.Shadow::ModifyMesh(UnityEngine.UI.VertexHelper)
extern void Shadow_ModifyMesh_mE9DC1E36A8F6A0838273B5A837235904D99E6C0B (void);
// 0x000004A4 System.Void UnityEngine.UI.Collections.IndexedSet`1::Add(T)
// 0x000004A5 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::AddUnique(T)
// 0x000004A6 System.Boolean UnityEngine.UI.Collections.IndexedSet`1::Remove(T)
// 0x000004A7 System.Collections.Generic.IEnumerator`1<T> UnityEngine.UI.Collections.IndexedSet`1::GetEnumerator()
// 0x000004A8 System.Collections.IEnumerator UnityEngine.UI.Collections.IndexedSet`1::System.Collections.IEnumerable.GetEnumerator()
// 0x000004A9 System.Void UnityEngine.UI.Collections.IndexedSet`1::Clear()
// 0x000004AA System.Boolean UnityEngine.UI.Collections.IndexedSet`1::Contains(T)
// 0x000004AB System.Void UnityEngine.UI.Collections.IndexedSet`1::CopyTo(T[],System.Int32)
// 0x000004AC System.Int32 UnityEngine.UI.Collections.IndexedSet`1::get_Count()
// 0x000004AD System.Boolean UnityEngine.UI.Collections.IndexedSet`1::get_IsReadOnly()
// 0x000004AE System.Int32 UnityEngine.UI.Collections.IndexedSet`1::IndexOf(T)
// 0x000004AF System.Void UnityEngine.UI.Collections.IndexedSet`1::Insert(System.Int32,T)
// 0x000004B0 System.Void UnityEngine.UI.Collections.IndexedSet`1::RemoveAt(System.Int32)
// 0x000004B1 T UnityEngine.UI.Collections.IndexedSet`1::get_Item(System.Int32)
// 0x000004B2 System.Void UnityEngine.UI.Collections.IndexedSet`1::set_Item(System.Int32,T)
// 0x000004B3 System.Void UnityEngine.UI.Collections.IndexedSet`1::RemoveAll(System.Predicate`1<T>)
// 0x000004B4 System.Void UnityEngine.UI.Collections.IndexedSet`1::Sort(System.Comparison`1<T>)
// 0x000004B5 System.Void UnityEngine.UI.Collections.IndexedSet`1::.ctor()
// 0x000004B6 System.Void UnityEngine.UI.CoroutineTween.ITweenValue::TweenValue(System.Single)
// 0x000004B7 System.Boolean UnityEngine.UI.CoroutineTween.ITweenValue::get_ignoreTimeScale()
// 0x000004B8 System.Single UnityEngine.UI.CoroutineTween.ITweenValue::get_duration()
// 0x000004B9 System.Boolean UnityEngine.UI.CoroutineTween.ITweenValue::ValidTarget()
// 0x000004BA UnityEngine.Color UnityEngine.UI.CoroutineTween.ColorTween::get_startColor()
extern void ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6 (void);
// 0x000004BB System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_startColor(UnityEngine.Color)
extern void ColorTween_set_startColor_mA57B5D1E4C2FA32133D13E91D9B07253CCF3BFD8 (void);
// 0x000004BC UnityEngine.Color UnityEngine.UI.CoroutineTween.ColorTween::get_targetColor()
extern void ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF (void);
// 0x000004BD System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_targetColor(UnityEngine.Color)
extern void ColorTween_set_targetColor_mB57B42752260A735D6F174F925822756088DAD26 (void);
// 0x000004BE UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenMode UnityEngine.UI.CoroutineTween.ColorTween::get_tweenMode()
extern void ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB (void);
// 0x000004BF System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_tweenMode(UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenMode)
extern void ColorTween_set_tweenMode_m2C089877F55E0D82F68BFC3EEC33737F7D3D9E54 (void);
// 0x000004C0 System.Single UnityEngine.UI.CoroutineTween.ColorTween::get_duration()
extern void ColorTween_get_duration_m7E952A00A8A606D7886422812EFB24A6D5BFB508 (void);
// 0x000004C1 System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_duration(System.Single)
extern void ColorTween_set_duration_mA6144F511A40F04787D3BEEAB4A0C0EBD66ADB5C (void);
// 0x000004C2 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::get_ignoreTimeScale()
extern void ColorTween_get_ignoreTimeScale_mF935C53CA27D67D47AE0021A0DB8D92C392EF56B (void);
// 0x000004C3 System.Void UnityEngine.UI.CoroutineTween.ColorTween::set_ignoreTimeScale(System.Boolean)
extern void ColorTween_set_ignoreTimeScale_m4B2110395267132EB58541D4355630D0DB466512 (void);
// 0x000004C4 System.Void UnityEngine.UI.CoroutineTween.ColorTween::TweenValue(System.Single)
extern void ColorTween_TweenValue_m4EF3CDDDDC3986BA6D06D4DB785310B131958749 (void);
// 0x000004C5 System.Void UnityEngine.UI.CoroutineTween.ColorTween::AddOnChangedCallback(UnityEngine.Events.UnityAction`1<UnityEngine.Color>)
extern void ColorTween_AddOnChangedCallback_mF516F2C835133EB59CB28895961716360131D82D (void);
// 0x000004C6 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::GetIgnoreTimescale()
extern void ColorTween_GetIgnoreTimescale_m1F87CC0531F370154DF63095DA34F0F88E1DDAF6 (void);
// 0x000004C7 System.Single UnityEngine.UI.CoroutineTween.ColorTween::GetDuration()
extern void ColorTween_GetDuration_mFE7A52AFDCA53B1CCB79D1E3577037A0E44F17C5 (void);
// 0x000004C8 System.Boolean UnityEngine.UI.CoroutineTween.ColorTween::ValidTarget()
extern void ColorTween_ValidTarget_mA5469658CB631C87CF97FC5AE2B9089A06678696 (void);
// 0x000004C9 System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_startValue()
extern void FloatTween_get_startValue_m90C461E4383568718E362BF3CB14F14D45585B0A (void);
// 0x000004CA System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_startValue(System.Single)
extern void FloatTween_set_startValue_m281ACCD10E8DCB7ADED2B25EB093EE5DCFFF57D8 (void);
// 0x000004CB System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_targetValue()
extern void FloatTween_get_targetValue_mAC9AD7101F181AA03EEA21EBE047376A27B18DC2 (void);
// 0x000004CC System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_targetValue(System.Single)
extern void FloatTween_set_targetValue_m948DD0F17FE536F38BFA213D13711B781934165F (void);
// 0x000004CD System.Single UnityEngine.UI.CoroutineTween.FloatTween::get_duration()
extern void FloatTween_get_duration_m17CD4518038CD642D714B3633236133D309EF13B (void);
// 0x000004CE System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_duration(System.Single)
extern void FloatTween_set_duration_m81021898C4F8F1F4D434CA46EAC596E0CC0F200B (void);
// 0x000004CF System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::get_ignoreTimeScale()
extern void FloatTween_get_ignoreTimeScale_m8281CB2B12F1697A512D2E2515F5DA058B429FD0 (void);
// 0x000004D0 System.Void UnityEngine.UI.CoroutineTween.FloatTween::set_ignoreTimeScale(System.Boolean)
extern void FloatTween_set_ignoreTimeScale_mC586D01F34D6C88892AB3C70A3298C4C7C45EA4D (void);
// 0x000004D1 System.Void UnityEngine.UI.CoroutineTween.FloatTween::TweenValue(System.Single)
extern void FloatTween_TweenValue_m78FEB902E18BE0882BC487BC29B6EA3905E4F05C (void);
// 0x000004D2 System.Void UnityEngine.UI.CoroutineTween.FloatTween::AddOnChangedCallback(UnityEngine.Events.UnityAction`1<System.Single>)
extern void FloatTween_AddOnChangedCallback_mADD5FACCDFA9E77C08CA65B8E5D33AE06DB79D50 (void);
// 0x000004D3 System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::GetIgnoreTimescale()
extern void FloatTween_GetIgnoreTimescale_m8FDD9D59F72DBC2CDEDD71A522ADD6DAD1438BE8 (void);
// 0x000004D4 System.Single UnityEngine.UI.CoroutineTween.FloatTween::GetDuration()
extern void FloatTween_GetDuration_m1022A6824C91E5C51E1F7FCD27B9D60D6E83EDB7 (void);
// 0x000004D5 System.Boolean UnityEngine.UI.CoroutineTween.FloatTween::ValidTarget()
extern void FloatTween_ValidTarget_m7DFE9AC7C8C0EBEF441D80472635CF4F38632E5E (void);
// 0x000004D6 System.Collections.IEnumerator UnityEngine.UI.CoroutineTween.TweenRunner`1::Start(T)
// 0x000004D7 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::Init(UnityEngine.MonoBehaviour)
// 0x000004D8 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::StartTween(T)
// 0x000004D9 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::StopTween()
// 0x000004DA System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1::.ctor()
// 0x000004DB UnityEngine.Vector2 UnityEngine.EventSystems.AxisEventData::get_moveVector()
extern void AxisEventData_get_moveVector_mCB9151FF8AFE8DC43886E715AD4B9932644DC171 (void);
// 0x000004DC System.Void UnityEngine.EventSystems.AxisEventData::set_moveVector(UnityEngine.Vector2)
extern void AxisEventData_set_moveVector_m863F26BE1230CBCCA2DEF5651CE0FC8B8F1D45A3 (void);
// 0x000004DD UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.AxisEventData::get_moveDir()
extern void AxisEventData_get_moveDir_mD9CF8343509BAE60C581138D824F9C53659DBBD4 (void);
// 0x000004DE System.Void UnityEngine.EventSystems.AxisEventData::set_moveDir(UnityEngine.EventSystems.MoveDirection)
extern void AxisEventData_set_moveDir_m6C647B27688638E9C02A98E47BEC5292C07465EE (void);
// 0x000004DF System.Void UnityEngine.EventSystems.AxisEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void AxisEventData__ctor_m9694BD920E181114C1A079141D07BD092E05B27D (void);
// 0x000004E0 System.Void UnityEngine.EventSystems.AbstractEventData::Reset()
extern void AbstractEventData_Reset_mF1DD0330808CADC4720AF29F268500B5B2905489 (void);
// 0x000004E1 System.Void UnityEngine.EventSystems.AbstractEventData::Use()
extern void AbstractEventData_Use_mF5CFA55F6C0995C78C1975842F503F2A321CCB45 (void);
// 0x000004E2 System.Boolean UnityEngine.EventSystems.AbstractEventData::get_used()
extern void AbstractEventData_get_used_m8B10645CCCD75CAE08799E835150E4009D64CDC8 (void);
// 0x000004E3 System.Void UnityEngine.EventSystems.AbstractEventData::.ctor()
extern void AbstractEventData__ctor_mE768723F461440691FA9218643BEC7692B816B36 (void);
// 0x000004E4 System.Void UnityEngine.EventSystems.BaseEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void BaseEventData__ctor_m4A8184F01D2CA8B2DE6BB752F486CF7DEF7A56AE (void);
// 0x000004E5 UnityEngine.EventSystems.BaseInputModule UnityEngine.EventSystems.BaseEventData::get_currentInputModule()
extern void BaseEventData_get_currentInputModule_m0887B0CB20374A4AA10D4C1B480E305581533512 (void);
// 0x000004E6 UnityEngine.GameObject UnityEngine.EventSystems.BaseEventData::get_selectedObject()
extern void BaseEventData_get_selectedObject_m234C3A09897246D2BF97D43017C9AE476BD91770 (void);
// 0x000004E7 System.Void UnityEngine.EventSystems.BaseEventData::set_selectedObject(UnityEngine.GameObject)
extern void BaseEventData_set_selectedObject_m8B7E784D728FE3078625FF45A1B5859E37092A2D (void);
// 0x000004E8 UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerEnter()
extern void PointerEventData_get_pointerEnter_m47E87ACB1557B6380D0E66F57C2F9FFFD5E86DC2 (void);
// 0x000004E9 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerEnter(UnityEngine.GameObject)
extern void PointerEventData_set_pointerEnter_mCA947226697EEC596FD611B31C10D7CE981026CC (void);
// 0x000004EA UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_lastPress()
extern void PointerEventData_get_lastPress_m6B005D786FC5B30ECD8D5BC068420D0C361357F4 (void);
// 0x000004EB System.Void UnityEngine.EventSystems.PointerEventData::set_lastPress(UnityEngine.GameObject)
extern void PointerEventData_set_lastPress_m3A938CE59A47898263BE6A6F880A3B3CD21D063D (void);
// 0x000004EC UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_rawPointerPress()
extern void PointerEventData_get_rawPointerPress_m6CECEFBAD7C50F04BD65172000B0BB916578B494 (void);
// 0x000004ED System.Void UnityEngine.EventSystems.PointerEventData::set_rawPointerPress(UnityEngine.GameObject)
extern void PointerEventData_set_rawPointerPress_mB7E32587FD73925A689A71FCAB560F9B78A233A5 (void);
// 0x000004EE UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerDrag()
extern void PointerEventData_get_pointerDrag_m20299CC70BC6DA11AFDB8A33A957AC306FBEE5C7 (void);
// 0x000004EF System.Void UnityEngine.EventSystems.PointerEventData::set_pointerDrag(UnityEngine.GameObject)
extern void PointerEventData_set_pointerDrag_m7E4BF3CF39EF734A80FA1994310FB09A5B095AF8 (void);
// 0x000004F0 UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::get_pointerCurrentRaycast()
extern void PointerEventData_get_pointerCurrentRaycast_mE58F786484E13AF2E6C2706E20C889E7453E3A7A (void);
// 0x000004F1 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerCurrentRaycast(UnityEngine.EventSystems.RaycastResult)
extern void PointerEventData_set_pointerCurrentRaycast_m0B0B77AF61C5402D29574A9031AEED66AE4C8455 (void);
// 0x000004F2 UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.PointerEventData::get_pointerPressRaycast()
extern void PointerEventData_get_pointerPressRaycast_m722BCA823E0405C9DF20312CDFBBEB5B1B05B7AE (void);
// 0x000004F3 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPressRaycast(UnityEngine.EventSystems.RaycastResult)
extern void PointerEventData_set_pointerPressRaycast_m559F6127EC11B0F1B5EEB7BFCA478128DE8E5536 (void);
// 0x000004F4 System.Boolean UnityEngine.EventSystems.PointerEventData::get_eligibleForClick()
extern void PointerEventData_get_eligibleForClick_m2039146EE2E6940436E592D0655FBA06096DBFFA (void);
// 0x000004F5 System.Void UnityEngine.EventSystems.PointerEventData::set_eligibleForClick(System.Boolean)
extern void PointerEventData_set_eligibleForClick_m403F4068866F6A5CC9814729B3918C8FF1C21DBD (void);
// 0x000004F6 System.Int32 UnityEngine.EventSystems.PointerEventData::get_pointerId()
extern void PointerEventData_get_pointerId_m73B8DCE39BDCB5BD7894D192DDA7FF8817FBE6C6 (void);
// 0x000004F7 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerId(System.Int32)
extern void PointerEventData_set_pointerId_m4CF9E4E445D841D14E46AE00B0B687EE3435C03E (void);
// 0x000004F8 UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_position()
extern void PointerEventData_get_position_mF25FC495A9C968C65BF34B5984616CBFB6332D55 (void);
// 0x000004F9 System.Void UnityEngine.EventSystems.PointerEventData::set_position(UnityEngine.Vector2)
extern void PointerEventData_set_position_mD63B59E6D4EF9B2B2E26D1F4893A7C67BD04266A (void);
// 0x000004FA UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_delta()
extern void PointerEventData_get_delta_mC5D62E985D40A7708316C6E07B699B96D9C8184E (void);
// 0x000004FB System.Void UnityEngine.EventSystems.PointerEventData::set_delta(UnityEngine.Vector2)
extern void PointerEventData_set_delta_mDFEB23DF789E945F2CEC51C1F902CEE6AF674415 (void);
// 0x000004FC UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_pressPosition()
extern void PointerEventData_get_pressPosition_m7C8D5A54C81C801EB577A60718C4211DFA1A3624 (void);
// 0x000004FD System.Void UnityEngine.EventSystems.PointerEventData::set_pressPosition(UnityEngine.Vector2)
extern void PointerEventData_set_pressPosition_m9DDE0BA5D6C31CBCDA926CEB62E51140F23013EA (void);
// 0x000004FE UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::get_worldPosition()
extern void PointerEventData_get_worldPosition_mF0DC1B57F31BB6FB8FFDD666603FF0909940EFA8 (void);
// 0x000004FF System.Void UnityEngine.EventSystems.PointerEventData::set_worldPosition(UnityEngine.Vector3)
extern void PointerEventData_set_worldPosition_mFF9BABD0B8DC58FC94CE7C775EA7BD1A72177EB6 (void);
// 0x00000500 UnityEngine.Vector3 UnityEngine.EventSystems.PointerEventData::get_worldNormal()
extern void PointerEventData_get_worldNormal_m310D7AC52A1EBD88080267B39ADA66A6EC778D26 (void);
// 0x00000501 System.Void UnityEngine.EventSystems.PointerEventData::set_worldNormal(UnityEngine.Vector3)
extern void PointerEventData_set_worldNormal_m1D2167440E774418D7F59F1A0E0D8E637C398519 (void);
// 0x00000502 System.Single UnityEngine.EventSystems.PointerEventData::get_clickTime()
extern void PointerEventData_get_clickTime_m023B539AF9EDF3782FD9406EC79F4742C855A3AF (void);
// 0x00000503 System.Void UnityEngine.EventSystems.PointerEventData::set_clickTime(System.Single)
extern void PointerEventData_set_clickTime_mFB2FD722D5898826A1D57379C153B8023272653C (void);
// 0x00000504 System.Int32 UnityEngine.EventSystems.PointerEventData::get_clickCount()
extern void PointerEventData_get_clickCount_mF3A09A090E418FAAAFFE55668D9761C2F23BCE24 (void);
// 0x00000505 System.Void UnityEngine.EventSystems.PointerEventData::set_clickCount(System.Int32)
extern void PointerEventData_set_clickCount_mE56F748082C3D03A340345630FAC2B119451E003 (void);
// 0x00000506 UnityEngine.Vector2 UnityEngine.EventSystems.PointerEventData::get_scrollDelta()
extern void PointerEventData_get_scrollDelta_mF473A122C860EC5279F6F5D085912BDA6418690B (void);
// 0x00000507 System.Void UnityEngine.EventSystems.PointerEventData::set_scrollDelta(UnityEngine.Vector2)
extern void PointerEventData_set_scrollDelta_m2B7F400B1DD1B45C36D22F291E625B02C76F9751 (void);
// 0x00000508 System.Boolean UnityEngine.EventSystems.PointerEventData::get_useDragThreshold()
extern void PointerEventData_get_useDragThreshold_mD254C2D9572E12F10EC86A21F28E4284EE29D39A (void);
// 0x00000509 System.Void UnityEngine.EventSystems.PointerEventData::set_useDragThreshold(System.Boolean)
extern void PointerEventData_set_useDragThreshold_mB5F06D15C2D1DB8D57F5B79CAEC3F58E4BF79684 (void);
// 0x0000050A System.Boolean UnityEngine.EventSystems.PointerEventData::get_dragging()
extern void PointerEventData_get_dragging_mA3B420FFEB0856189D7A7646AA00A981C745D4B4 (void);
// 0x0000050B System.Void UnityEngine.EventSystems.PointerEventData::set_dragging(System.Boolean)
extern void PointerEventData_set_dragging_m4A4C08AB5A2173557EA62190F47AEFF1E9332821 (void);
// 0x0000050C UnityEngine.EventSystems.PointerEventData/InputButton UnityEngine.EventSystems.PointerEventData::get_button()
extern void PointerEventData_get_button_mC662D5DAC02F0ED6AE9205259116CC91BB92BD3E (void);
// 0x0000050D System.Void UnityEngine.EventSystems.PointerEventData::set_button(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void PointerEventData_set_button_mD5D63D10CFE13D720287DD76AE0D8A852F8324CC (void);
// 0x0000050E System.Void UnityEngine.EventSystems.PointerEventData::.ctor(UnityEngine.EventSystems.EventSystem)
extern void PointerEventData__ctor_mA2208343CA6EE41C13A6B7123322CC88B00A723B (void);
// 0x0000050F System.Boolean UnityEngine.EventSystems.PointerEventData::IsPointerMoving()
extern void PointerEventData_IsPointerMoving_mDF9C046AEE3228B95BECFCF01AE4C45D318EB486 (void);
// 0x00000510 System.Boolean UnityEngine.EventSystems.PointerEventData::IsScrolling()
extern void PointerEventData_IsScrolling_m16BCB03C28009700C2F8AF6FF159E532D7DB0D1D (void);
// 0x00000511 UnityEngine.Camera UnityEngine.EventSystems.PointerEventData::get_enterEventCamera()
extern void PointerEventData_get_enterEventCamera_m4DCBA203F50F1F4D30118573061FD4634D4B4915 (void);
// 0x00000512 UnityEngine.Camera UnityEngine.EventSystems.PointerEventData::get_pressEventCamera()
extern void PointerEventData_get_pressEventCamera_mC505603722C7C3CBEE8C56029C2CA6C5CC769E76 (void);
// 0x00000513 UnityEngine.GameObject UnityEngine.EventSystems.PointerEventData::get_pointerPress()
extern void PointerEventData_get_pointerPress_m7B8C9E16E2B9E86C4DA93A2A2E3A58E56536406B (void);
// 0x00000514 System.Void UnityEngine.EventSystems.PointerEventData::set_pointerPress(UnityEngine.GameObject)
extern void PointerEventData_set_pointerPress_mDFB3D803C9C4137799F9F1D57810DAAF08238327 (void);
// 0x00000515 System.String UnityEngine.EventSystems.PointerEventData::ToString()
extern void PointerEventData_ToString_mA94EE73CA98DC98D20DA590DE44C4FCCE9729A73 (void);
// 0x00000516 System.Void UnityEngine.EventSystems.IPointerEnterHandler::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
// 0x00000517 System.Void UnityEngine.EventSystems.IPointerExitHandler::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
// 0x00000518 System.Void UnityEngine.EventSystems.IPointerDownHandler::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
// 0x00000519 System.Void UnityEngine.EventSystems.IPointerUpHandler::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
// 0x0000051A System.Void UnityEngine.EventSystems.IPointerClickHandler::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
// 0x0000051B System.Void UnityEngine.EventSystems.IBeginDragHandler::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051C System.Void UnityEngine.EventSystems.IInitializePotentialDragHandler::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051D System.Void UnityEngine.EventSystems.IDragHandler::OnDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051E System.Void UnityEngine.EventSystems.IEndDragHandler::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
// 0x0000051F System.Void UnityEngine.EventSystems.IDropHandler::OnDrop(UnityEngine.EventSystems.PointerEventData)
// 0x00000520 System.Void UnityEngine.EventSystems.IScrollHandler::OnScroll(UnityEngine.EventSystems.PointerEventData)
// 0x00000521 System.Void UnityEngine.EventSystems.IUpdateSelectedHandler::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
// 0x00000522 System.Void UnityEngine.EventSystems.ISelectHandler::OnSelect(UnityEngine.EventSystems.BaseEventData)
// 0x00000523 System.Void UnityEngine.EventSystems.IDeselectHandler::OnDeselect(UnityEngine.EventSystems.BaseEventData)
// 0x00000524 System.Void UnityEngine.EventSystems.IMoveHandler::OnMove(UnityEngine.EventSystems.AxisEventData)
// 0x00000525 System.Void UnityEngine.EventSystems.ISubmitHandler::OnSubmit(UnityEngine.EventSystems.BaseEventData)
// 0x00000526 System.Void UnityEngine.EventSystems.ICancelHandler::OnCancel(UnityEngine.EventSystems.BaseEventData)
// 0x00000527 UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.EventSystem::get_current()
extern void EventSystem_get_current_m3151477735829089F66A3E46AD6DAB14CFDDE7BD (void);
// 0x00000528 System.Void UnityEngine.EventSystems.EventSystem::set_current(UnityEngine.EventSystems.EventSystem)
extern void EventSystem_set_current_mADC79D2345234F851DA554EF79746D43CC6B6951 (void);
// 0x00000529 System.Boolean UnityEngine.EventSystems.EventSystem::get_sendNavigationEvents()
extern void EventSystem_get_sendNavigationEvents_m38D86573D180189D107B782AD1F1ED183D45DAD3 (void);
// 0x0000052A System.Void UnityEngine.EventSystems.EventSystem::set_sendNavigationEvents(System.Boolean)
extern void EventSystem_set_sendNavigationEvents_m211BD472505E223CD056E46DFB3D53BBFCE9F02B (void);
// 0x0000052B System.Int32 UnityEngine.EventSystems.EventSystem::get_pixelDragThreshold()
extern void EventSystem_get_pixelDragThreshold_m8E8607E0C4E56387677507B45455A24D4680E0D3 (void);
// 0x0000052C System.Void UnityEngine.EventSystems.EventSystem::set_pixelDragThreshold(System.Int32)
extern void EventSystem_set_pixelDragThreshold_m71146B09FD2FDC1CC2BD228AFCCB424007DAB269 (void);
// 0x0000052D UnityEngine.EventSystems.BaseInputModule UnityEngine.EventSystems.EventSystem::get_currentInputModule()
extern void EventSystem_get_currentInputModule_mAA917C940E32ECAC4324D6824A9E0A951F16D891 (void);
// 0x0000052E UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_firstSelectedGameObject()
extern void EventSystem_get_firstSelectedGameObject_m8CAFDA874F89BDA34E0984860046C1C171B200E1 (void);
// 0x0000052F System.Void UnityEngine.EventSystems.EventSystem::set_firstSelectedGameObject(UnityEngine.GameObject)
extern void EventSystem_set_firstSelectedGameObject_m3B6CA2C6EDC32EAE5FAF1F7B6A52F5B00A882381 (void);
// 0x00000530 UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_currentSelectedGameObject()
extern void EventSystem_get_currentSelectedGameObject_mE28E78D268403602DE1FB6F059EE3E9CDB7325A4 (void);
// 0x00000531 UnityEngine.GameObject UnityEngine.EventSystems.EventSystem::get_lastSelectedGameObject()
extern void EventSystem_get_lastSelectedGameObject_m761188B5E33641891010B7BBBEEDDB1F267A6A29 (void);
// 0x00000532 System.Boolean UnityEngine.EventSystems.EventSystem::get_isFocused()
extern void EventSystem_get_isFocused_mB7275507B3AFEC15722B1F128CACB1BA578AEC3B (void);
// 0x00000533 System.Void UnityEngine.EventSystems.EventSystem::.ctor()
extern void EventSystem__ctor_m7DCB0D2525B2EBA3458C5B6911231DCDFBB21104 (void);
// 0x00000534 System.Void UnityEngine.EventSystems.EventSystem::UpdateModules()
extern void EventSystem_UpdateModules_m9E90C6FD7A4202BD6E4801C6AF109D859167FE8A (void);
// 0x00000535 System.Boolean UnityEngine.EventSystems.EventSystem::get_alreadySelecting()
extern void EventSystem_get_alreadySelecting_m419F4730CDDE5B742056F931D7445F6E4AD92B7D (void);
// 0x00000536 System.Void UnityEngine.EventSystems.EventSystem::SetSelectedGameObject(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData)
extern void EventSystem_SetSelectedGameObject_m532EE7D0346462EDBB56E5BCD048CB3BEFB84E3A (void);
// 0x00000537 UnityEngine.EventSystems.BaseEventData UnityEngine.EventSystems.EventSystem::get_baseEventDataCache()
extern void EventSystem_get_baseEventDataCache_m2B14076E5EF918BE1A94F16DE1A827AC1401BC89 (void);
// 0x00000538 System.Void UnityEngine.EventSystems.EventSystem::SetSelectedGameObject(UnityEngine.GameObject)
extern void EventSystem_SetSelectedGameObject_mBAD02D750DCDEFFE322C9373646E28396084ABE1 (void);
// 0x00000539 System.Int32 UnityEngine.EventSystems.EventSystem::RaycastComparer(UnityEngine.EventSystems.RaycastResult,UnityEngine.EventSystems.RaycastResult)
extern void EventSystem_RaycastComparer_mECA916E0B66A65018A1E7544E51C6D77BC52F1CA (void);
// 0x0000053A System.Void UnityEngine.EventSystems.EventSystem::RaycastAll(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void EventSystem_RaycastAll_mA5A53B5404EF95AE97EE81445056153ED41CBF80 (void);
// 0x0000053B System.Boolean UnityEngine.EventSystems.EventSystem::IsPointerOverGameObject()
extern void EventSystem_IsPointerOverGameObject_m6E12F740DD96F03F15AC324D6426C475A48506D0 (void);
// 0x0000053C System.Boolean UnityEngine.EventSystems.EventSystem::IsPointerOverGameObject(System.Int32)
extern void EventSystem_IsPointerOverGameObject_mF2B40021727C8285F99201995760659C2A53E513 (void);
// 0x0000053D System.Void UnityEngine.EventSystems.EventSystem::OnEnable()
extern void EventSystem_OnEnable_mE18ECC7BE60F739FEE9ABA731010E46A965894ED (void);
// 0x0000053E System.Void UnityEngine.EventSystems.EventSystem::OnDisable()
extern void EventSystem_OnDisable_m35EE11C87000577B20D754B063E0B5C6849FA7E4 (void);
// 0x0000053F System.Void UnityEngine.EventSystems.EventSystem::TickModules()
extern void EventSystem_TickModules_m0A74957A4FF307FF480D2103AD225640693EB8C3 (void);
// 0x00000540 System.Void UnityEngine.EventSystems.EventSystem::OnApplicationFocus(System.Boolean)
extern void EventSystem_OnApplicationFocus_m9DC07EB33D438D53366AC8EA989AA8325A1BE276 (void);
// 0x00000541 System.Void UnityEngine.EventSystems.EventSystem::Update()
extern void EventSystem_Update_m62B9E3C3F69A8A22EE9BE644E9B44221140754ED (void);
// 0x00000542 System.Void UnityEngine.EventSystems.EventSystem::ChangeEventModule(UnityEngine.EventSystems.BaseInputModule)
extern void EventSystem_ChangeEventModule_mE2CF924DE5717273AA345F5A52C46BA98C8ED662 (void);
// 0x00000543 System.String UnityEngine.EventSystems.EventSystem::ToString()
extern void EventSystem_ToString_mAD8804AA87C37BF28EE8712110C185E7135C15B5 (void);
// 0x00000544 System.Void UnityEngine.EventSystems.EventSystem::.cctor()
extern void EventSystem__cctor_m97E5871EEF081006E2793E916D0723D59DBE6EAD (void);
// 0x00000545 System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry> UnityEngine.EventSystems.EventTrigger::get_delegates()
extern void EventTrigger_get_delegates_mA3A792558AA5B16BB51CDF02BDDF8E9DCFED158C (void);
// 0x00000546 System.Void UnityEngine.EventSystems.EventTrigger::set_delegates(System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry>)
extern void EventTrigger_set_delegates_mCDACA955115E5F10D9C077A4CE5A2F25D5D38AED (void);
// 0x00000547 System.Void UnityEngine.EventSystems.EventTrigger::.ctor()
extern void EventTrigger__ctor_mE62DEDD1565721A55B77AEE673402A3F23A1A795 (void);
// 0x00000548 System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry> UnityEngine.EventSystems.EventTrigger::get_triggers()
extern void EventTrigger_get_triggers_m16CC3F855662E6CEE23031B7787DA8CB4ADDF28A (void);
// 0x00000549 System.Void UnityEngine.EventSystems.EventTrigger::set_triggers(System.Collections.Generic.List`1<UnityEngine.EventSystems.EventTrigger/Entry>)
extern void EventTrigger_set_triggers_mF70F72B1E143AEE94E07B032C3E057A22625467C (void);
// 0x0000054A System.Void UnityEngine.EventSystems.EventTrigger::Execute(UnityEngine.EventSystems.EventTriggerType,UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_Execute_m012E5ACD13CF24C4CEC5C3C9E508185A57EF2890 (void);
// 0x0000054B System.Void UnityEngine.EventSystems.EventTrigger::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerEnter_m04B452EA2C2516F98483F6EC242B6E321D6B5B40 (void);
// 0x0000054C System.Void UnityEngine.EventSystems.EventTrigger::OnPointerExit(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerExit_mF5EF9969978928D43D54F521F5D4F376D2339A7E (void);
// 0x0000054D System.Void UnityEngine.EventSystems.EventTrigger::OnDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnDrag_m5D9429B4EBFA5D7F759959B907DA492703B861C7 (void);
// 0x0000054E System.Void UnityEngine.EventSystems.EventTrigger::OnDrop(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnDrop_m790E82403AB8D54A0EA5FE1DF9C95D14870125C4 (void);
// 0x0000054F System.Void UnityEngine.EventSystems.EventTrigger::OnPointerDown(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerDown_mA287796A4055EB6364E660BE570206FC6F1DF46E (void);
// 0x00000550 System.Void UnityEngine.EventSystems.EventTrigger::OnPointerUp(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerUp_m6DE8F821DED7D2DB1DB37374D4898B6141AF4689 (void);
// 0x00000551 System.Void UnityEngine.EventSystems.EventTrigger::OnPointerClick(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnPointerClick_m5246E16B5764AB16420082BF7ECA58F6C06F622F (void);
// 0x00000552 System.Void UnityEngine.EventSystems.EventTrigger::OnSelect(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnSelect_mA9FDA907A6286FFA9F5BD9FB63D627B39B7591B9 (void);
// 0x00000553 System.Void UnityEngine.EventSystems.EventTrigger::OnDeselect(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnDeselect_mCBB9E32B7B8319CDE1D4199F3205C949D2A588B0 (void);
// 0x00000554 System.Void UnityEngine.EventSystems.EventTrigger::OnScroll(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnScroll_mF20D72F4751F7F184B0916BB3C198418D0C08AFA (void);
// 0x00000555 System.Void UnityEngine.EventSystems.EventTrigger::OnMove(UnityEngine.EventSystems.AxisEventData)
extern void EventTrigger_OnMove_m9D1B943ADA57BC17D5E38259D58513D8A7AF04A6 (void);
// 0x00000556 System.Void UnityEngine.EventSystems.EventTrigger::OnUpdateSelected(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnUpdateSelected_mE19A22DB72549942C6E8E935D73846E364D05587 (void);
// 0x00000557 System.Void UnityEngine.EventSystems.EventTrigger::OnInitializePotentialDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnInitializePotentialDrag_mD1299225787F1132CE52885AA6EFB1609348AB39 (void);
// 0x00000558 System.Void UnityEngine.EventSystems.EventTrigger::OnBeginDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnBeginDrag_m4B64A8BBE2C33FB05920E9166D205EBE471AC7FE (void);
// 0x00000559 System.Void UnityEngine.EventSystems.EventTrigger::OnEndDrag(UnityEngine.EventSystems.PointerEventData)
extern void EventTrigger_OnEndDrag_mB7B2D7B3602649D660633584CCFEAC5B23D29EEB (void);
// 0x0000055A System.Void UnityEngine.EventSystems.EventTrigger::OnSubmit(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnSubmit_m27A7419DF201835D24B4FE2FA1EA771D03B19DC3 (void);
// 0x0000055B System.Void UnityEngine.EventSystems.EventTrigger::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void EventTrigger_OnCancel_mF2EFE2A47874BF335F9BED5C583F1F32667CA20C (void);
// 0x0000055C T UnityEngine.EventSystems.ExecuteEvents::ValidateEventData(UnityEngine.EventSystems.BaseEventData)
// 0x0000055D System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerEnterHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mFB517B969B21E23CB5EAD0E9D4DB09A357727233 (void);
// 0x0000055E System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerExitHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mE64EB9BA625A97760C7A43F67DC976C6F7A8D0F8 (void);
// 0x0000055F System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerDownHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m177896660F17B1D4CC55DD2AEB8A2C783B582DC7 (void);
// 0x00000560 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerUpHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mDFB526FB6BE7B2C5266937D471D15F9D25C1DD8F (void);
// 0x00000561 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IPointerClickHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mA47467EEFB5EB9632375D95D39D2ED878AF286A2 (void);
// 0x00000562 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IInitializePotentialDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m5AB8EA95A58AFC2614E9921F16B0603D0EA8ADA6 (void);
// 0x00000563 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IBeginDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m1C2C7DA0379E8A119C415FAFF3B613C9D5278E5A (void);
// 0x00000564 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mDE9458FFE6DB4E5446D9B92FD59A9282EF0E26F1 (void);
// 0x00000565 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IEndDragHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m046FB8ED863B38BD15281E9EED004E9686B87184 (void);
// 0x00000566 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDropHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_mEF9FBBA3E2BDF08B51E80190C3BC9C0E0204C417 (void);
// 0x00000567 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IScrollHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m00514A1B45480BC9D55FA88B66914ED163B6A6CC (void);
// 0x00000568 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IUpdateSelectedHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m2D4B7103DCEA057526CDF142A4D4C70136CC8233 (void);
// 0x00000569 System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ISelectHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m00C0AAED23C33309955E60AB6319863A3052AE61 (void);
// 0x0000056A System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IDeselectHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m8B55F40246FBF954F2C9981BEEEA0828A770A697 (void);
// 0x0000056B System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.IMoveHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m7CCC77D770D79991096597CD2FE892267BA7BA4B (void);
// 0x0000056C System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ISubmitHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m5354ABE381C181AA8B3514D1849E7788758E8505 (void);
// 0x0000056D System.Void UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.EventSystems.ICancelHandler,UnityEngine.EventSystems.BaseEventData)
extern void ExecuteEvents_Execute_m66FD7F4E4DE2617EE432AD9DA0D3A258C5F1FBFB (void);
// 0x0000056E UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerEnterHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerEnterHandler()
extern void ExecuteEvents_get_pointerEnterHandler_mFD5296E38EB1C5EB6D16CB83913430FEEBF889A5 (void);
// 0x0000056F UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerExitHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerExitHandler()
extern void ExecuteEvents_get_pointerExitHandler_mE5EC9537676A055EEE178A4E6B58D96F9B4AC301 (void);
// 0x00000570 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerDownHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerDownHandler()
extern void ExecuteEvents_get_pointerDownHandler_m8AE9CA906C86BBBEB75BA2D05F5DAB01F62519E3 (void);
// 0x00000571 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerUpHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerUpHandler()
extern void ExecuteEvents_get_pointerUpHandler_m7EDDD1128DC04344CECEBCB9B6B7CD064F7FAED2 (void);
// 0x00000572 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IPointerClickHandler> UnityEngine.EventSystems.ExecuteEvents::get_pointerClickHandler()
extern void ExecuteEvents_get_pointerClickHandler_mA657195AEC7D0A42036CBCAC9AD48F215C3C69E3 (void);
// 0x00000573 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IInitializePotentialDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_initializePotentialDrag()
extern void ExecuteEvents_get_initializePotentialDrag_m5B3D899EB08DA227EFBFC67778DDB98D7505C6D4 (void);
// 0x00000574 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IBeginDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_beginDragHandler()
extern void ExecuteEvents_get_beginDragHandler_m7F238765714F73899EAFDF0BA203D9A8A57AED31 (void);
// 0x00000575 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_dragHandler()
extern void ExecuteEvents_get_dragHandler_m41B7D77771806788CD773C83C2E5A53D5ED5B179 (void);
// 0x00000576 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IEndDragHandler> UnityEngine.EventSystems.ExecuteEvents::get_endDragHandler()
extern void ExecuteEvents_get_endDragHandler_m23B60D3E3873043263069A3C3145393475690769 (void);
// 0x00000577 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDropHandler> UnityEngine.EventSystems.ExecuteEvents::get_dropHandler()
extern void ExecuteEvents_get_dropHandler_mC2362B96C6CD3628B83722F4B7C73E707C6C1EAF (void);
// 0x00000578 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IScrollHandler> UnityEngine.EventSystems.ExecuteEvents::get_scrollHandler()
extern void ExecuteEvents_get_scrollHandler_m48E5B17388986BD59EC7A7BF27E3D30A9FD057F7 (void);
// 0x00000579 UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IUpdateSelectedHandler> UnityEngine.EventSystems.ExecuteEvents::get_updateSelectedHandler()
extern void ExecuteEvents_get_updateSelectedHandler_mE18DBB058B1EDC75D4F690A1E35003749BBC0567 (void);
// 0x0000057A UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ISelectHandler> UnityEngine.EventSystems.ExecuteEvents::get_selectHandler()
extern void ExecuteEvents_get_selectHandler_m26186C0D78CA4A8AFA0789A09F488F7E186BE1C8 (void);
// 0x0000057B UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IDeselectHandler> UnityEngine.EventSystems.ExecuteEvents::get_deselectHandler()
extern void ExecuteEvents_get_deselectHandler_mEAA9E3701CC972EFDD20B30E9B3CD9302B2FD668 (void);
// 0x0000057C UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.IMoveHandler> UnityEngine.EventSystems.ExecuteEvents::get_moveHandler()
extern void ExecuteEvents_get_moveHandler_m113A4222FC10723B2E38398E182C02F6624D6F24 (void);
// 0x0000057D UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ISubmitHandler> UnityEngine.EventSystems.ExecuteEvents::get_submitHandler()
extern void ExecuteEvents_get_submitHandler_m734C2BE2F7CDA7F5C42897E3C8023D3C7E1EDF88 (void);
// 0x0000057E UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<UnityEngine.EventSystems.ICancelHandler> UnityEngine.EventSystems.ExecuteEvents::get_cancelHandler()
extern void ExecuteEvents_get_cancelHandler_m5DB4A9513FB8B9248AE555F7D8E8043175B8D995 (void);
// 0x0000057F System.Void UnityEngine.EventSystems.ExecuteEvents::GetEventChain(UnityEngine.GameObject,System.Collections.Generic.IList`1<UnityEngine.Transform>)
extern void ExecuteEvents_GetEventChain_mD90FFC4A70E16AFA81AC6C9CFF174630F77C608C (void);
// 0x00000580 System.Boolean UnityEngine.EventSystems.ExecuteEvents::Execute(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData,UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<T>)
// 0x00000581 UnityEngine.GameObject UnityEngine.EventSystems.ExecuteEvents::ExecuteHierarchy(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData,UnityEngine.EventSystems.ExecuteEvents/EventFunction`1<T>)
// 0x00000582 System.Boolean UnityEngine.EventSystems.ExecuteEvents::ShouldSendToComponent(UnityEngine.Component)
// 0x00000583 System.Void UnityEngine.EventSystems.ExecuteEvents::GetEventList(UnityEngine.GameObject,System.Collections.Generic.IList`1<UnityEngine.EventSystems.IEventSystemHandler>)
// 0x00000584 System.Boolean UnityEngine.EventSystems.ExecuteEvents::CanHandleEvent(UnityEngine.GameObject)
// 0x00000585 UnityEngine.GameObject UnityEngine.EventSystems.ExecuteEvents::GetEventHandler(UnityEngine.GameObject)
// 0x00000586 System.Void UnityEngine.EventSystems.ExecuteEvents::.cctor()
extern void ExecuteEvents__cctor_mCD47C80D80A3C5F1D3AEEF3ACD31AD1EE197A883 (void);
// 0x00000587 System.String UnityEngine.EventSystems.BaseInput::get_compositionString()
extern void BaseInput_get_compositionString_m55FC44652CE283EC56A7E07186F6EF6160B0A122 (void);
// 0x00000588 UnityEngine.IMECompositionMode UnityEngine.EventSystems.BaseInput::get_imeCompositionMode()
extern void BaseInput_get_imeCompositionMode_mC26A90D1DDE30CEE508412D8F1FEA5AD37671DA8 (void);
// 0x00000589 System.Void UnityEngine.EventSystems.BaseInput::set_imeCompositionMode(UnityEngine.IMECompositionMode)
extern void BaseInput_set_imeCompositionMode_mC83B4474B044D31D81FF18CD35AE6E9CEC5A6BC3 (void);
// 0x0000058A UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_compositionCursorPos()
extern void BaseInput_get_compositionCursorPos_m08E6856B2A7240E1FEF880323757BDF8A4917046 (void);
// 0x0000058B System.Void UnityEngine.EventSystems.BaseInput::set_compositionCursorPos(UnityEngine.Vector2)
extern void BaseInput_set_compositionCursorPos_m48AAACE26E07BE130D5533F1BAA26741FD8B0F82 (void);
// 0x0000058C System.Boolean UnityEngine.EventSystems.BaseInput::get_mousePresent()
extern void BaseInput_get_mousePresent_mFA34ADCAE87E52208D112B46C1F8ABCEC60D585C (void);
// 0x0000058D System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButtonDown(System.Int32)
extern void BaseInput_GetMouseButtonDown_m5891841C7252506A8A6BDBD2DAC6A60A234E7CC5 (void);
// 0x0000058E System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButtonUp(System.Int32)
extern void BaseInput_GetMouseButtonUp_mEAADD66C40FDBE90A787E6892081B89A816B7768 (void);
// 0x0000058F System.Boolean UnityEngine.EventSystems.BaseInput::GetMouseButton(System.Int32)
extern void BaseInput_GetMouseButton_m2F512EB6088BEB4D69F3FF07115653C4E4E62A77 (void);
// 0x00000590 UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_mousePosition()
extern void BaseInput_get_mousePosition_m020D1FB7D27B45D19303B7B9E05038F2C7DA02ED (void);
// 0x00000591 UnityEngine.Vector2 UnityEngine.EventSystems.BaseInput::get_mouseScrollDelta()
extern void BaseInput_get_mouseScrollDelta_mBF6C6F5DD4C626413DEB5081A34D58C2F178389F (void);
// 0x00000592 System.Boolean UnityEngine.EventSystems.BaseInput::get_touchSupported()
extern void BaseInput_get_touchSupported_mDDDA5078A3F2B0E8B3B5181C9B8DC4D10C9B57D9 (void);
// 0x00000593 System.Int32 UnityEngine.EventSystems.BaseInput::get_touchCount()
extern void BaseInput_get_touchCount_m81840E0A652F5C646D18F6E0E13B4D6D4319435F (void);
// 0x00000594 UnityEngine.Touch UnityEngine.EventSystems.BaseInput::GetTouch(System.Int32)
extern void BaseInput_GetTouch_m156C4B5ADC8DE91BADE25D16422FDBB1B7B052A5 (void);
// 0x00000595 System.Single UnityEngine.EventSystems.BaseInput::GetAxisRaw(System.String)
extern void BaseInput_GetAxisRaw_mB6FE3749F8E040C6C86EDBBB8F0DC9E9B8A3D5B8 (void);
// 0x00000596 System.Boolean UnityEngine.EventSystems.BaseInput::GetButtonDown(System.String)
extern void BaseInput_GetButtonDown_m3EBF9A26EF50036386640FE5089DAB8EFF7B48BA (void);
// 0x00000597 System.Void UnityEngine.EventSystems.BaseInput::.ctor()
extern void BaseInput__ctor_m33F85C42EA9300A022A8328A83D1CB9FCEC6F042 (void);
// 0x00000598 UnityEngine.EventSystems.BaseInput UnityEngine.EventSystems.BaseInputModule::get_input()
extern void BaseInputModule_get_input_m385A99609A705346D5288D047EE17374ED406BE7 (void);
// 0x00000599 UnityEngine.EventSystems.BaseInput UnityEngine.EventSystems.BaseInputModule::get_inputOverride()
extern void BaseInputModule_get_inputOverride_m3C63C410A33009ACB7EAFB776066F734110391B8 (void);
// 0x0000059A System.Void UnityEngine.EventSystems.BaseInputModule::set_inputOverride(UnityEngine.EventSystems.BaseInput)
extern void BaseInputModule_set_inputOverride_mE88337B26EC069A3866174887FF59B1CD5C7EB85 (void);
// 0x0000059B UnityEngine.EventSystems.EventSystem UnityEngine.EventSystems.BaseInputModule::get_eventSystem()
extern void BaseInputModule_get_eventSystem_mEF6DEC17FF56D786AA217A52FCCFE8C6F38546BE (void);
// 0x0000059C System.Void UnityEngine.EventSystems.BaseInputModule::OnEnable()
extern void BaseInputModule_OnEnable_mD8CAA2DE8AEC7907D84C40DEA7A0A83A8C530D5E (void);
// 0x0000059D System.Void UnityEngine.EventSystems.BaseInputModule::OnDisable()
extern void BaseInputModule_OnDisable_m22FEF0A66345808B69CDDCFE47E506645EB1013C (void);
// 0x0000059E System.Void UnityEngine.EventSystems.BaseInputModule::Process()
// 0x0000059F UnityEngine.EventSystems.RaycastResult UnityEngine.EventSystems.BaseInputModule::FindFirstRaycast(System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void BaseInputModule_FindFirstRaycast_m4ABCD1BCF871A87518D47C906B8F63154B6BF275 (void);
// 0x000005A0 UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.BaseInputModule::DetermineMoveDirection(System.Single,System.Single)
extern void BaseInputModule_DetermineMoveDirection_mF99EA376D26F543AF0C3B10CC67AB9493054AA53 (void);
// 0x000005A1 UnityEngine.EventSystems.MoveDirection UnityEngine.EventSystems.BaseInputModule::DetermineMoveDirection(System.Single,System.Single,System.Single)
extern void BaseInputModule_DetermineMoveDirection_mC1D1D145996C9A384D865FAE4B02FDF9D106EA52 (void);
// 0x000005A2 UnityEngine.GameObject UnityEngine.EventSystems.BaseInputModule::FindCommonRoot(UnityEngine.GameObject,UnityEngine.GameObject)
extern void BaseInputModule_FindCommonRoot_m1995190ADC1341F180811C5213F1CA522B6282A5 (void);
// 0x000005A3 System.Void UnityEngine.EventSystems.BaseInputModule::HandlePointerExitAndEnter(UnityEngine.EventSystems.PointerEventData,UnityEngine.GameObject)
extern void BaseInputModule_HandlePointerExitAndEnter_mD32C0E209A19F78D07D964D162188D13762463BF (void);
// 0x000005A4 UnityEngine.EventSystems.AxisEventData UnityEngine.EventSystems.BaseInputModule::GetAxisEventData(System.Single,System.Single,System.Single)
extern void BaseInputModule_GetAxisEventData_m920ACD6398A0B3FD82E6990DF89B2A50DEE25990 (void);
// 0x000005A5 UnityEngine.EventSystems.BaseEventData UnityEngine.EventSystems.BaseInputModule::GetBaseEventData()
extern void BaseInputModule_GetBaseEventData_mB945B5DF7A5C2B825C7D542D944A7795D8F5F93F (void);
// 0x000005A6 System.Boolean UnityEngine.EventSystems.BaseInputModule::IsPointerOverGameObject(System.Int32)
extern void BaseInputModule_IsPointerOverGameObject_m4255E7C2D628B5E4524D02A2E26158DDE8640CF5 (void);
// 0x000005A7 System.Boolean UnityEngine.EventSystems.BaseInputModule::ShouldActivateModule()
extern void BaseInputModule_ShouldActivateModule_mA3CFFC349E1188C750346FC1B52F44D770104BCD (void);
// 0x000005A8 System.Void UnityEngine.EventSystems.BaseInputModule::DeactivateModule()
extern void BaseInputModule_DeactivateModule_m02E0A94E9EBC6793439FE1ABF81F2E84B79C7249 (void);
// 0x000005A9 System.Void UnityEngine.EventSystems.BaseInputModule::ActivateModule()
extern void BaseInputModule_ActivateModule_m1F16D868703EBA8610E0C2DF86B4760F934631D7 (void);
// 0x000005AA System.Void UnityEngine.EventSystems.BaseInputModule::UpdateModule()
extern void BaseInputModule_UpdateModule_m8A5973C39616DF6C34041F93014C2469DC667DE2 (void);
// 0x000005AB System.Boolean UnityEngine.EventSystems.BaseInputModule::IsModuleSupported()
extern void BaseInputModule_IsModuleSupported_mD2BB3DD4CF96C31549AED158F0753AE345C01647 (void);
// 0x000005AC System.Void UnityEngine.EventSystems.BaseInputModule::.ctor()
extern void BaseInputModule__ctor_m4D2F1DB4FA2524BCB5598111C11E5E00D4A95DC6 (void);
// 0x000005AD System.Boolean UnityEngine.EventSystems.PointerInputModule::GetPointerData(System.Int32,UnityEngine.EventSystems.PointerEventData&,System.Boolean)
extern void PointerInputModule_GetPointerData_mB16DD3B9751FFEBBB1EC7802533D8EF36C9C8248 (void);
// 0x000005AE System.Void UnityEngine.EventSystems.PointerInputModule::RemovePointerData(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_RemovePointerData_mDDADB278A6A01D38C46631A9531C62C17B4DEBEA (void);
// 0x000005AF UnityEngine.EventSystems.PointerEventData UnityEngine.EventSystems.PointerInputModule::GetTouchPointerEventData(UnityEngine.Touch,System.Boolean&,System.Boolean&)
extern void PointerInputModule_GetTouchPointerEventData_m630FA2AD7438552F7AF904ED42EA90FADD910055 (void);
// 0x000005B0 System.Void UnityEngine.EventSystems.PointerInputModule::CopyFromTo(UnityEngine.EventSystems.PointerEventData,UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_CopyFromTo_mDCFE9EA1411C24FA9ABDA993CC16182C2B1AF687 (void);
// 0x000005B1 UnityEngine.EventSystems.PointerEventData/FramePressState UnityEngine.EventSystems.PointerInputModule::StateForMouseButton(System.Int32)
extern void PointerInputModule_StateForMouseButton_m182B203D7CB0A9E0F39F39FAC8C0020D85C26D22 (void);
// 0x000005B2 UnityEngine.EventSystems.PointerInputModule/MouseState UnityEngine.EventSystems.PointerInputModule::GetMousePointerEventData()
extern void PointerInputModule_GetMousePointerEventData_mA8B6C810AE130118AA18CD4BD35F8F5BCE0D7E07 (void);
// 0x000005B3 UnityEngine.EventSystems.PointerInputModule/MouseState UnityEngine.EventSystems.PointerInputModule::GetMousePointerEventData(System.Int32)
extern void PointerInputModule_GetMousePointerEventData_m1BE3C022E0D9B001B96B9FB129FE57FEBFD13E7F (void);
// 0x000005B4 UnityEngine.EventSystems.PointerEventData UnityEngine.EventSystems.PointerInputModule::GetLastPointerEventData(System.Int32)
extern void PointerInputModule_GetLastPointerEventData_m709537DE2BCDD6D50C4C2F39B6A48C4D9A8A27F5 (void);
// 0x000005B5 System.Boolean UnityEngine.EventSystems.PointerInputModule::ShouldStartDrag(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Boolean)
extern void PointerInputModule_ShouldStartDrag_mE818EC5B7706E3803A4EDA09FD1D14A0ED105049 (void);
// 0x000005B6 System.Void UnityEngine.EventSystems.PointerInputModule::ProcessMove(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_ProcessMove_mF69B051D56D97F33857794A5EBB0A952AEAA276F (void);
// 0x000005B7 System.Void UnityEngine.EventSystems.PointerInputModule::ProcessDrag(UnityEngine.EventSystems.PointerEventData)
extern void PointerInputModule_ProcessDrag_m1B953F6640DBD2E46508B18F4F281ED461DD1360 (void);
// 0x000005B8 System.Boolean UnityEngine.EventSystems.PointerInputModule::IsPointerOverGameObject(System.Int32)
extern void PointerInputModule_IsPointerOverGameObject_m8F735B4286B61B82E9C92966B99A9A2D575495F5 (void);
// 0x000005B9 System.Void UnityEngine.EventSystems.PointerInputModule::ClearSelection()
extern void PointerInputModule_ClearSelection_m05E527F28FB39BEBA8FA27153DAE71C8E7FDC958 (void);
// 0x000005BA System.String UnityEngine.EventSystems.PointerInputModule::ToString()
extern void PointerInputModule_ToString_mD9C4C6C80C3CFD3A8C1E39D4F9A58A9E29DD1865 (void);
// 0x000005BB System.Void UnityEngine.EventSystems.PointerInputModule::DeselectIfSelectionChanged(UnityEngine.GameObject,UnityEngine.EventSystems.BaseEventData)
extern void PointerInputModule_DeselectIfSelectionChanged_m3A32EDB68D6F489FD2A22CAB5A98D343E0634BDD (void);
// 0x000005BC System.Void UnityEngine.EventSystems.PointerInputModule::.ctor()
extern void PointerInputModule__ctor_m1E5E97188BEB6F225E167E5D2BA6DAEF4BFA3510 (void);
// 0x000005BD System.Void UnityEngine.EventSystems.StandaloneInputModule::.ctor()
extern void StandaloneInputModule__ctor_m7ACED26CC5670B0729809379560FCBE0D0311AC8 (void);
// 0x000005BE UnityEngine.EventSystems.StandaloneInputModule/InputMode UnityEngine.EventSystems.StandaloneInputModule::get_inputMode()
extern void StandaloneInputModule_get_inputMode_m9E4FF00674C049A7F600D0CC5D278F474232B3D4 (void);
// 0x000005BF System.Boolean UnityEngine.EventSystems.StandaloneInputModule::get_allowActivationOnMobileDevice()
extern void StandaloneInputModule_get_allowActivationOnMobileDevice_mEBF5E05C6A412A45CCB07502C4798DCE743FDAEF (void);
// 0x000005C0 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_allowActivationOnMobileDevice(System.Boolean)
extern void StandaloneInputModule_set_allowActivationOnMobileDevice_m00941F74B0F6A1EB46E2BD52FF4907BE0617D547 (void);
// 0x000005C1 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::get_forceModuleActive()
extern void StandaloneInputModule_get_forceModuleActive_m6D41F04E01F96727E0246D6B74F63E0312E25022 (void);
// 0x000005C2 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_forceModuleActive(System.Boolean)
extern void StandaloneInputModule_set_forceModuleActive_m0438ABF86C05D6ACCE740D0464190AB0B2B44134 (void);
// 0x000005C3 System.Single UnityEngine.EventSystems.StandaloneInputModule::get_inputActionsPerSecond()
extern void StandaloneInputModule_get_inputActionsPerSecond_m9F5DE02D9DF4B16A6E0D0F36CB0CD293AB9C14EC (void);
// 0x000005C4 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_inputActionsPerSecond(System.Single)
extern void StandaloneInputModule_set_inputActionsPerSecond_m13D9F85BEB9BBE3C28498C3248C298AD86129950 (void);
// 0x000005C5 System.Single UnityEngine.EventSystems.StandaloneInputModule::get_repeatDelay()
extern void StandaloneInputModule_get_repeatDelay_m4FE04D7CFC8C789C9503E841FC5E0711CB0F8986 (void);
// 0x000005C6 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_repeatDelay(System.Single)
extern void StandaloneInputModule_set_repeatDelay_mD0B81B79DE60C3C26CAF2CDF1DAC32D02B148AFD (void);
// 0x000005C7 System.String UnityEngine.EventSystems.StandaloneInputModule::get_horizontalAxis()
extern void StandaloneInputModule_get_horizontalAxis_m0C0B26CDBBBD3AC956FBF77BB177BD719DF41791 (void);
// 0x000005C8 System.Void UnityEngine.EventSystems.StandaloneInputModule::set_horizontalAxis(System.String)
extern void StandaloneInputModule_set_horizontalAxis_m6458621A42F073F7CC8EDF884E3FBC3C2BBAA7B1 (void);
// 0x000005C9 System.String UnityEngine.EventSystems.StandaloneInputModule::get_verticalAxis()
extern void StandaloneInputModule_get_verticalAxis_mDF726FB43588DFA1D52E4CD825637B577EE06ED6 (void);
// 0x000005CA System.Void UnityEngine.EventSystems.StandaloneInputModule::set_verticalAxis(System.String)
extern void StandaloneInputModule_set_verticalAxis_mA75D79740A9057B319CF78A49209A35243E16948 (void);
// 0x000005CB System.String UnityEngine.EventSystems.StandaloneInputModule::get_submitButton()
extern void StandaloneInputModule_get_submitButton_m19B44B9FA36F84540E00BBBF7AA38799D2F2B0B3 (void);
// 0x000005CC System.Void UnityEngine.EventSystems.StandaloneInputModule::set_submitButton(System.String)
extern void StandaloneInputModule_set_submitButton_m4DB70E5FBAAE564C3CFD6C8908B9B19D247949A8 (void);
// 0x000005CD System.String UnityEngine.EventSystems.StandaloneInputModule::get_cancelButton()
extern void StandaloneInputModule_get_cancelButton_m0FB6DBE18639C06D6A124D89F2754F21D0F4CD76 (void);
// 0x000005CE System.Void UnityEngine.EventSystems.StandaloneInputModule::set_cancelButton(System.String)
extern void StandaloneInputModule_set_cancelButton_m4E19B22DEAF8E7C5F3C3A29B0198173772CB8A26 (void);
// 0x000005CF System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ShouldIgnoreEventsOnNoFocus()
extern void StandaloneInputModule_ShouldIgnoreEventsOnNoFocus_m00C2E7810D0D323B1A4A72097A75C6C2A87F0D9C (void);
// 0x000005D0 System.Void UnityEngine.EventSystems.StandaloneInputModule::UpdateModule()
extern void StandaloneInputModule_UpdateModule_m0525AD093E45EFB1FE8484731A81C3E45222EFB9 (void);
// 0x000005D1 System.Void UnityEngine.EventSystems.StandaloneInputModule::ReleaseMouse(UnityEngine.EventSystems.PointerEventData,UnityEngine.GameObject)
extern void StandaloneInputModule_ReleaseMouse_m1EE3D0D685BB09DAAE4556477420B7D05FE3F0C1 (void);
// 0x000005D2 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::IsModuleSupported()
extern void StandaloneInputModule_IsModuleSupported_mB6AE0DFF7278B18B24FD5FC1D1ACE571D26FCABA (void);
// 0x000005D3 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ShouldActivateModule()
extern void StandaloneInputModule_ShouldActivateModule_mD6CF146E884E38E295E95C6AC3A355029E653D35 (void);
// 0x000005D4 System.Void UnityEngine.EventSystems.StandaloneInputModule::ActivateModule()
extern void StandaloneInputModule_ActivateModule_m4861DB0128B954D53E51FB5A6CC1524346F76A1E (void);
// 0x000005D5 System.Void UnityEngine.EventSystems.StandaloneInputModule::DeactivateModule()
extern void StandaloneInputModule_DeactivateModule_m3495EC499261ADF166421DB15383F2808614CFDA (void);
// 0x000005D6 System.Void UnityEngine.EventSystems.StandaloneInputModule::Process()
extern void StandaloneInputModule_Process_mBF40EA3762B85C417E6F88D531174D05A7FFCE75 (void);
// 0x000005D7 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ProcessTouchEvents()
extern void StandaloneInputModule_ProcessTouchEvents_mFEED66642E804A218DD34A9C5F0F8EAA5CA3B019 (void);
// 0x000005D8 System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessTouchPress(UnityEngine.EventSystems.PointerEventData,System.Boolean,System.Boolean)
extern void StandaloneInputModule_ProcessTouchPress_m74A52DA64B9C5EB8B5A38889F25BFEAFC284FB51 (void);
// 0x000005D9 System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendSubmitEventToSelectedObject()
extern void StandaloneInputModule_SendSubmitEventToSelectedObject_m132BF623619679A3E5871B7DA5BC5DD7B2E274DA (void);
// 0x000005DA UnityEngine.Vector2 UnityEngine.EventSystems.StandaloneInputModule::GetRawMoveVector()
extern void StandaloneInputModule_GetRawMoveVector_m36E309DADA8C0BB4CA0710FAABE0F4E9B77C2F6A (void);
// 0x000005DB System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendMoveEventToSelectedObject()
extern void StandaloneInputModule_SendMoveEventToSelectedObject_m45E5CAE198660284CF7DB1FA464B79F9E26D44D3 (void);
// 0x000005DC System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMouseEvent()
extern void StandaloneInputModule_ProcessMouseEvent_m54B75447C4D230F1FBB2E9A440B323403CC176C0 (void);
// 0x000005DD System.Boolean UnityEngine.EventSystems.StandaloneInputModule::ForceAutoSelect()
extern void StandaloneInputModule_ForceAutoSelect_m89726C63D482B7D8529A5FD74E57FB8A92107F02 (void);
// 0x000005DE System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMouseEvent(System.Int32)
extern void StandaloneInputModule_ProcessMouseEvent_m4D1CB4E39517B014D3F81B9F0423B8FA6F8A8656 (void);
// 0x000005DF System.Boolean UnityEngine.EventSystems.StandaloneInputModule::SendUpdateEventToSelectedObject()
extern void StandaloneInputModule_SendUpdateEventToSelectedObject_m2982A721762040935DE3835DE71FBA28650036FB (void);
// 0x000005E0 System.Void UnityEngine.EventSystems.StandaloneInputModule::ProcessMousePress(UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData)
extern void StandaloneInputModule_ProcessMousePress_m795F279F981E957475C724C010FA8A87F9BE6CF4 (void);
// 0x000005E1 UnityEngine.GameObject UnityEngine.EventSystems.StandaloneInputModule::GetCurrentFocusedGameObject()
extern void StandaloneInputModule_GetCurrentFocusedGameObject_mA354FCB4E2546E1F49D165207705A26D29EBB3D7 (void);
// 0x000005E2 System.Void UnityEngine.EventSystems.TouchInputModule::.ctor()
extern void TouchInputModule__ctor_m170CD0EBE44E63A7061C8EA789455F21D0CB28ED (void);
// 0x000005E3 System.Boolean UnityEngine.EventSystems.TouchInputModule::get_allowActivationOnStandalone()
extern void TouchInputModule_get_allowActivationOnStandalone_mEC3885BA609BB734A3E8D2966B6CE6EF84789DBA (void);
// 0x000005E4 System.Void UnityEngine.EventSystems.TouchInputModule::set_allowActivationOnStandalone(System.Boolean)
extern void TouchInputModule_set_allowActivationOnStandalone_mB68D39F944C1E53061FADE6C67249B0A850168AA (void);
// 0x000005E5 System.Boolean UnityEngine.EventSystems.TouchInputModule::get_forceModuleActive()
extern void TouchInputModule_get_forceModuleActive_m000AEC6C27D5CA88EA2B87C33C9991F4F50D007F (void);
// 0x000005E6 System.Void UnityEngine.EventSystems.TouchInputModule::set_forceModuleActive(System.Boolean)
extern void TouchInputModule_set_forceModuleActive_m75A21D5518C85738F24D394A54981CC8BE4BC9D4 (void);
// 0x000005E7 System.Void UnityEngine.EventSystems.TouchInputModule::UpdateModule()
extern void TouchInputModule_UpdateModule_mAA1097F92F5F1808251CB8D9BFD124AE2663AEDA (void);
// 0x000005E8 System.Boolean UnityEngine.EventSystems.TouchInputModule::IsModuleSupported()
extern void TouchInputModule_IsModuleSupported_m0F4864F8FCBCA2AF3820A53EB3D8634FAB6763E5 (void);
// 0x000005E9 System.Boolean UnityEngine.EventSystems.TouchInputModule::ShouldActivateModule()
extern void TouchInputModule_ShouldActivateModule_mB2F45197C70AC23D1250782612B10ACBC1262022 (void);
// 0x000005EA System.Boolean UnityEngine.EventSystems.TouchInputModule::UseFakeInput()
extern void TouchInputModule_UseFakeInput_m2DE0550826DD4CA1249AB4AC2315DCA7F3AE571A (void);
// 0x000005EB System.Void UnityEngine.EventSystems.TouchInputModule::Process()
extern void TouchInputModule_Process_mA3BE6F717B77FE0267EBF12C53E9EA990E40EE48 (void);
// 0x000005EC System.Void UnityEngine.EventSystems.TouchInputModule::FakeTouches()
extern void TouchInputModule_FakeTouches_mB10F6B25D8CFACA3FD96C1823E6E4FF6427A5663 (void);
// 0x000005ED System.Void UnityEngine.EventSystems.TouchInputModule::ProcessTouchEvents()
extern void TouchInputModule_ProcessTouchEvents_m6A97A06586A000FF8C4C14DEEEE64E6876A79F08 (void);
// 0x000005EE System.Void UnityEngine.EventSystems.TouchInputModule::ProcessTouchPress(UnityEngine.EventSystems.PointerEventData,System.Boolean,System.Boolean)
extern void TouchInputModule_ProcessTouchPress_m10A4854C822E110906745CFB1EEAF846F48D2949 (void);
// 0x000005EF System.Void UnityEngine.EventSystems.TouchInputModule::DeactivateModule()
extern void TouchInputModule_DeactivateModule_m33EF87C66E547851B2FB23168182DEB86066ACE1 (void);
// 0x000005F0 System.String UnityEngine.EventSystems.TouchInputModule::ToString()
extern void TouchInputModule_ToString_m532F4130976306175BFCF9831A6F470346995BD2 (void);
// 0x000005F1 UnityEngine.GameObject UnityEngine.EventSystems.RaycastResult::get_gameObject()
extern void RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD (void);
// 0x000005F2 System.Void UnityEngine.EventSystems.RaycastResult::set_gameObject(UnityEngine.GameObject)
extern void RaycastResult_set_gameObject_m5EF3316E0D32FC1B45BB2BC087EC42E436DA1C07 (void);
// 0x000005F3 System.Boolean UnityEngine.EventSystems.RaycastResult::get_isValid()
extern void RaycastResult_get_isValid_m53278AA3529BC7B909A9AA082026D51CE6926813 (void);
// 0x000005F4 System.Void UnityEngine.EventSystems.RaycastResult::Clear()
extern void RaycastResult_Clear_m5C979A22E0B12FBD7BA035FE0815B4D81E82E9F7 (void);
// 0x000005F5 System.String UnityEngine.EventSystems.RaycastResult::ToString()
extern void RaycastResult_ToString_mFD0F27611425231BAF089CEBB0332FEFD7FB9E21 (void);
// 0x000005F6 System.Void UnityEngine.EventSystems.RaycasterManager::AddRaycaster(UnityEngine.EventSystems.BaseRaycaster)
extern void RaycasterManager_AddRaycaster_mB93CFBBCE344327BF96AC11CB500219FD1873B9A (void);
// 0x000005F7 System.Collections.Generic.List`1<UnityEngine.EventSystems.BaseRaycaster> UnityEngine.EventSystems.RaycasterManager::GetRaycasters()
extern void RaycasterManager_GetRaycasters_mA2491B7F058FB2DA88179C0BDE0EFB0B0E28B740 (void);
// 0x000005F8 System.Void UnityEngine.EventSystems.RaycasterManager::RemoveRaycasters(UnityEngine.EventSystems.BaseRaycaster)
extern void RaycasterManager_RemoveRaycasters_m26668BA781D690D83E3417436D2D9AE577004624 (void);
// 0x000005F9 System.Void UnityEngine.EventSystems.RaycasterManager::.cctor()
extern void RaycasterManager__cctor_mEF2E08745F0138B43512752C0E151055B953A3AF (void);
// 0x000005FA System.Void UnityEngine.EventSystems.BaseRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
// 0x000005FB UnityEngine.Camera UnityEngine.EventSystems.BaseRaycaster::get_eventCamera()
// 0x000005FC System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_priority()
extern void BaseRaycaster_get_priority_mF085F1BF77E4D69D84A8ACCFF61FBD80EB55AF50 (void);
// 0x000005FD System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_sortOrderPriority()
extern void BaseRaycaster_get_sortOrderPriority_m03BB34962FDC88F04B94A160138EC8C49BB50595 (void);
// 0x000005FE System.Int32 UnityEngine.EventSystems.BaseRaycaster::get_renderOrderPriority()
extern void BaseRaycaster_get_renderOrderPriority_mEF4CA94A52D130A2546E094C2C492B7DEAD6F3C4 (void);
// 0x000005FF UnityEngine.EventSystems.BaseRaycaster UnityEngine.EventSystems.BaseRaycaster::get_rootRaycaster()
extern void BaseRaycaster_get_rootRaycaster_m4DF6B023C195A4E8E9AF8D8E411379A9052D80A5 (void);
// 0x00000600 System.String UnityEngine.EventSystems.BaseRaycaster::ToString()
extern void BaseRaycaster_ToString_mED39E4461F0C708B924FC87DB5A2949917FF42F1 (void);
// 0x00000601 System.Void UnityEngine.EventSystems.BaseRaycaster::OnEnable()
extern void BaseRaycaster_OnEnable_m31B91C059934DAB7FEA26D8D5A030CCF469778C1 (void);
// 0x00000602 System.Void UnityEngine.EventSystems.BaseRaycaster::OnDisable()
extern void BaseRaycaster_OnDisable_m0FA75817BD8DADDF85C10E02B0067E835C80EE0C (void);
// 0x00000603 System.Void UnityEngine.EventSystems.BaseRaycaster::OnCanvasHierarchyChanged()
extern void BaseRaycaster_OnCanvasHierarchyChanged_m4DBBF545F6C74CFC7C375D7A7C42AD7F1B3CE17F (void);
// 0x00000604 System.Void UnityEngine.EventSystems.BaseRaycaster::OnTransformParentChanged()
extern void BaseRaycaster_OnTransformParentChanged_mD98668AF752E710CB0A8A863695E3957B2972083 (void);
// 0x00000605 System.Void UnityEngine.EventSystems.BaseRaycaster::.ctor()
extern void BaseRaycaster__ctor_m3F94FA62302E9BCB5290515C9D5C4DC1265F5C0F (void);
// 0x00000606 System.Void UnityEngine.EventSystems.Physics2DRaycaster::.ctor()
extern void Physics2DRaycaster__ctor_m460236B9F5697BA8777DF3D770AC0D394497748D (void);
// 0x00000607 System.Void UnityEngine.EventSystems.Physics2DRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void Physics2DRaycaster_Raycast_m3CEA59B484E46F41A6F62B923AC23FB140DE8DF3 (void);
// 0x00000608 System.Void UnityEngine.EventSystems.PhysicsRaycaster::.ctor()
extern void PhysicsRaycaster__ctor_m1A3C04070C6C1E3C4449D3BB4AD7C880D336D4CA (void);
// 0x00000609 UnityEngine.Camera UnityEngine.EventSystems.PhysicsRaycaster::get_eventCamera()
extern void PhysicsRaycaster_get_eventCamera_mA4D0809E09657E6B635FF54EA8178CA5280C297E (void);
// 0x0000060A System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_depth()
extern void PhysicsRaycaster_get_depth_mFEEAAEECAF9522513EC430D6AED0C4FE64354708 (void);
// 0x0000060B System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_finalEventMask()
extern void PhysicsRaycaster_get_finalEventMask_m33F53EF1231123847F95DBFF865C3B19E6CD1EB6 (void);
// 0x0000060C UnityEngine.LayerMask UnityEngine.EventSystems.PhysicsRaycaster::get_eventMask()
extern void PhysicsRaycaster_get_eventMask_m11D96704635B15FCD194B02B421807362676BE98 (void);
// 0x0000060D System.Void UnityEngine.EventSystems.PhysicsRaycaster::set_eventMask(UnityEngine.LayerMask)
extern void PhysicsRaycaster_set_eventMask_m59EAB6D3AA1F0FF53AAA32A0F62E240C60EAD7CB (void);
// 0x0000060E System.Int32 UnityEngine.EventSystems.PhysicsRaycaster::get_maxRayIntersections()
extern void PhysicsRaycaster_get_maxRayIntersections_m473112CC291635C45D0590CC4B03C07D652FB69A (void);
// 0x0000060F System.Void UnityEngine.EventSystems.PhysicsRaycaster::set_maxRayIntersections(System.Int32)
extern void PhysicsRaycaster_set_maxRayIntersections_m730A3F32F27E041B9AC49012E4B954C6152DC3D4 (void);
// 0x00000610 System.Boolean UnityEngine.EventSystems.PhysicsRaycaster::ComputeRayAndDistance(UnityEngine.EventSystems.PointerEventData,UnityEngine.Ray&,System.Int32&,System.Single&)
extern void PhysicsRaycaster_ComputeRayAndDistance_m92EFFE5A5287CC625EA6B66853DE2959985AFE7D (void);
// 0x00000611 System.Void UnityEngine.EventSystems.PhysicsRaycaster::Raycast(UnityEngine.EventSystems.PointerEventData,System.Collections.Generic.List`1<UnityEngine.EventSystems.RaycastResult>)
extern void PhysicsRaycaster_Raycast_m790F8B5B886500FF2C7D8E966DA72400A4C2B55C (void);
// 0x00000612 System.Void UnityEngine.EventSystems.UIBehaviour::Awake()
extern void UIBehaviour_Awake_m8283CBD45FF1CBA026DFD5F0319282EA464F8B33 (void);
// 0x00000613 System.Void UnityEngine.EventSystems.UIBehaviour::OnEnable()
extern void UIBehaviour_OnEnable_m4FF74AADA5E101F59DC5C19DCA82110F7482CB56 (void);
// 0x00000614 System.Void UnityEngine.EventSystems.UIBehaviour::Start()
extern void UIBehaviour_Start_m9717CD32EA9B3C678EB0D73CCF59C801C5E5207C (void);
// 0x00000615 System.Void UnityEngine.EventSystems.UIBehaviour::OnDisable()
extern void UIBehaviour_OnDisable_m43F5502A18FCFFD355381A95175DC71E0D4005EC (void);
// 0x00000616 System.Void UnityEngine.EventSystems.UIBehaviour::OnDestroy()
extern void UIBehaviour_OnDestroy_m12CAEB3F5221B9D061148F6D8FBFD0FDD90636F0 (void);
// 0x00000617 System.Boolean UnityEngine.EventSystems.UIBehaviour::IsActive()
extern void UIBehaviour_IsActive_m88452BA640BCCC2769D3FBD0F3E82333A0936A16 (void);
// 0x00000618 System.Void UnityEngine.EventSystems.UIBehaviour::OnRectTransformDimensionsChange()
extern void UIBehaviour_OnRectTransformDimensionsChange_mE273C2FDE70B13C9BCCC07C0FC83322EC03CC470 (void);
// 0x00000619 System.Void UnityEngine.EventSystems.UIBehaviour::OnBeforeTransformParentChanged()
extern void UIBehaviour_OnBeforeTransformParentChanged_mEA6FDD53F2468F7299110417A8B659B095A70EA5 (void);
// 0x0000061A System.Void UnityEngine.EventSystems.UIBehaviour::OnTransformParentChanged()
extern void UIBehaviour_OnTransformParentChanged_mBB0F5D46FF7791D80FE6E4EE1932433246D5B7CB (void);
// 0x0000061B System.Void UnityEngine.EventSystems.UIBehaviour::OnDidApplyAnimationProperties()
extern void UIBehaviour_OnDidApplyAnimationProperties_m36C4FA9136D24E5F7EE389E17CDA2A3D581220DC (void);
// 0x0000061C System.Void UnityEngine.EventSystems.UIBehaviour::OnCanvasGroupChanged()
extern void UIBehaviour_OnCanvasGroupChanged_mDB3CDCE40E08D3943F10655196188668D8A3F422 (void);
// 0x0000061D System.Void UnityEngine.EventSystems.UIBehaviour::OnCanvasHierarchyChanged()
extern void UIBehaviour_OnCanvasHierarchyChanged_m5A9FF86F647810726B4AE9F8C15862F353FBDAFD (void);
// 0x0000061E System.Boolean UnityEngine.EventSystems.UIBehaviour::IsDestroyed()
extern void UIBehaviour_IsDestroyed_m169BA727AB81FF96092471C152C845EBE944A269 (void);
// 0x0000061F System.Void UnityEngine.EventSystems.UIBehaviour::.ctor()
extern void UIBehaviour__ctor_m1B44EE4BDA3604F96C48379524B9907FEB15EB53 (void);
// 0x00000620 System.Void UnityEngine.UI.Button/ButtonClickedEvent::.ctor()
extern void ButtonClickedEvent__ctor_mEF3C31A6254EBAB9F98F8DAAE499700531B18681 (void);
// 0x00000621 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::.ctor(System.Int32)
extern void U3COnFinishSubmitU3Ed__9__ctor_m7ADCF9803F4A2AD6F3555209BCF182C603989A6F (void);
// 0x00000622 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.IDisposable.Dispose()
extern void U3COnFinishSubmitU3Ed__9_System_IDisposable_Dispose_m4FFECE47D511034EBA7270B6F32310FE1DA30B2F (void);
// 0x00000623 System.Boolean UnityEngine.UI.Button/<OnFinishSubmit>d__9::MoveNext()
extern void U3COnFinishSubmitU3Ed__9_MoveNext_mD0D8375C1B07F8EF9D3F9DE25191F6D3F4459E57 (void);
// 0x00000624 System.Object UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m18F63ADAE6DB6C2C632A5B28B07ACF80BE0DC4E8 (void);
// 0x00000625 System.Void UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.IEnumerator.Reset()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_Reset_mADAC8D44A98EB373142102E747F6F82CDCBF44E6 (void);
// 0x00000626 System.Object UnityEngine.UI.Button/<OnFinishSubmit>d__9::System.Collections.IEnumerator.get_Current()
extern void U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_get_Current_mB42667ABE8F377D6B1D73BF708B17CA0A60DF68A (void);
// 0x00000627 UnityEngine.GameObject UnityEngine.UI.DefaultControls/IFactoryControls::CreateGameObject(System.String,System.Type[])
// 0x00000628 UnityEngine.GameObject UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::CreateGameObject(System.String,System.Type[])
extern void DefaultRuntimeFactory_CreateGameObject_m76DCCBEF0431C815F2AC2360614D4FF09F98E34C (void);
// 0x00000629 System.Void UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::.ctor()
extern void DefaultRuntimeFactory__ctor_mC84BC30364958D9A5EEE040D5D4BE254393809CF (void);
// 0x0000062A System.Void UnityEngine.UI.DefaultControls/DefaultRuntimeFactory::.cctor()
extern void DefaultRuntimeFactory__cctor_m917CD6F4766028435BE57F5EAFD83A887E0CA4E8 (void);
// 0x0000062B UnityEngine.UI.Text UnityEngine.UI.Dropdown/DropdownItem::get_text()
extern void DropdownItem_get_text_mABB014D2DEE9F6B24515DE71A08EBFA82BB44829 (void);
// 0x0000062C System.Void UnityEngine.UI.Dropdown/DropdownItem::set_text(UnityEngine.UI.Text)
extern void DropdownItem_set_text_m2F87962E683F7DCF4CCD6CEA4E4E4562E89F939E (void);
// 0x0000062D UnityEngine.UI.Image UnityEngine.UI.Dropdown/DropdownItem::get_image()
extern void DropdownItem_get_image_m2879EEFCAB097FBA79BC4DA41ECBA4EBE3CB6185 (void);
// 0x0000062E System.Void UnityEngine.UI.Dropdown/DropdownItem::set_image(UnityEngine.UI.Image)
extern void DropdownItem_set_image_mEACD24E324362E50180808DEF29E160E52C81BDC (void);
// 0x0000062F UnityEngine.RectTransform UnityEngine.UI.Dropdown/DropdownItem::get_rectTransform()
extern void DropdownItem_get_rectTransform_mADBE4D843FE38C832CC1C9CFE03DC4D55B18E897 (void);
// 0x00000630 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_rectTransform(UnityEngine.RectTransform)
extern void DropdownItem_set_rectTransform_mEDEAE741CC3B0473F332D9B55B413EA290889240 (void);
// 0x00000631 UnityEngine.UI.Toggle UnityEngine.UI.Dropdown/DropdownItem::get_toggle()
extern void DropdownItem_get_toggle_m6DAC29FD2E711343DBCDF240B3218BD6211886DE (void);
// 0x00000632 System.Void UnityEngine.UI.Dropdown/DropdownItem::set_toggle(UnityEngine.UI.Toggle)
extern void DropdownItem_set_toggle_m4D3247AE384827C5F3C49FFDADECED4A91B3B5CE (void);
// 0x00000633 System.Void UnityEngine.UI.Dropdown/DropdownItem::OnPointerEnter(UnityEngine.EventSystems.PointerEventData)
extern void DropdownItem_OnPointerEnter_m9E39FBA9A0AF70B9C7A87E2A6A10252D3CA05ED8 (void);
// 0x00000634 System.Void UnityEngine.UI.Dropdown/DropdownItem::OnCancel(UnityEngine.EventSystems.BaseEventData)
extern void DropdownItem_OnCancel_mDD631AB9163515B0368C64482CC0B4937C5B1161 (void);
// 0x00000635 System.Void UnityEngine.UI.Dropdown/DropdownItem::.ctor()
extern void DropdownItem__ctor_m34EFA0120C66D0E04DE5E611F1D2EC9D6E985905 (void);
// 0x00000636 System.String UnityEngine.UI.Dropdown/OptionData::get_text()
extern void OptionData_get_text_m3AA3E93AC9264EB140F873BEFF0A6FCB48FB1BFF (void);
// 0x00000637 System.Void UnityEngine.UI.Dropdown/OptionData::set_text(System.String)
extern void OptionData_set_text_mED7FEA5D1C3CB30CD7B8878CE86CE57D8E68C735 (void);
// 0x00000638 UnityEngine.Sprite UnityEngine.UI.Dropdown/OptionData::get_image()
extern void OptionData_get_image_m0BF991D02528EE3C67FE841C3AA87EC1AE7D8E31 (void);
// 0x00000639 System.Void UnityEngine.UI.Dropdown/OptionData::set_image(UnityEngine.Sprite)
extern void OptionData_set_image_m9FA0F571B5ECF76C8E04CA91ED8BE1C8E9968265 (void);
// 0x0000063A System.Void UnityEngine.UI.Dropdown/OptionData::.ctor()
extern void OptionData__ctor_m45CB705FD6717ECEBDDA3E6F137BCC38C388CA1F (void);
// 0x0000063B System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(System.String)
extern void OptionData__ctor_m8AA4FDEB8771F714C90DF651743B77E0C75DEC00 (void);
// 0x0000063C System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(UnityEngine.Sprite)
extern void OptionData__ctor_m024A52D2CDF4A551D94A861B1D5255D528BC6FF2 (void);
// 0x0000063D System.Void UnityEngine.UI.Dropdown/OptionData::.ctor(System.String,UnityEngine.Sprite)
extern void OptionData__ctor_m9244487628FA5C49B7B1658FE1C82CA67000A6DB (void);
// 0x0000063E System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData> UnityEngine.UI.Dropdown/OptionDataList::get_options()
extern void OptionDataList_get_options_mEA305423DD1C0F201310F97CFD3FD1B89F063ED0 (void);
// 0x0000063F System.Void UnityEngine.UI.Dropdown/OptionDataList::set_options(System.Collections.Generic.List`1<UnityEngine.UI.Dropdown/OptionData>)
extern void OptionDataList_set_options_m674C45F57F90F85B6E33EF4C05BD0F0E236BF823 (void);
// 0x00000640 System.Void UnityEngine.UI.Dropdown/OptionDataList::.ctor()
extern void OptionDataList__ctor_m658891495892A98D411AC971EE3EF96C01560F73 (void);
// 0x00000641 System.Void UnityEngine.UI.Dropdown/DropdownEvent::.ctor()
extern void DropdownEvent__ctor_m9E61AABA58765E640C5044E5C82574ED362D2875 (void);
// 0x00000642 System.Void UnityEngine.UI.Dropdown/<>c__DisplayClass62_0::.ctor()
extern void U3CU3Ec__DisplayClass62_0__ctor_mE4628B27FE0F4517EFB2699040AFEB957D6A5FA8 (void);
// 0x00000643 System.Void UnityEngine.UI.Dropdown/<>c__DisplayClass62_0::<Show>b__0(System.Boolean)
extern void U3CU3Ec__DisplayClass62_0_U3CShowU3Eb__0_m63D2341A7D8EC695D01B0F934D58C2F9C3F306A3 (void);
// 0x00000644 System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::.ctor(System.Int32)
extern void U3CDelayedDestroyDropdownListU3Ed__74__ctor_mAD9EFC641FEA13E4B5E4BE5013C1784223CAEC3E (void);
// 0x00000645 System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.IDisposable.Dispose()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_IDisposable_Dispose_m50F4B9432686914B794A14F3505CB447DC3A765E (void);
// 0x00000646 System.Boolean UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::MoveNext()
extern void U3CDelayedDestroyDropdownListU3Ed__74_MoveNext_m9CBCC3C169274B09737B7B0FF88CF5FA38FAB5FD (void);
// 0x00000647 System.Object UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m343B7FFD7327324FF24FE7A1EC39ABAA5E262748 (void);
// 0x00000648 System.Void UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.Collections.IEnumerator.Reset()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_Reset_m108B8A0FF9DB569C5F473E4A82002F4C3E419020 (void);
// 0x00000649 System.Object UnityEngine.UI.Dropdown/<DelayedDestroyDropdownList>d__74::System.Collections.IEnumerator.get_Current()
extern void U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_get_Current_m4705AA405908792F7ADB20CCD83A425C15F397C8 (void);
// 0x0000064A System.Void UnityEngine.UI.GraphicRaycaster/<>c::.cctor()
extern void U3CU3Ec__cctor_m73361334C182D842500A50243025DE880A278E01 (void);
// 0x0000064B System.Void UnityEngine.UI.GraphicRaycaster/<>c::.ctor()
extern void U3CU3Ec__ctor_m7CA24FA9F8163B94385069D55847C56A9DCC929F (void);
// 0x0000064C System.Int32 UnityEngine.UI.GraphicRaycaster/<>c::<Raycast>b__24_0(UnityEngine.UI.Graphic,UnityEngine.UI.Graphic)
extern void U3CU3Ec_U3CRaycastU3Eb__24_0_m184D010D41E2E77338B51F88EAB8D2BBD5BC0FA6 (void);
// 0x0000064D System.Void UnityEngine.UI.InputField/OnValidateInput::.ctor(System.Object,System.IntPtr)
extern void OnValidateInput__ctor_mCCEBA7022E2F01B115A92B5F89C39A00868F09B2 (void);
// 0x0000064E System.Char UnityEngine.UI.InputField/OnValidateInput::Invoke(System.String,System.Int32,System.Char)
extern void OnValidateInput_Invoke_m8382B852D2F5364FB109A43601D08C3A8F0CCC09 (void);
// 0x0000064F System.IAsyncResult UnityEngine.UI.InputField/OnValidateInput::BeginInvoke(System.String,System.Int32,System.Char,System.AsyncCallback,System.Object)
extern void OnValidateInput_BeginInvoke_m97DC7AAEFA03939CBD65AF08D335965E79475694 (void);
// 0x00000650 System.Char UnityEngine.UI.InputField/OnValidateInput::EndInvoke(System.IAsyncResult)
extern void OnValidateInput_EndInvoke_m72E5E385FAAC8E0E704B5A0F6C4D9EFB740F0844 (void);
// 0x00000651 System.Void UnityEngine.UI.InputField/SubmitEvent::.ctor()
extern void SubmitEvent__ctor_m2E518230CEF5C85510216286F149236226332801 (void);
// 0x00000652 System.Void UnityEngine.UI.InputField/OnChangeEvent::.ctor()
extern void OnChangeEvent__ctor_m7A9F4AE92A614232DB49947CC1942AA7949BC245 (void);
// 0x00000653 System.Void UnityEngine.UI.InputField/<CaretBlink>d__161::.ctor(System.Int32)
extern void U3CCaretBlinkU3Ed__161__ctor_mF3953F6AF043F601BE7417A56694AFE359A7BC4C (void);
// 0x00000654 System.Void UnityEngine.UI.InputField/<CaretBlink>d__161::System.IDisposable.Dispose()
extern void U3CCaretBlinkU3Ed__161_System_IDisposable_Dispose_mADC123E40EFC9D3A18BFCE5A48A030C841BCB5C2 (void);
// 0x00000655 System.Boolean UnityEngine.UI.InputField/<CaretBlink>d__161::MoveNext()
extern void U3CCaretBlinkU3Ed__161_MoveNext_m35151EF2720A88857A15DF61BE9FB17CD46A9DCE (void);
// 0x00000656 System.Object UnityEngine.UI.InputField/<CaretBlink>d__161::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CCaretBlinkU3Ed__161_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD30EA25257DE83102EC6C592382A1B3983B2DACC (void);
// 0x00000657 System.Void UnityEngine.UI.InputField/<CaretBlink>d__161::System.Collections.IEnumerator.Reset()
extern void U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_Reset_m1F664E96DA0A069544B980F6643F331588D2EEA0 (void);
// 0x00000658 System.Object UnityEngine.UI.InputField/<CaretBlink>d__161::System.Collections.IEnumerator.get_Current()
extern void U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_get_Current_mD9739C54110E7FF93C9A98C89687F5270CDD43FE (void);
// 0x00000659 System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::.ctor(System.Int32)
extern void U3CMouseDragOutsideRectU3Ed__181__ctor_mCA2F0431FC266ACCA7E96B48FCAD33D9E2B50B4A (void);
// 0x0000065A System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.IDisposable.Dispose()
extern void U3CMouseDragOutsideRectU3Ed__181_System_IDisposable_Dispose_m9C376C3E6141A94D9BE1E3D955C083F64C980362 (void);
// 0x0000065B System.Boolean UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::MoveNext()
extern void U3CMouseDragOutsideRectU3Ed__181_MoveNext_mEE0C97213DB1AC9D8616A51B3CF37E4F344E7A15 (void);
// 0x0000065C System.Object UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CMouseDragOutsideRectU3Ed__181_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD7B93318E14B1294F6E3899888CEDD11CCB7850E (void);
// 0x0000065D System.Void UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.Collections.IEnumerator.Reset()
extern void U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_Reset_mD5F8E5381D857ED4475C019385881D92A2374A65 (void);
// 0x0000065E System.Object UnityEngine.UI.InputField/<MouseDragOutsideRect>d__181::System.Collections.IEnumerator.get_Current()
extern void U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_get_Current_m806304421955FA531328C392E9882C163A2B5386 (void);
// 0x0000065F System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::.ctor(System.Int32)
extern void U3CDelayedSetDirtyU3Ed__56__ctor_m02CDD709D0F09D88F2551E0CC17F655B849E8866 (void);
// 0x00000660 System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.IDisposable.Dispose()
extern void U3CDelayedSetDirtyU3Ed__56_System_IDisposable_Dispose_m4A49A21A509EB6308D418B720A4D7D9E89FEB25A (void);
// 0x00000661 System.Boolean UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::MoveNext()
extern void U3CDelayedSetDirtyU3Ed__56_MoveNext_m713F270B4716122410990ADFFE72DE8ED9149E38 (void);
// 0x00000662 System.Object UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA6012CCB25A71E72C44A960AFE1122BC589BEF88 (void);
// 0x00000663 System.Void UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.IEnumerator.Reset()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_Reset_m163068C35B92BEA03B53A89CAEC010459749C8FE (void);
// 0x00000664 System.Object UnityEngine.UI.LayoutGroup/<DelayedSetDirty>d__56::System.Collections.IEnumerator.get_Current()
extern void U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_get_Current_mE09727941D13EBD44B21A13822F9F20ED75FCE28 (void);
// 0x00000665 System.Void UnityEngine.UI.LayoutRebuilder/<>c::.cctor()
extern void U3CU3Ec__cctor_mA91A5C38199DBC143843D3D14BCD0037184CF870 (void);
// 0x00000666 System.Void UnityEngine.UI.LayoutRebuilder/<>c::.ctor()
extern void U3CU3Ec__ctor_mAE9CB345634F42E395788C14D46C0068D7DF5065 (void);
// 0x00000667 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<.cctor>b__5_0(UnityEngine.UI.LayoutRebuilder)
extern void U3CU3Ec_U3C_cctorU3Eb__5_0_mED1242446A6E160D4EC68EC766C4658D5652D960 (void);
// 0x00000668 System.Boolean UnityEngine.UI.LayoutRebuilder/<>c::<StripDisabledBehavioursFromList>b__10_0(UnityEngine.Component)
extern void U3CU3Ec_U3CStripDisabledBehavioursFromListU3Eb__10_0_mDBCD53C01C6E4E3530B4AC2319B675979E556B6E (void);
// 0x00000669 System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_0(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_0_m61C61EC7A163B590A8ECA1955B8471F8C2DC7F37 (void);
// 0x0000066A System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_1(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_1_mAD1F54287DD0877DAB5D684A63C65D00F01B2ECF (void);
// 0x0000066B System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_2(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_2_m4C5955D09B742EA65B16F86C3952DFD2005263BF (void);
// 0x0000066C System.Void UnityEngine.UI.LayoutRebuilder/<>c::<Rebuild>b__12_3(UnityEngine.Component)
extern void U3CU3Ec_U3CRebuildU3Eb__12_3_mE471222E89B5BD6D012D9C06D7A0262368C37A62 (void);
// 0x0000066D System.Void UnityEngine.UI.LayoutUtility/<>c::.cctor()
extern void U3CU3Ec__cctor_m09D5B404BD546771E0FEA451F81F91A9D0C2ECFC (void);
// 0x0000066E System.Void UnityEngine.UI.LayoutUtility/<>c::.ctor()
extern void U3CU3Ec__ctor_m8923A70336875668B745F0A4E63A97E94AC81B10 (void);
// 0x0000066F System.Single UnityEngine.UI.LayoutUtility/<>c::<GetMinWidth>b__3_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetMinWidthU3Eb__3_0_m25085EA832E41CA6905CCCCD1505C4DC091A6AC9 (void);
// 0x00000670 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredWidth>b__4_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredWidthU3Eb__4_0_m54D05611CC112A9CF9CD8819FCBE1812D751F27D (void);
// 0x00000671 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredWidth>b__4_1(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredWidthU3Eb__4_1_m33B5F83867470C8FE89B0E64FCD3B911B1BF4FD8 (void);
// 0x00000672 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetFlexibleWidth>b__5_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetFlexibleWidthU3Eb__5_0_m981137134604E2E04FD745310124AE85760BAEDE (void);
// 0x00000673 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetMinHeight>b__6_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetMinHeightU3Eb__6_0_mB5247A6F4D863D09EFC771EFA025852B7CA9C979 (void);
// 0x00000674 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredHeight>b__7_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredHeightU3Eb__7_0_m46420DB2062D89D2C2075B466B57B7EEEAD1032A (void);
// 0x00000675 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetPreferredHeight>b__7_1(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetPreferredHeightU3Eb__7_1_mDF489C3BF8D1B2EA9647B007B37EB09AD09A0A3F (void);
// 0x00000676 System.Single UnityEngine.UI.LayoutUtility/<>c::<GetFlexibleHeight>b__8_0(UnityEngine.UI.ILayoutElement)
extern void U3CU3Ec_U3CGetFlexibleHeightU3Eb__8_0_mC7AE9A4412EBB81B5BEED2E5B1BD0E0169AD4C37 (void);
// 0x00000677 System.Void UnityEngine.UI.MaskableGraphic/CullStateChangedEvent::.ctor()
extern void CullStateChangedEvent__ctor_m1C6F0A946C6C0DE083C533746B5951A31BB2540F (void);
// 0x00000678 System.Void UnityEngine.UI.ScrollRect/ScrollRectEvent::.ctor()
extern void ScrollRectEvent__ctor_m43B2F0C279DC5D16F5860AC794A42DBF348BE10C (void);
// 0x00000679 System.Void UnityEngine.UI.Scrollbar/ScrollEvent::.ctor()
extern void ScrollEvent__ctor_m06B78DA1F2D17D41E358CFE8A5303B3B760CBD45 (void);
// 0x0000067A System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::.ctor(System.Int32)
extern void U3CClickRepeatU3Ed__58__ctor_mBFBEBC50DB8C258BECD2372CBA491271F7866A94 (void);
// 0x0000067B System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.IDisposable.Dispose()
extern void U3CClickRepeatU3Ed__58_System_IDisposable_Dispose_mC5DADB5D35A04AAAD800A6DE0C2B2BF7EE628670 (void);
// 0x0000067C System.Boolean UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::MoveNext()
extern void U3CClickRepeatU3Ed__58_MoveNext_m7DE3E913BC69A7E53056DA1CA14BF4ABCE78F0C1 (void);
// 0x0000067D System.Object UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CClickRepeatU3Ed__58_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCAECE6E345E23E8B2F5266515DCBDFC051779351 (void);
// 0x0000067E System.Void UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.IEnumerator.Reset()
extern void U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_Reset_mFCBD2FB123CFE07B6A744AE0AA06DF2F09ADD9E8 (void);
// 0x0000067F System.Object UnityEngine.UI.Scrollbar/<ClickRepeat>d__58::System.Collections.IEnumerator.get_Current()
extern void U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_get_Current_m73011B6FFFA6257338144C3013F636D167A0F239 (void);
// 0x00000680 System.Void UnityEngine.UI.Slider/SliderEvent::.ctor()
extern void SliderEvent__ctor_mF221080DF1ADA94469050E30297C3ED8CC6B6D24 (void);
// 0x00000681 System.Void UnityEngine.UI.StencilMaterial/MatEntry::.ctor()
extern void MatEntry__ctor_mDD389E021313269F8B45DA142B419FC014A7D1CC (void);
// 0x00000682 System.Void UnityEngine.UI.Toggle/ToggleEvent::.ctor()
extern void ToggleEvent__ctor_mA38AE97395D2AC75ABDE8169DC9BFF161A78F494 (void);
// 0x00000683 System.Void UnityEngine.UI.ToggleGroup/<>c::.cctor()
extern void U3CU3Ec__cctor_mF0A991CBD937F58641CCE6D69CFCED6FF02A8F5C (void);
// 0x00000684 System.Void UnityEngine.UI.ToggleGroup/<>c::.ctor()
extern void U3CU3Ec__ctor_m9BBD797B8CE015A39E73055C7471D8C8A3F13381 (void);
// 0x00000685 System.Boolean UnityEngine.UI.ToggleGroup/<>c::<AnyTogglesOn>b__12_0(UnityEngine.UI.Toggle)
extern void U3CU3Ec_U3CAnyTogglesOnU3Eb__12_0_mE4A42BB2B94473E501CB14421D2843BAACE48417 (void);
// 0x00000686 System.Boolean UnityEngine.UI.ToggleGroup/<>c::<ActiveToggles>b__13_0(UnityEngine.UI.Toggle)
extern void U3CU3Ec_U3CActiveTogglesU3Eb__13_0_m031EB01E70BF3EBB9A4066C1EC4431A559681ED2 (void);
// 0x00000687 System.Void UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::.ctor(System.Object,System.IntPtr)
extern void Raycast3DCallback__ctor_m339AEB26F1488FF3945EEA5BD87C1AB67F9820F7 (void);
// 0x00000688 System.Boolean UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32)
extern void Raycast3DCallback_Invoke_m469DFE4719293B1D78F3F0F86219AC5A79C27B87 (void);
// 0x00000689 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit&,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void Raycast3DCallback_BeginInvoke_m1E07393535ADFE57FEA2C62286D721C1F3BD9F57 (void);
// 0x0000068A System.Boolean UnityEngine.UI.ReflectionMethodsCache/Raycast3DCallback::EndInvoke(UnityEngine.RaycastHit&,System.IAsyncResult)
extern void Raycast3DCallback_EndInvoke_mE57B7F3B0D593061B150CD4CD5E1F2EBF73B8CCC (void);
// 0x0000068B System.Void UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::.ctor(System.Object,System.IntPtr)
extern void RaycastAllCallback__ctor_mDEFB87C693C497DC24D704110C1747EEE784EB94 (void);
// 0x0000068C UnityEngine.RaycastHit[] UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::Invoke(UnityEngine.Ray,System.Single,System.Int32)
extern void RaycastAllCallback_Invoke_mCB0725E11A9E028E20E64D78BCA8D9029CAE051E (void);
// 0x0000068D System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::BeginInvoke(UnityEngine.Ray,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void RaycastAllCallback_BeginInvoke_m654E38089CE2E40935AA5E0B41EA7CBA6924FB15 (void);
// 0x0000068E UnityEngine.RaycastHit[] UnityEngine.UI.ReflectionMethodsCache/RaycastAllCallback::EndInvoke(System.IAsyncResult)
extern void RaycastAllCallback_EndInvoke_m6527130511F1A69C6B17EFA46E35A36D39884427 (void);
// 0x0000068F System.Void UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::.ctor(System.Object,System.IntPtr)
extern void GetRaycastNonAllocCallback__ctor_mCA532FF9C719E0D5A57EACF6B85D16E6340068E6 (void);
// 0x00000690 System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit[],System.Single,System.Int32)
extern void GetRaycastNonAllocCallback_Invoke_mF56C0670E33CB12DF1A8C16277E26A56EE1C7E20 (void);
// 0x00000691 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit[],System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRaycastNonAllocCallback_BeginInvoke_m72F0FCDE242E416E080760158AF6AE3FA64B61E1 (void);
// 0x00000692 System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRaycastNonAllocCallback::EndInvoke(System.IAsyncResult)
extern void GetRaycastNonAllocCallback_EndInvoke_m0F00432AB5ED1F37BEA57083436E40FA97AD86C8 (void);
// 0x00000693 System.Void UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::.ctor(System.Object,System.IntPtr)
extern void Raycast2DCallback__ctor_m0B4E563C73D95692021593B5FB8B75B93708C777 (void);
// 0x00000694 UnityEngine.RaycastHit2D UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::Invoke(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32)
extern void Raycast2DCallback_Invoke_m5842F896DD5C69D38E09CB7933F2ECE794D393A7 (void);
// 0x00000695 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::BeginInvoke(UnityEngine.Vector2,UnityEngine.Vector2,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void Raycast2DCallback_BeginInvoke_m0425889D38743CAB9B5E4C1072686CD30288269E (void);
// 0x00000696 UnityEngine.RaycastHit2D UnityEngine.UI.ReflectionMethodsCache/Raycast2DCallback::EndInvoke(System.IAsyncResult)
extern void Raycast2DCallback_EndInvoke_mFAD1B572AB085E448AFF551437592063BDAFB882 (void);
// 0x00000697 System.Void UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::.ctor(System.Object,System.IntPtr)
extern void GetRayIntersectionAllCallback__ctor_mB6548565EC361C677EB7E6ACA7008CB6378A3EA9 (void);
// 0x00000698 UnityEngine.RaycastHit2D[] UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::Invoke(UnityEngine.Ray,System.Single,System.Int32)
extern void GetRayIntersectionAllCallback_Invoke_m659B47C0727BE9179B3A96FD36AEA5216E66046D (void);
// 0x00000699 System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::BeginInvoke(UnityEngine.Ray,System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRayIntersectionAllCallback_BeginInvoke_m5E96B335A5D1D40E6793A91108341E18D06656C0 (void);
// 0x0000069A UnityEngine.RaycastHit2D[] UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllCallback::EndInvoke(System.IAsyncResult)
extern void GetRayIntersectionAllCallback_EndInvoke_mAA0209777FD43C9E9023997D5BFD33FA36933490 (void);
// 0x0000069B System.Void UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::.ctor(System.Object,System.IntPtr)
extern void GetRayIntersectionAllNonAllocCallback__ctor_m0EEAD5F4542FBADC0BEA6C39E44079A2FD355AF0 (void);
// 0x0000069C System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::Invoke(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single,System.Int32)
extern void GetRayIntersectionAllNonAllocCallback_Invoke_m6AAA07D1E9D27E50C3C647F368AA504E2A1BFE9B (void);
// 0x0000069D System.IAsyncResult UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::BeginInvoke(UnityEngine.Ray,UnityEngine.RaycastHit2D[],System.Single,System.Int32,System.AsyncCallback,System.Object)
extern void GetRayIntersectionAllNonAllocCallback_BeginInvoke_m21B8BAA2ED3A96EA9552939003DC8E30093DCDFA (void);
// 0x0000069E System.Int32 UnityEngine.UI.ReflectionMethodsCache/GetRayIntersectionAllNonAllocCallback::EndInvoke(System.IAsyncResult)
extern void GetRayIntersectionAllNonAllocCallback_EndInvoke_mDAD7394A68B735336E89CE7690206B55C739D44B (void);
// 0x0000069F System.Void UnityEngine.UI.CoroutineTween.ColorTween/ColorTweenCallback::.ctor()
extern void ColorTweenCallback__ctor_m7F7918E559131B5A1480199E6DC9B03A533D644D (void);
// 0x000006A0 System.Void UnityEngine.UI.CoroutineTween.FloatTween/FloatTweenCallback::.ctor()
extern void FloatTweenCallback__ctor_mE8AC174FE27E1A12832510D461316FEA939BD2F3 (void);
// 0x000006A1 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::.ctor(System.Int32)
// 0x000006A2 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.IDisposable.Dispose()
// 0x000006A3 System.Boolean UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::MoveNext()
// 0x000006A4 System.Object UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
// 0x000006A5 System.Void UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.IEnumerator.Reset()
// 0x000006A6 System.Object UnityEngine.UI.CoroutineTween.TweenRunner`1/<Start>d__2::System.Collections.IEnumerator.get_Current()
// 0x000006A7 System.Void UnityEngine.EventSystems.EventTrigger/TriggerEvent::.ctor()
extern void TriggerEvent__ctor_m5FA4AD9F5E1671A1F7F4C45AB1620624FEFC5F13 (void);
// 0x000006A8 System.Void UnityEngine.EventSystems.EventTrigger/Entry::.ctor()
extern void Entry__ctor_m646E309104AA1D549A0C07B948BE183013A927BF (void);
// 0x000006A9 System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::.ctor(System.Object,System.IntPtr)
// 0x000006AA System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::Invoke(T1,UnityEngine.EventSystems.BaseEventData)
// 0x000006AB System.IAsyncResult UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::BeginInvoke(T1,UnityEngine.EventSystems.BaseEventData,System.AsyncCallback,System.Object)
// 0x000006AC System.Void UnityEngine.EventSystems.ExecuteEvents/EventFunction`1::EndInvoke(System.IAsyncResult)
// 0x000006AD System.Void UnityEngine.EventSystems.ExecuteEvents/<>c::.cctor()
extern void U3CU3Ec__cctor_m61F9115D2905902E74081C1270593040BE0D9F4B (void);
// 0x000006AE System.Void UnityEngine.EventSystems.ExecuteEvents/<>c::.ctor()
extern void U3CU3Ec__ctor_mA3946064CEB17BF67A4B63F6E1716F3F7F27803A (void);
// 0x000006AF System.Void UnityEngine.EventSystems.ExecuteEvents/<>c::<.cctor>b__79_0(System.Collections.Generic.List`1<UnityEngine.EventSystems.IEventSystemHandler>)
extern void U3CU3Ec_U3C_cctorU3Eb__79_0_mC9A9AAD60D24FC76EFD98E83E9DAF5EECAABCD56 (void);
// 0x000006B0 UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData UnityEngine.EventSystems.PointerInputModule/ButtonState::get_eventData()
extern void ButtonState_get_eventData_mA9D054D526473A2481A997758CDDEB022E67351D (void);
// 0x000006B1 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::set_eventData(UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData)
extern void ButtonState_set_eventData_m844CA9F09A826E89AF0F8F137C016D96C71B30BD (void);
// 0x000006B2 UnityEngine.EventSystems.PointerEventData/InputButton UnityEngine.EventSystems.PointerInputModule/ButtonState::get_button()
extern void ButtonState_get_button_mB538B2D483C482A7E628D26BA390449A54C958A3 (void);
// 0x000006B3 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::set_button(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void ButtonState_set_button_mCC7BFBDDA9AA0710CBB64C456583CDCBAD227971 (void);
// 0x000006B4 System.Void UnityEngine.EventSystems.PointerInputModule/ButtonState::.ctor()
extern void ButtonState__ctor_mECE4E89A3E0BAD4B2C1E14E142DD30893CA7267A (void);
// 0x000006B5 System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseState::AnyPressesThisFrame()
extern void MouseState_AnyPressesThisFrame_m82FC431EAEE7573E5748685923194D4EB9540E2D (void);
// 0x000006B6 System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseState::AnyReleasesThisFrame()
extern void MouseState_AnyReleasesThisFrame_m330B78224B8AB1177B9BC160BDC015D3A9DB9309 (void);
// 0x000006B7 UnityEngine.EventSystems.PointerInputModule/ButtonState UnityEngine.EventSystems.PointerInputModule/MouseState::GetButtonState(UnityEngine.EventSystems.PointerEventData/InputButton)
extern void MouseState_GetButtonState_m0C2884609F720A284C72EAEF061C781F4874CCAE (void);
// 0x000006B8 System.Void UnityEngine.EventSystems.PointerInputModule/MouseState::SetButtonState(UnityEngine.EventSystems.PointerEventData/InputButton,UnityEngine.EventSystems.PointerEventData/FramePressState,UnityEngine.EventSystems.PointerEventData)
extern void MouseState_SetButtonState_mE7B149E168AC34F69B504C797B1AA9E70122AFC2 (void);
// 0x000006B9 System.Void UnityEngine.EventSystems.PointerInputModule/MouseState::.ctor()
extern void MouseState__ctor_m03EB3CF8C4BEA925F63C1BA8197C3FA632975F09 (void);
// 0x000006BA System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::PressedThisFrame()
extern void MouseButtonEventData_PressedThisFrame_m9437D00FBF27F51132154FA11AE9463377FDF86A (void);
// 0x000006BB System.Boolean UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::ReleasedThisFrame()
extern void MouseButtonEventData_ReleasedThisFrame_mD40162D1107F3C7EC2B560C415B20FD260051BB6 (void);
// 0x000006BC System.Void UnityEngine.EventSystems.PointerInputModule/MouseButtonEventData::.ctor()
extern void MouseButtonEventData__ctor_m2A5351DCA22508A2E1D85890CD69D223F4926A25 (void);
// 0x000006BD System.Int32 UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::Compare(UnityEngine.RaycastHit,UnityEngine.RaycastHit)
extern void RaycastHitComparer_Compare_m5A17D56D0EF75419CCCAEFE522E86A44C1EFD46B (void);
// 0x000006BE System.Void UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::.ctor()
extern void RaycastHitComparer__ctor_m1039CBA952391889242A9F00EA05958986E392B2 (void);
// 0x000006BF System.Void UnityEngine.EventSystems.PhysicsRaycaster/RaycastHitComparer::.cctor()
extern void RaycastHitComparer__cctor_m1CEECC8D87DDE7315C8F0845658FC13E34CD4A31 (void);
static Il2CppMethodPointer s_methodPointers[1727] = 
{
	AnimationTriggers_get_normalTrigger_m523D4A64E6677159ED80FC7E30E08F33658B3FE0,
	AnimationTriggers_set_normalTrigger_m8B1A7D283B031722F56F893F89578D4E14936A45,
	AnimationTriggers_get_highlightedTrigger_mA272B91B74330469F5732B2DE8624A62F5085B98,
	AnimationTriggers_set_highlightedTrigger_m4DECB61F087B3DA559E97FE431E44ECA8A466609,
	AnimationTriggers_get_pressedTrigger_m8D440CAC69B9DE329DA046D324BD61E3ED55FCD7,
	AnimationTriggers_set_pressedTrigger_mB627531FBBC50BE9E3EA2B9EFE1A7C941F5942FB,
	AnimationTriggers_get_selectedTrigger_mCD9621B82B7E2AA88D2734C58BC6B07664BC976B,
	AnimationTriggers_set_selectedTrigger_m9FB5C4728FA04DA1E22F2B55A2A4453481A6F501,
	AnimationTriggers_get_disabledTrigger_mC796C6111FDFF4DF411920AF82A95908D4E60A50,
	AnimationTriggers_set_disabledTrigger_m7F08D71BAC1A9D9A4F61E429A023141AC4293DBE,
	AnimationTriggers__ctor_mF0F35FC53FA65A88FEF8D4F52006FE957981C246,
	Button__ctor_m51451154939F30BAA6EB8B005BD480E2E20540CB,
	Button_get_onClick_m77E8CA6917881760CC7900930F4C789F3E2F8817,
	Button_set_onClick_m007C337F4A5B1B2A48CAF3636F87FBFB62271BB9,
	Button_Press_m58210E36B74902AC4667E5A75B4ADB891D1596C2,
	Button_OnPointerClick_m33A14004B5EA59CBF8D0247CC9001CFD9D3CEFEC,
	Button_OnSubmit_m9004AD829B9FE03D54DF1BF7F796530A966F9A2E,
	Button_OnFinishSubmit_m89D3F073EF025FE5DE11FAC04E41025685AAE20F,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	CanvasUpdateRegistry__ctor_m86AC7F2BD30DF9ABEA5CA8C74BA28367D5325E9A,
	CanvasUpdateRegistry_get_instance_m6A2150EA4C8C74AF18E53B3CF22BF6EAF70FF927,
	CanvasUpdateRegistry_ObjectValidForUpdate_m0A572FA254D152E92FD6D6DC63B4B0FA66B88250,
	CanvasUpdateRegistry_CleanInvalidItems_m033AB2A5652116F351F3287C37E0910AE78506D0,
	CanvasUpdateRegistry_PerformUpdate_m6C0C51EBC871BFD67FEE7403B0A4D8FC99AAE93E,
	CanvasUpdateRegistry_ParentCount_m41ED796F144AF2FF40F97F45687086942FE09776,
	CanvasUpdateRegistry_SortLayoutList_mB2F2B63B28CC722E5AA645835963DD3678FC08BA,
	CanvasUpdateRegistry_RegisterCanvasElementForLayoutRebuild_mD64DEDFC14F5B52DE3A685CD1B132907A784D70D,
	CanvasUpdateRegistry_TryRegisterCanvasElementForLayoutRebuild_m4D405FFBB41D68D0D1A260DBFBC196257EC95898,
	CanvasUpdateRegistry_InternalRegisterCanvasElementForLayoutRebuild_m4B27D53D884E8281D102493C216A85402702B02B,
	CanvasUpdateRegistry_RegisterCanvasElementForGraphicRebuild_m78F01AB29AC2F8BA889E0D0A67CD150BE0006508,
	CanvasUpdateRegistry_TryRegisterCanvasElementForGraphicRebuild_mF9026CA6334F6B484FC243F0C1BFAE15EDBDEB11,
	CanvasUpdateRegistry_InternalRegisterCanvasElementForGraphicRebuild_m21F2CD6F08EA106A9B7CB61836836E67D9AD014A,
	CanvasUpdateRegistry_UnRegisterCanvasElementForRebuild_m65BE77E918ACF3C08D0C2651B3120120AC7A5FD0,
	CanvasUpdateRegistry_InternalUnRegisterCanvasElementForLayoutRebuild_m257D195226FDF05E9A9723745094408E556A165E,
	CanvasUpdateRegistry_InternalUnRegisterCanvasElementForGraphicRebuild_mE9C5DB7632C213651671F55119B385984FDA52BB,
	CanvasUpdateRegistry_IsRebuildingLayout_m067422BB24431C94CE3DC7FB25760351B3015D80,
	CanvasUpdateRegistry_IsRebuildingGraphics_m9675CE4A1FED3F73C3B0EDCD1DA90BB390EE2A03,
	CanvasUpdateRegistry__cctor_m4816A252A4E24967FBEF0AD749DDE9B3F8D5FB44,
	ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905,
	ColorBlock_set_normalColor_mF36865F66914F3902ACAF7E64B3E6C664EA81911,
	ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF,
	ColorBlock_set_highlightedColor_mAE0BF4A697744D841048D8BE9A0C8963226B4B3A,
	ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5,
	ColorBlock_set_pressedColor_mAE69CAEBA8CA45E089F6C7CA2F1B8C530705E70B,
	ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D,
	ColorBlock_set_selectedColor_mA8B032467C571D28563D91766B0E956FB265ACC9,
	ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8,
	ColorBlock_set_disabledColor_m530D0573E0257BAB82F2FFEA0E22C743911B4588,
	ColorBlock_get_colorMultiplier_m8B3021855566FCCBD41100EB2B70B18172064DC5,
	ColorBlock_set_colorMultiplier_m815DE55D842A1480A11D1051D559D9B63EE34672,
	ColorBlock_get_fadeDuration_mD5EA922E1FA90C1BA224652C1DFC25FEE93830D5,
	ColorBlock_set_fadeDuration_mE31362D1331C613F27505EB7581A734A2E58C917,
	ColorBlock_get_defaultColorBlock_mD3AEFDABCF5F714D81FB2047A744930650EC223E,
	ColorBlock_Equals_mCA2055CA21C85A585504A447B3B048480BB7AB21,
	ColorBlock_Equals_m3768CE3E85F9FD55FCA305EA20FF33983B4DB26C,
	ColorBlock_op_Equality_m63592FF29309D3AF64710205FD9797D2E4AF4E3C,
	ColorBlock_op_Inequality_mEC2D35C789210F1825B114A5E224B0FB6975C1A0,
	ColorBlock_GetHashCode_m1F4A5EC52681DEE9C205F4A5C5A60051DAF71111,
	ClipperRegistry__ctor_mBE6A18696846AD82B4C069BEA3C4318777A59521,
	ClipperRegistry_get_instance_mE4E214237577A08B2A6C8AF9DD7CDAE1B75E387B,
	ClipperRegistry_Cull_mBCB5139DD0FBCC6436ABA8F014E455DF219ADB18,
	ClipperRegistry_Register_m3D9ADBB2F45433ABA125ADC70834A188BE5BB486,
	ClipperRegistry_Unregister_mA09C34BE5C5BC681695DA6F638C3CA585B236467,
	Clipping_FindCullAndClipWorldRect_mF3B79EF5BE61C8D2FCF12B428EA38A55FE1CA31A,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	RectangularVertexClipper_GetCanvasRect_m3A009069CB93F6A0D61221B26FD7BACD6A57533F,
	RectangularVertexClipper__ctor_m8627116751067B7124D26CF075DB1DB7AB21F37F,
	DefaultControls_get_factory_m616056407908402EFF7E24BC02D0A1B0CDED98B2,
	DefaultControls_CreateUIElementRoot_m6B5271F0FD59538B62BD2A81C972F919A8F2F184,
	DefaultControls_CreateUIObject_m40EAC1469CBFAFB6162127C38E148719A986C988,
	DefaultControls_SetDefaultTextValues_mA1638BD65C2A72207A3E3EA7D1D8A8485D108A1A,
	DefaultControls_SetDefaultColorTransitionValues_mA5D98948B9EB25EFC8EB302A63EDA5FC239F9B02,
	DefaultControls_SetParentAndAlign_m4176E84A699CD8A68747888300DC651B765A512A,
	DefaultControls_SetLayerRecursively_m090900DE7A3FFC976E3DBE9B54C11769EE126BF1,
	DefaultControls_CreatePanel_m6CC4319B8D81426FC2A4E94CA836AB4F0ECA0205,
	DefaultControls_CreateButton_m73704B2DEB6F80CF622B31A7B14BBEC3A24737C2,
	DefaultControls_CreateText_mB0CA319F4BF0C8EC8773075885BD67D78A4582FE,
	DefaultControls_CreateImage_m5A948ACE15B86771B6F3EB7A8A74EBE938CEB3E6,
	DefaultControls_CreateRawImage_m3704C3F2E829FBCFEEDA34F27668000B1E6E5A02,
	DefaultControls_CreateSlider_m2AF0A50D2FF4EB21A68A5DBF92076C8DB6D50C5B,
	DefaultControls_CreateScrollbar_m876785B77922E7A0918137096FE9CEEC4BBCA1C6,
	DefaultControls_CreateToggle_m9F0611E37F71C5C077EB3D64D998A7117C830B7F,
	DefaultControls_CreateInputField_mDF85B76D7CDE06E5E49F537EA5FDD8192DA5E65A,
	DefaultControls_CreateDropdown_m00FF9DE1B54D5EA9B22EECC23EAB2D465538C0B2,
	DefaultControls_CreateScrollView_m18E2B79533E8C63917A90B112C7861D8777FAB89,
	DefaultControls__cctor_m2CFE7925A4D7254130F760EBE94A377BB86417A9,
	Dropdown_get_template_m9C83BB0CFD2BA72F08ACC8B0FA9A274FAD0FC9C4,
	Dropdown_set_template_m2B92A6B03345CAFB7C987C648B6FC075420DF85A,
	Dropdown_get_captionText_m3E3FF20006F7EC8A8FD7ABBB7F9F723A0E3CD5FF,
	Dropdown_set_captionText_mFF1957B5BFA13D2295B54A092E863D0F582A3054,
	Dropdown_get_captionImage_mB846CCDC2F81DEC05EFC9FA1E38505409B428253,
	Dropdown_set_captionImage_mE671828EC16733683973D78B53EAAD8BF928C3FB,
	Dropdown_get_itemText_m1AEEFE1ACF751CD3483659F5E5B703239C28C7D5,
	Dropdown_set_itemText_m3FA2FA21BFB8D097F11F642B4061544FE97A250D,
	Dropdown_get_itemImage_m3B115ACA023FC279CAE1757FD4AB0DF91242BA50,
	Dropdown_set_itemImage_mF609D2C91FC45643A9F61E1F651BA1FC9DA4DF45,
	Dropdown_get_options_mE95E87D4EA905E9769CE8AC1CD1D9DB86A34F823,
	Dropdown_set_options_m6606D7A610BA8B07CE330099250482F230B41CAB,
	Dropdown_get_onValueChanged_m4EE82DC9AE8618C52CECA362EBDE6284F41E88FE,
	Dropdown_set_onValueChanged_m5933FE1D9A345810C095C9152A5A3FDE97132C59,
	Dropdown_get_alphaFadeSpeed_m6622DC342399634C72CE480D339380EDDFB41CBD,
	Dropdown_set_alphaFadeSpeed_m8B30DC0B7FE44FBAFD99455204B6EA904A903107,
	Dropdown_get_value_mF388FA389F2A050264AA87E61D4F9AFC41F48873,
	Dropdown_set_value_m155A45649AB62AC1B7AB10213EA556F22E8E91F3,
	Dropdown_SetValueWithoutNotify_m6D653006F090CE272709B7A777589C338AE81362,
	Dropdown_Set_mB556E466A427314DC78F38EA38DB4462672B2A49,
	Dropdown__ctor_m441023FADC43E0D5215546260F0230D92439AA9C,
	Dropdown_Awake_mDEFE3A3991573E2C6942EF866CC4D2350481322E,
	Dropdown_Start_m32F9113294B5F5EB5EFE41F9D2B6C49A516182E5,
	Dropdown_OnDisable_m7CBB6617F6557D89C1E92EC5A7433426AADCF53C,
	Dropdown_RefreshShownValue_m310DF4ABCFE31C74153AAE3874B40DDF3D6959E1,
	Dropdown_AddOptions_m00D0E094A726D9E20E42CDE57430879266456ABB,
	Dropdown_AddOptions_m1F55A888671D01E7933300CEFF571556EE717AC8,
	Dropdown_AddOptions_m07425DFFE48698B71FFAA7A88EA4EB9191A0A20D,
	Dropdown_ClearOptions_mC20522EBB5C22EFC938740AB7A2524EF8CCCDD0D,
	Dropdown_SetupTemplate_m3F4C22ABEF75FEC05E3D42D277EF2299A7934E0C,
	NULL,
	Dropdown_OnPointerClick_m2D739C0E96E848C4384C7BFEF289259717593B3A,
	Dropdown_OnSubmit_m51215780EC68329BEE4F305748A1EFBB501EDE6B,
	Dropdown_OnCancel_mCB303E40BF5CA8862F28F6E377C74AD618C6A54B,
	Dropdown_Show_m996910C935BA7D778E35EBAA55F1AC7299A0B3D9,
	Dropdown_CreateBlocker_m036190311A5551395BC6DD3807D909F851AC8075,
	Dropdown_DestroyBlocker_mEF1CA103B452EBED15714974CEE056CB44C17A58,
	Dropdown_CreateDropdownList_m4C38DE76864D27BBA2033CD5DD72A88B1D2896A9,
	Dropdown_DestroyDropdownList_m1049B8618DF9EFDC6504F4CF29F240252BCAC0A5,
	Dropdown_CreateItem_m591B3B4546D13786893F9930BE702F3A9AAE3CDC,
	Dropdown_DestroyItem_mC2B1258A6EF53D30D7C7693BB62B63B12E3283AB,
	Dropdown_AddItem_m0E0D9C4C7C73622BC2E7AC785BD4CEA48FE952EF,
	Dropdown_AlphaFadeList_m7E0D67E3ED4F3578B5850B47E4A6F9CFF19A49BB,
	Dropdown_AlphaFadeList_m86254B5CBD02903E1D9AF108EB1E86234DCE45E2,
	Dropdown_SetAlpha_mEFF1F7A014A6A66AEFFA937DA3EE8591B7F2336D,
	Dropdown_Hide_m396A627BAA21433514959C71BD8B13A31B7B99A8,
	Dropdown_DelayedDestroyDropdownList_m09235010EDBDA0A0341350E1D34BC0BA9A326CBF,
	Dropdown_ImmediateDestroyDropdownList_mB3CE7E1B2B95662433A48B5BA20A51755AAE677E,
	Dropdown_OnSelectItem_m28AC73C405708C623F4EE5C42E61D5C8D2ECC011,
	Dropdown__cctor_mC1DD8DB000D6E2DCA6CD41C429DDF120B6535442,
	FontData_get_defaultFontData_m395A2BA13B11A53C4BD4E8F1B7D97E9E278D6063,
	FontData_get_font_m63A03245926CD05B461E00C281724370C8B7D0F4,
	FontData_set_font_m6FC9FE436E4EE72CD5039010DA60F922F0B34F93,
	FontData_get_fontSize_mF53526AF53B326BFA253A65D36891015F3F3AC08,
	FontData_set_fontSize_mC3225A125A316DB700496872EF33829A1736AF9E,
	FontData_get_fontStyle_m463803A5ED384064EC9B03549BA921BEAAC8A4A6,
	FontData_set_fontStyle_m16F9715D8679E8CD51D3E4B9755DBAD86A28E20A,
	FontData_get_bestFit_m9B677268C0B0AC07DF39509A6EFA74D057C5D96C,
	FontData_set_bestFit_m8F31CB420AC3F76FB80964A4990F4F79C64BCC00,
	FontData_get_minSize_m963639D175365AF4A04B256EA11CDA29C73654F9,
	FontData_set_minSize_m7C66291B2D46DBB85BE699C63BE84835D7F20965,
	FontData_get_maxSize_m22DBD85840A55249A019D97A3480CFE515F613E2,
	FontData_set_maxSize_m681E9215562EB7A3F0DF1D8EAD6818E064E76DE6,
	FontData_get_alignment_m2492DD0F8619041BD0426388DFFE2DA4634DF095,
	FontData_set_alignment_m531F891C8FDB722FAAEADAE288FD3A6759C8100D,
	FontData_get_alignByGeometry_m847BD1E3B34CAFF67EE1E7983D1DFC02BDFA1F10,
	FontData_set_alignByGeometry_m490803F52D6C14BAE33AC20013A14DFAD6C0493C,
	FontData_get_richText_mEF4FF744C13484BFD1AADE759229DD339333840D,
	FontData_set_richText_m155CBB2B6901849428D2561277DE44792A0AFA36,
	FontData_get_horizontalOverflow_mD9704C9760A72DF3123CD12CF2C801424B43F9B8,
	FontData_set_horizontalOverflow_m0BE81B30BED3A1B575BA3DCC5FDDAC7BDCC92B4B,
	FontData_get_verticalOverflow_m42B923B1137DAEA0D1846C81B659284A5B93D2F0,
	FontData_set_verticalOverflow_m4779DAE6C93E455842499EB2CA08BA5E59D7B68E,
	FontData_get_lineSpacing_m82401018033F25E3FA5623ED10AF9841FEABF71D,
	FontData_set_lineSpacing_m035AE14D0ED7CA6022A28E886905297572A074AD,
	FontData_UnityEngine_ISerializationCallbackReceiver_OnBeforeSerialize_m4A4A8DB0EB7A584EBBD00EA62FCA8029FAEDA475,
	FontData_UnityEngine_ISerializationCallbackReceiver_OnAfterDeserialize_mF2B6D9180E6CAA5FC1AE9624C1A46877EC82EBC5,
	FontData__ctor_m239C5208D7A9C11EF178B2C5400B9DD5671F98BE,
	FontUpdateTracker_TrackText_m776156E82157345895376EBF8AE4E3EFB0C1C05C,
	FontUpdateTracker_RebuildForFont_m306DBA9E9C76DB32E297271E80C1BA1E828B9739,
	FontUpdateTracker_UntrackText_m97ABD557B35113C06A75DB24FBE91B0E247AC389,
	FontUpdateTracker__cctor_mE571B978C1362843C745826F1812DC32EED6E4FF,
	Graphic_get_defaultGraphicMaterial_m4CE20290CB9C10C4761280434B5C0DD703FAF5E9,
	Graphic_get_color_m41096F123C41440AEBA4DFA9895C200D6A57E3BB,
	Graphic_set_color_m71963C0A0B8A3BB3FD6D5FC2642C9637089478BC,
	Graphic_get_raycastTarget_mBC5D939562DDB05CEB992ED35D1A05FEDF05D9EB,
	Graphic_set_raycastTarget_m713EA4933B2B56078033A25C2983F26D2147694E,
	Graphic_get_useLegacyMeshGeneration_mA54E7D6F19996CB7BCDF204AB7AD55073B8B0A11,
	Graphic_set_useLegacyMeshGeneration_m4C7B26FE354E1779C95E292C4446F6FF1D0398B8,
	Graphic__ctor_m262586AFB0BB8853AC7A4279B287733828881D77,
	Graphic_SetAllDirty_mEFF3891228950806F6EA0CF37A3C19D14429412B,
	Graphic_SetLayoutDirty_mA05AE94955A2F3CBA01E4A8AB9BACAB4DCC102DC,
	Graphic_SetVerticesDirty_mBDCBB4E44DB03F2884478306C9FF03300A1BA438,
	Graphic_SetMaterialDirty_m6D540F0423275B213FA2F4C63DEF2E3346884BF6,
	Graphic_OnRectTransformDimensionsChange_mC7D63E3E33151C9944DCFEAD3B16B6E872A28FC9,
	Graphic_OnBeforeTransformParentChanged_m3709CA120490D6F743C4F5F1CCF6D35D37691349,
	Graphic_OnTransformParentChanged_mED19B74977B75B60876BFDAD79B440FC8CE8733D,
	Graphic_get_depth_m9FDE7D38AD015374E84E4A0319309507B02C044F,
	Graphic_get_rectTransform_m025371162D3A3FCD6D4692B43D0BD80602D0AFC4,
	Graphic_get_canvas_mE278CED637619008522EF95A32071868DD6F028C,
	Graphic_CacheCanvas_m61373C8047EBCD9C150E785F1AD5E58E71B82000,
	Graphic_get_canvasRenderer_mB3E532BE19116A3F0D6ADC1CD29D242428EAE8AA,
	Graphic_get_defaultMaterial_m0A1AF379749391DF306119369BC47E422B7E5AA8,
	Graphic_get_material_m009A329611244894C6F51FA7D72E7945074B1F66,
	Graphic_set_material_m4DC45A89DE40E6414FA349FC31957D9F8A69535E,
	Graphic_get_materialForRendering_m0FE5B8462BCE184C19D7C7991AB00733E499B168,
	Graphic_get_mainTexture_m8ADD95545D4FAB8D218C028196DCB9758C47B3E5,
	Graphic_OnEnable_m7882C581C61D2AC215A551E80CFC55EDFCAE2815,
	Graphic_OnDisable_m7E1C19B12C0F40015B8CEBAE7858CC00292A94AE,
	Graphic_OnDestroy_m269B2622D286DF6A08C3507A52A1ED97ECAF4159,
	Graphic_OnCanvasHierarchyChanged_m3B0022243DF53BB7C80573FCEB28305252A1EBEF,
	Graphic_OnCullingChanged_mD08B893C020E4FB67F825DD8B0CA2A870A5FB19F,
	Graphic_Rebuild_m691F66108929ADB2174644118215EFD7891E21A4,
	Graphic_LayoutComplete_mED506490B167B80D7225F1952B808B5DD6090317,
	Graphic_GraphicUpdateComplete_mF961E7FEB231A71A2E53C40C130DD18430B8AA12,
	Graphic_UpdateMaterial_mBB750492DC6787FF92DB7EA1E15C7D74967C33E6,
	Graphic_UpdateGeometry_m1EA57D6BB10A2ADD33BA385ACEDDAB205839853C,
	Graphic_DoMeshGeneration_m7BF07EEAF0B97B4EB48DF41D55C52282C3F938B4,
	Graphic_DoLegacyMeshGeneration_m0209A9D02FEFA8BBBF0C403CB2F3FCC7D1C67196,
	Graphic_get_workerMesh_m44288E0C1A3F7208C2F0C845C66D97CC243DA8F3,
	Graphic_OnFillVBO_m2F10FF0E7D1635058230F47F4C235F4D619D2210,
	Graphic_OnPopulateMesh_m68CFA054D095A5A8526A37CB57E76149BC222F13,
	Graphic_OnPopulateMesh_m5FBF47A58773160BFAD6E08F11911ECBD25B49FE,
	Graphic_OnDidApplyAnimationProperties_m183738197A547E50A740F2868A10E518D3855181,
	Graphic_SetNativeSize_mF93C864996EC62D9531D332E79B6589705354846,
	Graphic_Raycast_mB1E3E0D9B2C72901DB727DEA666C693330525F38,
	Graphic_PixelAdjustPoint_m6A06D04F7D6B6D946407ECBD984AB2E9B2EF2DCF,
	Graphic_GetPixelAdjustedRect_m324344D38946D6F976CD487B493B8D9787DE891B,
	Graphic_CrossFadeColor_mCF4CE369216048F08E314393B53F6EC870E925E2,
	Graphic_CrossFadeColor_m77BFABC485B2DDEBDC7EF44D8485032122D000DE,
	Graphic_CreateColorFromAlpha_mE5F922504327278097F1D089BE82469FED89EF79,
	Graphic_CrossFadeAlpha_m00EA1A85E402BDD8F423ED453C3D0BB91F1DB7F2,
	Graphic_RegisterDirtyLayoutCallback_mE78A94DE6CFBC38EBE7F12E7D43E6AF1DEAA0910,
	Graphic_UnregisterDirtyLayoutCallback_m6200AE0A0119212754E6D42C4F5EA6B103767D66,
	Graphic_RegisterDirtyVerticesCallback_mFD6FB14CE29384C3FBC04E536EEF6AAC11A9D830,
	Graphic_UnregisterDirtyVerticesCallback_m0B6927F51F8CB55029D63C291CD3441187F23C15,
	Graphic_RegisterDirtyMaterialCallback_mE0A605A0AAAE76C1AA11E3CB16F01AB452D8C389,
	Graphic_UnregisterDirtyMaterialCallback_mD8CEC569308463DFE42C65DACF7AB42FDC3BDE2F,
	Graphic__cctor_mAC1D29B9EC43A606C75C9D72D49CA11EF5CE8781,
	Graphic_UnityEngine_UI_ICanvasElement_get_transform_mCCB04E0F0F285EA97EDF6D033919593677F6A0DD,
	GraphicRaycaster_get_sortOrderPriority_m166C43A27A3C0AF761DED746D800560D01F5F608,
	GraphicRaycaster_get_renderOrderPriority_mD247B2065095F9AA83C77AA744548BD44E1F8FFF,
	GraphicRaycaster_get_ignoreReversedGraphics_m01C42ECDC73F4282FBC94416246B851E7F2CA45D,
	GraphicRaycaster_set_ignoreReversedGraphics_m38DC6947B4DE23FFEC12E8B45DC15AE7AAE06533,
	GraphicRaycaster_get_blockingObjects_m65760F738BEBB63000DD47E0E5E1FF8BA0AE49AF,
	GraphicRaycaster_set_blockingObjects_m19ABE0A1C77456D6DA4E2FA33D21649273AFCCC4,
	GraphicRaycaster__ctor_mF6A9D603EA95EB8170A4E34A5EB5C93757B4014F,
	GraphicRaycaster_get_canvas_m74BF579BA6B90DA2BB40CC35A4593891751D5CCA,
	GraphicRaycaster_Raycast_m383268A8AB2D43501C7EB3F63759856325B108EB,
	GraphicRaycaster_get_eventCamera_m9A3A721CBF84A96629E4BC1733BBB6A45FF9059D,
	GraphicRaycaster_Raycast_m552267A5FF8C7D636A1D94C8667F943B5B7DFEDF,
	GraphicRaycaster__cctor_m284F55D2EB48C602FAA815235EED41A80A7828BB,
	GraphicRegistry__ctor_mAB3A1033E0246E6DD01A842A71A7E85DF199358B,
	GraphicRegistry_get_instance_mC44355C0B339CE448FE227149CEE9E1469DEA198,
	GraphicRegistry_RegisterGraphicForCanvas_mAE18F217BAC37B8BB219905B3BD0A3D891DD9C21,
	GraphicRegistry_UnregisterGraphicForCanvas_mAEE5A2BF640ACA60440944931F48C515DEF91898,
	GraphicRegistry_GetGraphicsForCanvas_mAF4E2A47FE07E729F25D7324F46E8FB2E2785DB3,
	GraphicRegistry__cctor_m6E3EA95E443870B63C123D9BE7FCFDA764B79FF8,
	NULL,
	NULL,
	NULL,
	NULL,
	Image_get_sprite_m642D753672A8CBCEB67950914B44EF34C62DD137,
	Image_set_sprite_m77F8D681D4EE6D58F4F235AFF704C3EB165A9646,
	Image_DisableSpriteOptimizations_mF68C6A1BB8729F6F5CFF13D2320BD0A8F7ADBEBA,
	Image_get_overrideSprite_mE32E3D384CA6220B81702E9E3051FF83C4232FF0,
	Image_set_overrideSprite_m8714253751BEE8BE9A36E225D259BF68E88DE1A9,
	Image_get_activeSprite_mF8F075992BC21B86E47F76D5F8018524DA045A88,
	Image_get_type_mBF4695569A2C6FEBCDE60AB80A386F39D5708D6A,
	Image_set_type_mB5B2391926DA2F7326A98B2A847877C6CB8F0E2B,
	Image_get_preserveAspect_m75FB3091416F2A7B02AE9FD88457FF5F18364BAF,
	Image_set_preserveAspect_m9019A1737AB408F545503F1B6A8ACE48F85D8668,
	Image_get_fillCenter_mA68592BF9F9ABB0B9D0A7BBE87751D6353FEF16C,
	Image_set_fillCenter_mB27E08D8E2CBAE31419006E77FAB76D535E3A750,
	Image_get_fillMethod_m0F319641FE800193CB9FC939F4A4767D230D23F3,
	Image_set_fillMethod_mD7470E1F35FBF8B7A27A704C002969690B723A5F,
	Image_get_fillAmount_m5FF6EE8DB33C4A219B3677FB24F50A6E5CCF44F0,
	Image_set_fillAmount_m613B7AC920F2EA886AF0D931005C6CD13F89A160,
	Image_get_fillClockwise_mD0AB41F20B5AAD8775C944C752D45F7CEAABC1F3,
	Image_set_fillClockwise_mDDF4F5499EE8DDB33855B9A6ECAC17D642F9CCDA,
	Image_get_fillOrigin_m28266DE26D26E943BA893971EE1FB83132655920,
	Image_set_fillOrigin_m17D79352C290760B275F1B5A198F0CE5C1293E79,
	Image_get_eventAlphaThreshold_m1286AAA5CE0BBE17E125DD5FE02139649F0369D4,
	Image_set_eventAlphaThreshold_m1EB7D592AA13B9BEEACA3C2FC6DF97159282D071,
	Image_get_alphaHitTestMinimumThreshold_mA90C5ADE6E119ADF2B483F8239A1C66C3A2E3E2E,
	Image_set_alphaHitTestMinimumThreshold_mBF21EA4ECF7EF080B7CF64C2D2DBA98C4BDE360C,
	Image_get_useSpriteMesh_m36A6D1A2FF7C0DFCA3E0AE2DA79FA339335BDA55,
	Image_set_useSpriteMesh_m1B7EB82514B9F94A94D45E2654327F235C8EF58E,
	Image__ctor_m107392C55619451EAF98F5CF71E6449E8E2AF1D7,
	Image_get_defaultETC1GraphicMaterial_m471CA72CC6141A7F71D521C366E04D728F0F66A0,
	Image_get_mainTexture_mB257690C040998ECFC1BE091374B54B181823D27,
	Image_get_hasBorder_m5633A7D963D07F709BC44C45499EAC2B91996BF8,
	Image_get_pixelsPerUnitMultiplier_mC9DC2AFDADC2CF3B81BE6913661216D958D72153,
	Image_set_pixelsPerUnitMultiplier_m8775619FBA98B1E657A2421CBDD707CCB58A7C75,
	Image_get_pixelsPerUnit_m4E763A10D3BA64B0AA5CE0474A42A6B8B4C0F990,
	Image_get_multipliedPixelsPerUnit_m336435DCB82AA41DA8C79AC24F3102D90CD92A28,
	Image_get_material_m75690B58C80538290BEECC5E1D145FB19158ACCA,
	Image_set_material_m972B05F260CCA585187416B416F6BE227589C6DE,
	Image_OnBeforeSerialize_m2C27418FB79FF38445F2B998BC6027990FAB1AE3,
	Image_OnAfterDeserialize_m3A6ECD0D548C102C460D0FC63E885791781AD35B,
	Image_PreserveSpriteAspectRatio_mBC0E31CEB88E7C6BE29234193B954ABD84A48F1C,
	Image_GetDrawingDimensions_mC16B4DC39F042073D15F8A98D8B1594C70BD27A8,
	Image_SetNativeSize_m226D9782963DE3740563978C9CEF135D3724BAA5,
	Image_OnPopulateMesh_m9CAE895CE1CCF9E950684C0EC9A7036A1AF735CF,
	Image_TrackSprite_m97B866E177E385BA1E4651B934FFE35552B8AC71,
	Image_OnEnable_m33696C9050F3C0686FBCD9C79E7B77C5828A4881,
	Image_OnDisable_m1BB9055E8C7EE894D196761AEAB37E321A3766B2,
	Image_UpdateMaterial_m546E64701AE4B936C898238357945BFFCE6D290C,
	Image_OnCanvasHierarchyChanged_m1B834FEE18F11EEEB71E30FD8B6E4D3B6FE767DD,
	Image_GenerateSimpleSprite_m7076714628A1AFC168192050332FF5DD6BB2E16F,
	Image_GenerateSprite_mAB424DB0484CD040E0A3B5E061306FF2F8831C7D,
	Image_GenerateSlicedSprite_m921AE8C58315EEEC06A6C9412A7056166B1FF4ED,
	Image_GenerateTiledSprite_mEDC93862A3A37EBF5D425E27DF9B3D3A6D31BB6C,
	Image_AddQuad_m9AC07E2C127F3195B0E6E3EA47CDF71A62016AC5,
	Image_AddQuad_m52DD32636BA84FA0BF9D2420FD70A85BEB2843F0,
	Image_GetAdjustedBorders_mCF8A75527B652B1EE38AA901633CB4ECAD52AB89,
	Image_GenerateFilledSprite_mB5C23FAF9510592B583DB495396E710242848093,
	Image_RadialCut_m80B9F9BADD0E0808A1761C794BD56649B64FD7FC,
	Image_RadialCut_mAA0ABBAEF18371501B3A6BAD624CA32949F485E9,
	Image_CalculateLayoutInputHorizontal_m8BB12172013052DA3440EFF710A429C8BF2BFEC9,
	Image_CalculateLayoutInputVertical_m3E85E197B85895E6248FE25BE4D65E4FD507E8A5,
	Image_get_minWidth_m5DF43F172E23E902CABB2D69FB67F5D6CB241317,
	Image_get_preferredWidth_m489AFD0929A50D0A681F828115FF6A0FBBAE17AD,
	Image_get_flexibleWidth_mEC388A0703E9F11DBE52E0824FF2E8B9DADB4B7D,
	Image_get_minHeight_m7CD99A4954247FDDA404AD53732F9787C46B12EC,
	Image_get_preferredHeight_m1840628A58BD9839D18E389342223101345E3334,
	Image_get_flexibleHeight_m784DE68069CA731F4D134A6DB88E2E9B87415C8F,
	Image_get_layoutPriority_mE1DA3C23A995D1644C9E32E6D4D6F5B343CE9C89,
	Image_IsRaycastLocationValid_m160CE24D1C865615BF6020950EACD52306D1A0DD,
	Image_MapCoordinate_m90184DC8DE94E172E71287F95A400EE4C5EF464C,
	Image_RebuildImage_m1C0BD1F567C7F1616033BAAFDF36CD90D12B6E4E,
	Image_TrackImage_mF542664453B48FAA6BA7656FF4B776596493F43C,
	Image_UnTrackImage_mADD4B39F262A992CCDE99E7668504F4A963E6769,
	Image_OnDidApplyAnimationProperties_m0638444390B79CB555DB3D0A32EB81FD4255EE6C,
	Image__cctor_m8A33A91F993F21D61579B9096ECCBFB8AE85AD1B,
	InputField_get_input_mAF4210F766099F23FA8695F12CA970CC8E5CA80A,
	InputField_get_compositionString_m023139DE6EF012E022F61934667F47505DC0C767,
	InputField__ctor_m092A4C9CFF5530E3091767467F078A79FDFC33D5,
	InputField_get_mesh_m6546FECF63F4A23B1A3C8B58B0BFE294106BAE7A,
	InputField_get_cachedInputTextGenerator_m6E2FFA43D0AE993D930B4763184F248AE1915CA0,
	InputField_set_shouldHideMobileInput_m9F2CAA3714EFEA7137E7B88589BE987B2104E594,
	InputField_get_shouldHideMobileInput_m0187F216F281D2CF39293E56F46E408C894BA4B9,
	InputField_set_shouldActivateOnSelect_m9B19AA526E57756B3B2E25F1D5469062AA0089C9,
	InputField_get_shouldActivateOnSelect_mC1914B9D456B836B094A8C2ADBD47962D257F229,
	InputField_get_text_m5FA1E757563597DE4B57559A9E68D645FF2CC461,
	InputField_set_text_m172924B88B50056001C94A68403D06B8A3922602,
	InputField_SetTextWithoutNotify_mF83F442F931F51BB4D2DC44E10AD6D868C4751C4,
	InputField_SetText_mF04EC7C40C0A5CF1B305173F8879A7C977D733C1,
	InputField_get_isFocused_m96F65188C4517CE6F2A818F717CE23BD565E43A2,
	InputField_get_caretBlinkRate_m90B21829D909134FE51C38B3DFC44369504B1DAC,
	InputField_set_caretBlinkRate_m294E75C38336F482E6F5577ABF08CA77D58D7C6E,
	InputField_get_caretWidth_m3F8ADE9650CAF8E2DAA3859CA79BB78B832A0076,
	InputField_set_caretWidth_mF41505CA56ED0518E2E64CF5D6806896D97A13E2,
	InputField_get_textComponent_mC1FC063C41D84947A3B0BE349C6E937EDF0EB19E,
	InputField_set_textComponent_m6706EFF9E1F112E923041792E86515FB0E9A0661,
	InputField_get_placeholder_mBDB090222F665AE8A1C96F1F375732346F177EEB,
	InputField_set_placeholder_m1DBBD3A9F82F0660B33CE7B08CE62BD2CCA5E859,
	InputField_get_caretColor_m9CC9FE92EE010A1F980A2838A41B4C081D2FDA3A,
	InputField_set_caretColor_mA948529F9562298217DED4DEB399D203300E3723,
	InputField_get_customCaretColor_m2A443DD5624262216DCF1E2E71D07F36E176C69D,
	InputField_set_customCaretColor_mCE05E6BA5569DDC65984F569E5495C8204BA1A1B,
	InputField_get_selectionColor_mA49DCB951B526D232C0E090783433304261D4D1C,
	InputField_set_selectionColor_mB4D275506E3BF3962B0F6470F8F1C84DFE526CF6,
	InputField_get_onEndEdit_m912D9CA48D579EE1A68544EA58EF5EEB633148C1,
	InputField_set_onEndEdit_m7F8734F533100D371BC3980661A3021D86A0C49B,
	InputField_get_onValueChange_mC6364A9208DD2811E7DFF5F0A1225246A278BCD7,
	InputField_set_onValueChange_mA6AA9EF96B0AC2DF68CFC4827B1FC4CE03D98B0E,
	InputField_get_onValueChanged_m1AE46D57FF8D96F53F2039722DE9CDDB6AB58CA1,
	InputField_set_onValueChanged_m140035DE99534F06D4E02DF2C9ED8ACE7DE471BB,
	InputField_get_onValidateInput_mCF04910E2F6920903CD095B86C1D61DA4C01B553,
	InputField_set_onValidateInput_m3CA787E084564B5313C29B41A3C8F660CBB0ABD0,
	InputField_get_characterLimit_mA047A0B080E33B75C9F6F10E4344D3E00BB82832,
	InputField_set_characterLimit_m9D5AB377A2B229A6909D55B5BBC4BD50EE3C8E25,
	InputField_get_contentType_mBDEC121EFB7451BE3F56D8A2F68BF78FC28D2329,
	InputField_set_contentType_m9A0923CA1A61F3A401DD81C3FFA95199AD928392,
	InputField_get_lineType_mAFC713A8DC2FABB2FFC6902A767DAE2932A5BDBE,
	InputField_set_lineType_m134CFEC1C04BC47E15A9B4748A5A9AE7CF7FAC2A,
	InputField_get_inputType_m1B9C2C98A32BBD27759C950DC4C65F0FD69329CF,
	InputField_set_inputType_m5EDCC3EF52E67D192DFF47907CB8794E6D6A7C49,
	InputField_get_touchScreenKeyboard_m6C45EACFFF50802976ADF0025CEAE8741153CB1E,
	InputField_get_keyboardType_m9837579BEE93CA6EEA8314AF9CE3074F39D8E661,
	InputField_set_keyboardType_mB1C977510496B883E5FB0ED519577B624963C0B0,
	InputField_get_characterValidation_m3BA91CE0FC3845B40E1D43D6F0E36C5DB1D3EC29,
	InputField_set_characterValidation_m9337FC9604B586365B61B96A673FA0C2F6A4F336,
	InputField_get_readOnly_m88449A161BC0C32E5DB56D6043E8BF09E41AF879,
	InputField_set_readOnly_m4ACF8C2FE1C219DA88F776CF1697EE4BBD99938D,
	InputField_get_multiLine_mE74D2E2E2B1B715CF8F2DDD068AA3E7CB270A6FF,
	InputField_get_asteriskChar_mAECFBAC3E3B2455CFF6FCDA2C1278B5F604975BC,
	InputField_set_asteriskChar_m86FC12F2F6BFBBE4124C1B9C7579C894696E0FEB,
	InputField_get_wasCanceled_m7264DBE00BEAF36F065295F2FBC50B8566BE0371,
	InputField_ClampPos_m689A5F00064B74687B8239042F9B68F1F849BFA9,
	InputField_get_caretPositionInternal_mEC8598C831864F6A91793DB28C771D209A424D20,
	InputField_set_caretPositionInternal_mE4B5E92558EE35A7FAF16AA47BC251A82457E9E6,
	InputField_get_caretSelectPositionInternal_mB352D3D787F61AE057ADF532829E4611D6653535,
	InputField_set_caretSelectPositionInternal_m6798CB1CBC2B865DCAE6F34E86DD2BAA5E342865,
	InputField_get_hasSelection_m6F4401A7C105A9F98CB30CC20701D32EADDD065D,
	InputField_get_caretPosition_m469B2760743F458AC3E0572D3BC2AAB527FFB83F,
	InputField_set_caretPosition_mF3087396BFF28DD18DDF4748CBB63FE612A79D3E,
	InputField_get_selectionAnchorPosition_m97767BE40A46C125D9870756E4811C96D5A69ED2,
	InputField_set_selectionAnchorPosition_mEBBF06150FAD599FBA198DE2DDDA16A4458BD690,
	InputField_get_selectionFocusPosition_m857CA86FB5E4E5CAC82D2470C25EB2DB956B6F83,
	InputField_set_selectionFocusPosition_mA955354B576532237D0613025B962A4E901AADAF,
	InputField_OnEnable_mBC45E0F8CB32D800C14DFDDE11C54E50E7104CCA,
	InputField_OnDisable_mBF996F6B4C54639764A5F820FBEB190CAEBB268E,
	InputField_CaretBlink_mB6FA4368435DD2EA04B11D65DD56952C7A5D6E9F,
	InputField_SetCaretVisible_m0A6E0FEC73CA9ECABDB88B7A661A981C89EFD1B1,
	InputField_SetCaretActive_m068E9440B67305ADFAA15948398C98BB0CABAC0D,
	InputField_UpdateCaretMaterial_m4282444657DE957E095074C778C0DCDDBEF889EC,
	InputField_OnFocus_m7E5AE4E065E548BA17D615864A50467DABE4AD3E,
	InputField_SelectAll_m624A39430E584572EC6FF74DDFA7B5CE30291B5B,
	InputField_MoveTextEnd_mB10C0A3193CC68DED56B462D94A2F87DC5B1E199,
	InputField_MoveTextStart_m7EE5E3C883FDF3DE228133D18E02DC5BCA75613D,
	InputField_get_clipboard_mC542B7C4955906AD2FBA0A67F2731F2F83DBF18B,
	InputField_set_clipboard_m4688C2642B87778FE818C27FABEEA887B206A99E,
	InputField_InPlaceEditing_m09B0693FF30033E3A32E2B1DAF56A689F5ACE87D,
	InputField_UpdateCaretFromKeyboard_m2182C0A903DD164C19F68CD790B142179B61295C,
	InputField_LateUpdate_m927226704A65F0D5917161263D51673D1CEADF3E,
	InputField_ScreenToLocal_m4B659514B174BA0738ECB4D1D6BE5DCB9A75665D,
	InputField_GetUnclampedCharacterLineFromPosition_m4B258917A2B47C3D458F1444405C44B4BFF54C3D,
	InputField_GetCharacterIndexFromPosition_mC1C7C2FF61BCDEB174078C8C0A14DDB52856C594,
	InputField_MayDrag_m6263CAC380EDE95E47E4DDF90FE26E9124C57551,
	InputField_OnBeginDrag_m1F28DFB7583238E43B92E7AD5289DECD1C5A1A02,
	InputField_OnDrag_m5CF3D5BD094B3CE1B50CA1A1205E21BEBEAA7CFB,
	InputField_MouseDragOutsideRect_m1562ADF5A78C0E7DC6CD4A59A85D07CD5B730BF9,
	InputField_OnEndDrag_mDB2BBF4256853A7D9B4AAFB37E18BBFADC276D6D,
	InputField_OnPointerDown_mB8464546C064051BA93907C26B0DDCD78D5EE270,
	InputField_KeyPressed_mEA9D60091DBDFCC1F62B626C119A1618DB2395E4,
	InputField_IsValidChar_m838CF42058EEF5524DD8A21D850032713A1BCB79,
	InputField_ProcessEvent_m8857A03013CDF861BFA943227EE6FC50E22ABEEE,
	InputField_OnUpdateSelected_m2BE044B17738BCF0BE2B0CB2913D2488A722D965,
	InputField_GetSelectedString_mA40FFB2E340E8329F265BA04BEA4308290351691,
	InputField_FindtNextWordBegin_m20A12396AC506CE580C1D76907E9DD4DB418724F,
	InputField_MoveRight_m0C722FF6835D9658387A5A8197D2C6AE91167007,
	InputField_FindtPrevWordBegin_m86D6EA31B6DFB7E00BB65DF44B2BFB174C76B779,
	InputField_MoveLeft_mB7649E1BB71E08918FA75129504637E5993BE9C9,
	InputField_DetermineCharacterLine_mC6268169D371E4E9E4F53FE7328467D198900E2A,
	InputField_LineUpCharacterPosition_m8A576AC1B875A888FEDC82321C9AE31DA81AA7D9,
	InputField_LineDownCharacterPosition_m939685CBD14BAFA5A567816BA45169ED8D44163A,
	InputField_MoveDown_m2645944F4CDCD56B539B1A26147F105BD77C90BE,
	InputField_MoveDown_mECF02ABCDDA5BF6C6CE4E697ED528F8DD1F08E09,
	InputField_MoveUp_m0AEA4013B6F62617843F78A8CA28C7789FE17390,
	InputField_MoveUp_mCBE40CD7F6C7D69B70747F7C21100FCEA9529A79,
	InputField_Delete_m0B2140554D2DDE9D0FCE3CE31BAB0BA2DB5E117A,
	InputField_ForwardSpace_m2244ECD6B4F4FBC516C3DFF98C26AD7232923672,
	InputField_Backspace_mDB2818F556D60FAC307837C43B658B85E2CDAC54,
	InputField_Insert_m21CF9A3F16E052701E5EF653ACF2A6292543A00C,
	InputField_UpdateTouchKeyboardFromEditChanges_m30BC6AF6EDEE51BC7841BDB359559841983E0F66,
	InputField_SendOnValueChangedAndUpdateLabel_mB41A9F9492E1E9CB804FD776F8DF0C184AFAF8C3,
	InputField_SendOnValueChanged_mF963DEFC41C615416425F340491E9683542E824F,
	InputField_SendOnSubmit_m308F5B06A977B56339C2A04DFCE76980A060D029,
	InputField_Append_m50F5FFDCBB6DE549E0AB02A18EFF3C6C330C1920,
	InputField_Append_mC02A5BBA8C791725783C71A0690EFAE9B30E5843,
	InputField_UpdateLabel_m712626C2AA5BAACB64354E3A47FDB7D6A08B3540,
	InputField_IsSelectionVisible_mBB46CED5BB481A103E2F451807796BC62F7412D1,
	InputField_GetLineStartPosition_m32048C5BC96D90A8A643C7574D1DB15855A91B02,
	InputField_GetLineEndPosition_m6E72CC73B8CECDFABDEB91B2C16FAAB8DD4D8410,
	InputField_SetDrawRangeToContainCaretPosition_mC1C84B1E904F4E85E302B2C01C485541FD3C855A,
	InputField_ForceLabelUpdate_mE56AAD54AA9A4EB94E6F2488686164EE5470EC3A,
	InputField_MarkGeometryAsDirty_m955A5B6E775E18ECCDD4DC231F3962AC678C63B7,
	InputField_Rebuild_mCB5DCC1F18118169973384D5E1D2B4CA81E9D505,
	InputField_LayoutComplete_mA6A49786196656DB139F8BC45951453E9131577F,
	InputField_GraphicUpdateComplete_mE6D545372C45ABDEE746269DFBCC8902F1200FFC,
	InputField_UpdateGeometry_mEECCF310C7D3393A7DDA08F3B83D90000E218985,
	InputField_AssignPositioningIfNeeded_mE8FEF64ACBED85DDCF0DAA8DA6F3EEF148C12E15,
	InputField_OnFillVBO_m87FE3DEAA2F942B54E9584A90A3B33FAEEE148C7,
	InputField_GenerateCaret_mF8725BE2F3B7E70E1E0B0EFD29E7C4ADC52FF5F1,
	InputField_CreateCursorVerts_m86F38ABBC9B6E0D1772EC65497B6CD54EACB3D24,
	InputField_GenerateHighlight_m5C0CA7EFFD52B7E21A308D1BEAFEA7EDE1C3E1EA,
	InputField_Validate_mB9125CCC24144FC5B3DD29FE985E87F62869DFAB,
	InputField_ActivateInputField_mAAA204298664775BB3A7A2D5569B998BE2E93034,
	InputField_ActivateInputFieldInternal_m1D5C71983027899BC648ABE4056DFD9A07D5022B,
	InputField_OnSelect_mA97FBA3324F22D4FCFAECD870C87982476BD7538,
	InputField_OnPointerClick_m0E8E33963FDF4764C05268FAA9CFD7C8DAA4A7D3,
	InputField_DeactivateInputField_m6302C815A2363039468EFE763DB58EC6C4433B12,
	InputField_OnDeselect_m0B418A98AD504283D5151EF93DF853F651C82A5B,
	InputField_OnSubmit_mA55A52599C8D0073D78993E23F5AC79D73741508,
	InputField_EnforceContentType_m735408B4D205AF1FC3D36B518DDA640F86A88A0B,
	InputField_EnforceTextHOverflow_mEF2E66E0DC46C7AECCE7C5B990FBF802AA28306C,
	InputField_SetToCustomIfContentTypeIsNot_m7555D5C16577D1FBE9DA7ACBB6D6505735AC6050,
	InputField_SetToCustom_m3C3E73F1BD3DD5F83F5CC335604D017E4FC8B62B,
	InputField_DoStateTransition_mECA873FA9210DFA03C164B554FC74A72B91955B2,
	InputField_CalculateLayoutInputHorizontal_mD9DC3557122AF0F1120D7B254E461CF49663C603,
	InputField_CalculateLayoutInputVertical_mFA809A45E5C5552D0F3CFB733EEAFB3A613BBC6C,
	InputField_get_minWidth_mAE0C5234BB329079A707CE4DBF9E5749D3138CE0,
	InputField_get_preferredWidth_mBF8E829F1B2A29346BCB0ADA620181C72C68AE5A,
	InputField_get_flexibleWidth_m3BB11CF1846542B95CCE88E50EA2C4895DFE9DF3,
	InputField_get_minHeight_m1AF6A8396567A7FD26A1F278D2A106D86A2DD0BA,
	InputField_get_preferredHeight_mEF8661384E11AB11AE6FDBD4CC22D6BEF5DFEFA6,
	InputField_get_flexibleHeight_m61212D0FF1ABA904E329D2C9F6AA092A85E0228F,
	InputField_get_layoutPriority_mA7FA21CE021992A6BAED68EC6ED314507E47A5B3,
	InputField__cctor_mB8D2F31A004D010ADE0789E0FA5914448E2672A0,
	InputField_UnityEngine_UI_ICanvasElement_get_transform_mA04C52C3E8831E49F2D5ED03E7A1B532E83D0C28,
	AspectRatioFitter_get_aspectMode_m9DC7F64E9AB97AAB413EEF9931EDEDF90ACE0B75,
	AspectRatioFitter_set_aspectMode_mDF90DA2FC20507B35EC237C91C93A3DBB3CB4322,
	AspectRatioFitter_get_aspectRatio_mCA6B68F9D4FB640574390BF43ACF3DC8D42AEF99,
	AspectRatioFitter_set_aspectRatio_m3E56408CB25114762687C9C5398E34BBCBE8DB01,
	AspectRatioFitter_get_rectTransform_m10762C918EB094ED7335B938446F6537EF9E7F26,
	AspectRatioFitter__ctor_m2AC759B3A6146540893D7540C4FED29B4BF26CD9,
	AspectRatioFitter_OnEnable_m40B817004571F69A96776F46D000E6F24D21B08A,
	AspectRatioFitter_OnDisable_m82534D7AD69F406A0A90A9E912B05658E7AD9A88,
	AspectRatioFitter_Update_mA54B4CE8AE14353C5936E26AFD7797E42AB073F8,
	AspectRatioFitter_OnRectTransformDimensionsChange_m221F31DD8F2247C30B942904590D71C0E018D973,
	AspectRatioFitter_UpdateRect_m9C9311A3A55D5C3175E80C87944B0035DD9084E0,
	AspectRatioFitter_GetSizeDeltaToProduceSize_mCDD7A3B13A26729FD9ACE0D7AAAAD0714F4FE9AC,
	AspectRatioFitter_GetParentSize_m5AA652B731F6930CA9C9B342C93354D73EFB6874,
	AspectRatioFitter_SetLayoutHorizontal_m5B37DEF0AD6FD781A4B42FE51695709EFF139290,
	AspectRatioFitter_SetLayoutVertical_m515415507DB485E9A58CF0583DCD20CC655A9374,
	AspectRatioFitter_SetDirty_mFB1E634E75B793DD239BC6E236001B6A794B1D78,
	CanvasScaler_get_uiScaleMode_m8D75124B20A8598DFEF27665EBE9C5925CB25301,
	CanvasScaler_set_uiScaleMode_m27A14E550C83FC847435C85081D912276730B467,
	CanvasScaler_get_referencePixelsPerUnit_m74D7EF4EB4D71E99A30C975BFAFDAD8CACA73A57,
	CanvasScaler_set_referencePixelsPerUnit_m71C00FD0516FC9E580C828E684788ACAA60EAD28,
	CanvasScaler_get_scaleFactor_m79BDE0DCD960EF17AF645344664F6C91A5519CAE,
	CanvasScaler_set_scaleFactor_mDA73D373B6D69FCD255C7784576B93079F2A6CC0,
	CanvasScaler_get_referenceResolution_m8CB18ECD76532AD9FAFA92D9D395AB1070730A8C,
	CanvasScaler_set_referenceResolution_m816A6770562B655C056B255757993A589C1DFA4B,
	CanvasScaler_get_screenMatchMode_mD1444EF5D606499AE030E88AEACD0D4319C394F2,
	CanvasScaler_set_screenMatchMode_m48F770842F9333E077F5F57726F5074B140C43E9,
	CanvasScaler_get_matchWidthOrHeight_m7CF35A053967D576A0519D156E491D7D77AF363D,
	CanvasScaler_set_matchWidthOrHeight_m3A1FAAE9A6CA76AF4484C002AA8ED0B9C100F5BE,
	CanvasScaler_get_physicalUnit_m2F6DD4DFDDA3DE8652A5F295C1E66060D0D8E94A,
	CanvasScaler_set_physicalUnit_mC60DC2F6DC43C15C1EEB1EF64A653BF64DA7C06A,
	CanvasScaler_get_fallbackScreenDPI_mB24A47CA5792781C10AE198C2EE6988CCB9AB635,
	CanvasScaler_set_fallbackScreenDPI_m4D32B6C619E00682EB8D0DE0F6D71BE6139250EF,
	CanvasScaler_get_defaultSpriteDPI_m670E425C6F635BDC28B2C2B5C71C65353A1E82FF,
	CanvasScaler_set_defaultSpriteDPI_m7509D86B586D726E29D2C21A2CB4E0C567BFF65A,
	CanvasScaler_get_dynamicPixelsPerUnit_m1D1058E155B70C06DD98C7C39B630848E803E155,
	CanvasScaler_set_dynamicPixelsPerUnit_m4D7A2EE8F92EAF2EC58886C851D828111FC34494,
	CanvasScaler__ctor_mBF6E3BBA137405C93E27640EF7E53F6B2808A8D6,
	CanvasScaler_OnEnable_m4FDFAD573E34C335F6EBCC5CB0625353AF189E64,
	CanvasScaler_Canvas_preWillRenderCanvases_m33AF90619C3CE3A826F5EB55843A457B23EA5052,
	CanvasScaler_OnDisable_mC2B96434A71E3BCAE8C03B54D6BA51E22327F070,
	CanvasScaler_Handle_m867273F56329565834F7793E05C970D8E32DA4B6,
	CanvasScaler_HandleWorldCanvas_m0F9D6A0089798542BC7BD4772D782C00FBF643A2,
	CanvasScaler_HandleConstantPixelSize_m2FBD457CCC6225DFB1C3B7A5C737C45E5CBAEB39,
	CanvasScaler_HandleScaleWithScreenSize_mB3430B5FD262C0826FF228EDC80AD0144F7826F6,
	CanvasScaler_HandleConstantPhysicalSize_mE2459900B0F585298C659A103393011B42F721E9,
	CanvasScaler_SetScaleFactor_m2FA24C807078ECFCCA188F8C92B3B5E11409151B,
	CanvasScaler_SetReferencePixelsPerUnit_m2C7B8AB6515B8B3CFB22B7511907F0063163212A,
	ContentSizeFitter_get_horizontalFit_mB775F652AC10946108F7D44BB52C57413086F524,
	ContentSizeFitter_set_horizontalFit_m38BB1F91ECB19CA55395886DE04404293568DE53,
	ContentSizeFitter_get_verticalFit_m937F784A1D950E72A561B7DF96206ADA5F1FC490,
	ContentSizeFitter_set_verticalFit_mFE092A2EA456864549B62369A11A711230C181EF,
	ContentSizeFitter_get_rectTransform_mE7FD5F977E954B6D54B9C1CCD112A4A70840CF56,
	ContentSizeFitter__ctor_mBEE0AF95BB3FAFA553708EBC870D4FE2E3443B65,
	ContentSizeFitter_OnEnable_m13D8C85D4331DD5890A140523A57221153FE2657,
	ContentSizeFitter_OnDisable_m1E5A38232518EDD43A9B2265B2EB496F91C9DEB8,
	ContentSizeFitter_OnRectTransformDimensionsChange_m42E361EACC44809C1FFC876582163D1E2D5FE0AC,
	ContentSizeFitter_HandleSelfFittingAlongAxis_m6CB47EDA5C86EB609586AC0EA09289063A5E8E21,
	ContentSizeFitter_SetLayoutHorizontal_m7A86741FD35792D94D3ECD29F258EDB2C1C0E821,
	ContentSizeFitter_SetLayoutVertical_m32994803FA0364E902848414EE2A906C4A540C7E,
	ContentSizeFitter_SetDirty_m018F67222A9B6CB351DB14625794E9508A153670,
	GridLayoutGroup_get_startCorner_m8D842137857E7AD45EE6AC346E0413A8F392729F,
	GridLayoutGroup_set_startCorner_mFCF40F8B8DB31E37C69FD9AFFDE72A86EF2BCCDD,
	GridLayoutGroup_get_startAxis_mAA66BAC768514A784F891AF3771952CFDE713E7D,
	GridLayoutGroup_set_startAxis_m0274E444A5EA78193D8F6A1863D6FA4A04B59E76,
	GridLayoutGroup_get_cellSize_mC5817788B1279F0ED4FA8E97D64B705FB782FCAA,
	GridLayoutGroup_set_cellSize_m55D9E33312D320F223797A150AC3FC5A377B1EDC,
	GridLayoutGroup_get_spacing_m4E066AD77C47D776D142944838AA592DCDBFB1F1,
	GridLayoutGroup_set_spacing_mB478EF4E026982009F548F99DD715981EDDDEC63,
	GridLayoutGroup_get_constraint_mD3C4128F573301158661CC38EB13105D2A3CD0F8,
	GridLayoutGroup_set_constraint_mA9572E37898BA95574F79A1233FC2542F013B804,
	GridLayoutGroup_get_constraintCount_m21913887C313155C2623C66EF614076D89154E55,
	GridLayoutGroup_set_constraintCount_m543F39FB71E239F6C22E793645B662E04D2B383D,
	GridLayoutGroup__ctor_m821D85B183D0948FD6754FDE7A307D139AFCF354,
	GridLayoutGroup_CalculateLayoutInputHorizontal_mCC205DFC6F928A51D0E1DF2BDBF0C9F335633DE8,
	GridLayoutGroup_CalculateLayoutInputVertical_mB9245498EF2C8DD7E2B85B295F2E50B86AA1DFCA,
	GridLayoutGroup_SetLayoutHorizontal_mED9E07022D040F404F806BF059AAA114E6D54BC2,
	GridLayoutGroup_SetLayoutVertical_m27268A990F1DE734666CD987B0CD87782A4D080F,
	GridLayoutGroup_SetCellsAlongAxis_m43BBA8EA7D65D65119E8D49C304F2DBE3B5AA574,
	HorizontalLayoutGroup__ctor_m5303C6DCDF90E5B49EFAC8C1C1690ACF199A0433,
	HorizontalLayoutGroup_CalculateLayoutInputHorizontal_m696524F96532846E5976722B848EE600E99ECB24,
	HorizontalLayoutGroup_CalculateLayoutInputVertical_mFCC3059D6992DFACE01B00B5111862EDEEDF39ED,
	HorizontalLayoutGroup_SetLayoutHorizontal_m3750F103E00A49D3617AEBE708B248F0E3120A66,
	HorizontalLayoutGroup_SetLayoutVertical_m566231E37D3A0FB2430817654FF8C9A548D71593,
	HorizontalOrVerticalLayoutGroup_get_spacing_mCE7919753288D05C02592FD55069875A08DDF19A,
	HorizontalOrVerticalLayoutGroup_set_spacing_mA147719DAEC6BD5E9F3AA4E3B08C0AB5DA222596,
	HorizontalOrVerticalLayoutGroup_get_childForceExpandWidth_mA1C3F9419088A02B32A59137EA87936FAF327279,
	HorizontalOrVerticalLayoutGroup_set_childForceExpandWidth_m11D946155AAE60441705178AE0592ACB29B1A9FC,
	HorizontalOrVerticalLayoutGroup_get_childForceExpandHeight_m63750DDE1224118C83C84A5BA565604DD987147B,
	HorizontalOrVerticalLayoutGroup_set_childForceExpandHeight_m73E01EADA63CFB3A693BC3AB2E54330A97E43F35,
	HorizontalOrVerticalLayoutGroup_get_childControlWidth_mF6647BC3ADB7632354D117FE8B1D78C634090A2F,
	HorizontalOrVerticalLayoutGroup_set_childControlWidth_m366D5679DF396FB4F74485D2392B3868B5897EED,
	HorizontalOrVerticalLayoutGroup_get_childControlHeight_m47B013D1CC0A957A8E090F9CEF448B3448EB0A3C,
	HorizontalOrVerticalLayoutGroup_set_childControlHeight_mA5DA8F5FFDC9757177A75052C8275ED220090E30,
	HorizontalOrVerticalLayoutGroup_get_childScaleWidth_mD6EC6A7D07F464FDA669A69712195E364161F8D1,
	HorizontalOrVerticalLayoutGroup_set_childScaleWidth_mB71709DD594BD6972720F31FC7EB2A2F5E2F2A85,
	HorizontalOrVerticalLayoutGroup_get_childScaleHeight_m0683A5239FE33AE4639ED0175541C168CC2152A5,
	HorizontalOrVerticalLayoutGroup_set_childScaleHeight_m57453CB7D1D422B3E41E4E5714ECA2B174D23808,
	HorizontalOrVerticalLayoutGroup_CalcAlongAxis_mAE030B65D045B1901FDD7330152569A29F1D2AC8,
	HorizontalOrVerticalLayoutGroup_SetChildrenAlongAxis_m2F3057C3C3BD96B7B5C69298EA9709BD456FE640,
	HorizontalOrVerticalLayoutGroup_GetChildSizes_mEB4BECA34FE89481D75F422445090FBB0D9BB3C1,
	HorizontalOrVerticalLayoutGroup__ctor_m2051FBB8D92638A863519B168AB243A5C91A5FE3,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	LayoutElement_get_ignoreLayout_m76A33CF6EDC8B31FB599FC1B29D3A181B54A1316,
	LayoutElement_set_ignoreLayout_mB1FB05BBE439A1D837419CE6052C54D9997E9A91,
	LayoutElement_CalculateLayoutInputHorizontal_mBB97174653148BCE26DB38BDE270149F5D6B66B1,
	LayoutElement_CalculateLayoutInputVertical_mB16DE5998CCF9F0A86248792EF11ADA58CDD1D01,
	LayoutElement_get_minWidth_mC37C09DA0557739757F314A9DB76BD9CDADB1CEA,
	LayoutElement_set_minWidth_m13DFE770E642FE52C5BC1D6528FCB66CDB497C46,
	LayoutElement_get_minHeight_m4593A898277D5663C0664664F9DF2D52A00FE320,
	LayoutElement_set_minHeight_m482EB19B529540E06F43BA319BC01F7DE7015A46,
	LayoutElement_get_preferredWidth_m3681B308EC2A341CDBBC6C48DF5729BB29BA2B82,
	LayoutElement_set_preferredWidth_m717CCB1C45A1586871E47E66FB0DD6A9E56EFC25,
	LayoutElement_get_preferredHeight_m4520ED06B8806DD4759E07989DC8C7E7EB52BA4E,
	LayoutElement_set_preferredHeight_mF09A4D8DF6AC50C997136C961793F5EE55182933,
	LayoutElement_get_flexibleWidth_m6B083FC777D575170153035E7CB0D8D24EB2993F,
	LayoutElement_set_flexibleWidth_mE083E617E101B01130B578749186123C8B730778,
	LayoutElement_get_flexibleHeight_mB27ABAC0E8C2D3AFEF4B2626F9024BDF8634B213,
	LayoutElement_set_flexibleHeight_m374C189D99D8DD2CE2CBB98CAC0072ADA5A60A7F,
	LayoutElement_get_layoutPriority_mB107040D948E21E4B4B955BDD9D92CA22BC56A26,
	LayoutElement_set_layoutPriority_m4EF6C474731A4273DFCFCA67C49418CD797411BD,
	LayoutElement__ctor_mD5313205D44DAD8CACE3E8E52DC9A41FAB4E2383,
	LayoutElement_OnEnable_m839B2DCFCFE90FCA8B222C0572D3011DC39629B2,
	LayoutElement_OnTransformParentChanged_m95A3CE5064623EEE62669FD7DF5D5AC904F948F8,
	LayoutElement_OnDisable_m1346841458ED38340601C8B27FCAC21CDD0B11A9,
	LayoutElement_OnDidApplyAnimationProperties_m5E355B394104A04D09F00DCE99F3DE07A69CCA2E,
	LayoutElement_OnBeforeTransformParentChanged_mA809983BB6D9F1A1F0B33A59EF8211BD3184C7A9,
	LayoutElement_SetDirty_m14EE2C04CACB76A50F23CCA7A92726C2B25163FE,
	LayoutGroup_get_padding_m7C98F5699A1F144A3CD754094159DD61EDEA6D18,
	LayoutGroup_set_padding_m946C7A5D562DAB48575119599768D5AC58A5CC39,
	LayoutGroup_get_childAlignment_mC2E6A497C4BCAEF50E46CB271EA4FB48EF345826,
	LayoutGroup_set_childAlignment_mABF0882AFCFE117F4C3DDBA21EA9AF324EAAFD87,
	LayoutGroup_get_rectTransform_mBA2164F608E800F4C819611E721EA825995BA9B8,
	LayoutGroup_get_rectChildren_mE1363B47FF118F2E5DD3ADA17FC5A47ADAD1D3E7,
	LayoutGroup_CalculateLayoutInputHorizontal_m70721CBFED66DA145C6B04D966AA5C3E367238F0,
	NULL,
	LayoutGroup_get_minWidth_mDB9DA90E62CB48DA4ACFFA412FA31A0ED19ECED1,
	LayoutGroup_get_preferredWidth_m4A3AFC14DC765C8706EE5C0F9B7CDDD1B9C70293,
	LayoutGroup_get_flexibleWidth_m8F081F140F0161484ADB59E48E482CF40DCA8F52,
	LayoutGroup_get_minHeight_m80D0D817E7F73A66A4F235D579C87B2134AAB10B,
	LayoutGroup_get_preferredHeight_mF2F6C67C5DB339A75D1400842443215A83E3E4C7,
	LayoutGroup_get_flexibleHeight_m59E16B746E1A0B6BB6DACFC8D6152BF579FCCD5D,
	LayoutGroup_get_layoutPriority_mAD4B8787F1A48D790AE512ED665F38341E15EA13,
	NULL,
	NULL,
	LayoutGroup__ctor_m2C5C490F181E3F50BA80CC50925CA350B9FD3606,
	LayoutGroup_OnEnable_m7E8EB5898A5FDFAD1961A3E187BDEC7AEB19C8D0,
	LayoutGroup_OnDisable_mCBBAA98E2608635DE371E69143109F6F3EF7B1E2,
	LayoutGroup_OnDidApplyAnimationProperties_m9E692318A31C3C10F7624B5074D4B370E610545F,
	LayoutGroup_GetTotalMinSize_m02F81DE9ED57CCBD6610D08AA52CB4483A14D6C4,
	LayoutGroup_GetTotalPreferredSize_m26A75A466512570E3416211F5820D19E5C334041,
	LayoutGroup_GetTotalFlexibleSize_m2DD1DC991BB246FC1BECB613E4581C26EEC3A5C2,
	LayoutGroup_GetStartOffset_mA584346FF8D8CDA081C5218D9A8B8CE5C32D49F3,
	LayoutGroup_GetAlignmentOnAxis_m5A480C265D82670D4E55F497D62193DEEE83185D,
	LayoutGroup_SetLayoutInputForAxis_m1CFF9123134CD5524FD85132A1F3BC2906CC0B3D,
	LayoutGroup_SetChildAlongAxis_mB027128152BE0E28E93FEEE4832742DF12053D29,
	LayoutGroup_SetChildAlongAxisWithScale_mAC805B74A9ED9D6E60B4D2B1F5C8F90B58018977,
	LayoutGroup_SetChildAlongAxis_mEB8A7D3F5151D0CABAD9ADDBEDA28E6BC950D95E,
	LayoutGroup_SetChildAlongAxisWithScale_mCE45E4D84779E88D4B6D733B37E2F9D08BAB183E,
	LayoutGroup_get_isRootLayoutGroup_m11B6FC2BA36E3D1E3156BFB6FC0A49964AEC0624,
	LayoutGroup_OnRectTransformDimensionsChange_m571418DF9E3FE2876D8ED083017B51899DA69027,
	LayoutGroup_OnTransformChildrenChanged_m808102C3FCB5D1536191BD1B25228CCF2A736694,
	NULL,
	LayoutGroup_SetDirty_m645D3182781863DCF43C794556AFE0A7B5342D2A,
	LayoutGroup_DelayedSetDirty_m3FC471D3FEAE926C5BF4FB9FE86048BEE4ADE7D3,
	LayoutRebuilder_Initialize_mED8FA1C15C499B1CF164C8410C7EC7AA1193E639,
	LayoutRebuilder_Clear_mD62901890B7A04550D68F469D30A69A10A3ECA8E,
	LayoutRebuilder__cctor_m59F750AAC5A8255D5E91C85D730BD21DC47A2439,
	LayoutRebuilder_ReapplyDrivenProperties_m1F244863563056F136E31CE9CD1F9007787D7BB1,
	LayoutRebuilder_get_transform_mE890ECF65A84FF10C7EE33BBC73D01503908D090,
	LayoutRebuilder_IsDestroyed_m7F48C198D7E6EAFB29195BFEAFB00500D9BB2392,
	LayoutRebuilder_StripDisabledBehavioursFromList_mC658A39EF2EAA28CACE766C50A4FE65DDEE8C290,
	LayoutRebuilder_ForceRebuildLayoutImmediate_m376EFAB3B8D5C86A085DCFEECA0538B8BA03B732,
	LayoutRebuilder_Rebuild_mC1C4D6DD8BDF52780C68301A56F5E8448ADEC9EB,
	LayoutRebuilder_PerformLayoutControl_m70054B6DA220D54A47D2FF6F7C96B36C1D315D7F,
	LayoutRebuilder_PerformLayoutCalculation_m224DE892AF29C076175A728D28B996A45E178A6A,
	LayoutRebuilder_MarkLayoutForRebuild_m09DF1D1C1BFD83B8D9181E982D745F26D891343A,
	LayoutRebuilder_ValidController_m64AEE496D31C069A7CB33947B450AC8241F49823,
	LayoutRebuilder_MarkLayoutRootForRebuild_m78BC85D18FDF71D66D6D05BA5D2D6C6D06F202D3,
	LayoutRebuilder_LayoutComplete_mEB05ECB1C59C036E473A9F2ACDF677573503174B,
	LayoutRebuilder_GraphicUpdateComplete_mCB905F4C297FF55213084D38A15EBCBBB0ADDF25,
	LayoutRebuilder_GetHashCode_mA5573A92ACEB8458B044C8672510A81B0610B886,
	LayoutRebuilder_Equals_m09E017404762129F3FBC3AF56CFA3DD3C0BDA123,
	LayoutRebuilder_ToString_mB41A4B211755A589013385975FE15C99B5253F13,
	LayoutRebuilder__ctor_m4067180E573DA57B9FB140E2E69B8D3A683F351E,
	LayoutUtility_GetMinSize_m8A7CF1EB3F3D1CDC9FFA33F34761322F42701CB3,
	LayoutUtility_GetPreferredSize_mC035133B1A561870CB8FE14212D8E71BFF1742F6,
	LayoutUtility_GetFlexibleSize_m8BFABBB6A7B83002524740DB6AD822E9569F6D3D,
	LayoutUtility_GetMinWidth_m0A249DB81847B782C7C353BF71B5B7640E9E9170,
	LayoutUtility_GetPreferredWidth_m8195172DCEFB387447F1C79FAA4BE820E6FA7DAF,
	LayoutUtility_GetFlexibleWidth_m76471A259115F8DB090C6CC1D2635D86B11E6667,
	LayoutUtility_GetMinHeight_m84472A7D150C6C97225CD75391ABF26191B46B89,
	LayoutUtility_GetPreferredHeight_m9CCEAD3F208DDB5449BE5F6A9586AFC53182FEF3,
	LayoutUtility_GetFlexibleHeight_m9233B5C740407532073977D64E59B1BB879515BC,
	LayoutUtility_GetLayoutProperty_m9CFFE5E3F3D739D5C675B2B33522ABC0275005A8,
	LayoutUtility_GetLayoutProperty_m1A6AF4D756528EB97FC81880079431766DC28F38,
	VerticalLayoutGroup__ctor_m8305F2E2D8759A1F113865FAF45A9534B7102A1E,
	VerticalLayoutGroup_CalculateLayoutInputHorizontal_mC9BF7EF4A3236F05DCBB1B2F2A23C6EC2ED0C672,
	VerticalLayoutGroup_CalculateLayoutInputVertical_m0F339BFE5894A745EC7A47D238BC1CEA0264A807,
	VerticalLayoutGroup_SetLayoutHorizontal_m943B5CB7CC5ED5053E69CA7297E2DB5F23E0BE7D,
	VerticalLayoutGroup_SetLayoutVertical_m5731A6B9245778C72AFC45863D04DC7CA0735EF7,
	Mask_get_rectTransform_m9D5D4775C23D46D7ED977FE1E00424A2E592B0FC,
	Mask_get_showMaskGraphic_m8D7850F726E5E2786B594B426E581B396DC4E707,
	Mask_set_showMaskGraphic_m26E107B60ECE971C8EC07A92755F3DB5308CF568,
	Mask_get_graphic_m5B49E746A9E93A4D1BAAFD83F9ACB7C90633B5B3,
	Mask__ctor_mDB0377FD085C92709863EBD1ADD669613A72492B,
	Mask_MaskEnabled_m7AFB8DA19DCF7C660BB22AE523EE5EF986F1A699,
	Mask_OnSiblingGraphicEnabledDisabled_m919DBB6316B2A3DF8825C82E66B1AC01F28F97B4,
	Mask_OnEnable_m63EE8B765F07480CF68C4E92A09A87EBAC751B89,
	Mask_OnDisable_m78F7F27003EE6C0B47A1FA35C64AE15321D1A4D7,
	Mask_IsRaycastLocationValid_mA814C1B406D968DB92C90B9698C521FE7716663D,
	Mask_GetModifiedMaterial_m708D77F5312C3DA4B3E2D5D71046393BE533DDEF,
	MaskUtilities_Notify2DMaskStateChanged_m103B0AF2E08CF02F93FE1F273BF757F72CA17FFC,
	MaskUtilities_NotifyStencilStateChanged_mC41DE843E662F1DF71008DCC7F241DAF46955DE5,
	MaskUtilities_FindRootSortOverrideCanvas_m7E303D29D22F86212DD023C8854211C525629FDD,
	MaskUtilities_GetStencilDepth_m44DDA4B7EA65CE2648B4585602B9761C369FA8F1,
	MaskUtilities_IsDescendantOrSelf_m63215BDD8B4DBE2A94AF5C65C6500A3157211195,
	MaskUtilities_GetRectMaskForClippable_mA22FA75F79D98E00CF0B0A41DFBD0FC2D4DC2F28,
	MaskUtilities_GetRectMasksForClip_mD205C0800E173F71E21F1DEDE40D8FE643E1536F,
	MaskUtilities__ctor_m35905E18A945C6E943BE796B62D79382982F902A,
	MaskableGraphic_get_onCullStateChanged_m9CF82537F28EEEC73E48B437DF49EA0B2312BDE8,
	MaskableGraphic_set_onCullStateChanged_m20FDC3099975522E7B72995B688D21AF99A77504,
	MaskableGraphic_get_maskable_mFC2D6219D6A2BBB98989FA5EC7DA6E970142F422,
	MaskableGraphic_set_maskable_mF9E02A4A578C16D988B076E290A162443A4BDEB8,
	MaskableGraphic_get_isMaskingGraphic_mAB10CA54042B113C62DB1982BFEB289F73A19868,
	MaskableGraphic_set_isMaskingGraphic_m9AC52E85DAD1BA0064883224CB408DF0B45E3BA4,
	MaskableGraphic_GetModifiedMaterial_m8FCD645EF28C3D0E9C40DE6CA88C4A6FA9D1DC31,
	MaskableGraphic_Cull_mF00BD574B73F921345341DFDCCD90C76914325F9,
	MaskableGraphic_UpdateCull_m2DCD0726782AE0782A49EE46F409C270F769865B,
	MaskableGraphic_SetClipRect_mE9B8DBF437AE3A64C7083F93E846255D51D914B4,
	MaskableGraphic_SetClipSoftness_m1B840B94309647C54C47E635BD6A4596995D0E47,
	MaskableGraphic_OnEnable_m1C4621EF4156EA27E72335253F9270C7FCD7E42B,
	MaskableGraphic_OnDisable_m4DD5B717F92C2ECD7F0B9589A2E9EE020D977E9A,
	MaskableGraphic_OnTransformParentChanged_mCD5C5C91E934480A384615A511DDD7D439FDB1CB,
	MaskableGraphic_ParentMaskStateChanged_m694F5C7651E14953B42F4B6B0AC5C08B01FCDF03,
	MaskableGraphic_OnCanvasHierarchyChanged_m4CFDF1C4903CAE89DAB4ED5A789182FABCE2E14E,
	MaskableGraphic_get_rootCanvasRect_m2751607479FE02BDA964AF973CDD19B62B208DA4,
	MaskableGraphic_UpdateClipParent_m5073282E1101E9ACBFF214505B37C945BC013FFC,
	MaskableGraphic_RecalculateClipping_m51967B70B3A54B811F3E2FAEC8CB68A1E36E97AD,
	MaskableGraphic_RecalculateMasking_m798019D3372397B5F0E09E0DCE64DC415CABE672,
	MaskableGraphic__ctor_mFB0B016448AB894C802C279ED045DB1E4DE5D8FC,
	MaskableGraphic_UnityEngine_UI_IClippable_get_gameObject_m68A7FD1C35B1E5A0A1FFF135F89A62F4F1521DB8,
	NULL,
	Misc_Destroy_m1CD11D22DBCAE5B55367EAD70A946B1AD3043EFF,
	Misc_DestroyImmediate_mC8B94565596867AE4C03E38C6C1DD0CF82C429A5,
	MultipleDisplayUtilities_GetRelativeMousePositionForDrag_mDA78E1728A60D2B05F5225EB8B77BF03B81A0D5A,
	MultipleDisplayUtilities_GetMousePositionRelativeToMainDisplayResolution_m2D3CB08174B28122E201011E77C0A1BE762C948C,
	Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E,
	Navigation_set_mode_m35D711F016E4F41230C710882696279BA04399D2,
	Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E,
	Navigation_set_selectOnUp_mB61F72B8B577FB9424150F42EC57767A8F3B4453,
	Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398,
	Navigation_set_selectOnDown_m0EEC959195918EDDBF71B0D640D42BB85061D0A5,
	Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA,
	Navigation_set_selectOnLeft_m51D5BC3AE8C05E4233269B961ADA98BB3FBF9D53,
	Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328,
	Navigation_set_selectOnRight_m3429A471ECA0295B871C161960FB3F8C1D1D3571,
	Navigation_get_defaultNavigation_m00087A1157696556EB1D34E20D7324DE4788F6C6,
	Navigation_Equals_mBAEC72440C03A77E0981AD0FEFDFF823984B7CE0,
	RawImage__ctor_mF23F5B56BE2C19DDD001D183C7DD1FBA2C7AF6D4,
	RawImage_get_mainTexture_mAC899EE3026C3BD076E21B43D840D05162F56E29,
	RawImage_get_texture_m992AF81884D22B9ADC97A800AB931DCB4140954E,
	RawImage_set_texture_m63BC52D3B64A3BFD0EC182034FDD51E9A46F99F9,
	RawImage_get_uvRect_m3BE55AF17D17143B9F084B1FA4689C5A52A0F530,
	RawImage_set_uvRect_m843AD44101EA0FB2C7E684095BDAFDCA579935AE,
	RawImage_SetNativeSize_m531E57A3BEF08985C084AB73117CFB0F9B2417AC,
	RawImage_OnPopulateMesh_m816B08ED2C7E33CA0A7CF767C66E4223F0DAEBE1,
	RawImage_OnDidApplyAnimationProperties_m003499201735E7AF73A5F31113DD6323778A4BCE,
	RectMask2D_get_padding_mAE70AF9C0ABD28AD225A2BFD4965C45883B31E20,
	RectMask2D_set_padding_m199BEF4609F76B4E68DC99B1D531E0E13A551F66,
	RectMask2D_get_softness_m67F6E132A98566FC2191856462BAB6F7080884C8,
	RectMask2D_set_softness_m2B1C4456CD59EEAD639EBE76EE4BC34BFDA1B8B4,
	RectMask2D_get_Canvas_m67059D0D1FF1530F8AA8B5D94F1A27D559C25C41,
	RectMask2D_get_canvasRect_m2CFEAC92FBAE3C1E500CAD0BDB3D6CDD263558BA,
	RectMask2D_get_rectTransform_m2EE1645888FCF5638B9B59EE4087B96FB53574AC,
	RectMask2D__ctor_m9BB0431D7C6969736E453CCC924EFA770DCF0F7F,
	RectMask2D_OnEnable_m4FF369F853F32C62E211DC69F27A599AC61E35AF,
	RectMask2D_OnDisable_m4EF6F587CD9090C18F353C7E914E3292B40401B0,
	RectMask2D_IsRaycastLocationValid_m139090CB5B0299545AAC8E223A9E86A91452E445,
	RectMask2D_get_rootCanvasRect_m17D93FBA715A10CB270CE52C794B1FB687DD5431,
	RectMask2D_PerformClipping_m69EEBDE9F0F74FB6C5CCE8DCDA316AC277429EE7,
	RectMask2D_UpdateClipSoftness_mCD3F4A7BB0E8F82614A971404C60B10B9771665C,
	RectMask2D_AddClippable_m6DCAA0D7BF3FEE0E6CBE627ABDB764EA8822B761,
	RectMask2D_RemoveClippable_m65177F56AAD85127135142626833817B5A427B76,
	RectMask2D_OnTransformParentChanged_m4ECFFB298A62E01AE2FB50ED9F5E7E6EF7531E00,
	RectMask2D_OnCanvasHierarchyChanged_mE447313B871CBE3B97E680BA7B6790B1C6489C72,
	ScrollRect_get_content_m7F3FC07991CE67DFBEE4068D6E14ED0A1E26B526,
	ScrollRect_set_content_m1D59059E32D0563BDF511A547978965B2C4F81F7,
	ScrollRect_get_horizontal_mCD2647148C80355520AEE9A171E2DDFFD007D6C4,
	ScrollRect_set_horizontal_m62275F56268C9EF22F5E71F68BC8026779A60B7E,
	ScrollRect_get_vertical_mEF9A7604052858643BCDF9A76BE2086E0AAC085B,
	ScrollRect_set_vertical_m635C296C6E8CD7B41AF22296D51E34D3C1BEF850,
	ScrollRect_get_movementType_m96D7F76863CD4288A6E36481A9ED3028EA37CFFC,
	ScrollRect_set_movementType_m2953F8BC5ABFDD067D5DDC54AE15953DBD754942,
	ScrollRect_get_elasticity_m34D19B22AA11D0ECC4B348639594CEDF35018B85,
	ScrollRect_set_elasticity_mB1C87653D202F8BA28EC911B782791FBB8C494B8,
	ScrollRect_get_inertia_m20D064DAB868538A30848F8078A5437B6D62FF73,
	ScrollRect_set_inertia_m10EE4253B2F07D743197089F42B3AEE3C25BC9FF,
	ScrollRect_get_decelerationRate_m353068153F2D59EEB1AEBD2BC79DDEB680F5CF3D,
	ScrollRect_set_decelerationRate_m3A4F636EDD5C1196B065B16DAD9BCB8B6BF97F20,
	ScrollRect_get_scrollSensitivity_m8A671FB9A7C6E4F52DD3E572BCC01C04FA7FA806,
	ScrollRect_set_scrollSensitivity_mE55DE672446762A94155115BE9D2FD5702F86A46,
	ScrollRect_get_viewport_mD3C6CD4F782A5FC7F886BA1CC4DB6CF250DF164D,
	ScrollRect_set_viewport_mBBD71C770D85A0C3B131B919255CEE568EA48506,
	ScrollRect_get_horizontalScrollbar_m258E5BA6988FD113301575E1107A37D506515273,
	ScrollRect_set_horizontalScrollbar_mA67D54C0D2CE7E492F6E58190EE00BB1A46BFC3A,
	ScrollRect_get_verticalScrollbar_m0A9EBD87C90FBC567C11D37ECEBD2E6A7218BD0E,
	ScrollRect_set_verticalScrollbar_mF02C8BDC24D4FB53A5B25ACFC61B9134BC5ABB61,
	ScrollRect_get_horizontalScrollbarVisibility_mC43D0E4908D8876D399B15F36A8D98B827C77DDC,
	ScrollRect_set_horizontalScrollbarVisibility_m2D6DB4D340121E55942254C331B5EA343D0ED082,
	ScrollRect_get_verticalScrollbarVisibility_m8D671BA3821D2F3F263DAC0C7FE1487333326DA9,
	ScrollRect_set_verticalScrollbarVisibility_m20B34375553122E7EEA5BEEDBFD80E87E18177F6,
	ScrollRect_get_horizontalScrollbarSpacing_m4418B98A218392087300D54F085ECEB8FE54E9A3,
	ScrollRect_set_horizontalScrollbarSpacing_m22675D0F7497561D02FC4171023BD297688D445F,
	ScrollRect_get_verticalScrollbarSpacing_m611F47D7B342D1649DF95FF20BF6B1846CC6961C,
	ScrollRect_set_verticalScrollbarSpacing_m782C4FC20B2D4C50D151344F6E501BD03BBBD8B5,
	ScrollRect_get_onValueChanged_mB59CCC8D8CD14BEB23018EDEE69EDB1EEE32C08B,
	ScrollRect_set_onValueChanged_m56C696AD9D6D36B5A1A702B72D21B44365CB24CC,
	ScrollRect_get_viewRect_m4CAAF3A523BAB284A6DA9D5EC45057D7EE51D89A,
	ScrollRect_get_velocity_m44CA563C38ED997693167D354904EF8139C0C9D9,
	ScrollRect_set_velocity_mF149AD6C33EDC6F469B2A572A21751A6420EDB4E,
	ScrollRect_get_rectTransform_m8DB7B0810D6E5D34C973716FCAC50C5B259DA3FE,
	ScrollRect__ctor_mBBD973627D003DFD7A55474B678F70BFC02E4B99,
	ScrollRect_Rebuild_mD3D65CBBA3547A87A73EFF2D5516C9558C9D7694,
	ScrollRect_LayoutComplete_mB2EB41711791810DE2C5A219F54084DFD1C9C8A8,
	ScrollRect_GraphicUpdateComplete_m99BDEBF15E0912DBFA651B23347D298F6A2D95A7,
	ScrollRect_UpdateCachedData_m08E0AC380D5C5DD2BA5072C465E13690AFAD1AE6,
	ScrollRect_OnEnable_m6B32C0F1789C68F8BB0CE74544F064E4F4D0C4F4,
	ScrollRect_OnDisable_m73602C6393005CB74565608201F6E95AA184C9AE,
	ScrollRect_IsActive_mBA755BC1C46E74199B97A7101E6949D6DFAFA2EF,
	ScrollRect_EnsureLayoutHasRebuilt_mD2A10A4F2E6B8F7964203FD8EFFB316E0C1F0F05,
	ScrollRect_StopMovement_m1F488BEC0F7EA905CE7EAD421BCD1933E2CF2E55,
	ScrollRect_OnScroll_m2614593B93CCC14C6BF84EC3362D0F873CA5F70D,
	ScrollRect_OnInitializePotentialDrag_m0D6B75E40AB0952544DC5ED2A6E551DECBD783B1,
	ScrollRect_OnBeginDrag_m3F388158339494482D1B6C87F07AF7F340B9C2A3,
	ScrollRect_OnEndDrag_m14F35F7B13EBEFC3EDF8F4F339D6BD17015EA27C,
	ScrollRect_OnDrag_mDF40D32B4403B7D7CF2D59BAE04D8CE7824DFDA3,
	ScrollRect_SetContentAnchoredPosition_mBA6FAAA668D7F15508B2CEC7765CDEE525516A45,
	ScrollRect_LateUpdate_m5799552B786F3CFF3AD972E5CCCA834850CB9612,
	ScrollRect_UpdatePrevData_m2DCB69FE758212196471BE93B26BB5BBF8D1F227,
	ScrollRect_UpdateScrollbars_m9070717C80898346C4044011C497023BB14C1669,
	ScrollRect_get_normalizedPosition_m064ABEFDFBCD4B9E01A01A9802297827AA5C8B5E,
	ScrollRect_set_normalizedPosition_mB1DB78D03B3ACF444E9F05944A482DEB9BC52EFD,
	ScrollRect_get_horizontalNormalizedPosition_m9DAB8C7B610E7608DF2A4E37F6592EA805B2AFFB,
	ScrollRect_set_horizontalNormalizedPosition_m6E4EE949EFDB63389929D10A6EA484B7A67A510C,
	ScrollRect_get_verticalNormalizedPosition_m2610419B87DC4D38682C49457CDCF0D7993039A1,
	ScrollRect_set_verticalNormalizedPosition_m5224C3751F3C93C4F6BAD63AD439DB1D1C9FB405,
	ScrollRect_SetHorizontalNormalizedPosition_m5C1BA3A7C9E76C637A30778244EFD61A09686B56,
	ScrollRect_SetVerticalNormalizedPosition_m6F7EA0650DE73E6066794040A851A6616CF70816,
	ScrollRect_SetNormalizedPosition_mDE21FF15D57B81231447F4123C8385DDA66F5939,
	ScrollRect_RubberDelta_m1FF0368AD83A2E0398713D9B6C1E1959C600FC9A,
	ScrollRect_OnRectTransformDimensionsChange_mB4B86CCC66F0BB23FCA325D510D6619B9885FF92,
	ScrollRect_get_hScrollingNeeded_mA906B60373FBF3980BADE84D2554668ACF580E77,
	ScrollRect_get_vScrollingNeeded_mD9953600A5FBB510E37884A9B85E7E249487FA85,
	ScrollRect_CalculateLayoutInputHorizontal_mA15641491BB2B1A14470F27EA9A6D5A679B6F331,
	ScrollRect_CalculateLayoutInputVertical_m90C18A8168305E5E7266B6C9FBC0633F8455ECD4,
	ScrollRect_get_minWidth_mACC47A71B6DE98E83968950C10E4CBDA4BE8235E,
	ScrollRect_get_preferredWidth_mA942CC4D2620ADA96B52C85D85DDC44CEABA0245,
	ScrollRect_get_flexibleWidth_m3CCB92FBADE66795DE7C7E88AAB0FABB94002624,
	ScrollRect_get_minHeight_m06D03D93A566C4B1C40127A013793C63FFEBBB34,
	ScrollRect_get_preferredHeight_m137F08C4E69F195E882100587331DB539ABBB3BC,
	ScrollRect_get_flexibleHeight_mFA28B6541E9BA06727D530C77F2456309DFC8A94,
	ScrollRect_get_layoutPriority_m821763E3D87C3A8EAE8A19A0DD42FD6B3C1EB110,
	ScrollRect_SetLayoutHorizontal_m8BA1A9251684C54F3285C57E3E50A51C8AA6382C,
	ScrollRect_SetLayoutVertical_m734054404869720AEBEB189A7EE81A77BCB595E8,
	ScrollRect_UpdateScrollbarVisibility_m25A602E7A418DADCF59D0AE019EA22724B886E5C,
	ScrollRect_UpdateOneScrollbarVisibility_m5D467DDD4182171886FFB73962BBFEF965A6E361,
	ScrollRect_UpdateScrollbarLayout_mB93549D9A2CA6B6CEA6C6361E58D1804C9B19B96,
	ScrollRect_UpdateBounds_m4CAA83FD9B50E62152FB5EF32614FCFC2E9B5F4B,
	ScrollRect_AdjustBounds_mDEFEA53E51AF1299C7A5DBA5897E7CEB78CE1485,
	ScrollRect_GetBounds_m4E34C67E606612B3B541AC10CABD1A8DD60BFB51,
	ScrollRect_InternalGetBounds_m57F907604A74BB8C930F0E8E83643B58B4F70EF4,
	ScrollRect_CalculateOffset_m198A2DD190E762F54FFDF9ADB4F9D09C3C72C49D,
	ScrollRect_InternalCalculateOffset_mBD16E2DE166034B7CA7DDC2DBD22D7C2AF0E699C,
	ScrollRect_SetDirty_m5B4DB26D806EBDE5054538B78DCD848D244EE16A,
	ScrollRect_SetDirtyCaching_mEC7A66F35782EDAC92076CDF249DA9E77E2511F1,
	ScrollRect_UnityEngine_UI_ICanvasElement_get_transform_m5BCD58D5BF9AF3D8FB743417F783A815344B38B0,
	Scrollbar_get_handleRect_m104FE0AF1CA77701926B9247530BBDE16CD03421,
	Scrollbar_set_handleRect_mF48210CE73FD1F67BAC1CAD76FA07132FDBA5C40,
	Scrollbar_get_direction_m9DE22D72DE14200D3B7F70410865872034DB3C26,
	Scrollbar_set_direction_mF62CEE52EFDA9D19B07DB3E4B14F8A202DBEB38E,
	Scrollbar__ctor_mB9ED51581883273DDE3E80BB5843177CF391A973,
	Scrollbar_get_value_mB50146DF84D5A824370AEB1E41336B3034D3D7A0,
	Scrollbar_set_value_mC653E9457FC7D581904F1F854495BF82D1048C4F,
	Scrollbar_SetValueWithoutNotify_mBA3A6C8E4E46C9D2292EE1C63342641F24FDFB65,
	Scrollbar_get_size_m86928300A01FD31035162D85AB3FD2EF2609E53B,
	Scrollbar_set_size_mD67D27E3E45E4E68157685A71E4CAC070FFF2919,
	Scrollbar_get_numberOfSteps_m714B1DCD3B8F7BB16F0888BA96717A24022AEC79,
	Scrollbar_set_numberOfSteps_m7064A8877F8963A27E36BAB31AA0635B5FA6FF73,
	Scrollbar_get_onValueChanged_mC58EA55182B24E42CEBC360FBA3F0533B3CF0FF8,
	Scrollbar_set_onValueChanged_mF3ACFCE81E88851377F3DF12328FF6EAC75519D7,
	Scrollbar_get_stepSize_mDBAC88FA8AC842435BBED92163F0D4FB7F74620E,
	Scrollbar_Rebuild_m7E265DB3E505F59959D76F974128B950BDCD8D34,
	Scrollbar_LayoutComplete_mBC4100641697FCD54B4A09588E65C556D2AE6780,
	Scrollbar_GraphicUpdateComplete_m53FC1F514861C873B1D4FC4DEA2A23AFD96317F5,
	Scrollbar_OnEnable_m085DDBA4B1B49C44F25D4B46DF7E2A68D015DFA0,
	Scrollbar_OnDisable_m32660E3BFE2FAC5696A39CBD51FFD90126884D97,
	Scrollbar_Update_m7D470599F3F1877F3149649C638D99E6761D1F0B,
	Scrollbar_UpdateCachedReferences_m887202A953CD6A96434A026857CCD2E343220F4F,
	Scrollbar_Set_m5954E234014C71EE954348B9829868226C727669,
	Scrollbar_OnRectTransformDimensionsChange_m9223B26A4F446E33771DE873A1C97E6C47AFAD0F,
	Scrollbar_get_axis_m45122AD4E1A73A6555181B4A6A9C86DE2EE07EE3,
	Scrollbar_get_reverseValue_m71865B3B46FC42B226BA85FFDBFA97E01144519D,
	Scrollbar_UpdateVisuals_m4461DBA1BE6D20450162164D1A16D738551B289D,
	Scrollbar_UpdateDrag_m4054447E0018CAE8A27BB8FE06CB29DAFA233BD6,
	Scrollbar_DoUpdateDrag_m35075A4C4F34F88BF08B5556DD0BF6EF2C681950,
	Scrollbar_MayDrag_m6E73F2C637DC75313CB95CC09A7620E7E261CB53,
	Scrollbar_OnBeginDrag_m9A65BCF26559DBA675E4510309833A01200AF72E,
	Scrollbar_OnDrag_mE070D6E80D00BCB2537E1F27E31E48B68B4D5616,
	Scrollbar_OnPointerDown_m51D30F596D1BF64484960370BE045DD986B558F1,
	Scrollbar_ClickRepeat_mFF5D7554F28B24960944E2CB6B1E61597706B0FA,
	Scrollbar_ClickRepeat_mE4895549A915C1D6255EC52CAAA50D7D93FAC24B,
	Scrollbar_OnPointerUp_m6B451E29A019186FB0D0BD8135CD055D61583D75,
	Scrollbar_OnMove_m478ED366B5461D37FB215820D0C6BCD5EBC01B6D,
	Scrollbar_FindSelectableOnLeft_m374B5705442CC40C149835019C9EAB55C079F6BB,
	Scrollbar_FindSelectableOnRight_mC2CAC3EB7EA1FC16155EF3E90B6E088B5E09FD5B,
	Scrollbar_FindSelectableOnUp_m9ADBB11544C5D9D09414A397C4B22B19E60C252F,
	Scrollbar_FindSelectableOnDown_m3A2776AE65F7CDFE6F3AF88B607F06A39B35C7D2,
	Scrollbar_OnInitializePotentialDrag_m45B071544234C35AD0DD56A9CED8507EA07D21EB,
	Scrollbar_SetDirection_mA9024B104537EDF63AFF1C437A8F0D193CA562F8,
	Scrollbar_UnityEngine_UI_ICanvasElement_get_transform_m582D531E9319A901C4C02AB8BE873C0F286AAC11,
	Selectable_get_allSelectablesArray_m04E41DC3D73950382018953096CCCB4666D75D78,
	Selectable_get_allSelectableCount_mB446CA731CCC10DF19C4337BD7BF51BE9F6B0DEA,
	Selectable_get_allSelectables_m54D3FAA34B85B657086A45FC0D535A92D2AB8597,
	Selectable_AllSelectablesNoAlloc_mE78AA8943AAE64691E36C0663F137D115A81F825,
	Selectable_get_navigation_mE0FE811B11269EFDEE21C98701059F786580FB50,
	Selectable_set_navigation_m9680DCFEEBF25F70A64BF24B5890A429CB389029,
	Selectable_get_transition_mC5883DD4A0EC4A58F41285A8684B018309041D9E,
	Selectable_set_transition_mDED891CACA218179385815C92CD5CC931C588FB0,
	Selectable_get_colors_m9E63E13A7B6C40CB0F20414FFBE15873BE5F3E4E,
	Selectable_set_colors_m7A8172ACD89481DC904523D216A7C7D42BE50DF7,
	Selectable_get_spriteState_m0A341E18A903DAEF82259637F2D09B1CEC4DFD85,
	Selectable_set_spriteState_mE6E733B21046B975C3F73C594D7B726F19AD8B90,
	Selectable_get_animationTriggers_m6F8F01A53FACD447624E24686E89F05EBEBF64E3,
	Selectable_set_animationTriggers_m725D39C037387AEBE4F0DFD4426426D1B0629ED1,
	Selectable_get_targetGraphic_mB12CA26D04922ADB483397992561CA3941E78F92,
	Selectable_set_targetGraphic_m69C71056F05A767EC0D2ED14E80ABCA15B5E2FDE,
	Selectable_get_interactable_m4A788C1B797A434D9033539514D5E20610E2664F,
	Selectable_set_interactable_mF0897CD627B603DE1F3714FFD8B121AB694E0B6B,
	Selectable_get_isPointerInside_m18E62C81578321F6B3B232F2F1668FF46AC1B96A,
	Selectable_set_isPointerInside_mCCB1EE89C56C75E08A2D3F0F6125F0F0278EC281,
	Selectable_get_isPointerDown_m89F51DDA55A4613A0647C1EFC8BB892E02DADDC6,
	Selectable_set_isPointerDown_m5F89C05475A68DFF2AB2144462D361F9DF9BD812,
	Selectable_get_hasSelection_mDC9AB6128F5289F7CCA06C7AFE5C69B90EC8E051,
	Selectable_set_hasSelection_m104FB1A00B8F942EEE8FC5309760CE7AC2276FE7,
	Selectable__ctor_mDADF3659E1B861470987564058F1D0B89FF3660A,
	Selectable_get_image_m74FFCB0802A2E8380B33314F53A9748370D1C9F7,
	Selectable_set_image_m0E818601F5B5959AB91259DAB7385FAD9B0210BB,
	Selectable_get_animator_m6117A378EE32B632B32C7441887BABF3ABA1C9A8,
	Selectable_Awake_m9902C8912907C8E252F066B80E46C002DFCC94E5,
	Selectable_OnCanvasGroupChanged_m9D61A1DF7A7D0DE90B027D635DA023F2AE92D59E,
	Selectable_IsInteractable_mEA20244501979E1CF199CA93406348CD690FCC0C,
	Selectable_OnDidApplyAnimationProperties_mB8D3432A68D0AD88E707EDF0005FD493F8F2DCE4,
	Selectable_OnEnable_mA3FFC8965134ECD3B5A2E4028CACBEFAAB80315F,
	Selectable_OnTransformParentChanged_m4B01503ED75E5F209858B78E20BAE3F87D2EC131,
	Selectable_OnSetProperty_mFAB235B05A20A34BE15ABE7190E8EDC1B6E616EA,
	Selectable_OnDisable_m258B5CEC8D2EA2F2FF1225CB76970EF089BF6349,
	Selectable_get_currentSelectionState_m37B79D51884A49924B92D1AE1BAA354C55CA1FD0,
	Selectable_InstantClearState_mEAC746472F389A3CF194938147F01CBD1120B587,
	Selectable_DoStateTransition_m927C2A16FA000A1E2BD57B157F9C230FA235ED68,
	Selectable_FindSelectable_m7197D69C5F25246DD57F86B660218D9F64F4902A,
	Selectable_GetPointOnRectEdge_mD500D4CD3E1541B610D04181241091241A0F5A28,
	Selectable_Navigate_m96B635DBE276C394922162C4C7B927CEB5AA16CF,
	Selectable_FindSelectableOnLeft_m501FD2B988BBFFDAD318800A4D164FB21F1AE315,
	Selectable_FindSelectableOnRight_mA5550ED566545FF1E5113E935F4F57B63F3760FA,
	Selectable_FindSelectableOnUp_m26D12F3EBE3D07C4D69C639DE4D219B40886E8FA,
	Selectable_FindSelectableOnDown_m2EC533E6757FC29A2FABAB68A5E8D56394FE2637,
	Selectable_OnMove_m5046BFC32450CE2F2EAF1B717A8BC07093B82697,
	Selectable_StartColorTween_m12987AE49EB48CCB154EEC150976A4D7C0E4368D,
	Selectable_DoSpriteSwap_m0E056EA93743ADF5125CE102F87A73C5937E5852,
	Selectable_TriggerAnimation_m2CDED21669A18BD20770EFED1319A9573CFA31EF,
	Selectable_IsHighlighted_mA816817EA9CD76759031AC0310E6925DE4E5C8BA,
	Selectable_IsPressed_m9605FD46CED6FB525E7CE95C0D1341D9FB2946C8,
	Selectable_EvaluateAndTransitionToSelectionState_m70A67F91AFB94FAC63CF9C9551F2E81B852896EE,
	Selectable_OnPointerDown_m061689C2799399DCDAA05A08DCE26D087B46A840,
	Selectable_OnPointerUp_m2D9280DBBFB84904DD468B6A231BFA5F493E8300,
	Selectable_OnPointerEnter_mF67D44F4E9CA340034DAA3FE58674183DA2DF157,
	Selectable_OnPointerExit_m74266715C60B43A8DC6640C90E8FE55965294220,
	Selectable_OnSelect_mA9D63C2B429DC2ED93158B1109F99467542C24DE,
	Selectable_OnDeselect_mEE6A5BF7CF1D34D0E94E9F5B22AB8223081DC643,
	Selectable_Select_mF1D3E4BEF6C795B709FDC441930074ED9088A31D,
	Selectable__cctor_m06CFEB59AFEDFD37552B7D4D172711EDC24FD86E,
	SetPropertyUtility_SetColor_mB5174CC6EF9515E83B9FD7F2066ABEBA52B165B3,
	NULL,
	NULL,
	Slider_get_fillRect_mEDD45CFE2E622B61B82469DBA18B52FC3C3C279D,
	Slider_set_fillRect_m7055CC8682DDB328A754116BDAE0AF6DFFF437AF,
	Slider_get_handleRect_m2EFF3788BEBE513F7C5CCD3E494F37C153F2AAD8,
	Slider_set_handleRect_m25A60ED142D621A5243E48AEDE097986FA3B2E10,
	Slider_get_direction_mE9A02803187D68D400284913BC6F93F587610022,
	Slider_set_direction_m804216132A017C3D68832C8941B49B4038B5A72E,
	Slider_get_minValue_m1C1AF023D40CD9C4816CA83C1216BDC0177BB3C4,
	Slider_set_minValue_m9531D4EC6314F28CB1B2778862FC44E6109781B3,
	Slider_get_maxValue_m0066E03DC62047617783B6EB3589344CB57B3349,
	Slider_set_maxValue_m45561A3731F4EB48C10715E062856824B5AEF20B,
	Slider_get_wholeNumbers_m8D2011D5DC11FAF8E24B3547683B0EF6B9F3936F,
	Slider_set_wholeNumbers_m54BF44BC60EA3DB739F3DE35B1AE7B498ADC1036,
	Slider_get_value_mA3B6A0E422E6FAB3013AAC6807DD4244D98B563D,
	Slider_set_value_mCEA86111DBC0BCB1361B8E96EFCBAA7AF801F66C,
	Slider_SetValueWithoutNotify_m061B64AFCE6AC1F281A89784C8567C450B76217A,
	Slider_get_normalizedValue_mEE13F0582A3A980C74804DA1E57D083DA30F4C09,
	Slider_set_normalizedValue_mFF773CA2C18C7DC7003F731A738B6D845D19045D,
	Slider_get_onValueChanged_m9D9177CDBF349783372AABF032F2D2B3178A84D6,
	Slider_set_onValueChanged_mDAEDCF0C4BAAC1D0610BE850E4563F1677511EEE,
	Slider_get_stepSize_m46A0B4FAD8DAACE6523D2B50D51955443482E226,
	Slider__ctor_mAB7240B4FBB6B6428C5426AA0628AFCB99968411,
	Slider_Rebuild_m20AD0C4E7EE5F2C1E75718298E8414F896415A9B,
	Slider_LayoutComplete_m1D1C1486B1F457F35CDADD47D0C429CAD176AE9F,
	Slider_GraphicUpdateComplete_mE44527ACA522A1F9A87C4B4063ADA4CF5D25F9F4,
	Slider_OnEnable_mBC3CEE93CCFDC04B6C275B837A32BD45CD8A578C,
	Slider_OnDisable_m4D0E6DFD5E0EC3F78F779A35404968EDC7E374D2,
	Slider_Update_m40FCCCDE2D7C13639A653129171E0557ACAF494F,
	Slider_OnDidApplyAnimationProperties_mE0AF1A75688D285E36D47B4569967C27B72E339A,
	Slider_UpdateCachedReferences_m5683DC0B59751B8A436CE6C4F321F19CFC2F295D,
	Slider_ClampValue_m424D036945D298F14F6EA66C8AF19A669BCEB8D7,
	Slider_Set_mB34DDC06242DB0E6FFB5C8C0C4F332E9E5CE01B4,
	Slider_OnRectTransformDimensionsChange_m7CD43EAC6B8A9EC0D8CB51AC69579EEE981E9AEA,
	Slider_get_axis_m9F710E0C68A9BB669EEAEC975162175F7739EB0D,
	Slider_get_reverseValue_mB5AF7FF5484376E3CEB96C032D0A7D623CBFA441,
	Slider_UpdateVisuals_m4DB93A792742A44468481C914A4D14066B577A51,
	Slider_UpdateDrag_m7755A3B37FA9D65D845B21D182803408EECB97FE,
	Slider_MayDrag_m40FE0F769073CA0C4FBF91313C8FEF6C73E58CB0,
	Slider_OnPointerDown_m790F1E28A4C17345262D27FCCB4022188F832686,
	Slider_OnDrag_mD2D5B8F1AC180999FAB55174ACE782235D157AB1,
	Slider_OnMove_m44D7E1C1F1CA184BA5F10F1E18E8DD97B2EDAE0D,
	Slider_FindSelectableOnLeft_m1712ADA199F792D4C30D0094AA9A43D3441C7471,
	Slider_FindSelectableOnRight_m42B9D352422ABEB7719BD3F63821A6166261C646,
	Slider_FindSelectableOnUp_mC66B25E4FB7290FCF82048F6AA857F0C6ECC3FA7,
	Slider_FindSelectableOnDown_mD2F38D581CB5AFA849AFE901EA512579A2799E6D,
	Slider_OnInitializePotentialDrag_m0EF05021FE0CFA44BCA7BC359641F2F521AA383C,
	Slider_SetDirection_m2140588E77F45546866468171FD83E475C1731BF,
	Slider_UnityEngine_UI_ICanvasElement_get_transform_m47384BECFD0D74507A4118F086EFA66216799287,
	SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0,
	SpriteState_set_highlightedSprite_mC897DA30106251AC1865FD7FD26BD987AC3EFE83,
	SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB,
	SpriteState_set_pressedSprite_m29B2F72FB74B08A85E99BAB26A73C18C96CEEE6C,
	SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B,
	SpriteState_set_selectedSprite_m5A23CA415AF8956BC3507C8DD7FEE57C3EB34951,
	SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57,
	SpriteState_set_disabledSprite_m57C60F8DAF18851169F170BE37787FC3EEDF23D2,
	SpriteState_Equals_mD9E480FA2D996155ED689F6BA29917273DF036E2,
	StencilMaterial_Add_m5A9FE4FB6F7D51DA0DC3A8AFDBB24E48E38B3F67,
	StencilMaterial_Add_mD64708D42FA5E0A4B99042A43C0DAA9E0B4F8345,
	StencilMaterial_Add_mF73CF843BED16D1C9FCF82F1F3B5AA79DFC08B55,
	StencilMaterial_Remove_m21C1F511B591FD641E85F691893FC148DDC09093,
	StencilMaterial_ClearAll_m0B45EE641BF07278CBAB5401E441338674856874,
	StencilMaterial__cctor_m97D7B30D3189DDAF637E592A24CEE556E93C131A,
	Text__ctor_m46DA95EE5FCBDECA991B74008C4CEB29D7EC381D,
	Text_get_cachedTextGenerator_mC2FED5B2D9A7BF6D4372FDC993D0B7F0EA3C1DA8,
	Text_get_cachedTextGeneratorForLayout_m0F227772707238FF803F6A14F7B06B17D87A8BC5,
	Text_get_mainTexture_m2DB4BB9E001F9251B8B95887CC17CA78DAEB5C45,
	Text_FontTextureChanged_m4C40032BB34A17CCA489805DCB6C37980BB83E0E,
	Text_get_font_mC5492E71F03FA7CD2B9C42672B662FF2383A7919,
	Text_set_font_m26FF2D1FF6581C2F82F17A632FE34B7CCD497078,
	Text_get_text_m0E3C7440DD7BF5921F47D8E6A7EFFBB650F43497,
	Text_set_text_m452D7963AADBC94DF661C34AFCC1522E22E3C37C,
	Text_get_supportRichText_m8AB4EDE9827A90CA8988FE0B9CB84D0E87C961AF,
	Text_set_supportRichText_mE34FE6932EE7B93912E760AB30DC5F48DD8F98FB,
	Text_get_resizeTextForBestFit_mED7D33409B61524487134F08A49DE2612427EF63,
	Text_set_resizeTextForBestFit_m9D5758B61D60016E11E2C672993D506983E92A3C,
	Text_get_resizeTextMinSize_m737CB8B5C096414C48B5F54C8C4D19528BD334D6,
	Text_set_resizeTextMinSize_mD5D212EBAE999E7EB60083AEF1D64B636897B2F4,
	Text_get_resizeTextMaxSize_m6DCE61E88700B8DAC601E85304C29A1291DC03C6,
	Text_set_resizeTextMaxSize_m187DF8AC98B2079BD97B5FB0CA3EB6F97021C057,
	Text_get_alignment_m764224AECDEEF22CCC70D507944D753FBCF58D97,
	Text_set_alignment_m7C6F240D274640BFBCDAEDACB08684939900CB29,
	Text_get_alignByGeometry_mD43B4AC1B70CFF2816FEDD9AC3A54A43B6AA5595,
	Text_set_alignByGeometry_m34037C4F97257BA940A34A109795E9F9A13AECA9,
	Text_get_fontSize_mF35590920019224B052DA5BC93E8D8F13CEF767A,
	Text_set_fontSize_mA2E192AAB4668CE91F02762DDE558FC59C1EBE0C,
	Text_get_horizontalOverflow_mEBD747C7A0B0DEF7AEC55307A8EDA6DD1ECCC5B2,
	Text_set_horizontalOverflow_mD27CA8D9A4E883A0ECA5D3D94E11C28E2084C96F,
	Text_get_verticalOverflow_mA8582227054F2DB4071BDC70204103C98C1D7D79,
	Text_set_verticalOverflow_m033685FF5F3B8FBB7B2D4BEDB42FB4822A13B9A1,
	Text_get_lineSpacing_mAB4E9E2BEC7F2DD5BD426E72B3A34859914D6C4A,
	Text_set_lineSpacing_m2CB64D3EEB4A4AC1B50D9870BC0272EC2933E40F,
	Text_get_fontStyle_mA223DF2A20DDBB2755624498CFD8C99E22A981CA,
	Text_set_fontStyle_mF63C76D954DB1E7BC689FE3BE02E14FABECAADF1,
	Text_get_pixelsPerUnit_mFD570EA1798CC83C73320FDA714FC5049C6AF40D,
	Text_OnEnable_m3F57EFFF42BA830FC4AE96E5AEE71562793C9AA6,
	Text_OnDisable_m3C2B587F41523C9641AFCB45FC7EA1B76C897027,
	Text_UpdateGeometry_m015733C848B7644CA6C4FD167CB843ED362BDAB4,
	Text_AssignDefaultFont_m6667512908BFA6FCAF388E44993574590990212A,
	Text_GetGenerationSettings_m601D90FFD85B04F8DD7DA4D701080AAB77F2FAAD,
	Text_GetTextAnchorPivot_m46E0F5CDDA2E0366DBB463A2D46F3F334FC1D058,
	Text_OnPopulateMesh_mE2F50C5115FA0B46BDAE39EA77CD7FADFA58E5D3,
	Text_CalculateLayoutInputHorizontal_mD8A4D4E919FF27E2DB64C9A1A038C0AAC7D1DC25,
	Text_CalculateLayoutInputVertical_mD42D7A1B5B4529CD5AD80102A88C44C532107CD7,
	Text_get_minWidth_m23E3C5FD8C144437DE9E1663CE948E6F0083B6AA,
	Text_get_preferredWidth_m35CA8F0051CA8BBD14009ACEF86FB46C1D0CE524,
	Text_get_flexibleWidth_mA5F51D5CA16FF84C16967F0C122298623B93BF8F,
	Text_get_minHeight_mEE716E96B81DF651C5214979DEAD3F9177DD744B,
	Text_get_preferredHeight_m8E624602FE9ABCBB826F9AD8C0508439EAB3D852,
	Text_get_flexibleHeight_mFBA5F23377F02C40B26E5F48E3084BA0E5ACF04B,
	Text_get_layoutPriority_m3A1931C3D8472EB3CCDCD73EDB2EE87C27E1765B,
	Text__cctor_m24B54815C6098811B83EBABFAC08719B1266F11F,
	Toggle_get_group_m8A53B9EF413E699F639789C84035237AA9E6F614,
	Toggle_set_group_mCFE13F6C93FE5841351DA36A6C0D4E4C7A4B9467,
	Toggle__ctor_mFAEB14B18423E0515EC8DA11C92F3CC78EC51FB6,
	Toggle_Rebuild_mA0FFFC2EA5EFA1658DB2878E10829359E76D380E,
	Toggle_LayoutComplete_mEB02EAC95ADA7B004AC8C11AFE1F455CCF2C3D99,
	Toggle_GraphicUpdateComplete_mD2A9EDDDDCB17A3B8318048BFB0B1ED50D166F8B,
	Toggle_OnDestroy_mC713CA5908C52B2690ED67A0D811DA985CD01E45,
	Toggle_OnEnable_m650977B1A65F13B453BFEFACD0A056036ED31C50,
	Toggle_OnDisable_m527A9265B820301574BF6007F3E3DAAE2A1E38D6,
	Toggle_OnDidApplyAnimationProperties_mBA919980714BDAF57FE75D38593A9F12326D683F,
	Toggle_SetToggleGroup_mEEB6E7080982AC3BC3AB6EE2C5D7A65F5B9520CC,
	Toggle_get_isOn_mA34B03BED48C7189F0AB8498F986485B4CD6B44A,
	Toggle_set_isOn_mCAA660F49688DBA29E896B961E0054154C42EA2B,
	Toggle_SetIsOnWithoutNotify_m13F5DDCC4283536BDEEEA62954321DD89DE6E3B9,
	Toggle_Set_mA5D5E91124E529711683D367EBC3E086774A4A71,
	Toggle_PlayEffect_m2E1C2401C14A7F0176F9276E6A6AF61F70D8415C,
	Toggle_Start_mE2D13390AB45E4C86C36562578C73AE55D5098D6,
	Toggle_InternalToggle_m133D399909D2110A37AB166F5A317F46800C77D7,
	Toggle_OnPointerClick_m7BD5D04DEB667723AD5399A1D19B81669DA765BE,
	Toggle_OnSubmit_m9D1C9C60F248DD59DF6BB83A901B64BB37E34326,
	Toggle_UnityEngine_UI_ICanvasElement_get_transform_m0C71617F839B3BCEEA765EF98476562CF609835D,
	ToggleGroup_get_allowSwitchOff_mDBD76826D07767C85BD645688EDC2D9746AFEBF6,
	ToggleGroup_set_allowSwitchOff_mDF772934D4B93710533DAB1DCF22F73594AB9715,
	ToggleGroup__ctor_m67056DE0B68BC307E7F5FDC8F355376A1A95F834,
	ToggleGroup_Start_m4D27D8D0A1960B592F615ABFBF127CE2AF93DC05,
	ToggleGroup_ValidateToggleIsInGroup_m1550241F81F555678D89C16D069D536521558CFE,
	ToggleGroup_NotifyToggleOn_m8F3C60481CF0B2ACB0C1CDB3CEFC34758AE9E546,
	ToggleGroup_UnregisterToggle_mC42CA055A43CB304512A1DC5553528DD5ACC2615,
	ToggleGroup_RegisterToggle_mBD20EAFCD962FA19414504CE7B67A3B18108BE71,
	ToggleGroup_EnsureValidState_m78912EAC0B48EDC37DFE5E5E50A32631EEEB65A6,
	ToggleGroup_AnyTogglesOn_mA4DD200C568F21DEF7062CEBD93140FF74693360,
	ToggleGroup_ActiveToggles_m33CE32ED560C9721E5A370A11BF6D9071F3D28CC,
	ToggleGroup_SetAllTogglesOff_mD22DFABD24A486723AEB3823EBE0CEF573FE1A07,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ReflectionMethodsCache__ctor_m3FB6C9DCD567D5F7C37B0A4BA07E639B49D38D34,
	ReflectionMethodsCache_get_Singleton_m6C50C55DEEA425161B73545918267BB90B7FCB9B,
	ReflectionMethodsCache__cctor_m250D2D715E326ECFC950FF368C2B709F064F6338,
	VertexHelper__ctor_m43D3D0D2AFD14CBAF624E434A6D55295B76A3C29,
	VertexHelper__ctor_m798A4537737219B31DC65597A980514488DB1C76,
	VertexHelper_InitializeListIfRequired_mCB55977EEF771AA4E31A9678D5AA17B46F3E1C89,
	VertexHelper_Dispose_m41D8B361DB5C7323EFCE24F5555CE9D5D7F30F9F,
	VertexHelper_Clear_mB5B07793D0ED50C7993E3D2ECC9A18FFD6DC5425,
	VertexHelper_get_currentVertCount_m82BFAF1788809C0CFBF468CE70606D61730D83ED,
	VertexHelper_get_currentIndexCount_mD5FAED86A961FFD9C5EF41A0EA69EE123C72F920,
	VertexHelper_PopulateUIVertex_m86AC68C02173081B1C0B7C0F9AE6624031E65B7C,
	VertexHelper_SetUIVertex_m41470CE62983973DA57AF3D2C4165869816B6F6D,
	VertexHelper_FillMesh_m42F81894DE19863AC187F06DFB7922A71BC29247,
	VertexHelper_AddVert_m652DF4ABCDB6CE6AE29F81EF90674DDDCF31BB9B,
	VertexHelper_AddVert_mD859215DD00E2B617B47488EF5389C9D4EFCF5BB,
	VertexHelper_AddVert_m2A24026B8B4DAA44EB873B380B3EC60861A26CCF,
	VertexHelper_AddVert_m68BE4AFF505B1175210A6874DD9FC1D3611A200A,
	VertexHelper_AddTriangle_mD69A46AC22FC94799173320ED5F4144A883F44F4,
	VertexHelper_AddUIVertexQuad_mFD743F0DAF7F30C352D19C0F4B1619DA9463099A,
	VertexHelper_AddUIVertexStream_mC5E2CED3AEEA13EAB65E99F5EEF4528132C8D644,
	VertexHelper_AddUIVertexTriangleStream_m83D0E84141AAC0D349E9D754ACFA57D0E05BCA01,
	VertexHelper_GetUIVertexStream_mE3869FC59400C59FA179ED769002E1098B6585F7,
	VertexHelper__cctor_m739422D4F325E4EF35B301477B98A90A8E8FCB61,
	NULL,
	BaseVertexEffect__ctor_mA9DBADF41E794B1F6254174E99F4EAC83EDD8E54,
	BaseMeshEffect_get_graphic_mDD7D8CD6F220B9DE656145A1346EA9799255BE21,
	BaseMeshEffect_OnEnable_m34959EE194208A72A3D64460D0232CAD04398CAA,
	BaseMeshEffect_OnDisable_mE6A5C8C62463E34A982933C7A77B2E2ECB91C8F1,
	BaseMeshEffect_OnDidApplyAnimationProperties_mBAC052B0C5723BBFD501BA63F93C74BE3667B144,
	BaseMeshEffect_ModifyMesh_m1E691826E2BD65C3D2B76E991842BC5671A3B295,
	NULL,
	BaseMeshEffect__ctor_m12D1C94ABAD84C1F86D70908CAAAD9754372C09F,
	NULL,
	NULL,
	NULL,
	Outline__ctor_m8D766B20697B73B37C4FD3D1706C6013BB6E6DA6,
	Outline_ModifyMesh_mD6753C5F2B9F57A504255A5EC5050FDC8B6A0053,
	PositionAsUV1__ctor_m10DEF955BF4DF33573F54FD0120682EB557BBFD8,
	PositionAsUV1_ModifyMesh_m76222DEA6713B3A2FFA9CC6D2EF1EC85869684FA,
	Shadow__ctor_mC030EE1625435DDA0030F43F992685B4AFD2FF3E,
	Shadow_get_effectColor_mC7BF6CDDEC9998A03E993ED9216092782C66EC16,
	Shadow_set_effectColor_m1197327C64A5D9F15AA10F93876EA267D3975D0F,
	Shadow_get_effectDistance_m4B496C7CE07930847630E0E636E3C255D78B08BB,
	Shadow_set_effectDistance_m644CE2DCAFF42F908630094DA68A3D8EBB8C09B5,
	Shadow_get_useGraphicAlpha_m459DB69C3A786929E371818BBA990DC2C0B7A38E,
	Shadow_set_useGraphicAlpha_mE71F14530C25BC6C1363D12AF6D4862762B06216,
	Shadow_ApplyShadowZeroAlloc_m523BB704A795039F8B796603F1B06542C6AA52EC,
	Shadow_ApplyShadow_mC556C084C1DC87748C6C3385383416F5D36CB1F5,
	Shadow_ModifyMesh_mE9DC1E36A8F6A0838273B5A837235904D99E6C0B,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6,
	ColorTween_set_startColor_mA57B5D1E4C2FA32133D13E91D9B07253CCF3BFD8,
	ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF,
	ColorTween_set_targetColor_mB57B42752260A735D6F174F925822756088DAD26,
	ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB,
	ColorTween_set_tweenMode_m2C089877F55E0D82F68BFC3EEC33737F7D3D9E54,
	ColorTween_get_duration_m7E952A00A8A606D7886422812EFB24A6D5BFB508,
	ColorTween_set_duration_mA6144F511A40F04787D3BEEAB4A0C0EBD66ADB5C,
	ColorTween_get_ignoreTimeScale_mF935C53CA27D67D47AE0021A0DB8D92C392EF56B,
	ColorTween_set_ignoreTimeScale_m4B2110395267132EB58541D4355630D0DB466512,
	ColorTween_TweenValue_m4EF3CDDDDC3986BA6D06D4DB785310B131958749,
	ColorTween_AddOnChangedCallback_mF516F2C835133EB59CB28895961716360131D82D,
	ColorTween_GetIgnoreTimescale_m1F87CC0531F370154DF63095DA34F0F88E1DDAF6,
	ColorTween_GetDuration_mFE7A52AFDCA53B1CCB79D1E3577037A0E44F17C5,
	ColorTween_ValidTarget_mA5469658CB631C87CF97FC5AE2B9089A06678696,
	FloatTween_get_startValue_m90C461E4383568718E362BF3CB14F14D45585B0A,
	FloatTween_set_startValue_m281ACCD10E8DCB7ADED2B25EB093EE5DCFFF57D8,
	FloatTween_get_targetValue_mAC9AD7101F181AA03EEA21EBE047376A27B18DC2,
	FloatTween_set_targetValue_m948DD0F17FE536F38BFA213D13711B781934165F,
	FloatTween_get_duration_m17CD4518038CD642D714B3633236133D309EF13B,
	FloatTween_set_duration_m81021898C4F8F1F4D434CA46EAC596E0CC0F200B,
	FloatTween_get_ignoreTimeScale_m8281CB2B12F1697A512D2E2515F5DA058B429FD0,
	FloatTween_set_ignoreTimeScale_mC586D01F34D6C88892AB3C70A3298C4C7C45EA4D,
	FloatTween_TweenValue_m78FEB902E18BE0882BC487BC29B6EA3905E4F05C,
	FloatTween_AddOnChangedCallback_mADD5FACCDFA9E77C08CA65B8E5D33AE06DB79D50,
	FloatTween_GetIgnoreTimescale_m8FDD9D59F72DBC2CDEDD71A522ADD6DAD1438BE8,
	FloatTween_GetDuration_m1022A6824C91E5C51E1F7FCD27B9D60D6E83EDB7,
	FloatTween_ValidTarget_m7DFE9AC7C8C0EBEF441D80472635CF4F38632E5E,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	AxisEventData_get_moveVector_mCB9151FF8AFE8DC43886E715AD4B9932644DC171,
	AxisEventData_set_moveVector_m863F26BE1230CBCCA2DEF5651CE0FC8B8F1D45A3,
	AxisEventData_get_moveDir_mD9CF8343509BAE60C581138D824F9C53659DBBD4,
	AxisEventData_set_moveDir_m6C647B27688638E9C02A98E47BEC5292C07465EE,
	AxisEventData__ctor_m9694BD920E181114C1A079141D07BD092E05B27D,
	AbstractEventData_Reset_mF1DD0330808CADC4720AF29F268500B5B2905489,
	AbstractEventData_Use_mF5CFA55F6C0995C78C1975842F503F2A321CCB45,
	AbstractEventData_get_used_m8B10645CCCD75CAE08799E835150E4009D64CDC8,
	AbstractEventData__ctor_mE768723F461440691FA9218643BEC7692B816B36,
	BaseEventData__ctor_m4A8184F01D2CA8B2DE6BB752F486CF7DEF7A56AE,
	BaseEventData_get_currentInputModule_m0887B0CB20374A4AA10D4C1B480E305581533512,
	BaseEventData_get_selectedObject_m234C3A09897246D2BF97D43017C9AE476BD91770,
	BaseEventData_set_selectedObject_m8B7E784D728FE3078625FF45A1B5859E37092A2D,
	PointerEventData_get_pointerEnter_m47E87ACB1557B6380D0E66F57C2F9FFFD5E86DC2,
	PointerEventData_set_pointerEnter_mCA947226697EEC596FD611B31C10D7CE981026CC,
	PointerEventData_get_lastPress_m6B005D786FC5B30ECD8D5BC068420D0C361357F4,
	PointerEventData_set_lastPress_m3A938CE59A47898263BE6A6F880A3B3CD21D063D,
	PointerEventData_get_rawPointerPress_m6CECEFBAD7C50F04BD65172000B0BB916578B494,
	PointerEventData_set_rawPointerPress_mB7E32587FD73925A689A71FCAB560F9B78A233A5,
	PointerEventData_get_pointerDrag_m20299CC70BC6DA11AFDB8A33A957AC306FBEE5C7,
	PointerEventData_set_pointerDrag_m7E4BF3CF39EF734A80FA1994310FB09A5B095AF8,
	PointerEventData_get_pointerCurrentRaycast_mE58F786484E13AF2E6C2706E20C889E7453E3A7A,
	PointerEventData_set_pointerCurrentRaycast_m0B0B77AF61C5402D29574A9031AEED66AE4C8455,
	PointerEventData_get_pointerPressRaycast_m722BCA823E0405C9DF20312CDFBBEB5B1B05B7AE,
	PointerEventData_set_pointerPressRaycast_m559F6127EC11B0F1B5EEB7BFCA478128DE8E5536,
	PointerEventData_get_eligibleForClick_m2039146EE2E6940436E592D0655FBA06096DBFFA,
	PointerEventData_set_eligibleForClick_m403F4068866F6A5CC9814729B3918C8FF1C21DBD,
	PointerEventData_get_pointerId_m73B8DCE39BDCB5BD7894D192DDA7FF8817FBE6C6,
	PointerEventData_set_pointerId_m4CF9E4E445D841D14E46AE00B0B687EE3435C03E,
	PointerEventData_get_position_mF25FC495A9C968C65BF34B5984616CBFB6332D55,
	PointerEventData_set_position_mD63B59E6D4EF9B2B2E26D1F4893A7C67BD04266A,
	PointerEventData_get_delta_mC5D62E985D40A7708316C6E07B699B96D9C8184E,
	PointerEventData_set_delta_mDFEB23DF789E945F2CEC51C1F902CEE6AF674415,
	PointerEventData_get_pressPosition_m7C8D5A54C81C801EB577A60718C4211DFA1A3624,
	PointerEventData_set_pressPosition_m9DDE0BA5D6C31CBCDA926CEB62E51140F23013EA,
	PointerEventData_get_worldPosition_mF0DC1B57F31BB6FB8FFDD666603FF0909940EFA8,
	PointerEventData_set_worldPosition_mFF9BABD0B8DC58FC94CE7C775EA7BD1A72177EB6,
	PointerEventData_get_worldNormal_m310D7AC52A1EBD88080267B39ADA66A6EC778D26,
	PointerEventData_set_worldNormal_m1D2167440E774418D7F59F1A0E0D8E637C398519,
	PointerEventData_get_clickTime_m023B539AF9EDF3782FD9406EC79F4742C855A3AF,
	PointerEventData_set_clickTime_mFB2FD722D5898826A1D57379C153B8023272653C,
	PointerEventData_get_clickCount_mF3A09A090E418FAAAFFE55668D9761C2F23BCE24,
	PointerEventData_set_clickCount_mE56F748082C3D03A340345630FAC2B119451E003,
	PointerEventData_get_scrollDelta_mF473A122C860EC5279F6F5D085912BDA6418690B,
	PointerEventData_set_scrollDelta_m2B7F400B1DD1B45C36D22F291E625B02C76F9751,
	PointerEventData_get_useDragThreshold_mD254C2D9572E12F10EC86A21F28E4284EE29D39A,
	PointerEventData_set_useDragThreshold_mB5F06D15C2D1DB8D57F5B79CAEC3F58E4BF79684,
	PointerEventData_get_dragging_mA3B420FFEB0856189D7A7646AA00A981C745D4B4,
	PointerEventData_set_dragging_m4A4C08AB5A2173557EA62190F47AEFF1E9332821,
	PointerEventData_get_button_mC662D5DAC02F0ED6AE9205259116CC91BB92BD3E,
	PointerEventData_set_button_mD5D63D10CFE13D720287DD76AE0D8A852F8324CC,
	PointerEventData__ctor_mA2208343CA6EE41C13A6B7123322CC88B00A723B,
	PointerEventData_IsPointerMoving_mDF9C046AEE3228B95BECFCF01AE4C45D318EB486,
	PointerEventData_IsScrolling_m16BCB03C28009700C2F8AF6FF159E532D7DB0D1D,
	PointerEventData_get_enterEventCamera_m4DCBA203F50F1F4D30118573061FD4634D4B4915,
	PointerEventData_get_pressEventCamera_mC505603722C7C3CBEE8C56029C2CA6C5CC769E76,
	PointerEventData_get_pointerPress_m7B8C9E16E2B9E86C4DA93A2A2E3A58E56536406B,
	PointerEventData_set_pointerPress_mDFB3D803C9C4137799F9F1D57810DAAF08238327,
	PointerEventData_ToString_mA94EE73CA98DC98D20DA590DE44C4FCCE9729A73,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	EventSystem_get_current_m3151477735829089F66A3E46AD6DAB14CFDDE7BD,
	EventSystem_set_current_mADC79D2345234F851DA554EF79746D43CC6B6951,
	EventSystem_get_sendNavigationEvents_m38D86573D180189D107B782AD1F1ED183D45DAD3,
	EventSystem_set_sendNavigationEvents_m211BD472505E223CD056E46DFB3D53BBFCE9F02B,
	EventSystem_get_pixelDragThreshold_m8E8607E0C4E56387677507B45455A24D4680E0D3,
	EventSystem_set_pixelDragThreshold_m71146B09FD2FDC1CC2BD228AFCCB424007DAB269,
	EventSystem_get_currentInputModule_mAA917C940E32ECAC4324D6824A9E0A951F16D891,
	EventSystem_get_firstSelectedGameObject_m8CAFDA874F89BDA34E0984860046C1C171B200E1,
	EventSystem_set_firstSelectedGameObject_m3B6CA2C6EDC32EAE5FAF1F7B6A52F5B00A882381,
	EventSystem_get_currentSelectedGameObject_mE28E78D268403602DE1FB6F059EE3E9CDB7325A4,
	EventSystem_get_lastSelectedGameObject_m761188B5E33641891010B7BBBEEDDB1F267A6A29,
	EventSystem_get_isFocused_mB7275507B3AFEC15722B1F128CACB1BA578AEC3B,
	EventSystem__ctor_m7DCB0D2525B2EBA3458C5B6911231DCDFBB21104,
	EventSystem_UpdateModules_m9E90C6FD7A4202BD6E4801C6AF109D859167FE8A,
	EventSystem_get_alreadySelecting_m419F4730CDDE5B742056F931D7445F6E4AD92B7D,
	EventSystem_SetSelectedGameObject_m532EE7D0346462EDBB56E5BCD048CB3BEFB84E3A,
	EventSystem_get_baseEventDataCache_m2B14076E5EF918BE1A94F16DE1A827AC1401BC89,
	EventSystem_SetSelectedGameObject_mBAD02D750DCDEFFE322C9373646E28396084ABE1,
	EventSystem_RaycastComparer_mECA916E0B66A65018A1E7544E51C6D77BC52F1CA,
	EventSystem_RaycastAll_mA5A53B5404EF95AE97EE81445056153ED41CBF80,
	EventSystem_IsPointerOverGameObject_m6E12F740DD96F03F15AC324D6426C475A48506D0,
	EventSystem_IsPointerOverGameObject_mF2B40021727C8285F99201995760659C2A53E513,
	EventSystem_OnEnable_mE18ECC7BE60F739FEE9ABA731010E46A965894ED,
	EventSystem_OnDisable_m35EE11C87000577B20D754B063E0B5C6849FA7E4,
	EventSystem_TickModules_m0A74957A4FF307FF480D2103AD225640693EB8C3,
	EventSystem_OnApplicationFocus_m9DC07EB33D438D53366AC8EA989AA8325A1BE276,
	EventSystem_Update_m62B9E3C3F69A8A22EE9BE644E9B44221140754ED,
	EventSystem_ChangeEventModule_mE2CF924DE5717273AA345F5A52C46BA98C8ED662,
	EventSystem_ToString_mAD8804AA87C37BF28EE8712110C185E7135C15B5,
	EventSystem__cctor_m97E5871EEF081006E2793E916D0723D59DBE6EAD,
	EventTrigger_get_delegates_mA3A792558AA5B16BB51CDF02BDDF8E9DCFED158C,
	EventTrigger_set_delegates_mCDACA955115E5F10D9C077A4CE5A2F25D5D38AED,
	EventTrigger__ctor_mE62DEDD1565721A55B77AEE673402A3F23A1A795,
	EventTrigger_get_triggers_m16CC3F855662E6CEE23031B7787DA8CB4ADDF28A,
	EventTrigger_set_triggers_mF70F72B1E143AEE94E07B032C3E057A22625467C,
	EventTrigger_Execute_m012E5ACD13CF24C4CEC5C3C9E508185A57EF2890,
	EventTrigger_OnPointerEnter_m04B452EA2C2516F98483F6EC242B6E321D6B5B40,
	EventTrigger_OnPointerExit_mF5EF9969978928D43D54F521F5D4F376D2339A7E,
	EventTrigger_OnDrag_m5D9429B4EBFA5D7F759959B907DA492703B861C7,
	EventTrigger_OnDrop_m790E82403AB8D54A0EA5FE1DF9C95D14870125C4,
	EventTrigger_OnPointerDown_mA287796A4055EB6364E660BE570206FC6F1DF46E,
	EventTrigger_OnPointerUp_m6DE8F821DED7D2DB1DB37374D4898B6141AF4689,
	EventTrigger_OnPointerClick_m5246E16B5764AB16420082BF7ECA58F6C06F622F,
	EventTrigger_OnSelect_mA9FDA907A6286FFA9F5BD9FB63D627B39B7591B9,
	EventTrigger_OnDeselect_mCBB9E32B7B8319CDE1D4199F3205C949D2A588B0,
	EventTrigger_OnScroll_mF20D72F4751F7F184B0916BB3C198418D0C08AFA,
	EventTrigger_OnMove_m9D1B943ADA57BC17D5E38259D58513D8A7AF04A6,
	EventTrigger_OnUpdateSelected_mE19A22DB72549942C6E8E935D73846E364D05587,
	EventTrigger_OnInitializePotentialDrag_mD1299225787F1132CE52885AA6EFB1609348AB39,
	EventTrigger_OnBeginDrag_m4B64A8BBE2C33FB05920E9166D205EBE471AC7FE,
	EventTrigger_OnEndDrag_mB7B2D7B3602649D660633584CCFEAC5B23D29EEB,
	EventTrigger_OnSubmit_m27A7419DF201835D24B4FE2FA1EA771D03B19DC3,
	EventTrigger_OnCancel_mF2EFE2A47874BF335F9BED5C583F1F32667CA20C,
	NULL,
	ExecuteEvents_Execute_mFB517B969B21E23CB5EAD0E9D4DB09A357727233,
	ExecuteEvents_Execute_mE64EB9BA625A97760C7A43F67DC976C6F7A8D0F8,
	ExecuteEvents_Execute_m177896660F17B1D4CC55DD2AEB8A2C783B582DC7,
	ExecuteEvents_Execute_mDFB526FB6BE7B2C5266937D471D15F9D25C1DD8F,
	ExecuteEvents_Execute_mA47467EEFB5EB9632375D95D39D2ED878AF286A2,
	ExecuteEvents_Execute_m5AB8EA95A58AFC2614E9921F16B0603D0EA8ADA6,
	ExecuteEvents_Execute_m1C2C7DA0379E8A119C415FAFF3B613C9D5278E5A,
	ExecuteEvents_Execute_mDE9458FFE6DB4E5446D9B92FD59A9282EF0E26F1,
	ExecuteEvents_Execute_m046FB8ED863B38BD15281E9EED004E9686B87184,
	ExecuteEvents_Execute_mEF9FBBA3E2BDF08B51E80190C3BC9C0E0204C417,
	ExecuteEvents_Execute_m00514A1B45480BC9D55FA88B66914ED163B6A6CC,
	ExecuteEvents_Execute_m2D4B7103DCEA057526CDF142A4D4C70136CC8233,
	ExecuteEvents_Execute_m00C0AAED23C33309955E60AB6319863A3052AE61,
	ExecuteEvents_Execute_m8B55F40246FBF954F2C9981BEEEA0828A770A697,
	ExecuteEvents_Execute_m7CCC77D770D79991096597CD2FE892267BA7BA4B,
	ExecuteEvents_Execute_m5354ABE381C181AA8B3514D1849E7788758E8505,
	ExecuteEvents_Execute_m66FD7F4E4DE2617EE432AD9DA0D3A258C5F1FBFB,
	ExecuteEvents_get_pointerEnterHandler_mFD5296E38EB1C5EB6D16CB83913430FEEBF889A5,
	ExecuteEvents_get_pointerExitHandler_mE5EC9537676A055EEE178A4E6B58D96F9B4AC301,
	ExecuteEvents_get_pointerDownHandler_m8AE9CA906C86BBBEB75BA2D05F5DAB01F62519E3,
	ExecuteEvents_get_pointerUpHandler_m7EDDD1128DC04344CECEBCB9B6B7CD064F7FAED2,
	ExecuteEvents_get_pointerClickHandler_mA657195AEC7D0A42036CBCAC9AD48F215C3C69E3,
	ExecuteEvents_get_initializePotentialDrag_m5B3D899EB08DA227EFBFC67778DDB98D7505C6D4,
	ExecuteEvents_get_beginDragHandler_m7F238765714F73899EAFDF0BA203D9A8A57AED31,
	ExecuteEvents_get_dragHandler_m41B7D77771806788CD773C83C2E5A53D5ED5B179,
	ExecuteEvents_get_endDragHandler_m23B60D3E3873043263069A3C3145393475690769,
	ExecuteEvents_get_dropHandler_mC2362B96C6CD3628B83722F4B7C73E707C6C1EAF,
	ExecuteEvents_get_scrollHandler_m48E5B17388986BD59EC7A7BF27E3D30A9FD057F7,
	ExecuteEvents_get_updateSelectedHandler_mE18DBB058B1EDC75D4F690A1E35003749BBC0567,
	ExecuteEvents_get_selectHandler_m26186C0D78CA4A8AFA0789A09F488F7E186BE1C8,
	ExecuteEvents_get_deselectHandler_mEAA9E3701CC972EFDD20B30E9B3CD9302B2FD668,
	ExecuteEvents_get_moveHandler_m113A4222FC10723B2E38398E182C02F6624D6F24,
	ExecuteEvents_get_submitHandler_m734C2BE2F7CDA7F5C42897E3C8023D3C7E1EDF88,
	ExecuteEvents_get_cancelHandler_m5DB4A9513FB8B9248AE555F7D8E8043175B8D995,
	ExecuteEvents_GetEventChain_mD90FFC4A70E16AFA81AC6C9CFF174630F77C608C,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	ExecuteEvents__cctor_mCD47C80D80A3C5F1D3AEEF3ACD31AD1EE197A883,
	BaseInput_get_compositionString_m55FC44652CE283EC56A7E07186F6EF6160B0A122,
	BaseInput_get_imeCompositionMode_mC26A90D1DDE30CEE508412D8F1FEA5AD37671DA8,
	BaseInput_set_imeCompositionMode_mC83B4474B044D31D81FF18CD35AE6E9CEC5A6BC3,
	BaseInput_get_compositionCursorPos_m08E6856B2A7240E1FEF880323757BDF8A4917046,
	BaseInput_set_compositionCursorPos_m48AAACE26E07BE130D5533F1BAA26741FD8B0F82,
	BaseInput_get_mousePresent_mFA34ADCAE87E52208D112B46C1F8ABCEC60D585C,
	BaseInput_GetMouseButtonDown_m5891841C7252506A8A6BDBD2DAC6A60A234E7CC5,
	BaseInput_GetMouseButtonUp_mEAADD66C40FDBE90A787E6892081B89A816B7768,
	BaseInput_GetMouseButton_m2F512EB6088BEB4D69F3FF07115653C4E4E62A77,
	BaseInput_get_mousePosition_m020D1FB7D27B45D19303B7B9E05038F2C7DA02ED,
	BaseInput_get_mouseScrollDelta_mBF6C6F5DD4C626413DEB5081A34D58C2F178389F,
	BaseInput_get_touchSupported_mDDDA5078A3F2B0E8B3B5181C9B8DC4D10C9B57D9,
	BaseInput_get_touchCount_m81840E0A652F5C646D18F6E0E13B4D6D4319435F,
	BaseInput_GetTouch_m156C4B5ADC8DE91BADE25D16422FDBB1B7B052A5,
	BaseInput_GetAxisRaw_mB6FE3749F8E040C6C86EDBBB8F0DC9E9B8A3D5B8,
	BaseInput_GetButtonDown_m3EBF9A26EF50036386640FE5089DAB8EFF7B48BA,
	BaseInput__ctor_m33F85C42EA9300A022A8328A83D1CB9FCEC6F042,
	BaseInputModule_get_input_m385A99609A705346D5288D047EE17374ED406BE7,
	BaseInputModule_get_inputOverride_m3C63C410A33009ACB7EAFB776066F734110391B8,
	BaseInputModule_set_inputOverride_mE88337B26EC069A3866174887FF59B1CD5C7EB85,
	BaseInputModule_get_eventSystem_mEF6DEC17FF56D786AA217A52FCCFE8C6F38546BE,
	BaseInputModule_OnEnable_mD8CAA2DE8AEC7907D84C40DEA7A0A83A8C530D5E,
	BaseInputModule_OnDisable_m22FEF0A66345808B69CDDCFE47E506645EB1013C,
	NULL,
	BaseInputModule_FindFirstRaycast_m4ABCD1BCF871A87518D47C906B8F63154B6BF275,
	BaseInputModule_DetermineMoveDirection_mF99EA376D26F543AF0C3B10CC67AB9493054AA53,
	BaseInputModule_DetermineMoveDirection_mC1D1D145996C9A384D865FAE4B02FDF9D106EA52,
	BaseInputModule_FindCommonRoot_m1995190ADC1341F180811C5213F1CA522B6282A5,
	BaseInputModule_HandlePointerExitAndEnter_mD32C0E209A19F78D07D964D162188D13762463BF,
	BaseInputModule_GetAxisEventData_m920ACD6398A0B3FD82E6990DF89B2A50DEE25990,
	BaseInputModule_GetBaseEventData_mB945B5DF7A5C2B825C7D542D944A7795D8F5F93F,
	BaseInputModule_IsPointerOverGameObject_m4255E7C2D628B5E4524D02A2E26158DDE8640CF5,
	BaseInputModule_ShouldActivateModule_mA3CFFC349E1188C750346FC1B52F44D770104BCD,
	BaseInputModule_DeactivateModule_m02E0A94E9EBC6793439FE1ABF81F2E84B79C7249,
	BaseInputModule_ActivateModule_m1F16D868703EBA8610E0C2DF86B4760F934631D7,
	BaseInputModule_UpdateModule_m8A5973C39616DF6C34041F93014C2469DC667DE2,
	BaseInputModule_IsModuleSupported_mD2BB3DD4CF96C31549AED158F0753AE345C01647,
	BaseInputModule__ctor_m4D2F1DB4FA2524BCB5598111C11E5E00D4A95DC6,
	PointerInputModule_GetPointerData_mB16DD3B9751FFEBBB1EC7802533D8EF36C9C8248,
	PointerInputModule_RemovePointerData_mDDADB278A6A01D38C46631A9531C62C17B4DEBEA,
	PointerInputModule_GetTouchPointerEventData_m630FA2AD7438552F7AF904ED42EA90FADD910055,
	PointerInputModule_CopyFromTo_mDCFE9EA1411C24FA9ABDA993CC16182C2B1AF687,
	PointerInputModule_StateForMouseButton_m182B203D7CB0A9E0F39F39FAC8C0020D85C26D22,
	PointerInputModule_GetMousePointerEventData_mA8B6C810AE130118AA18CD4BD35F8F5BCE0D7E07,
	PointerInputModule_GetMousePointerEventData_m1BE3C022E0D9B001B96B9FB129FE57FEBFD13E7F,
	PointerInputModule_GetLastPointerEventData_m709537DE2BCDD6D50C4C2F39B6A48C4D9A8A27F5,
	PointerInputModule_ShouldStartDrag_mE818EC5B7706E3803A4EDA09FD1D14A0ED105049,
	PointerInputModule_ProcessMove_mF69B051D56D97F33857794A5EBB0A952AEAA276F,
	PointerInputModule_ProcessDrag_m1B953F6640DBD2E46508B18F4F281ED461DD1360,
	PointerInputModule_IsPointerOverGameObject_m8F735B4286B61B82E9C92966B99A9A2D575495F5,
	PointerInputModule_ClearSelection_m05E527F28FB39BEBA8FA27153DAE71C8E7FDC958,
	PointerInputModule_ToString_mD9C4C6C80C3CFD3A8C1E39D4F9A58A9E29DD1865,
	PointerInputModule_DeselectIfSelectionChanged_m3A32EDB68D6F489FD2A22CAB5A98D343E0634BDD,
	PointerInputModule__ctor_m1E5E97188BEB6F225E167E5D2BA6DAEF4BFA3510,
	StandaloneInputModule__ctor_m7ACED26CC5670B0729809379560FCBE0D0311AC8,
	StandaloneInputModule_get_inputMode_m9E4FF00674C049A7F600D0CC5D278F474232B3D4,
	StandaloneInputModule_get_allowActivationOnMobileDevice_mEBF5E05C6A412A45CCB07502C4798DCE743FDAEF,
	StandaloneInputModule_set_allowActivationOnMobileDevice_m00941F74B0F6A1EB46E2BD52FF4907BE0617D547,
	StandaloneInputModule_get_forceModuleActive_m6D41F04E01F96727E0246D6B74F63E0312E25022,
	StandaloneInputModule_set_forceModuleActive_m0438ABF86C05D6ACCE740D0464190AB0B2B44134,
	StandaloneInputModule_get_inputActionsPerSecond_m9F5DE02D9DF4B16A6E0D0F36CB0CD293AB9C14EC,
	StandaloneInputModule_set_inputActionsPerSecond_m13D9F85BEB9BBE3C28498C3248C298AD86129950,
	StandaloneInputModule_get_repeatDelay_m4FE04D7CFC8C789C9503E841FC5E0711CB0F8986,
	StandaloneInputModule_set_repeatDelay_mD0B81B79DE60C3C26CAF2CDF1DAC32D02B148AFD,
	StandaloneInputModule_get_horizontalAxis_m0C0B26CDBBBD3AC956FBF77BB177BD719DF41791,
	StandaloneInputModule_set_horizontalAxis_m6458621A42F073F7CC8EDF884E3FBC3C2BBAA7B1,
	StandaloneInputModule_get_verticalAxis_mDF726FB43588DFA1D52E4CD825637B577EE06ED6,
	StandaloneInputModule_set_verticalAxis_mA75D79740A9057B319CF78A49209A35243E16948,
	StandaloneInputModule_get_submitButton_m19B44B9FA36F84540E00BBBF7AA38799D2F2B0B3,
	StandaloneInputModule_set_submitButton_m4DB70E5FBAAE564C3CFD6C8908B9B19D247949A8,
	StandaloneInputModule_get_cancelButton_m0FB6DBE18639C06D6A124D89F2754F21D0F4CD76,
	StandaloneInputModule_set_cancelButton_m4E19B22DEAF8E7C5F3C3A29B0198173772CB8A26,
	StandaloneInputModule_ShouldIgnoreEventsOnNoFocus_m00C2E7810D0D323B1A4A72097A75C6C2A87F0D9C,
	StandaloneInputModule_UpdateModule_m0525AD093E45EFB1FE8484731A81C3E45222EFB9,
	StandaloneInputModule_ReleaseMouse_m1EE3D0D685BB09DAAE4556477420B7D05FE3F0C1,
	StandaloneInputModule_IsModuleSupported_mB6AE0DFF7278B18B24FD5FC1D1ACE571D26FCABA,
	StandaloneInputModule_ShouldActivateModule_mD6CF146E884E38E295E95C6AC3A355029E653D35,
	StandaloneInputModule_ActivateModule_m4861DB0128B954D53E51FB5A6CC1524346F76A1E,
	StandaloneInputModule_DeactivateModule_m3495EC499261ADF166421DB15383F2808614CFDA,
	StandaloneInputModule_Process_mBF40EA3762B85C417E6F88D531174D05A7FFCE75,
	StandaloneInputModule_ProcessTouchEvents_mFEED66642E804A218DD34A9C5F0F8EAA5CA3B019,
	StandaloneInputModule_ProcessTouchPress_m74A52DA64B9C5EB8B5A38889F25BFEAFC284FB51,
	StandaloneInputModule_SendSubmitEventToSelectedObject_m132BF623619679A3E5871B7DA5BC5DD7B2E274DA,
	StandaloneInputModule_GetRawMoveVector_m36E309DADA8C0BB4CA0710FAABE0F4E9B77C2F6A,
	StandaloneInputModule_SendMoveEventToSelectedObject_m45E5CAE198660284CF7DB1FA464B79F9E26D44D3,
	StandaloneInputModule_ProcessMouseEvent_m54B75447C4D230F1FBB2E9A440B323403CC176C0,
	StandaloneInputModule_ForceAutoSelect_m89726C63D482B7D8529A5FD74E57FB8A92107F02,
	StandaloneInputModule_ProcessMouseEvent_m4D1CB4E39517B014D3F81B9F0423B8FA6F8A8656,
	StandaloneInputModule_SendUpdateEventToSelectedObject_m2982A721762040935DE3835DE71FBA28650036FB,
	StandaloneInputModule_ProcessMousePress_m795F279F981E957475C724C010FA8A87F9BE6CF4,
	StandaloneInputModule_GetCurrentFocusedGameObject_mA354FCB4E2546E1F49D165207705A26D29EBB3D7,
	TouchInputModule__ctor_m170CD0EBE44E63A7061C8EA789455F21D0CB28ED,
	TouchInputModule_get_allowActivationOnStandalone_mEC3885BA609BB734A3E8D2966B6CE6EF84789DBA,
	TouchInputModule_set_allowActivationOnStandalone_mB68D39F944C1E53061FADE6C67249B0A850168AA,
	TouchInputModule_get_forceModuleActive_m000AEC6C27D5CA88EA2B87C33C9991F4F50D007F,
	TouchInputModule_set_forceModuleActive_m75A21D5518C85738F24D394A54981CC8BE4BC9D4,
	TouchInputModule_UpdateModule_mAA1097F92F5F1808251CB8D9BFD124AE2663AEDA,
	TouchInputModule_IsModuleSupported_m0F4864F8FCBCA2AF3820A53EB3D8634FAB6763E5,
	TouchInputModule_ShouldActivateModule_mB2F45197C70AC23D1250782612B10ACBC1262022,
	TouchInputModule_UseFakeInput_m2DE0550826DD4CA1249AB4AC2315DCA7F3AE571A,
	TouchInputModule_Process_mA3BE6F717B77FE0267EBF12C53E9EA990E40EE48,
	TouchInputModule_FakeTouches_mB10F6B25D8CFACA3FD96C1823E6E4FF6427A5663,
	TouchInputModule_ProcessTouchEvents_m6A97A06586A000FF8C4C14DEEEE64E6876A79F08,
	TouchInputModule_ProcessTouchPress_m10A4854C822E110906745CFB1EEAF846F48D2949,
	TouchInputModule_DeactivateModule_m33EF87C66E547851B2FB23168182DEB86066ACE1,
	TouchInputModule_ToString_m532F4130976306175BFCF9831A6F470346995BD2,
	RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD,
	RaycastResult_set_gameObject_m5EF3316E0D32FC1B45BB2BC087EC42E436DA1C07,
	RaycastResult_get_isValid_m53278AA3529BC7B909A9AA082026D51CE6926813,
	RaycastResult_Clear_m5C979A22E0B12FBD7BA035FE0815B4D81E82E9F7,
	RaycastResult_ToString_mFD0F27611425231BAF089CEBB0332FEFD7FB9E21,
	RaycasterManager_AddRaycaster_mB93CFBBCE344327BF96AC11CB500219FD1873B9A,
	RaycasterManager_GetRaycasters_mA2491B7F058FB2DA88179C0BDE0EFB0B0E28B740,
	RaycasterManager_RemoveRaycasters_m26668BA781D690D83E3417436D2D9AE577004624,
	RaycasterManager__cctor_mEF2E08745F0138B43512752C0E151055B953A3AF,
	NULL,
	NULL,
	BaseRaycaster_get_priority_mF085F1BF77E4D69D84A8ACCFF61FBD80EB55AF50,
	BaseRaycaster_get_sortOrderPriority_m03BB34962FDC88F04B94A160138EC8C49BB50595,
	BaseRaycaster_get_renderOrderPriority_mEF4CA94A52D130A2546E094C2C492B7DEAD6F3C4,
	BaseRaycaster_get_rootRaycaster_m4DF6B023C195A4E8E9AF8D8E411379A9052D80A5,
	BaseRaycaster_ToString_mED39E4461F0C708B924FC87DB5A2949917FF42F1,
	BaseRaycaster_OnEnable_m31B91C059934DAB7FEA26D8D5A030CCF469778C1,
	BaseRaycaster_OnDisable_m0FA75817BD8DADDF85C10E02B0067E835C80EE0C,
	BaseRaycaster_OnCanvasHierarchyChanged_m4DBBF545F6C74CFC7C375D7A7C42AD7F1B3CE17F,
	BaseRaycaster_OnTransformParentChanged_mD98668AF752E710CB0A8A863695E3957B2972083,
	BaseRaycaster__ctor_m3F94FA62302E9BCB5290515C9D5C4DC1265F5C0F,
	Physics2DRaycaster__ctor_m460236B9F5697BA8777DF3D770AC0D394497748D,
	Physics2DRaycaster_Raycast_m3CEA59B484E46F41A6F62B923AC23FB140DE8DF3,
	PhysicsRaycaster__ctor_m1A3C04070C6C1E3C4449D3BB4AD7C880D336D4CA,
	PhysicsRaycaster_get_eventCamera_mA4D0809E09657E6B635FF54EA8178CA5280C297E,
	PhysicsRaycaster_get_depth_mFEEAAEECAF9522513EC430D6AED0C4FE64354708,
	PhysicsRaycaster_get_finalEventMask_m33F53EF1231123847F95DBFF865C3B19E6CD1EB6,
	PhysicsRaycaster_get_eventMask_m11D96704635B15FCD194B02B421807362676BE98,
	PhysicsRaycaster_set_eventMask_m59EAB6D3AA1F0FF53AAA32A0F62E240C60EAD7CB,
	PhysicsRaycaster_get_maxRayIntersections_m473112CC291635C45D0590CC4B03C07D652FB69A,
	PhysicsRaycaster_set_maxRayIntersections_m730A3F32F27E041B9AC49012E4B954C6152DC3D4,
	PhysicsRaycaster_ComputeRayAndDistance_m92EFFE5A5287CC625EA6B66853DE2959985AFE7D,
	PhysicsRaycaster_Raycast_m790F8B5B886500FF2C7D8E966DA72400A4C2B55C,
	UIBehaviour_Awake_m8283CBD45FF1CBA026DFD5F0319282EA464F8B33,
	UIBehaviour_OnEnable_m4FF74AADA5E101F59DC5C19DCA82110F7482CB56,
	UIBehaviour_Start_m9717CD32EA9B3C678EB0D73CCF59C801C5E5207C,
	UIBehaviour_OnDisable_m43F5502A18FCFFD355381A95175DC71E0D4005EC,
	UIBehaviour_OnDestroy_m12CAEB3F5221B9D061148F6D8FBFD0FDD90636F0,
	UIBehaviour_IsActive_m88452BA640BCCC2769D3FBD0F3E82333A0936A16,
	UIBehaviour_OnRectTransformDimensionsChange_mE273C2FDE70B13C9BCCC07C0FC83322EC03CC470,
	UIBehaviour_OnBeforeTransformParentChanged_mEA6FDD53F2468F7299110417A8B659B095A70EA5,
	UIBehaviour_OnTransformParentChanged_mBB0F5D46FF7791D80FE6E4EE1932433246D5B7CB,
	UIBehaviour_OnDidApplyAnimationProperties_m36C4FA9136D24E5F7EE389E17CDA2A3D581220DC,
	UIBehaviour_OnCanvasGroupChanged_mDB3CDCE40E08D3943F10655196188668D8A3F422,
	UIBehaviour_OnCanvasHierarchyChanged_m5A9FF86F647810726B4AE9F8C15862F353FBDAFD,
	UIBehaviour_IsDestroyed_m169BA727AB81FF96092471C152C845EBE944A269,
	UIBehaviour__ctor_m1B44EE4BDA3604F96C48379524B9907FEB15EB53,
	ButtonClickedEvent__ctor_mEF3C31A6254EBAB9F98F8DAAE499700531B18681,
	U3COnFinishSubmitU3Ed__9__ctor_m7ADCF9803F4A2AD6F3555209BCF182C603989A6F,
	U3COnFinishSubmitU3Ed__9_System_IDisposable_Dispose_m4FFECE47D511034EBA7270B6F32310FE1DA30B2F,
	U3COnFinishSubmitU3Ed__9_MoveNext_mD0D8375C1B07F8EF9D3F9DE25191F6D3F4459E57,
	U3COnFinishSubmitU3Ed__9_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m18F63ADAE6DB6C2C632A5B28B07ACF80BE0DC4E8,
	U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_Reset_mADAC8D44A98EB373142102E747F6F82CDCBF44E6,
	U3COnFinishSubmitU3Ed__9_System_Collections_IEnumerator_get_Current_mB42667ABE8F377D6B1D73BF708B17CA0A60DF68A,
	NULL,
	DefaultRuntimeFactory_CreateGameObject_m76DCCBEF0431C815F2AC2360614D4FF09F98E34C,
	DefaultRuntimeFactory__ctor_mC84BC30364958D9A5EEE040D5D4BE254393809CF,
	DefaultRuntimeFactory__cctor_m917CD6F4766028435BE57F5EAFD83A887E0CA4E8,
	DropdownItem_get_text_mABB014D2DEE9F6B24515DE71A08EBFA82BB44829,
	DropdownItem_set_text_m2F87962E683F7DCF4CCD6CEA4E4E4562E89F939E,
	DropdownItem_get_image_m2879EEFCAB097FBA79BC4DA41ECBA4EBE3CB6185,
	DropdownItem_set_image_mEACD24E324362E50180808DEF29E160E52C81BDC,
	DropdownItem_get_rectTransform_mADBE4D843FE38C832CC1C9CFE03DC4D55B18E897,
	DropdownItem_set_rectTransform_mEDEAE741CC3B0473F332D9B55B413EA290889240,
	DropdownItem_get_toggle_m6DAC29FD2E711343DBCDF240B3218BD6211886DE,
	DropdownItem_set_toggle_m4D3247AE384827C5F3C49FFDADECED4A91B3B5CE,
	DropdownItem_OnPointerEnter_m9E39FBA9A0AF70B9C7A87E2A6A10252D3CA05ED8,
	DropdownItem_OnCancel_mDD631AB9163515B0368C64482CC0B4937C5B1161,
	DropdownItem__ctor_m34EFA0120C66D0E04DE5E611F1D2EC9D6E985905,
	OptionData_get_text_m3AA3E93AC9264EB140F873BEFF0A6FCB48FB1BFF,
	OptionData_set_text_mED7FEA5D1C3CB30CD7B8878CE86CE57D8E68C735,
	OptionData_get_image_m0BF991D02528EE3C67FE841C3AA87EC1AE7D8E31,
	OptionData_set_image_m9FA0F571B5ECF76C8E04CA91ED8BE1C8E9968265,
	OptionData__ctor_m45CB705FD6717ECEBDDA3E6F137BCC38C388CA1F,
	OptionData__ctor_m8AA4FDEB8771F714C90DF651743B77E0C75DEC00,
	OptionData__ctor_m024A52D2CDF4A551D94A861B1D5255D528BC6FF2,
	OptionData__ctor_m9244487628FA5C49B7B1658FE1C82CA67000A6DB,
	OptionDataList_get_options_mEA305423DD1C0F201310F97CFD3FD1B89F063ED0,
	OptionDataList_set_options_m674C45F57F90F85B6E33EF4C05BD0F0E236BF823,
	OptionDataList__ctor_m658891495892A98D411AC971EE3EF96C01560F73,
	DropdownEvent__ctor_m9E61AABA58765E640C5044E5C82574ED362D2875,
	U3CU3Ec__DisplayClass62_0__ctor_mE4628B27FE0F4517EFB2699040AFEB957D6A5FA8,
	U3CU3Ec__DisplayClass62_0_U3CShowU3Eb__0_m63D2341A7D8EC695D01B0F934D58C2F9C3F306A3,
	U3CDelayedDestroyDropdownListU3Ed__74__ctor_mAD9EFC641FEA13E4B5E4BE5013C1784223CAEC3E,
	U3CDelayedDestroyDropdownListU3Ed__74_System_IDisposable_Dispose_m50F4B9432686914B794A14F3505CB447DC3A765E,
	U3CDelayedDestroyDropdownListU3Ed__74_MoveNext_m9CBCC3C169274B09737B7B0FF88CF5FA38FAB5FD,
	U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m343B7FFD7327324FF24FE7A1EC39ABAA5E262748,
	U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_Reset_m108B8A0FF9DB569C5F473E4A82002F4C3E419020,
	U3CDelayedDestroyDropdownListU3Ed__74_System_Collections_IEnumerator_get_Current_m4705AA405908792F7ADB20CCD83A425C15F397C8,
	U3CU3Ec__cctor_m73361334C182D842500A50243025DE880A278E01,
	U3CU3Ec__ctor_m7CA24FA9F8163B94385069D55847C56A9DCC929F,
	U3CU3Ec_U3CRaycastU3Eb__24_0_m184D010D41E2E77338B51F88EAB8D2BBD5BC0FA6,
	OnValidateInput__ctor_mCCEBA7022E2F01B115A92B5F89C39A00868F09B2,
	OnValidateInput_Invoke_m8382B852D2F5364FB109A43601D08C3A8F0CCC09,
	OnValidateInput_BeginInvoke_m97DC7AAEFA03939CBD65AF08D335965E79475694,
	OnValidateInput_EndInvoke_m72E5E385FAAC8E0E704B5A0F6C4D9EFB740F0844,
	SubmitEvent__ctor_m2E518230CEF5C85510216286F149236226332801,
	OnChangeEvent__ctor_m7A9F4AE92A614232DB49947CC1942AA7949BC245,
	U3CCaretBlinkU3Ed__161__ctor_mF3953F6AF043F601BE7417A56694AFE359A7BC4C,
	U3CCaretBlinkU3Ed__161_System_IDisposable_Dispose_mADC123E40EFC9D3A18BFCE5A48A030C841BCB5C2,
	U3CCaretBlinkU3Ed__161_MoveNext_m35151EF2720A88857A15DF61BE9FB17CD46A9DCE,
	U3CCaretBlinkU3Ed__161_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD30EA25257DE83102EC6C592382A1B3983B2DACC,
	U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_Reset_m1F664E96DA0A069544B980F6643F331588D2EEA0,
	U3CCaretBlinkU3Ed__161_System_Collections_IEnumerator_get_Current_mD9739C54110E7FF93C9A98C89687F5270CDD43FE,
	U3CMouseDragOutsideRectU3Ed__181__ctor_mCA2F0431FC266ACCA7E96B48FCAD33D9E2B50B4A,
	U3CMouseDragOutsideRectU3Ed__181_System_IDisposable_Dispose_m9C376C3E6141A94D9BE1E3D955C083F64C980362,
	U3CMouseDragOutsideRectU3Ed__181_MoveNext_mEE0C97213DB1AC9D8616A51B3CF37E4F344E7A15,
	U3CMouseDragOutsideRectU3Ed__181_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mD7B93318E14B1294F6E3899888CEDD11CCB7850E,
	U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_Reset_mD5F8E5381D857ED4475C019385881D92A2374A65,
	U3CMouseDragOutsideRectU3Ed__181_System_Collections_IEnumerator_get_Current_m806304421955FA531328C392E9882C163A2B5386,
	U3CDelayedSetDirtyU3Ed__56__ctor_m02CDD709D0F09D88F2551E0CC17F655B849E8866,
	U3CDelayedSetDirtyU3Ed__56_System_IDisposable_Dispose_m4A49A21A509EB6308D418B720A4D7D9E89FEB25A,
	U3CDelayedSetDirtyU3Ed__56_MoveNext_m713F270B4716122410990ADFFE72DE8ED9149E38,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA6012CCB25A71E72C44A960AFE1122BC589BEF88,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_Reset_m163068C35B92BEA03B53A89CAEC010459749C8FE,
	U3CDelayedSetDirtyU3Ed__56_System_Collections_IEnumerator_get_Current_mE09727941D13EBD44B21A13822F9F20ED75FCE28,
	U3CU3Ec__cctor_mA91A5C38199DBC143843D3D14BCD0037184CF870,
	U3CU3Ec__ctor_mAE9CB345634F42E395788C14D46C0068D7DF5065,
	U3CU3Ec_U3C_cctorU3Eb__5_0_mED1242446A6E160D4EC68EC766C4658D5652D960,
	U3CU3Ec_U3CStripDisabledBehavioursFromListU3Eb__10_0_mDBCD53C01C6E4E3530B4AC2319B675979E556B6E,
	U3CU3Ec_U3CRebuildU3Eb__12_0_m61C61EC7A163B590A8ECA1955B8471F8C2DC7F37,
	U3CU3Ec_U3CRebuildU3Eb__12_1_mAD1F54287DD0877DAB5D684A63C65D00F01B2ECF,
	U3CU3Ec_U3CRebuildU3Eb__12_2_m4C5955D09B742EA65B16F86C3952DFD2005263BF,
	U3CU3Ec_U3CRebuildU3Eb__12_3_mE471222E89B5BD6D012D9C06D7A0262368C37A62,
	U3CU3Ec__cctor_m09D5B404BD546771E0FEA451F81F91A9D0C2ECFC,
	U3CU3Ec__ctor_m8923A70336875668B745F0A4E63A97E94AC81B10,
	U3CU3Ec_U3CGetMinWidthU3Eb__3_0_m25085EA832E41CA6905CCCCD1505C4DC091A6AC9,
	U3CU3Ec_U3CGetPreferredWidthU3Eb__4_0_m54D05611CC112A9CF9CD8819FCBE1812D751F27D,
	U3CU3Ec_U3CGetPreferredWidthU3Eb__4_1_m33B5F83867470C8FE89B0E64FCD3B911B1BF4FD8,
	U3CU3Ec_U3CGetFlexibleWidthU3Eb__5_0_m981137134604E2E04FD745310124AE85760BAEDE,
	U3CU3Ec_U3CGetMinHeightU3Eb__6_0_mB5247A6F4D863D09EFC771EFA025852B7CA9C979,
	U3CU3Ec_U3CGetPreferredHeightU3Eb__7_0_m46420DB2062D89D2C2075B466B57B7EEEAD1032A,
	U3CU3Ec_U3CGetPreferredHeightU3Eb__7_1_mDF489C3BF8D1B2EA9647B007B37EB09AD09A0A3F,
	U3CU3Ec_U3CGetFlexibleHeightU3Eb__8_0_mC7AE9A4412EBB81B5BEED2E5B1BD0E0169AD4C37,
	CullStateChangedEvent__ctor_m1C6F0A946C6C0DE083C533746B5951A31BB2540F,
	ScrollRectEvent__ctor_m43B2F0C279DC5D16F5860AC794A42DBF348BE10C,
	ScrollEvent__ctor_m06B78DA1F2D17D41E358CFE8A5303B3B760CBD45,
	U3CClickRepeatU3Ed__58__ctor_mBFBEBC50DB8C258BECD2372CBA491271F7866A94,
	U3CClickRepeatU3Ed__58_System_IDisposable_Dispose_mC5DADB5D35A04AAAD800A6DE0C2B2BF7EE628670,
	U3CClickRepeatU3Ed__58_MoveNext_m7DE3E913BC69A7E53056DA1CA14BF4ABCE78F0C1,
	U3CClickRepeatU3Ed__58_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mCAECE6E345E23E8B2F5266515DCBDFC051779351,
	U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_Reset_mFCBD2FB123CFE07B6A744AE0AA06DF2F09ADD9E8,
	U3CClickRepeatU3Ed__58_System_Collections_IEnumerator_get_Current_m73011B6FFFA6257338144C3013F636D167A0F239,
	SliderEvent__ctor_mF221080DF1ADA94469050E30297C3ED8CC6B6D24,
	MatEntry__ctor_mDD389E021313269F8B45DA142B419FC014A7D1CC,
	ToggleEvent__ctor_mA38AE97395D2AC75ABDE8169DC9BFF161A78F494,
	U3CU3Ec__cctor_mF0A991CBD937F58641CCE6D69CFCED6FF02A8F5C,
	U3CU3Ec__ctor_m9BBD797B8CE015A39E73055C7471D8C8A3F13381,
	U3CU3Ec_U3CAnyTogglesOnU3Eb__12_0_mE4A42BB2B94473E501CB14421D2843BAACE48417,
	U3CU3Ec_U3CActiveTogglesU3Eb__13_0_m031EB01E70BF3EBB9A4066C1EC4431A559681ED2,
	Raycast3DCallback__ctor_m339AEB26F1488FF3945EEA5BD87C1AB67F9820F7,
	Raycast3DCallback_Invoke_m469DFE4719293B1D78F3F0F86219AC5A79C27B87,
	Raycast3DCallback_BeginInvoke_m1E07393535ADFE57FEA2C62286D721C1F3BD9F57,
	Raycast3DCallback_EndInvoke_mE57B7F3B0D593061B150CD4CD5E1F2EBF73B8CCC,
	RaycastAllCallback__ctor_mDEFB87C693C497DC24D704110C1747EEE784EB94,
	RaycastAllCallback_Invoke_mCB0725E11A9E028E20E64D78BCA8D9029CAE051E,
	RaycastAllCallback_BeginInvoke_m654E38089CE2E40935AA5E0B41EA7CBA6924FB15,
	RaycastAllCallback_EndInvoke_m6527130511F1A69C6B17EFA46E35A36D39884427,
	GetRaycastNonAllocCallback__ctor_mCA532FF9C719E0D5A57EACF6B85D16E6340068E6,
	GetRaycastNonAllocCallback_Invoke_mF56C0670E33CB12DF1A8C16277E26A56EE1C7E20,
	GetRaycastNonAllocCallback_BeginInvoke_m72F0FCDE242E416E080760158AF6AE3FA64B61E1,
	GetRaycastNonAllocCallback_EndInvoke_m0F00432AB5ED1F37BEA57083436E40FA97AD86C8,
	Raycast2DCallback__ctor_m0B4E563C73D95692021593B5FB8B75B93708C777,
	Raycast2DCallback_Invoke_m5842F896DD5C69D38E09CB7933F2ECE794D393A7,
	Raycast2DCallback_BeginInvoke_m0425889D38743CAB9B5E4C1072686CD30288269E,
	Raycast2DCallback_EndInvoke_mFAD1B572AB085E448AFF551437592063BDAFB882,
	GetRayIntersectionAllCallback__ctor_mB6548565EC361C677EB7E6ACA7008CB6378A3EA9,
	GetRayIntersectionAllCallback_Invoke_m659B47C0727BE9179B3A96FD36AEA5216E66046D,
	GetRayIntersectionAllCallback_BeginInvoke_m5E96B335A5D1D40E6793A91108341E18D06656C0,
	GetRayIntersectionAllCallback_EndInvoke_mAA0209777FD43C9E9023997D5BFD33FA36933490,
	GetRayIntersectionAllNonAllocCallback__ctor_m0EEAD5F4542FBADC0BEA6C39E44079A2FD355AF0,
	GetRayIntersectionAllNonAllocCallback_Invoke_m6AAA07D1E9D27E50C3C647F368AA504E2A1BFE9B,
	GetRayIntersectionAllNonAllocCallback_BeginInvoke_m21B8BAA2ED3A96EA9552939003DC8E30093DCDFA,
	GetRayIntersectionAllNonAllocCallback_EndInvoke_mDAD7394A68B735336E89CE7690206B55C739D44B,
	ColorTweenCallback__ctor_m7F7918E559131B5A1480199E6DC9B03A533D644D,
	FloatTweenCallback__ctor_mE8AC174FE27E1A12832510D461316FEA939BD2F3,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	TriggerEvent__ctor_m5FA4AD9F5E1671A1F7F4C45AB1620624FEFC5F13,
	Entry__ctor_m646E309104AA1D549A0C07B948BE183013A927BF,
	NULL,
	NULL,
	NULL,
	NULL,
	U3CU3Ec__cctor_m61F9115D2905902E74081C1270593040BE0D9F4B,
	U3CU3Ec__ctor_mA3946064CEB17BF67A4B63F6E1716F3F7F27803A,
	U3CU3Ec_U3C_cctorU3Eb__79_0_mC9A9AAD60D24FC76EFD98E83E9DAF5EECAABCD56,
	ButtonState_get_eventData_mA9D054D526473A2481A997758CDDEB022E67351D,
	ButtonState_set_eventData_m844CA9F09A826E89AF0F8F137C016D96C71B30BD,
	ButtonState_get_button_mB538B2D483C482A7E628D26BA390449A54C958A3,
	ButtonState_set_button_mCC7BFBDDA9AA0710CBB64C456583CDCBAD227971,
	ButtonState__ctor_mECE4E89A3E0BAD4B2C1E14E142DD30893CA7267A,
	MouseState_AnyPressesThisFrame_m82FC431EAEE7573E5748685923194D4EB9540E2D,
	MouseState_AnyReleasesThisFrame_m330B78224B8AB1177B9BC160BDC015D3A9DB9309,
	MouseState_GetButtonState_m0C2884609F720A284C72EAEF061C781F4874CCAE,
	MouseState_SetButtonState_mE7B149E168AC34F69B504C797B1AA9E70122AFC2,
	MouseState__ctor_m03EB3CF8C4BEA925F63C1BA8197C3FA632975F09,
	MouseButtonEventData_PressedThisFrame_m9437D00FBF27F51132154FA11AE9463377FDF86A,
	MouseButtonEventData_ReleasedThisFrame_mD40162D1107F3C7EC2B560C415B20FD260051BB6,
	MouseButtonEventData__ctor_m2A5351DCA22508A2E1D85890CD69D223F4926A25,
	RaycastHitComparer_Compare_m5A17D56D0EF75419CCCAEFE522E86A44C1EFD46B,
	RaycastHitComparer__ctor_m1039CBA952391889242A9F00EA05958986E392B2,
	RaycastHitComparer__cctor_m1CEECC8D87DDE7315C8F0845658FC13E34CD4A31,
};
extern void ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905_AdjustorThunk (void);
extern void ColorBlock_set_normalColor_mF36865F66914F3902ACAF7E64B3E6C664EA81911_AdjustorThunk (void);
extern void ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF_AdjustorThunk (void);
extern void ColorBlock_set_highlightedColor_mAE0BF4A697744D841048D8BE9A0C8963226B4B3A_AdjustorThunk (void);
extern void ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5_AdjustorThunk (void);
extern void ColorBlock_set_pressedColor_mAE69CAEBA8CA45E089F6C7CA2F1B8C530705E70B_AdjustorThunk (void);
extern void ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D_AdjustorThunk (void);
extern void ColorBlock_set_selectedColor_mA8B032467C571D28563D91766B0E956FB265ACC9_AdjustorThunk (void);
extern void ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8_AdjustorThunk (void);
extern void ColorBlock_set_disabledColor_m530D0573E0257BAB82F2FFEA0E22C743911B4588_AdjustorThunk (void);
extern void ColorBlock_get_colorMultiplier_m8B3021855566FCCBD41100EB2B70B18172064DC5_AdjustorThunk (void);
extern void ColorBlock_set_colorMultiplier_m815DE55D842A1480A11D1051D559D9B63EE34672_AdjustorThunk (void);
extern void ColorBlock_get_fadeDuration_mD5EA922E1FA90C1BA224652C1DFC25FEE93830D5_AdjustorThunk (void);
extern void ColorBlock_set_fadeDuration_mE31362D1331C613F27505EB7581A734A2E58C917_AdjustorThunk (void);
extern void ColorBlock_Equals_mCA2055CA21C85A585504A447B3B048480BB7AB21_AdjustorThunk (void);
extern void ColorBlock_Equals_m3768CE3E85F9FD55FCA305EA20FF33983B4DB26C_AdjustorThunk (void);
extern void ColorBlock_GetHashCode_m1F4A5EC52681DEE9C205F4A5C5A60051DAF71111_AdjustorThunk (void);
extern void Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E_AdjustorThunk (void);
extern void Navigation_set_mode_m35D711F016E4F41230C710882696279BA04399D2_AdjustorThunk (void);
extern void Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E_AdjustorThunk (void);
extern void Navigation_set_selectOnUp_mB61F72B8B577FB9424150F42EC57767A8F3B4453_AdjustorThunk (void);
extern void Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398_AdjustorThunk (void);
extern void Navigation_set_selectOnDown_m0EEC959195918EDDBF71B0D640D42BB85061D0A5_AdjustorThunk (void);
extern void Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA_AdjustorThunk (void);
extern void Navigation_set_selectOnLeft_m51D5BC3AE8C05E4233269B961ADA98BB3FBF9D53_AdjustorThunk (void);
extern void Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328_AdjustorThunk (void);
extern void Navigation_set_selectOnRight_m3429A471ECA0295B871C161960FB3F8C1D1D3571_AdjustorThunk (void);
extern void Navigation_Equals_mBAEC72440C03A77E0981AD0FEFDFF823984B7CE0_AdjustorThunk (void);
extern void SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0_AdjustorThunk (void);
extern void SpriteState_set_highlightedSprite_mC897DA30106251AC1865FD7FD26BD987AC3EFE83_AdjustorThunk (void);
extern void SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB_AdjustorThunk (void);
extern void SpriteState_set_pressedSprite_m29B2F72FB74B08A85E99BAB26A73C18C96CEEE6C_AdjustorThunk (void);
extern void SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B_AdjustorThunk (void);
extern void SpriteState_set_selectedSprite_m5A23CA415AF8956BC3507C8DD7FEE57C3EB34951_AdjustorThunk (void);
extern void SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57_AdjustorThunk (void);
extern void SpriteState_set_disabledSprite_m57C60F8DAF18851169F170BE37787FC3EEDF23D2_AdjustorThunk (void);
extern void SpriteState_Equals_mD9E480FA2D996155ED689F6BA29917273DF036E2_AdjustorThunk (void);
extern void ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6_AdjustorThunk (void);
extern void ColorTween_set_startColor_mA57B5D1E4C2FA32133D13E91D9B07253CCF3BFD8_AdjustorThunk (void);
extern void ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF_AdjustorThunk (void);
extern void ColorTween_set_targetColor_mB57B42752260A735D6F174F925822756088DAD26_AdjustorThunk (void);
extern void ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB_AdjustorThunk (void);
extern void ColorTween_set_tweenMode_m2C089877F55E0D82F68BFC3EEC33737F7D3D9E54_AdjustorThunk (void);
extern void ColorTween_get_duration_m7E952A00A8A606D7886422812EFB24A6D5BFB508_AdjustorThunk (void);
extern void ColorTween_set_duration_mA6144F511A40F04787D3BEEAB4A0C0EBD66ADB5C_AdjustorThunk (void);
extern void ColorTween_get_ignoreTimeScale_mF935C53CA27D67D47AE0021A0DB8D92C392EF56B_AdjustorThunk (void);
extern void ColorTween_set_ignoreTimeScale_m4B2110395267132EB58541D4355630D0DB466512_AdjustorThunk (void);
extern void ColorTween_TweenValue_m4EF3CDDDDC3986BA6D06D4DB785310B131958749_AdjustorThunk (void);
extern void ColorTween_AddOnChangedCallback_mF516F2C835133EB59CB28895961716360131D82D_AdjustorThunk (void);
extern void ColorTween_GetIgnoreTimescale_m1F87CC0531F370154DF63095DA34F0F88E1DDAF6_AdjustorThunk (void);
extern void ColorTween_GetDuration_mFE7A52AFDCA53B1CCB79D1E3577037A0E44F17C5_AdjustorThunk (void);
extern void ColorTween_ValidTarget_mA5469658CB631C87CF97FC5AE2B9089A06678696_AdjustorThunk (void);
extern void FloatTween_get_startValue_m90C461E4383568718E362BF3CB14F14D45585B0A_AdjustorThunk (void);
extern void FloatTween_set_startValue_m281ACCD10E8DCB7ADED2B25EB093EE5DCFFF57D8_AdjustorThunk (void);
extern void FloatTween_get_targetValue_mAC9AD7101F181AA03EEA21EBE047376A27B18DC2_AdjustorThunk (void);
extern void FloatTween_set_targetValue_m948DD0F17FE536F38BFA213D13711B781934165F_AdjustorThunk (void);
extern void FloatTween_get_duration_m17CD4518038CD642D714B3633236133D309EF13B_AdjustorThunk (void);
extern void FloatTween_set_duration_m81021898C4F8F1F4D434CA46EAC596E0CC0F200B_AdjustorThunk (void);
extern void FloatTween_get_ignoreTimeScale_m8281CB2B12F1697A512D2E2515F5DA058B429FD0_AdjustorThunk (void);
extern void FloatTween_set_ignoreTimeScale_mC586D01F34D6C88892AB3C70A3298C4C7C45EA4D_AdjustorThunk (void);
extern void FloatTween_TweenValue_m78FEB902E18BE0882BC487BC29B6EA3905E4F05C_AdjustorThunk (void);
extern void FloatTween_AddOnChangedCallback_mADD5FACCDFA9E77C08CA65B8E5D33AE06DB79D50_AdjustorThunk (void);
extern void FloatTween_GetIgnoreTimescale_m8FDD9D59F72DBC2CDEDD71A522ADD6DAD1438BE8_AdjustorThunk (void);
extern void FloatTween_GetDuration_m1022A6824C91E5C51E1F7FCD27B9D60D6E83EDB7_AdjustorThunk (void);
extern void FloatTween_ValidTarget_m7DFE9AC7C8C0EBEF441D80472635CF4F38632E5E_AdjustorThunk (void);
extern void RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD_AdjustorThunk (void);
extern void RaycastResult_set_gameObject_m5EF3316E0D32FC1B45BB2BC087EC42E436DA1C07_AdjustorThunk (void);
extern void RaycastResult_get_isValid_m53278AA3529BC7B909A9AA082026D51CE6926813_AdjustorThunk (void);
extern void RaycastResult_Clear_m5C979A22E0B12FBD7BA035FE0815B4D81E82E9F7_AdjustorThunk (void);
extern void RaycastResult_ToString_mFD0F27611425231BAF089CEBB0332FEFD7FB9E21_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[70] = 
{
	{ 0x0600002B, ColorBlock_get_normalColor_mE0A4EBADEFB7A6F245F590B0A5DBB59F289C0905_AdjustorThunk },
	{ 0x0600002C, ColorBlock_set_normalColor_mF36865F66914F3902ACAF7E64B3E6C664EA81911_AdjustorThunk },
	{ 0x0600002D, ColorBlock_get_highlightedColor_m779349828B304DB2551C3A3CCDDD69861A21EDFF_AdjustorThunk },
	{ 0x0600002E, ColorBlock_set_highlightedColor_mAE0BF4A697744D841048D8BE9A0C8963226B4B3A_AdjustorThunk },
	{ 0x0600002F, ColorBlock_get_pressedColor_m19AA95DCC2519975D93202C997EECB3E06CE96E5_AdjustorThunk },
	{ 0x06000030, ColorBlock_set_pressedColor_mAE69CAEBA8CA45E089F6C7CA2F1B8C530705E70B_AdjustorThunk },
	{ 0x06000031, ColorBlock_get_selectedColor_mE6DDB9D2D3466CCFFFF000286619BEC4AB60F83D_AdjustorThunk },
	{ 0x06000032, ColorBlock_set_selectedColor_mA8B032467C571D28563D91766B0E956FB265ACC9_AdjustorThunk },
	{ 0x06000033, ColorBlock_get_disabledColor_mD865FC8BCFE7B8535A51A68E78130409F3C97FC8_AdjustorThunk },
	{ 0x06000034, ColorBlock_set_disabledColor_m530D0573E0257BAB82F2FFEA0E22C743911B4588_AdjustorThunk },
	{ 0x06000035, ColorBlock_get_colorMultiplier_m8B3021855566FCCBD41100EB2B70B18172064DC5_AdjustorThunk },
	{ 0x06000036, ColorBlock_set_colorMultiplier_m815DE55D842A1480A11D1051D559D9B63EE34672_AdjustorThunk },
	{ 0x06000037, ColorBlock_get_fadeDuration_mD5EA922E1FA90C1BA224652C1DFC25FEE93830D5_AdjustorThunk },
	{ 0x06000038, ColorBlock_set_fadeDuration_mE31362D1331C613F27505EB7581A734A2E58C917_AdjustorThunk },
	{ 0x0600003A, ColorBlock_Equals_mCA2055CA21C85A585504A447B3B048480BB7AB21_AdjustorThunk },
	{ 0x0600003B, ColorBlock_Equals_m3768CE3E85F9FD55FCA305EA20FF33983B4DB26C_AdjustorThunk },
	{ 0x0600003E, ColorBlock_GetHashCode_m1F4A5EC52681DEE9C205F4A5C5A60051DAF71111_AdjustorThunk },
	{ 0x060002EA, Navigation_get_mode_m3C77554140D0A56ACD06B1E6DB2D016F080FB95E_AdjustorThunk },
	{ 0x060002EB, Navigation_set_mode_m35D711F016E4F41230C710882696279BA04399D2_AdjustorThunk },
	{ 0x060002EC, Navigation_get_selectOnUp_m8E3A8A4358C862B402C322E93062E10F22371A0E_AdjustorThunk },
	{ 0x060002ED, Navigation_set_selectOnUp_mB61F72B8B577FB9424150F42EC57767A8F3B4453_AdjustorThunk },
	{ 0x060002EE, Navigation_get_selectOnDown_mC9469ADD19689D5D263A39861E70E43A75BB9398_AdjustorThunk },
	{ 0x060002EF, Navigation_set_selectOnDown_m0EEC959195918EDDBF71B0D640D42BB85061D0A5_AdjustorThunk },
	{ 0x060002F0, Navigation_get_selectOnLeft_m1B2D71E749D06A2D89855AE6715DBD253BC623FA_AdjustorThunk },
	{ 0x060002F1, Navigation_set_selectOnLeft_m51D5BC3AE8C05E4233269B961ADA98BB3FBF9D53_AdjustorThunk },
	{ 0x060002F2, Navigation_get_selectOnRight_mD44071FB2CBE195EBD6EBF37437C3F5BBFA5B328_AdjustorThunk },
	{ 0x060002F3, Navigation_set_selectOnRight_m3429A471ECA0295B871C161960FB3F8C1D1D3571_AdjustorThunk },
	{ 0x060002F5, Navigation_Equals_mBAEC72440C03A77E0981AD0FEFDFF823984B7CE0_AdjustorThunk },
	{ 0x06000407, SpriteState_get_highlightedSprite_mB8CB5AD077F9FDA5A7DA9B0700B70FEB471B15F0_AdjustorThunk },
	{ 0x06000408, SpriteState_set_highlightedSprite_mC897DA30106251AC1865FD7FD26BD987AC3EFE83_AdjustorThunk },
	{ 0x06000409, SpriteState_get_pressedSprite_m42EB6FFB954E6BDC6384B5DCDD7348DE4F7D44EB_AdjustorThunk },
	{ 0x0600040A, SpriteState_set_pressedSprite_m29B2F72FB74B08A85E99BAB26A73C18C96CEEE6C_AdjustorThunk },
	{ 0x0600040B, SpriteState_get_selectedSprite_mC69216B3ABE6539D061E34707C086FA76F28FF5B_AdjustorThunk },
	{ 0x0600040C, SpriteState_set_selectedSprite_m5A23CA415AF8956BC3507C8DD7FEE57C3EB34951_AdjustorThunk },
	{ 0x0600040D, SpriteState_get_disabledSprite_m08ED7B54CD394C0CE044519A296600DFF14D0B57_AdjustorThunk },
	{ 0x0600040E, SpriteState_set_disabledSprite_m57C60F8DAF18851169F170BE37787FC3EEDF23D2_AdjustorThunk },
	{ 0x0600040F, SpriteState_Equals_mD9E480FA2D996155ED689F6BA29917273DF036E2_AdjustorThunk },
	{ 0x060004BA, ColorTween_get_startColor_mA979B663DFD611DAC95F4A7B98AA36E24EE5E3D6_AdjustorThunk },
	{ 0x060004BB, ColorTween_set_startColor_mA57B5D1E4C2FA32133D13E91D9B07253CCF3BFD8_AdjustorThunk },
	{ 0x060004BC, ColorTween_get_targetColor_m2620FDCF03617764286DCDF8000AA3BE59C9E7AF_AdjustorThunk },
	{ 0x060004BD, ColorTween_set_targetColor_mB57B42752260A735D6F174F925822756088DAD26_AdjustorThunk },
	{ 0x060004BE, ColorTween_get_tweenMode_m908DEFB153497AC18AD08CB73AFF655C1F6D05FB_AdjustorThunk },
	{ 0x060004BF, ColorTween_set_tweenMode_m2C089877F55E0D82F68BFC3EEC33737F7D3D9E54_AdjustorThunk },
	{ 0x060004C0, ColorTween_get_duration_m7E952A00A8A606D7886422812EFB24A6D5BFB508_AdjustorThunk },
	{ 0x060004C1, ColorTween_set_duration_mA6144F511A40F04787D3BEEAB4A0C0EBD66ADB5C_AdjustorThunk },
	{ 0x060004C2, ColorTween_get_ignoreTimeScale_mF935C53CA27D67D47AE0021A0DB8D92C392EF56B_AdjustorThunk },
	{ 0x060004C3, ColorTween_set_ignoreTimeScale_m4B2110395267132EB58541D4355630D0DB466512_AdjustorThunk },
	{ 0x060004C4, ColorTween_TweenValue_m4EF3CDDDDC3986BA6D06D4DB785310B131958749_AdjustorThunk },
	{ 0x060004C5, ColorTween_AddOnChangedCallback_mF516F2C835133EB59CB28895961716360131D82D_AdjustorThunk },
	{ 0x060004C6, ColorTween_GetIgnoreTimescale_m1F87CC0531F370154DF63095DA34F0F88E1DDAF6_AdjustorThunk },
	{ 0x060004C7, ColorTween_GetDuration_mFE7A52AFDCA53B1CCB79D1E3577037A0E44F17C5_AdjustorThunk },
	{ 0x060004C8, ColorTween_ValidTarget_mA5469658CB631C87CF97FC5AE2B9089A06678696_AdjustorThunk },
	{ 0x060004C9, FloatTween_get_startValue_m90C461E4383568718E362BF3CB14F14D45585B0A_AdjustorThunk },
	{ 0x060004CA, FloatTween_set_startValue_m281ACCD10E8DCB7ADED2B25EB093EE5DCFFF57D8_AdjustorThunk },
	{ 0x060004CB, FloatTween_get_targetValue_mAC9AD7101F181AA03EEA21EBE047376A27B18DC2_AdjustorThunk },
	{ 0x060004CC, FloatTween_set_targetValue_m948DD0F17FE536F38BFA213D13711B781934165F_AdjustorThunk },
	{ 0x060004CD, FloatTween_get_duration_m17CD4518038CD642D714B3633236133D309EF13B_AdjustorThunk },
	{ 0x060004CE, FloatTween_set_duration_m81021898C4F8F1F4D434CA46EAC596E0CC0F200B_AdjustorThunk },
	{ 0x060004CF, FloatTween_get_ignoreTimeScale_m8281CB2B12F1697A512D2E2515F5DA058B429FD0_AdjustorThunk },
	{ 0x060004D0, FloatTween_set_ignoreTimeScale_mC586D01F34D6C88892AB3C70A3298C4C7C45EA4D_AdjustorThunk },
	{ 0x060004D1, FloatTween_TweenValue_m78FEB902E18BE0882BC487BC29B6EA3905E4F05C_AdjustorThunk },
	{ 0x060004D2, FloatTween_AddOnChangedCallback_mADD5FACCDFA9E77C08CA65B8E5D33AE06DB79D50_AdjustorThunk },
	{ 0x060004D3, FloatTween_GetIgnoreTimescale_m8FDD9D59F72DBC2CDEDD71A522ADD6DAD1438BE8_AdjustorThunk },
	{ 0x060004D4, FloatTween_GetDuration_m1022A6824C91E5C51E1F7FCD27B9D60D6E83EDB7_AdjustorThunk },
	{ 0x060004D5, FloatTween_ValidTarget_m7DFE9AC7C8C0EBEF441D80472635CF4F38632E5E_AdjustorThunk },
	{ 0x060005F1, RaycastResult_get_gameObject_m9D77DEDFF498BAFE29A5F88E9F238400D04C8FDD_AdjustorThunk },
	{ 0x060005F2, RaycastResult_set_gameObject_m5EF3316E0D32FC1B45BB2BC087EC42E436DA1C07_AdjustorThunk },
	{ 0x060005F3, RaycastResult_get_isValid_m53278AA3529BC7B909A9AA082026D51CE6926813_AdjustorThunk },
	{ 0x060005F4, RaycastResult_Clear_m5C979A22E0B12FBD7BA035FE0815B4D81E82E9F7_AdjustorThunk },
	{ 0x060005F5, RaycastResult_ToString_mFD0F27611425231BAF089CEBB0332FEFD7FB9E21_AdjustorThunk },
};
static const int32_t s_InvokerIndices[1727] = 
{
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	23,
	14,
	26,
	23,
	26,
	26,
	14,
	32,
	14,
	23,
	23,
	89,
	23,
	4,
	9,
	23,
	23,
	94,
	143,
	159,
	116,
	9,
	159,
	116,
	9,
	159,
	26,
	26,
	49,
	49,
	3,
	1329,
	1330,
	1329,
	1330,
	1329,
	1330,
	1329,
	1330,
	1329,
	1330,
	728,
	338,
	728,
	338,
	1854,
	9,
	1855,
	1856,
	1856,
	10,
	23,
	4,
	23,
	159,
	159,
	1857,
	23,
	14,
	23,
	14,
	1858,
	1858,
	1355,
	1859,
	23,
	4,
	1860,
	2,
	159,
	159,
	142,
	374,
	1861,
	1861,
	1861,
	1861,
	1861,
	1861,
	1861,
	1861,
	1861,
	1861,
	1861,
	3,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	728,
	338,
	10,
	32,
	32,
	139,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	23,
	23,
	-1,
	26,
	26,
	26,
	23,
	28,
	26,
	28,
	26,
	28,
	26,
	850,
	1439,
	1419,
	338,
	23,
	664,
	23,
	26,
	3,
	4,
	14,
	26,
	10,
	32,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	89,
	31,
	89,
	31,
	10,
	32,
	10,
	32,
	728,
	338,
	23,
	23,
	23,
	159,
	159,
	159,
	3,
	4,
	1329,
	1330,
	89,
	31,
	89,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	10,
	14,
	14,
	23,
	14,
	14,
	14,
	26,
	14,
	14,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	4,
	26,
	26,
	26,
	23,
	23,
	1789,
	1862,
	1331,
	1863,
	1864,
	1865,
	1866,
	26,
	26,
	26,
	26,
	26,
	26,
	3,
	14,
	10,
	10,
	89,
	31,
	10,
	32,
	23,
	14,
	27,
	14,
	1867,
	3,
	23,
	4,
	142,
	142,
	0,
	3,
	23,
	89,
	14,
	23,
	14,
	26,
	23,
	14,
	26,
	14,
	10,
	32,
	89,
	31,
	89,
	31,
	10,
	32,
	728,
	338,
	89,
	31,
	10,
	32,
	728,
	338,
	728,
	338,
	89,
	31,
	23,
	4,
	14,
	89,
	728,
	338,
	728,
	728,
	14,
	26,
	23,
	23,
	1868,
	1869,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	457,
	457,
	26,
	26,
	1870,
	1871,
	1872,
	457,
	1873,
	1874,
	23,
	23,
	728,
	728,
	728,
	728,
	728,
	728,
	10,
	1789,
	1875,
	159,
	159,
	159,
	23,
	3,
	14,
	14,
	23,
	14,
	14,
	31,
	89,
	31,
	89,
	14,
	26,
	26,
	457,
	89,
	728,
	338,
	10,
	32,
	14,
	26,
	14,
	26,
	1329,
	1330,
	89,
	31,
	1329,
	1330,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	14,
	10,
	32,
	10,
	32,
	89,
	31,
	89,
	241,
	607,
	89,
	6,
	10,
	32,
	10,
	32,
	89,
	10,
	32,
	10,
	32,
	10,
	32,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	31,
	31,
	4,
	159,
	89,
	23,
	23,
	1862,
	1876,
	1877,
	9,
	26,
	26,
	28,
	26,
	26,
	112,
	234,
	26,
	26,
	14,
	10,
	42,
	10,
	42,
	1878,
	118,
	118,
	31,
	42,
	31,
	42,
	23,
	23,
	23,
	607,
	23,
	23,
	23,
	23,
	26,
	607,
	23,
	89,
	114,
	114,
	32,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	26,
	1387,
	23,
	1387,
	1879,
	23,
	23,
	26,
	26,
	23,
	26,
	26,
	23,
	23,
	26,
	23,
	139,
	23,
	23,
	728,
	728,
	728,
	728,
	728,
	728,
	10,
	3,
	14,
	10,
	32,
	728,
	338,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	1881,
	1354,
	23,
	23,
	23,
	10,
	32,
	728,
	338,
	728,
	338,
	1354,
	1355,
	10,
	32,
	728,
	338,
	10,
	32,
	728,
	338,
	728,
	338,
	728,
	338,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	338,
	338,
	10,
	32,
	10,
	32,
	14,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	10,
	32,
	10,
	32,
	1354,
	1355,
	1354,
	1355,
	10,
	32,
	10,
	32,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	728,
	338,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	139,
	139,
	1882,
	23,
	23,
	23,
	728,
	728,
	728,
	728,
	728,
	728,
	10,
	23,
	23,
	89,
	89,
	31,
	23,
	23,
	728,
	338,
	728,
	338,
	728,
	338,
	728,
	338,
	728,
	338,
	728,
	338,
	10,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	26,
	10,
	32,
	14,
	14,
	23,
	23,
	728,
	728,
	728,
	728,
	728,
	728,
	10,
	23,
	23,
	23,
	23,
	23,
	23,
	1380,
	1380,
	1380,
	1883,
	1380,
	1884,
	1885,
	1886,
	1886,
	1887,
	89,
	23,
	23,
	-1,
	23,
	28,
	26,
	23,
	3,
	159,
	14,
	89,
	159,
	159,
	32,
	27,
	27,
	159,
	121,
	159,
	23,
	23,
	10,
	9,
	14,
	23,
	100,
	100,
	100,
	1555,
	1555,
	1555,
	1555,
	1555,
	1555,
	1888,
	1889,
	23,
	23,
	23,
	23,
	23,
	14,
	89,
	31,
	14,
	23,
	89,
	23,
	23,
	23,
	1789,
	28,
	159,
	159,
	0,
	143,
	121,
	0,
	142,
	23,
	14,
	26,
	89,
	31,
	89,
	31,
	28,
	1858,
	31,
	1858,
	1355,
	23,
	23,
	23,
	23,
	23,
	1331,
	23,
	23,
	23,
	23,
	14,
	28,
	159,
	159,
	220,
	1470,
	10,
	32,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	1890,
	1891,
	23,
	14,
	14,
	26,
	1331,
	1351,
	23,
	26,
	23,
	1502,
	1892,
	1893,
	1894,
	14,
	1331,
	14,
	23,
	23,
	23,
	1789,
	1331,
	23,
	23,
	26,
	26,
	23,
	23,
	14,
	26,
	89,
	31,
	89,
	31,
	10,
	32,
	728,
	338,
	89,
	31,
	728,
	338,
	728,
	338,
	14,
	26,
	14,
	26,
	14,
	26,
	10,
	32,
	10,
	32,
	728,
	338,
	728,
	338,
	14,
	26,
	14,
	1354,
	1355,
	14,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	89,
	23,
	23,
	26,
	26,
	26,
	26,
	26,
	1355,
	23,
	23,
	1355,
	1354,
	1355,
	728,
	338,
	728,
	338,
	338,
	338,
	1895,
	443,
	23,
	89,
	89,
	23,
	23,
	728,
	728,
	728,
	728,
	728,
	728,
	10,
	23,
	23,
	23,
	1896,
	23,
	23,
	1435,
	1377,
	1897,
	1862,
	1898,
	23,
	23,
	14,
	14,
	26,
	10,
	32,
	23,
	728,
	338,
	338,
	728,
	338,
	10,
	32,
	14,
	26,
	728,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	1899,
	23,
	10,
	89,
	23,
	26,
	1900,
	9,
	26,
	26,
	26,
	28,
	1901,
	26,
	26,
	14,
	14,
	14,
	14,
	26,
	139,
	14,
	4,
	106,
	4,
	94,
	1902,
	1903,
	10,
	32,
	1904,
	1905,
	1906,
	1907,
	14,
	26,
	14,
	26,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	23,
	14,
	26,
	14,
	23,
	23,
	89,
	23,
	23,
	23,
	23,
	23,
	10,
	23,
	139,
	1908,
	1909,
	27,
	14,
	14,
	14,
	14,
	26,
	1910,
	26,
	26,
	89,
	89,
	23,
	26,
	26,
	26,
	26,
	26,
	26,
	23,
	3,
	1911,
	-1,
	-1,
	14,
	26,
	14,
	26,
	10,
	32,
	728,
	338,
	728,
	338,
	89,
	31,
	728,
	338,
	338,
	728,
	338,
	14,
	26,
	728,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	1328,
	1899,
	23,
	10,
	89,
	23,
	27,
	9,
	26,
	26,
	26,
	14,
	14,
	14,
	14,
	26,
	139,
	14,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	1912,
	115,
	1913,
	1914,
	159,
	3,
	3,
	23,
	14,
	14,
	14,
	23,
	14,
	26,
	14,
	26,
	89,
	31,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	728,
	338,
	10,
	32,
	728,
	23,
	23,
	23,
	23,
	1915,
	1916,
	26,
	23,
	23,
	728,
	728,
	728,
	728,
	728,
	728,
	10,
	3,
	14,
	26,
	23,
	32,
	23,
	23,
	23,
	23,
	23,
	23,
	457,
	89,
	31,
	31,
	42,
	31,
	23,
	23,
	26,
	26,
	14,
	89,
	31,
	23,
	23,
	26,
	457,
	26,
	26,
	23,
	89,
	14,
	31,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	23,
	4,
	3,
	23,
	26,
	23,
	23,
	23,
	10,
	10,
	64,
	1926,
	26,
	1927,
	1928,
	1929,
	1930,
	38,
	26,
	27,
	26,
	26,
	3,
	26,
	23,
	14,
	23,
	23,
	23,
	26,
	26,
	23,
	26,
	26,
	26,
	23,
	26,
	23,
	26,
	23,
	1329,
	1330,
	1354,
	1355,
	89,
	31,
	1931,
	1931,
	26,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	338,
	89,
	728,
	89,
	1329,
	1330,
	1329,
	1330,
	10,
	32,
	728,
	338,
	89,
	31,
	338,
	26,
	89,
	728,
	89,
	728,
	338,
	728,
	338,
	728,
	338,
	89,
	31,
	338,
	26,
	89,
	728,
	89,
	-1,
	-1,
	-1,
	-1,
	-1,
	1354,
	1355,
	10,
	32,
	26,
	23,
	23,
	89,
	23,
	26,
	14,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	1932,
	1933,
	1932,
	1933,
	89,
	31,
	10,
	32,
	1354,
	1355,
	1354,
	1355,
	1354,
	1355,
	1344,
	1345,
	1344,
	1345,
	728,
	338,
	10,
	32,
	1354,
	1355,
	89,
	31,
	89,
	31,
	10,
	32,
	26,
	89,
	89,
	14,
	14,
	14,
	26,
	14,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	4,
	159,
	89,
	31,
	10,
	32,
	14,
	14,
	26,
	14,
	14,
	89,
	23,
	23,
	89,
	27,
	14,
	26,
	1934,
	27,
	89,
	30,
	23,
	23,
	23,
	31,
	23,
	26,
	14,
	3,
	14,
	26,
	23,
	14,
	26,
	62,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	26,
	-1,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	142,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	4,
	142,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	3,
	14,
	10,
	32,
	1354,
	1355,
	89,
	30,
	30,
	30,
	1354,
	1354,
	89,
	10,
	1935,
	223,
	9,
	23,
	14,
	14,
	26,
	14,
	23,
	23,
	23,
	1936,
	1937,
	1938,
	1,
	27,
	1939,
	14,
	30,
	89,
	23,
	23,
	23,
	89,
	23,
	1940,
	26,
	1941,
	27,
	37,
	14,
	34,
	34,
	1942,
	26,
	26,
	30,
	23,
	14,
	27,
	23,
	23,
	10,
	89,
	31,
	89,
	31,
	728,
	338,
	728,
	338,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	89,
	23,
	27,
	89,
	89,
	23,
	23,
	23,
	89,
	812,
	89,
	1354,
	89,
	23,
	89,
	32,
	89,
	26,
	14,
	23,
	89,
	31,
	89,
	31,
	23,
	89,
	89,
	89,
	23,
	23,
	23,
	812,
	23,
	14,
	14,
	26,
	89,
	23,
	14,
	159,
	4,
	159,
	3,
	27,
	14,
	10,
	10,
	10,
	14,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	27,
	23,
	14,
	10,
	10,
	1943,
	1724,
	10,
	32,
	1944,
	27,
	23,
	23,
	23,
	23,
	23,
	89,
	23,
	23,
	23,
	23,
	23,
	23,
	89,
	23,
	23,
	32,
	23,
	89,
	14,
	23,
	14,
	105,
	105,
	23,
	3,
	14,
	26,
	14,
	26,
	14,
	26,
	14,
	26,
	26,
	26,
	23,
	14,
	26,
	14,
	26,
	23,
	26,
	26,
	27,
	14,
	26,
	23,
	23,
	23,
	31,
	32,
	23,
	89,
	14,
	23,
	14,
	3,
	23,
	41,
	131,
	1879,
	1880,
	221,
	23,
	23,
	32,
	23,
	89,
	14,
	23,
	14,
	32,
	23,
	89,
	14,
	23,
	14,
	32,
	23,
	89,
	14,
	23,
	14,
	3,
	23,
	26,
	9,
	26,
	26,
	26,
	26,
	3,
	23,
	223,
	223,
	223,
	223,
	223,
	223,
	223,
	223,
	23,
	23,
	23,
	32,
	23,
	89,
	14,
	23,
	14,
	23,
	23,
	23,
	3,
	23,
	9,
	9,
	131,
	1917,
	1918,
	1919,
	131,
	1920,
	1921,
	28,
	131,
	1922,
	1923,
	112,
	131,
	1698,
	1924,
	1925,
	131,
	1920,
	1921,
	28,
	131,
	1922,
	1923,
	112,
	23,
	23,
	-1,
	-1,
	-1,
	-1,
	-1,
	-1,
	23,
	23,
	-1,
	-1,
	-1,
	-1,
	3,
	23,
	26,
	14,
	26,
	10,
	32,
	23,
	89,
	89,
	34,
	616,
	23,
	89,
	89,
	23,
	1945,
	23,
	3,
};
static const Il2CppTokenRangePair s_rgctxIndices[16] = 
{
	{ 0x0200003C, { 8, 9 } },
	{ 0x0200003D, { 17, 12 } },
	{ 0x02000047, { 29, 22 } },
	{ 0x0200004B, { 51, 6 } },
	{ 0x020000B8, { 57, 1 } },
	{ 0x0600007F, { 0, 3 } },
	{ 0x06000295, { 3, 1 } },
	{ 0x060003D6, { 4, 3 } },
	{ 0x060003D7, { 7, 1 } },
	{ 0x0600055C, { 58, 2 } },
	{ 0x06000580, { 60, 4 } },
	{ 0x06000581, { 64, 1 } },
	{ 0x06000582, { 65, 1 } },
	{ 0x06000583, { 66, 1 } },
	{ 0x06000584, { 67, 1 } },
	{ 0x06000585, { 68, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[69] = 
{
	{ (Il2CppRGCTXDataType)3, 12658 },
	{ (Il2CppRGCTXDataType)2, 18949 },
	{ (Il2CppRGCTXDataType)3, 12659 },
	{ (Il2CppRGCTXDataType)2, 19147 },
	{ (Il2CppRGCTXDataType)3, 12660 },
	{ (Il2CppRGCTXDataType)2, 21285 },
	{ (Il2CppRGCTXDataType)3, 12661 },
	{ (Il2CppRGCTXDataType)2, 19274 },
	{ (Il2CppRGCTXDataType)3, 12662 },
	{ (Il2CppRGCTXDataType)2, 21286 },
	{ (Il2CppRGCTXDataType)3, 12663 },
	{ (Il2CppRGCTXDataType)3, 12664 },
	{ (Il2CppRGCTXDataType)3, 12665 },
	{ (Il2CppRGCTXDataType)2, 21287 },
	{ (Il2CppRGCTXDataType)3, 12666 },
	{ (Il2CppRGCTXDataType)2, 21288 },
	{ (Il2CppRGCTXDataType)3, 12667 },
	{ (Il2CppRGCTXDataType)3, 12668 },
	{ (Il2CppRGCTXDataType)3, 12669 },
	{ (Il2CppRGCTXDataType)3, 12670 },
	{ (Il2CppRGCTXDataType)2, 21289 },
	{ (Il2CppRGCTXDataType)3, 12671 },
	{ (Il2CppRGCTXDataType)3, 12672 },
	{ (Il2CppRGCTXDataType)3, 12673 },
	{ (Il2CppRGCTXDataType)3, 12674 },
	{ (Il2CppRGCTXDataType)3, 12675 },
	{ (Il2CppRGCTXDataType)3, 12676 },
	{ (Il2CppRGCTXDataType)2, 19324 },
	{ (Il2CppRGCTXDataType)3, 12677 },
	{ (Il2CppRGCTXDataType)3, 12678 },
	{ (Il2CppRGCTXDataType)3, 12679 },
	{ (Il2CppRGCTXDataType)3, 12680 },
	{ (Il2CppRGCTXDataType)3, 12681 },
	{ (Il2CppRGCTXDataType)3, 12682 },
	{ (Il2CppRGCTXDataType)3, 12683 },
	{ (Il2CppRGCTXDataType)3, 12684 },
	{ (Il2CppRGCTXDataType)3, 12685 },
	{ (Il2CppRGCTXDataType)3, 12686 },
	{ (Il2CppRGCTXDataType)3, 12687 },
	{ (Il2CppRGCTXDataType)3, 12688 },
	{ (Il2CppRGCTXDataType)3, 12689 },
	{ (Il2CppRGCTXDataType)3, 12690 },
	{ (Il2CppRGCTXDataType)3, 12691 },
	{ (Il2CppRGCTXDataType)3, 12692 },
	{ (Il2CppRGCTXDataType)3, 12693 },
	{ (Il2CppRGCTXDataType)3, 12694 },
	{ (Il2CppRGCTXDataType)3, 12695 },
	{ (Il2CppRGCTXDataType)2, 21290 },
	{ (Il2CppRGCTXDataType)3, 12696 },
	{ (Il2CppRGCTXDataType)2, 21291 },
	{ (Il2CppRGCTXDataType)3, 12697 },
	{ (Il2CppRGCTXDataType)2, 21292 },
	{ (Il2CppRGCTXDataType)3, 12698 },
	{ (Il2CppRGCTXDataType)3, 12699 },
	{ (Il2CppRGCTXDataType)2, 19387 },
	{ (Il2CppRGCTXDataType)3, 12700 },
	{ (Il2CppRGCTXDataType)2, 21293 },
	{ (Il2CppRGCTXDataType)2, 21294 },
	{ (Il2CppRGCTXDataType)2, 19463 },
	{ (Il2CppRGCTXDataType)1, 19463 },
	{ (Il2CppRGCTXDataType)3, 12701 },
	{ (Il2CppRGCTXDataType)2, 19465 },
	{ (Il2CppRGCTXDataType)1, 19465 },
	{ (Il2CppRGCTXDataType)3, 12702 },
	{ (Il2CppRGCTXDataType)3, 12703 },
	{ (Il2CppRGCTXDataType)2, 21295 },
	{ (Il2CppRGCTXDataType)3, 12704 },
	{ (Il2CppRGCTXDataType)3, 12705 },
	{ (Il2CppRGCTXDataType)3, 12706 },
};
extern const Il2CppCodeGenModule g_UnityEngine_UICodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_UICodeGenModule = 
{
	"UnityEngine.UI.dll",
	1727,
	s_methodPointers,
	70,
	s_adjustorThunks,
	s_InvokerIndices,
	0,
	NULL,
	16,
	s_rgctxIndices,
	69,
	s_rgctxValues,
	NULL,
};
