﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"



extern const RuntimeMethod* EncryptorNative_OnNativeLog_m07553F096F482149F7B3DCEED091CD30B3245822_RuntimeMethod_var;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void ExitGames.Client.Photon.Hashtable::.ctor()
extern void Hashtable__ctor_mE996A03E5E1B26FE2BBBD341FD9A2136BE9B6CFA (void);
// 0x00000002 System.Void ExitGames.Client.Photon.Hashtable::.ctor(System.Int32)
extern void Hashtable__ctor_mCB9C9F7759F7E1E5CC8D849BF738138602743386 (void);
// 0x00000003 System.Object ExitGames.Client.Photon.Hashtable::get_Item(System.Object)
extern void Hashtable_get_Item_mEA0BC15131E914D1F8A751B2F267BB5E7EF53CCB (void);
// 0x00000004 System.Void ExitGames.Client.Photon.Hashtable::set_Item(System.Object,System.Object)
extern void Hashtable_set_Item_m8F5609AF5DD4CF7409FA6D7D5AD2EE5E62175790 (void);
// 0x00000005 System.String ExitGames.Client.Photon.Hashtable::ToString()
extern void Hashtable_ToString_m93A67EB6E2A579D0E2A0B96BD536414ED986A501 (void);
// 0x00000006 System.Void ExitGames.Client.Photon.EnetChannel::.ctor(System.Byte,System.Int32)
extern void EnetChannel__ctor_mD5AA95DE1F09EE5180201EB7D326B6548E587344 (void);
// 0x00000007 System.Boolean ExitGames.Client.Photon.EnetChannel::ContainsUnreliableSequenceNumber(System.Int32)
extern void EnetChannel_ContainsUnreliableSequenceNumber_mBF6ED1BEDB8495A2B3285347F1815D2596ED9940 (void);
// 0x00000008 System.Boolean ExitGames.Client.Photon.EnetChannel::ContainsReliableSequenceNumber(System.Int32)
extern void EnetChannel_ContainsReliableSequenceNumber_m4501E29890B5655E75FE717003FE2D120BAC308D (void);
// 0x00000009 ExitGames.Client.Photon.NCommand ExitGames.Client.Photon.EnetChannel::FetchReliableSequenceNumber(System.Int32)
extern void EnetChannel_FetchReliableSequenceNumber_m7A31D3584F4A1669D44AF0F14D59B2581B776D18 (void);
// 0x0000000A System.Boolean ExitGames.Client.Photon.EnetChannel::TryGetFragment(System.Int32,System.Boolean,ExitGames.Client.Photon.NCommand&)
extern void EnetChannel_TryGetFragment_m95F2CDF2572BBA651A812841FAF0C2BE19FE1B9E (void);
// 0x0000000B System.Void ExitGames.Client.Photon.EnetChannel::RemoveFragment(System.Int32,System.Boolean)
extern void EnetChannel_RemoveFragment_m60744DC70D856AF6C654C09970CB7CC85A9B0D3C (void);
// 0x0000000C System.Void ExitGames.Client.Photon.EnetChannel::clearAll()
extern void EnetChannel_clearAll_m8FA93E8874A0672CCF5D29CDFBDE9774E73A773A (void);
// 0x0000000D System.Boolean ExitGames.Client.Photon.EnetChannel::QueueIncomingReliableUnsequenced(ExitGames.Client.Photon.NCommand)
extern void EnetChannel_QueueIncomingReliableUnsequenced_m3EC60A99FD70DE943971BA33E87EE85113554370 (void);
// 0x0000000E System.Void ExitGames.Client.Photon.EnetPeer::.ctor()
extern void EnetPeer__ctor_mCE63D7CB59AEB131437E902E7AAC67BC3BB505CC (void);
// 0x0000000F System.Void ExitGames.Client.Photon.EnetPeer::InitPeerBase()
extern void EnetPeer_InitPeerBase_m85AA8DA6A4FFD733D8F4299D13E6E193F881AE54 (void);
// 0x00000010 System.Void ExitGames.Client.Photon.EnetPeer::ApplyRandomizedSequenceNumbers()
extern void EnetPeer_ApplyRandomizedSequenceNumbers_m59E5779349F0EFD409FB36B80A3560C51F940DA7 (void);
// 0x00000011 System.Boolean ExitGames.Client.Photon.EnetPeer::Connect(System.String,System.String,System.String,System.Object)
extern void EnetPeer_Connect_m38BAE9D792D1C322666E9DABA70962EBC600892E (void);
// 0x00000012 System.Void ExitGames.Client.Photon.EnetPeer::OnConnect()
extern void EnetPeer_OnConnect_m25EF6747DF94590FF8DF0D942CC3D682AE97F559 (void);
// 0x00000013 System.Void ExitGames.Client.Photon.EnetPeer::Disconnect()
extern void EnetPeer_Disconnect_m316F3FD8FE8C3A8F75CDA3FCD56FBD85E0404FCF (void);
// 0x00000014 System.Void ExitGames.Client.Photon.EnetPeer::StopConnection()
extern void EnetPeer_StopConnection_m0172B66F705B5B12222C083D09E22E745A29ED85 (void);
// 0x00000015 System.Void ExitGames.Client.Photon.EnetPeer::FetchServerTimestamp()
extern void EnetPeer_FetchServerTimestamp_m912C5F1C67AFAD32F1FEDC8FCA7E5FEA3A506F49 (void);
// 0x00000016 System.Boolean ExitGames.Client.Photon.EnetPeer::DispatchIncomingCommands()
extern void EnetPeer_DispatchIncomingCommands_m1FA4DE76E9BC048D6DC7FA27226648A743113037 (void);
// 0x00000017 System.Int32 ExitGames.Client.Photon.EnetPeer::GetFragmentLength()
extern void EnetPeer_GetFragmentLength_mBC348352267884C3B3283B69AB80A42EA591073F (void);
// 0x00000018 System.Int32 ExitGames.Client.Photon.EnetPeer::CalculateBufferLen()
extern void EnetPeer_CalculateBufferLen_m7A060E811EFD72438DC0F286A9EDEB7D8B9A4732 (void);
// 0x00000019 System.Int32 ExitGames.Client.Photon.EnetPeer::CalculateInitialOffset()
extern void EnetPeer_CalculateInitialOffset_m7A30AF7A5034D7F4A2160CD7399722D50BFC504D (void);
// 0x0000001A System.Boolean ExitGames.Client.Photon.EnetPeer::SendAcksOnly()
extern void EnetPeer_SendAcksOnly_m1623304367333BE3803F2E25E0858A043BE66F4B (void);
// 0x0000001B System.Boolean ExitGames.Client.Photon.EnetPeer::SendOutgoingCommands()
extern void EnetPeer_SendOutgoingCommands_mF3F86D00646EC75199BA15C482ADE4820191496D (void);
// 0x0000001C System.Boolean ExitGames.Client.Photon.EnetPeer::AreReliableCommandsInTransit()
extern void EnetPeer_AreReliableCommandsInTransit_mC3BC52833C11BBE15655E4D0B63473C63D820E17 (void);
// 0x0000001D System.Boolean ExitGames.Client.Photon.EnetPeer::EnqueueOperation(System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Byte,ExitGames.Client.Photon.SendOptions,ExitGames.Client.Photon.EgMessageType)
extern void EnetPeer_EnqueueOperation_mE7FE6B857DD15D5D9EB73A60657E9CD5A906B7B6 (void);
// 0x0000001E ExitGames.Client.Photon.EnetChannel ExitGames.Client.Photon.EnetPeer::GetChannel(System.Byte)
extern void EnetPeer_GetChannel_m82A687D7F53D89ED9EDB9160B5FFB2E81EE9F1BD (void);
// 0x0000001F System.Boolean ExitGames.Client.Photon.EnetPeer::CreateAndEnqueueCommand(System.Byte,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void EnetPeer_CreateAndEnqueueCommand_m44445FE28F0BC9EC382F60685CC09BD3C4D7629F (void);
// 0x00000020 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.EnetPeer::SerializeOperationToMessage(System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,ExitGames.Client.Photon.EgMessageType,System.Boolean)
extern void EnetPeer_SerializeOperationToMessage_m8EFF9E19D2CF89BED7E0C759B1BB4F0DE49AF3A5 (void);
// 0x00000021 System.Int32 ExitGames.Client.Photon.EnetPeer::SerializeAckToBuffer()
extern void EnetPeer_SerializeAckToBuffer_m8A3A046FFED87990F9C4DE1F7C4FC3D7290132F9 (void);
// 0x00000022 System.Int32 ExitGames.Client.Photon.EnetPeer::SerializeToBuffer(System.Collections.Generic.Queue`1<ExitGames.Client.Photon.NCommand>)
extern void EnetPeer_SerializeToBuffer_mEBA817BB85D0F6DD134BE5FF5CF32BF3B0C45D49 (void);
// 0x00000023 System.Void ExitGames.Client.Photon.EnetPeer::SendData(System.Byte[],System.Int32)
extern void EnetPeer_SendData_mA5006A34962108D600817991CD75170503CEE17A (void);
// 0x00000024 System.Void ExitGames.Client.Photon.EnetPeer::SendToSocket(System.Byte[],System.Int32)
extern void EnetPeer_SendToSocket_m821575DAE15FC8F916B850C47B6E8F4FB168DAC6 (void);
// 0x00000025 System.Void ExitGames.Client.Photon.EnetPeer::SendDataEncrypted(System.Byte[],System.Int32)
extern void EnetPeer_SendDataEncrypted_mD99B483D427FEE4E4CFA60DF95B571AA4A64D983 (void);
// 0x00000026 System.Void ExitGames.Client.Photon.EnetPeer::QueueSentCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueSentCommand_m664D85D8193D1AFE6A0302F289F492D17F6E1B97 (void);
// 0x00000027 System.Void ExitGames.Client.Photon.EnetPeer::QueueOutgoingReliableCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueOutgoingReliableCommand_m98D7F09F9B884D9D037FA2E5E61BE807390B6166 (void);
// 0x00000028 System.Void ExitGames.Client.Photon.EnetPeer::QueueOutgoingUnreliableCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueOutgoingUnreliableCommand_m5CF1EF701DEB2B71285DACA057AC5C5DB87C237E (void);
// 0x00000029 System.Void ExitGames.Client.Photon.EnetPeer::QueueOutgoingAcknowledgement(ExitGames.Client.Photon.NCommand,System.Int32)
extern void EnetPeer_QueueOutgoingAcknowledgement_mDDD093B4F54337D1A2D6CE6403DB009E779C2348 (void);
// 0x0000002A System.Void ExitGames.Client.Photon.EnetPeer::ReceiveIncomingCommands(System.Byte[],System.Int32)
extern void EnetPeer_ReceiveIncomingCommands_m5BF5FB27E5C214C92ACCB7ED89B60126F3FA66B7 (void);
// 0x0000002B System.Boolean ExitGames.Client.Photon.EnetPeer::ExecuteCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_ExecuteCommand_m92DB23388C5C65057DC4B4D27544C06C9BB84A05 (void);
// 0x0000002C System.Boolean ExitGames.Client.Photon.EnetPeer::QueueIncomingCommand(ExitGames.Client.Photon.NCommand)
extern void EnetPeer_QueueIncomingCommand_mB28BDEBFC64477E00B2CE4F8EECA237894F6C616 (void);
// 0x0000002D ExitGames.Client.Photon.NCommand ExitGames.Client.Photon.EnetPeer::RemoveSentReliableCommand(System.Int32,System.Int32,System.Boolean)
extern void EnetPeer_RemoveSentReliableCommand_mBCE5ACB35DC4D1F4FE7D9F45E2C9E3515864A9E0 (void);
// 0x0000002E System.Void ExitGames.Client.Photon.EnetPeer::.cctor()
extern void EnetPeer__cctor_mA3A9B9F56C2296527DCABCA215C25C2955F78CC5 (void);
// 0x0000002F System.Void ExitGames.Client.Photon.EnetPeer::<ExecuteCommand>b__72_0()
extern void EnetPeer_U3CExecuteCommandU3Eb__72_0_m1A94B84A917D13000370466AA81DAF46AABCDAE5 (void);
// 0x00000030 System.Void ExitGames.Client.Photon.IPhotonPeerListener::DebugReturn(ExitGames.Client.Photon.DebugLevel,System.String)
// 0x00000031 System.Void ExitGames.Client.Photon.IPhotonPeerListener::OnOperationResponse(ExitGames.Client.Photon.OperationResponse)
// 0x00000032 System.Void ExitGames.Client.Photon.IPhotonPeerListener::OnStatusChanged(ExitGames.Client.Photon.StatusCode)
// 0x00000033 System.Void ExitGames.Client.Photon.IPhotonPeerListener::OnEvent(ExitGames.Client.Photon.EventData)
// 0x00000034 ExitGames.Client.Photon.IPhotonPeerListener ExitGames.Client.Photon.IPhotonSocket::get_Listener()
extern void IPhotonSocket_get_Listener_m42B3B576D85944C0D6EC569FDACF2FD2604017DF (void);
// 0x00000035 System.Int32 ExitGames.Client.Photon.IPhotonSocket::get_MTU()
extern void IPhotonSocket_get_MTU_mA8D3FA4922F611A8C54E85007CCDF656EC10E56D (void);
// 0x00000036 ExitGames.Client.Photon.PhotonSocketState ExitGames.Client.Photon.IPhotonSocket::get_State()
extern void IPhotonSocket_get_State_m7C108A9426B1A81D9946D6EE1F376C2F006CD785 (void);
// 0x00000037 System.Void ExitGames.Client.Photon.IPhotonSocket::set_State(ExitGames.Client.Photon.PhotonSocketState)
extern void IPhotonSocket_set_State_mF63814C2EBE87B57C3DC2E514F1CB8A43AF7FEF4 (void);
// 0x00000038 System.Boolean ExitGames.Client.Photon.IPhotonSocket::get_Connected()
extern void IPhotonSocket_get_Connected_mECF6D474468E6B2BE842BBA125FB8F27E8277651 (void);
// 0x00000039 System.String ExitGames.Client.Photon.IPhotonSocket::get_ServerAddress()
extern void IPhotonSocket_get_ServerAddress_mFB4E6BE4A79451E9407B42EB0DC3CE0A1E4326FA (void);
// 0x0000003A System.Void ExitGames.Client.Photon.IPhotonSocket::set_ServerAddress(System.String)
extern void IPhotonSocket_set_ServerAddress_mA3D1A26F820B0775BC5FBFF598D633E730E396F4 (void);
// 0x0000003B System.String ExitGames.Client.Photon.IPhotonSocket::get_ServerIpAddress()
extern void IPhotonSocket_get_ServerIpAddress_m4B9AC8676D7C400D533D086D1C2880639B9D1DC3 (void);
// 0x0000003C System.Void ExitGames.Client.Photon.IPhotonSocket::set_ServerIpAddress(System.String)
extern void IPhotonSocket_set_ServerIpAddress_mB5195CBE6E1C5DFA4D40B7E2FA51B3A0EF47E3A5 (void);
// 0x0000003D System.Int32 ExitGames.Client.Photon.IPhotonSocket::get_ServerPort()
extern void IPhotonSocket_get_ServerPort_mD39890926FFB3F6E0E0F71CFF2377D65B2C4FAAF (void);
// 0x0000003E System.Void ExitGames.Client.Photon.IPhotonSocket::set_ServerPort(System.Int32)
extern void IPhotonSocket_set_ServerPort_m2509605DE841239A20AA9666AF23D95A9014C7E3 (void);
// 0x0000003F System.Boolean ExitGames.Client.Photon.IPhotonSocket::get_AddressResolvedAsIpv6()
extern void IPhotonSocket_get_AddressResolvedAsIpv6_m4C993135DF9E667DFFE644628D5FF29CA3D22CD7 (void);
// 0x00000040 System.Void ExitGames.Client.Photon.IPhotonSocket::set_AddressResolvedAsIpv6(System.Boolean)
extern void IPhotonSocket_set_AddressResolvedAsIpv6_m885AE7F2D7FE54C0D48E0442A8D7F21C98B7EFEE (void);
// 0x00000041 System.Void ExitGames.Client.Photon.IPhotonSocket::set_UrlProtocol(System.String)
extern void IPhotonSocket_set_UrlProtocol_mAAAD44B5C7D42AA907B9A7488615613682889122 (void);
// 0x00000042 System.Void ExitGames.Client.Photon.IPhotonSocket::set_UrlPath(System.String)
extern void IPhotonSocket_set_UrlPath_mE8654D2807954FF2F6D25A843E29C6DD161108F5 (void);
// 0x00000043 System.Void ExitGames.Client.Photon.IPhotonSocket::.ctor(ExitGames.Client.Photon.PeerBase)
extern void IPhotonSocket__ctor_mBE9765771BEEBAAE76EE017AA030185C18FECA02 (void);
// 0x00000044 System.Boolean ExitGames.Client.Photon.IPhotonSocket::Connect()
extern void IPhotonSocket_Connect_m5B79987D3BB75DDCDFE52583DDB72F87524F1023 (void);
// 0x00000045 System.Boolean ExitGames.Client.Photon.IPhotonSocket::Disconnect()
// 0x00000046 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.IPhotonSocket::Send(System.Byte[],System.Int32)
// 0x00000047 System.Void ExitGames.Client.Photon.IPhotonSocket::HandleReceivedDatagram(System.Byte[],System.Int32,System.Boolean)
extern void IPhotonSocket_HandleReceivedDatagram_m1F3614CC07BB483DACCEF4043587A8F5BC0058BA (void);
// 0x00000048 System.Boolean ExitGames.Client.Photon.IPhotonSocket::ReportDebugOfLevel(ExitGames.Client.Photon.DebugLevel)
extern void IPhotonSocket_ReportDebugOfLevel_mF56809B21066361C527C94E529A4B91D1720A51D (void);
// 0x00000049 System.Void ExitGames.Client.Photon.IPhotonSocket::EnqueueDebugReturn(ExitGames.Client.Photon.DebugLevel,System.String)
extern void IPhotonSocket_EnqueueDebugReturn_m119928C26BAEA000979E9C2EE58A885C255FE439 (void);
// 0x0000004A System.Void ExitGames.Client.Photon.IPhotonSocket::HandleException(ExitGames.Client.Photon.StatusCode)
extern void IPhotonSocket_HandleException_m75AA4120B6C98820119D858576E2C34686BD7A20 (void);
// 0x0000004B System.Boolean ExitGames.Client.Photon.IPhotonSocket::TryParseAddress(System.String,System.String&,System.UInt16&,System.String&,System.String&)
extern void IPhotonSocket_TryParseAddress_mA2CA500D39BD7BB97054547629DAD611A19E79A3 (void);
// 0x0000004C System.Net.IPAddress[] ExitGames.Client.Photon.IPhotonSocket::GetIpAddresses(System.String)
extern void IPhotonSocket_GetIpAddresses_m5895ED8BB9047D28A723298C54E71A6B7E6F82B8 (void);
// 0x0000004D System.Int32 ExitGames.Client.Photon.IPhotonSocket::AddressSortComparer(System.Net.IPAddress,System.Net.IPAddress)
extern void IPhotonSocket_AddressSortComparer_m6710F2ECEA18A4EBFA0F2A9B31DEF036FB41E9C6 (void);
// 0x0000004E System.Void ExitGames.Client.Photon.IPhotonSocket::<HandleException>b__53_0()
extern void IPhotonSocket_U3CHandleExceptionU3Eb__53_0_m666844A68BB1EA44524E991216C64C6F910E4B84 (void);
// 0x0000004F System.Void ExitGames.Client.Photon.IPhotonSocket/<>c::.cctor()
extern void U3CU3Ec__cctor_m6F2C5F7846EBC1241902A246937BACD023D842E4 (void);
// 0x00000050 System.Void ExitGames.Client.Photon.IPhotonSocket/<>c::.ctor()
extern void U3CU3Ec__ctor_m5A72A7C8355FC7164FE9806B865F77AEEF50AE88 (void);
// 0x00000051 System.String ExitGames.Client.Photon.IPhotonSocket/<>c::<GetIpAddresses>b__56_0(System.Net.IPAddress)
extern void U3CU3Ec_U3CGetIpAddressesU3Eb__56_0_m25F77E111DE5514D204D5EE1D022EC164EE21AA4 (void);
// 0x00000052 ExitGames.Client.Photon.IProtocol ExitGames.Client.Photon.SerializationProtocolFactory::Create(ExitGames.Client.Photon.SerializationProtocol)
extern void SerializationProtocolFactory_Create_m9E5DE950F95A8DECD7106887DA1790FB25E21083 (void);
// 0x00000053 System.String ExitGames.Client.Photon.IProtocol::get_ProtocolType()
// 0x00000054 System.Byte[] ExitGames.Client.Photon.IProtocol::get_VersionBytes()
// 0x00000055 System.Void ExitGames.Client.Photon.IProtocol::Serialize(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
// 0x00000056 System.Void ExitGames.Client.Photon.IProtocol::SerializeShort(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
// 0x00000057 System.Void ExitGames.Client.Photon.IProtocol::SerializeString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
// 0x00000058 System.Void ExitGames.Client.Photon.IProtocol::SerializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,System.Boolean)
// 0x00000059 System.Void ExitGames.Client.Photon.IProtocol::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Boolean)
// 0x0000005A System.Void ExitGames.Client.Photon.IProtocol::SerializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationResponse,System.Boolean)
// 0x0000005B System.Object ExitGames.Client.Photon.IProtocol::Deserialize(ExitGames.Client.Photon.StreamBuffer,System.Byte)
// 0x0000005C System.Int16 ExitGames.Client.Photon.IProtocol::DeserializeShort(ExitGames.Client.Photon.StreamBuffer)
// 0x0000005D System.Byte ExitGames.Client.Photon.IProtocol::DeserializeByte(ExitGames.Client.Photon.StreamBuffer)
// 0x0000005E ExitGames.Client.Photon.EventData ExitGames.Client.Photon.IProtocol::DeserializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData)
// 0x0000005F ExitGames.Client.Photon.OperationRequest ExitGames.Client.Photon.IProtocol::DeserializeOperationRequest(ExitGames.Client.Photon.StreamBuffer)
// 0x00000060 ExitGames.Client.Photon.OperationResponse ExitGames.Client.Photon.IProtocol::DeserializeOperationResponse(ExitGames.Client.Photon.StreamBuffer)
// 0x00000061 System.Byte[] ExitGames.Client.Photon.IProtocol::Serialize(System.Object)
extern void IProtocol_Serialize_mC977A6746116FE416BB9F048172624B9F56F8F39 (void);
// 0x00000062 System.Object ExitGames.Client.Photon.IProtocol::DeserializeMessage(ExitGames.Client.Photon.StreamBuffer)
extern void IProtocol_DeserializeMessage_m13E9C362585D067DAE26E734A61F081B2FFADE30 (void);
// 0x00000063 System.Void ExitGames.Client.Photon.IProtocol::.ctor()
extern void IProtocol__ctor_m9D9A2EE05167D6292F77844D52995C1434CDE48D (void);
// 0x00000064 System.Int32 ExitGames.Client.Photon.NCommand::get_SizeOfPayload()
extern void NCommand_get_SizeOfPayload_m0FD3319AC6CAEDCE05F213904543A2AE2F20C4B3 (void);
// 0x00000065 System.Boolean ExitGames.Client.Photon.NCommand::get_IsFlaggedUnsequenced()
extern void NCommand_get_IsFlaggedUnsequenced_mF1332E8836A22D0F9352C4C09E52E4AF0DFBF573 (void);
// 0x00000066 System.Boolean ExitGames.Client.Photon.NCommand::get_IsFlaggedReliable()
extern void NCommand_get_IsFlaggedReliable_m227B4D4EB21524B5E54EBE4485A27CAFA01D4D1D (void);
// 0x00000067 System.Void ExitGames.Client.Photon.NCommand::.ctor(ExitGames.Client.Photon.EnetPeer,System.Byte,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void NCommand__ctor_mEE92BFA5F4278B1E592CAFFCBE83F2ACD04A19FB (void);
// 0x00000068 System.Void ExitGames.Client.Photon.NCommand::CreateAck(System.Byte[],System.Int32,ExitGames.Client.Photon.NCommand,System.Int32)
extern void NCommand_CreateAck_mBD6D99BFE232A6005E235725FCD0F30693C9624D (void);
// 0x00000069 System.Void ExitGames.Client.Photon.NCommand::.ctor(ExitGames.Client.Photon.EnetPeer,System.Byte[],System.Int32&)
extern void NCommand__ctor_m0E88EA02D5DD11F9B617C0FC5963DE9D05DD1C73 (void);
// 0x0000006A System.Void ExitGames.Client.Photon.NCommand::SerializeHeader(System.Byte[],System.Int32&)
extern void NCommand_SerializeHeader_m56AC0DC2386330E02974B00A27DFF4EDCA8F9DA1 (void);
// 0x0000006B System.Byte[] ExitGames.Client.Photon.NCommand::Serialize()
extern void NCommand_Serialize_m280130DDB13815ED1564B79394D34E0C8ECBA449 (void);
// 0x0000006C System.Void ExitGames.Client.Photon.NCommand::FreePayload()
extern void NCommand_FreePayload_mDFA6213C58D735B9D4D294FD0D914B26FA025038 (void);
// 0x0000006D System.Int32 ExitGames.Client.Photon.NCommand::CompareTo(ExitGames.Client.Photon.NCommand)
extern void NCommand_CompareTo_m3C742BEA3081D254E10ADFA1281B1B85C5D30671 (void);
// 0x0000006E System.String ExitGames.Client.Photon.NCommand::ToString()
extern void NCommand_ToString_mE06145D36BDFABEB191A2B4F35FA9CC91C8A3A64 (void);
// 0x0000006F System.Void ExitGames.Client.Photon.SimulationItem::.ctor()
extern void SimulationItem__ctor_mF16E045A79B0C3E232A8846CFD5FE59B11F5FA45 (void);
// 0x00000070 System.Int32 ExitGames.Client.Photon.SimulationItem::get_Delay()
extern void SimulationItem_get_Delay_m0E2FC38D9E81BED2A9407CB30645CFC3707C787E (void);
// 0x00000071 System.Void ExitGames.Client.Photon.SimulationItem::set_Delay(System.Int32)
extern void SimulationItem_set_Delay_m39FAC59EAB036F41C43FE9B194F1FC85917662D1 (void);
// 0x00000072 System.Boolean ExitGames.Client.Photon.NetworkSimulationSet::get_IsSimulationEnabled()
extern void NetworkSimulationSet_get_IsSimulationEnabled_mCB4BF4ACF44CC41C0F47C6DE208151BD81F562E6 (void);
// 0x00000073 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IsSimulationEnabled(System.Boolean)
extern void NetworkSimulationSet_set_IsSimulationEnabled_mFE15FB897F3CD1AAEF08BDBE63B130C963662B56 (void);
// 0x00000074 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_OutgoingLag()
extern void NetworkSimulationSet_get_OutgoingLag_mCA1AEEAEB69B816D2FB864A765883EBBD944AC6D (void);
// 0x00000075 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_OutgoingLag(System.Int32)
extern void NetworkSimulationSet_set_OutgoingLag_m09A073E0A2BEFE65952953E7200E744040F3E48F (void);
// 0x00000076 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_OutgoingJitter()
extern void NetworkSimulationSet_get_OutgoingJitter_mDA8191F4B5FCF1CCAEBF48868B6FB8932281BC06 (void);
// 0x00000077 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_OutgoingJitter(System.Int32)
extern void NetworkSimulationSet_set_OutgoingJitter_mE095935EFFDF02170CCA916EFD6DE55C15CA9946 (void);
// 0x00000078 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_OutgoingLossPercentage()
extern void NetworkSimulationSet_get_OutgoingLossPercentage_m1A1043A839517A7326FB7D9AD7C9DAC1644D2C42 (void);
// 0x00000079 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_OutgoingLossPercentage(System.Int32)
extern void NetworkSimulationSet_set_OutgoingLossPercentage_mA06F42FF1E2271BCE03C9829FBC20D50A7DB356B (void);
// 0x0000007A System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_IncomingLag()
extern void NetworkSimulationSet_get_IncomingLag_mA8B2D8A009AB453F54B1116E71FB8B69B4552779 (void);
// 0x0000007B System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IncomingLag(System.Int32)
extern void NetworkSimulationSet_set_IncomingLag_m047633C5F701A5673649BAF8B58D0CC3D586D6F9 (void);
// 0x0000007C System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_IncomingJitter()
extern void NetworkSimulationSet_get_IncomingJitter_m0FB33F0E94C8361BF6FABA0FE941FB4A57937A26 (void);
// 0x0000007D System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IncomingJitter(System.Int32)
extern void NetworkSimulationSet_set_IncomingJitter_mCC7B8E71388AB95021A6ED88CBE1D71D62A815A7 (void);
// 0x0000007E System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_IncomingLossPercentage()
extern void NetworkSimulationSet_get_IncomingLossPercentage_mDE273AC243857A219A0A0549408E755FED2E704B (void);
// 0x0000007F System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_IncomingLossPercentage(System.Int32)
extern void NetworkSimulationSet_set_IncomingLossPercentage_mDB4DC5D690394D381A8FD9083FF2C3C15E130F82 (void);
// 0x00000080 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_LostPackagesOut()
extern void NetworkSimulationSet_get_LostPackagesOut_m1A8F0D3C9A902FD15A1F1F6338AEFC3293DF358F (void);
// 0x00000081 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_LostPackagesOut(System.Int32)
extern void NetworkSimulationSet_set_LostPackagesOut_mF38EA104FB9D97E7B07E18E9F184ACC8E19B7AB7 (void);
// 0x00000082 System.Int32 ExitGames.Client.Photon.NetworkSimulationSet::get_LostPackagesIn()
extern void NetworkSimulationSet_get_LostPackagesIn_m45D6DFEA7C2CC7D3EC203C5ECB11964074775920 (void);
// 0x00000083 System.Void ExitGames.Client.Photon.NetworkSimulationSet::set_LostPackagesIn(System.Int32)
extern void NetworkSimulationSet_set_LostPackagesIn_m3F5B6837BEA117DAE4FED4D5733B4575B47E6EEC (void);
// 0x00000084 System.String ExitGames.Client.Photon.NetworkSimulationSet::ToString()
extern void NetworkSimulationSet_ToString_m536403BE9F8814AB501AA0DF47AB713ECD60A183 (void);
// 0x00000085 System.Void ExitGames.Client.Photon.NetworkSimulationSet::.ctor()
extern void NetworkSimulationSet__ctor_mE71120E1103214BBAF889A9ED5F68007B4BE0E96 (void);
// 0x00000086 System.Void ExitGames.Client.Photon.PhotonCodes::.cctor()
extern void PhotonCodes__cctor_mB31F92BB81E94E996A36550AFC40C60ACE0D01A9 (void);
// 0x00000087 System.Type ExitGames.Client.Photon.PeerBase::get_SocketImplementation()
extern void PeerBase_get_SocketImplementation_m9F3C1F4CA732965FAE27FB983365A8BD1C669ABA (void);
// 0x00000088 System.String ExitGames.Client.Photon.PeerBase::get_ServerAddress()
extern void PeerBase_get_ServerAddress_m547C81E080C9FF6D567E3F66E723305408D7473F (void);
// 0x00000089 System.Void ExitGames.Client.Photon.PeerBase::set_ServerAddress(System.String)
extern void PeerBase_set_ServerAddress_mBD5D8F2743EF4730AD4F13984D5EFB72A942535F (void);
// 0x0000008A System.Void ExitGames.Client.Photon.PeerBase::set_ProxyServerAddress(System.String)
extern void PeerBase_set_ProxyServerAddress_m266D46979760AFFDCF9D8B67B169C5F4515DD747 (void);
// 0x0000008B ExitGames.Client.Photon.IPhotonPeerListener ExitGames.Client.Photon.PeerBase::get_Listener()
extern void PeerBase_get_Listener_m15B7DA6F4AE0A75F6D3133144396A964163DE2F7 (void);
// 0x0000008C ExitGames.Client.Photon.DebugLevel ExitGames.Client.Photon.PeerBase::get_debugOut()
extern void PeerBase_get_debugOut_m85AA81B1BE53EEC17724817886B3AF998313B1CD (void);
// 0x0000008D System.Int32 ExitGames.Client.Photon.PeerBase::get_DisconnectTimeout()
extern void PeerBase_get_DisconnectTimeout_m088E0B5FCEDE4039B8229380B0A3E2E287BB2F3F (void);
// 0x0000008E System.Int32 ExitGames.Client.Photon.PeerBase::get_timePingInterval()
extern void PeerBase_get_timePingInterval_m396C87462BB003CDA00356D16226C027E86DD874 (void);
// 0x0000008F System.Byte ExitGames.Client.Photon.PeerBase::get_ChannelCount()
extern void PeerBase_get_ChannelCount_mDC5EC382F24DB9B2B45F46378EBC963D2D9F47A8 (void);
// 0x00000090 System.String ExitGames.Client.Photon.PeerBase::get_PeerID()
extern void PeerBase_get_PeerID_m497C3DFBC699F00585313439A97758F4E8849382 (void);
// 0x00000091 System.Int32 ExitGames.Client.Photon.PeerBase::get_timeInt()
extern void PeerBase_get_timeInt_m30F9D55FD178CD2391A3A6B4C4783010436162F7 (void);
// 0x00000092 System.Boolean ExitGames.Client.Photon.PeerBase::get_IsSendingOnlyAcks()
extern void PeerBase_get_IsSendingOnlyAcks_m22C40193C9B7EA43ACAFC41D519A1D11CB1AECA5 (void);
// 0x00000093 System.Int32 ExitGames.Client.Photon.PeerBase::get_mtu()
extern void PeerBase_get_mtu_m9A35C168D308FF1EE9270C91C093FA5ED37BBD18 (void);
// 0x00000094 System.Boolean ExitGames.Client.Photon.PeerBase::get_IsIpv6()
extern void PeerBase_get_IsIpv6_mB388AFC08E48745F47FF73FCA3715C264C960B2A (void);
// 0x00000095 System.Void ExitGames.Client.Photon.PeerBase::.ctor()
extern void PeerBase__ctor_mDD91134C7C88054893923483996ECC4CE8C0940F (void);
// 0x00000096 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.PeerBase::MessageBufferPoolGet()
extern void PeerBase_MessageBufferPoolGet_m376289B1E0D6220C57074C24969E9F0A5B121530 (void);
// 0x00000097 System.Void ExitGames.Client.Photon.PeerBase::MessageBufferPoolPut(ExitGames.Client.Photon.StreamBuffer)
extern void PeerBase_MessageBufferPoolPut_m3DC3182B7F8F31CB2E48142A8AB69D5D7459EBD9 (void);
// 0x00000098 System.Void ExitGames.Client.Photon.PeerBase::InitPeerBase()
extern void PeerBase_InitPeerBase_m4471E86AB037FB7722190DF8645A033E5DFC54C0 (void);
// 0x00000099 System.Boolean ExitGames.Client.Photon.PeerBase::Connect(System.String,System.String,System.String,System.Object)
// 0x0000009A System.String ExitGames.Client.Photon.PeerBase::GetHttpKeyValueString(System.Collections.Generic.Dictionary`2<System.String,System.String>)
extern void PeerBase_GetHttpKeyValueString_m8E17295D2A49FAFEAA604F2ECE7105B3FA22999B (void);
// 0x0000009B System.Byte[] ExitGames.Client.Photon.PeerBase::PrepareConnectData(System.String,System.String,System.Object)
extern void PeerBase_PrepareConnectData_mADEDD363795949D3BF00A3FB1374C3255B711739 (void);
// 0x0000009C System.String ExitGames.Client.Photon.PeerBase::PepareWebSocketUrl(System.String,System.String,System.Object)
extern void PeerBase_PepareWebSocketUrl_m7B031D20E62843BF0E8021884044F1EBC57BF948 (void);
// 0x0000009D System.Void ExitGames.Client.Photon.PeerBase::OnConnect()
// 0x0000009E System.Void ExitGames.Client.Photon.PeerBase::InitCallback()
extern void PeerBase_InitCallback_mBA8F524B7A19E5B85E99D6447BE1127A04B3CC73 (void);
// 0x0000009F System.Void ExitGames.Client.Photon.PeerBase::Disconnect()
// 0x000000A0 System.Void ExitGames.Client.Photon.PeerBase::StopConnection()
// 0x000000A1 System.Void ExitGames.Client.Photon.PeerBase::FetchServerTimestamp()
// 0x000000A2 System.Boolean ExitGames.Client.Photon.PeerBase::EnqueueOperation(System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Byte,ExitGames.Client.Photon.SendOptions,ExitGames.Client.Photon.EgMessageType)
// 0x000000A3 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.PeerBase::SerializeOperationToMessage(System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,ExitGames.Client.Photon.EgMessageType,System.Boolean)
// 0x000000A4 System.Boolean ExitGames.Client.Photon.PeerBase::SendOutgoingCommands()
// 0x000000A5 System.Boolean ExitGames.Client.Photon.PeerBase::SendAcksOnly()
extern void PeerBase_SendAcksOnly_m2CA1C6C0E01F97AB7B8B96C9F9597CBDE90BBF67 (void);
// 0x000000A6 System.Void ExitGames.Client.Photon.PeerBase::ReceiveIncomingCommands(System.Byte[],System.Int32)
// 0x000000A7 System.Boolean ExitGames.Client.Photon.PeerBase::DispatchIncomingCommands()
// 0x000000A8 System.Boolean ExitGames.Client.Photon.PeerBase::DeserializeMessageAndCallback(ExitGames.Client.Photon.StreamBuffer)
extern void PeerBase_DeserializeMessageAndCallback_mDCF4AD0E0E18347D08373E4076083EC4C628A244 (void);
// 0x000000A9 System.Void ExitGames.Client.Photon.PeerBase::UpdateRoundTripTimeAndVariance(System.Int32)
extern void PeerBase_UpdateRoundTripTimeAndVariance_mCC9D4AC8FB60CEB13DEB975FD5C387FB224D0988 (void);
// 0x000000AA System.Boolean ExitGames.Client.Photon.PeerBase::ExchangeKeysForEncryption(System.Object)
extern void PeerBase_ExchangeKeysForEncryption_m4BC57B47EAAC798B40125E8F54534E38253AA451 (void);
// 0x000000AB System.Void ExitGames.Client.Photon.PeerBase::DeriveSharedKey(ExitGames.Client.Photon.OperationResponse)
extern void PeerBase_DeriveSharedKey_mE28F6EA79ADC9EC7A27B83EF2416A2172FBFC6AE (void);
// 0x000000AC System.Void ExitGames.Client.Photon.PeerBase::InitEncryption(System.Byte[])
extern void PeerBase_InitEncryption_mDDC0BD75FF470934CF68B90B25308C509B43BA88 (void);
// 0x000000AD System.Void ExitGames.Client.Photon.PeerBase::EnqueueActionForDispatch(ExitGames.Client.Photon.PeerBase/MyAction)
extern void PeerBase_EnqueueActionForDispatch_mD3DFD4B13F0BCDD43A444C3F5AD006177537A5C7 (void);
// 0x000000AE System.Void ExitGames.Client.Photon.PeerBase::EnqueueDebugReturn(ExitGames.Client.Photon.DebugLevel,System.String)
extern void PeerBase_EnqueueDebugReturn_m9DA0EAA11DBB1970C201233242AA998DC44B5918 (void);
// 0x000000AF System.Void ExitGames.Client.Photon.PeerBase::EnqueueStatusCallback(ExitGames.Client.Photon.StatusCode)
extern void PeerBase_EnqueueStatusCallback_m1E30B68E57E2A9F7B548638A099E611FF9403BC7 (void);
// 0x000000B0 ExitGames.Client.Photon.NetworkSimulationSet ExitGames.Client.Photon.PeerBase::get_NetworkSimulationSettings()
extern void PeerBase_get_NetworkSimulationSettings_mA8D2730E66EA668B75A5A05B2574A319C4EA9E46 (void);
// 0x000000B1 System.Void ExitGames.Client.Photon.PeerBase::SendNetworkSimulated(System.Byte[])
extern void PeerBase_SendNetworkSimulated_m7DD3FF6CF309207A5FDCE8DD23A3852BB4668868 (void);
// 0x000000B2 System.Void ExitGames.Client.Photon.PeerBase::ReceiveNetworkSimulated(System.Byte[])
extern void PeerBase_ReceiveNetworkSimulated_m1C15257E16D0782F7E0ACA920EA2A241D3EB21F8 (void);
// 0x000000B3 System.Void ExitGames.Client.Photon.PeerBase::NetworkSimRun()
extern void PeerBase_NetworkSimRun_mB944274AC2069696E6A3C6926D1C82685EC9952B (void);
// 0x000000B4 System.Boolean ExitGames.Client.Photon.PeerBase::get_TrafficStatsEnabled()
extern void PeerBase_get_TrafficStatsEnabled_m9ABD7B9A6061867C58FCDCE994B0973BEB473C4E (void);
// 0x000000B5 ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PeerBase::get_TrafficStatsIncoming()
extern void PeerBase_get_TrafficStatsIncoming_mA1F80DA24CB9F1931B431982BC4488D7549E195C (void);
// 0x000000B6 ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PeerBase::get_TrafficStatsOutgoing()
extern void PeerBase_get_TrafficStatsOutgoing_mEE011226E87871A511F8A0630B6AC5686979F529 (void);
// 0x000000B7 ExitGames.Client.Photon.TrafficStatsGameLevel ExitGames.Client.Photon.PeerBase::get_TrafficStatsGameLevel()
extern void PeerBase_get_TrafficStatsGameLevel_m86D11A93B3DFDCAB7922B57F0D65B831658DC5AB (void);
// 0x000000B8 System.Int32 ExitGames.Client.Photon.PeerBase::get_CommandLogSize()
extern void PeerBase_get_CommandLogSize_mF2CCBE304C7488BD15445B364AB7699F1A6EB0F6 (void);
// 0x000000B9 System.Void ExitGames.Client.Photon.PeerBase::CommandLogResize()
extern void PeerBase_CommandLogResize_m346E3B2DA1A8BD157704FFD924D63C3FC4CC6D86 (void);
// 0x000000BA System.Void ExitGames.Client.Photon.PeerBase::CommandLogInit()
extern void PeerBase_CommandLogInit_mF7639859C4647F1632A963F95AC9D0B3614CB50C (void);
// 0x000000BB System.Void ExitGames.Client.Photon.PeerBase::.cctor()
extern void PeerBase__cctor_m44BC665131F8496CDF82E4543209AF7C011DB7BD (void);
// 0x000000BC System.Void ExitGames.Client.Photon.PeerBase/MyAction::.ctor(System.Object,System.IntPtr)
extern void MyAction__ctor_m3B63B36D6AA83D0CCB5CCCC873F54001FE59FC93 (void);
// 0x000000BD System.Void ExitGames.Client.Photon.PeerBase/MyAction::Invoke()
extern void MyAction_Invoke_mE6FE7CEE6F0B88C67258AA4C7664CA7C3FA8E6DD (void);
// 0x000000BE System.IAsyncResult ExitGames.Client.Photon.PeerBase/MyAction::BeginInvoke(System.AsyncCallback,System.Object)
extern void MyAction_BeginInvoke_m0A36566266D3C5EB748AA90C4A639C8E2B9510B5 (void);
// 0x000000BF System.Void ExitGames.Client.Photon.PeerBase/MyAction::EndInvoke(System.IAsyncResult)
extern void MyAction_EndInvoke_m64D79A798A43CF4867E9A2C25A705A8F78EC3308 (void);
// 0x000000C0 System.Void ExitGames.Client.Photon.PeerBase/<>c__DisplayClass108_0::.ctor()
extern void U3CU3Ec__DisplayClass108_0__ctor_m09D5D5821D4FB1914CB2DD456671F3246FDBB898 (void);
// 0x000000C1 System.Void ExitGames.Client.Photon.PeerBase/<>c__DisplayClass108_0::<EnqueueDebugReturn>b__0()
extern void U3CU3Ec__DisplayClass108_0_U3CEnqueueDebugReturnU3Eb__0_mADB0EC8A6BC58D1C685B326CFDFEA6310EC019AD (void);
// 0x000000C2 System.Void ExitGames.Client.Photon.PeerBase/<>c__DisplayClass109_0::.ctor()
extern void U3CU3Ec__DisplayClass109_0__ctor_m9EE64486D6DA63BB2BFD6A4F5DF2FC6002ED8516 (void);
// 0x000000C3 System.Void ExitGames.Client.Photon.PeerBase/<>c__DisplayClass109_0::<EnqueueStatusCallback>b__0()
extern void U3CU3Ec__DisplayClass109_0_U3CEnqueueStatusCallbackU3Eb__0_m0B1C6713321761A24A3E4DCC5FD3C1F4BF397C44 (void);
// 0x000000C4 System.Void ExitGames.Client.Photon.CmdLogItem::.ctor()
extern void CmdLogItem__ctor_mA65C4CC55316E90AC1E5E2D61AACAE54350DAD71 (void);
// 0x000000C5 System.Void ExitGames.Client.Photon.CmdLogItem::.ctor(ExitGames.Client.Photon.NCommand,System.Int32,System.Int32,System.Int32)
extern void CmdLogItem__ctor_mC61DFEDF6C3A5FD00790D54D6BA362EE5DF90C62 (void);
// 0x000000C6 System.String ExitGames.Client.Photon.CmdLogItem::ToString()
extern void CmdLogItem_ToString_mBC6DDDF48224B905A195FB9B887CDF6BB145151F (void);
// 0x000000C7 System.Void ExitGames.Client.Photon.CmdLogReceivedReliable::.ctor(ExitGames.Client.Photon.NCommand,System.Int32,System.Int32,System.Int32,System.Int32,System.Int32)
extern void CmdLogReceivedReliable__ctor_m9ECDAA2CD8FD8E6930A5E98D5104A70AD4EC8F3D (void);
// 0x000000C8 System.String ExitGames.Client.Photon.CmdLogReceivedReliable::ToString()
extern void CmdLogReceivedReliable_ToString_m32C689910BB130652566B36C4FA6D892A5447EF8 (void);
// 0x000000C9 System.Void ExitGames.Client.Photon.CmdLogReceivedAck::.ctor(ExitGames.Client.Photon.NCommand,System.Int32,System.Int32,System.Int32)
extern void CmdLogReceivedAck__ctor_m6EF325F6B4403CE97F1BCAE4482E75820C8A0D35 (void);
// 0x000000CA System.String ExitGames.Client.Photon.CmdLogReceivedAck::ToString()
extern void CmdLogReceivedAck_ToString_m383B7CB1CD007EEB0D949CD7DF5A0F87C44419C8 (void);
// 0x000000CB System.Void ExitGames.Client.Photon.CmdLogSentReliable::.ctor(ExitGames.Client.Photon.NCommand,System.Int32,System.Int32,System.Int32,System.Boolean)
extern void CmdLogSentReliable__ctor_mDB9400C85E4060467E963763294D97125DD27EE4 (void);
// 0x000000CC System.String ExitGames.Client.Photon.CmdLogSentReliable::ToString()
extern void CmdLogSentReliable_ToString_m424424F12945CD24F9A242667F2081DBCCF1CF2B (void);
// 0x000000CD System.Byte ExitGames.Client.Photon.PhotonPeer::get_ClientSdkIdShifted()
extern void PhotonPeer_get_ClientSdkIdShifted_m5E09AE4034A5F0454E813BD34E1F65C1C8A97A48 (void);
// 0x000000CE System.String ExitGames.Client.Photon.PhotonPeer::get_ClientVersion()
extern void PhotonPeer_get_ClientVersion_m9585B88FAE81DE7FDF03CD2631F9FF1AA458AD37 (void);
// 0x000000CF System.Boolean ExitGames.Client.Photon.PhotonPeer::get_NativeSocketLibAvailable()
extern void PhotonPeer_get_NativeSocketLibAvailable_m6ADA8FCE1DB070EEB3A7D0DBCB326C73C5013070 (void);
// 0x000000D0 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_NativePayloadEncryptionLibAvailable()
extern void PhotonPeer_get_NativePayloadEncryptionLibAvailable_m22F9866A06FA63CBC7C4EC0DBF85531E2C302FD1 (void);
// 0x000000D1 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_NativeDatagramEncryptionLibAvailable()
extern void PhotonPeer_get_NativeDatagramEncryptionLibAvailable_mC368038B4D73DDFF2FF95CC9AE6DF1E42510103C (void);
// 0x000000D2 System.Void ExitGames.Client.Photon.PhotonPeer::CheckNativeLibsAvailability()
extern void PhotonPeer_CheckNativeLibsAvailability_m63925E53F65B93E61982330DE242DA9CDE7154D4 (void);
// 0x000000D3 ExitGames.Client.Photon.SerializationProtocol ExitGames.Client.Photon.PhotonPeer::get_SerializationProtocolType()
extern void PhotonPeer_get_SerializationProtocolType_m244DBA83394266249CF1AF8331F63CFEE3EA2A44 (void);
// 0x000000D4 System.Void ExitGames.Client.Photon.PhotonPeer::set_SerializationProtocolType(ExitGames.Client.Photon.SerializationProtocol)
extern void PhotonPeer_set_SerializationProtocolType_m9141765EA0AA102D96F41A345D48111E0B5408B9 (void);
// 0x000000D5 System.Type ExitGames.Client.Photon.PhotonPeer::get_SocketImplementation()
extern void PhotonPeer_get_SocketImplementation_mDF36FAFEB15F2F490E704EAF7CBDE199BDCAD32A (void);
// 0x000000D6 System.Void ExitGames.Client.Photon.PhotonPeer::set_SocketImplementation(System.Type)
extern void PhotonPeer_set_SocketImplementation_m1B5A0C941576402378C6EE476052164B5D798ED0 (void);
// 0x000000D7 ExitGames.Client.Photon.IPhotonPeerListener ExitGames.Client.Photon.PhotonPeer::get_Listener()
extern void PhotonPeer_get_Listener_m92E5CDF7E18EA95E6FA89FA130DCE92ADD2413C9 (void);
// 0x000000D8 System.Void ExitGames.Client.Photon.PhotonPeer::set_Listener(ExitGames.Client.Photon.IPhotonPeerListener)
extern void PhotonPeer_set_Listener_m6E6CBA1288754723528C3107D0BB546B1EB1FCC9 (void);
// 0x000000D9 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_ReuseEventInstance()
extern void PhotonPeer_get_ReuseEventInstance_m7E7E3745396E3DB82D4D7D970F4135DAE110BF2E (void);
// 0x000000DA System.Boolean ExitGames.Client.Photon.PhotonPeer::get_EnableServerTracing()
extern void PhotonPeer_get_EnableServerTracing_m9ADAD471B11BECBF171E1225B2BE9628935E1B08 (void);
// 0x000000DB System.Byte ExitGames.Client.Photon.PhotonPeer::get_QuickResendAttempts()
extern void PhotonPeer_get_QuickResendAttempts_m4754366FAE7A652996F981B047B8F7596CE486B5 (void);
// 0x000000DC System.Void ExitGames.Client.Photon.PhotonPeer::set_QuickResendAttempts(System.Byte)
extern void PhotonPeer_set_QuickResendAttempts_mAFA68057A93CBCA88E4B6C4006EBD29CB61B97E0 (void);
// 0x000000DD ExitGames.Client.Photon.PeerStateValue ExitGames.Client.Photon.PhotonPeer::get_PeerState()
extern void PhotonPeer_get_PeerState_mAD6503E3F6464FEFD6DDD8736A04B2A7F3B04A82 (void);
// 0x000000DE System.String ExitGames.Client.Photon.PhotonPeer::get_PeerID()
extern void PhotonPeer_get_PeerID_m11C6195468D5AE4C90B1220E1C5AEF3C1A84DB0C (void);
// 0x000000DF System.Boolean ExitGames.Client.Photon.PhotonPeer::get_CrcEnabled()
extern void PhotonPeer_get_CrcEnabled_m2FAF075107150C695D89498334A40C55943898F7 (void);
// 0x000000E0 System.Void ExitGames.Client.Photon.PhotonPeer::set_CrcEnabled(System.Boolean)
extern void PhotonPeer_set_CrcEnabled_m780993C1E41BAD5F9675B59C3043A627DCA810D3 (void);
// 0x000000E1 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_PacketLossByCrc()
extern void PhotonPeer_get_PacketLossByCrc_m9FFDD111129E2A002F30B3A565975391999FC4F0 (void);
// 0x000000E2 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ResentReliableCommands()
extern void PhotonPeer_get_ResentReliableCommands_mB65EA7CF4DED0AB3BC91559AD15BB48B941F3C48 (void);
// 0x000000E3 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ServerTimeInMilliSeconds()
extern void PhotonPeer_get_ServerTimeInMilliSeconds_m7545C8B086D1D787926F3EE0D911EC5A93580319 (void);
// 0x000000E4 System.Void ExitGames.Client.Photon.PhotonPeer::set_LocalMsTimestampDelegate(ExitGames.Client.Photon.SupportClass/IntegerMillisecondsDelegate)
extern void PhotonPeer_set_LocalMsTimestampDelegate_mEA7C28C9927F3AFD449F721CC227B5D7B5F46A68 (void);
// 0x000000E5 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_ConnectionTime()
extern void PhotonPeer_get_ConnectionTime_m02CE9C692F480249E64ECA62525B6BD6522ED78B (void);
// 0x000000E6 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LastSendOutgoingTime()
extern void PhotonPeer_get_LastSendOutgoingTime_mBE2D01726CB005A1BC8B535523EF86E461107925 (void);
// 0x000000E7 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_LongestSentCall()
extern void PhotonPeer_get_LongestSentCall_mE4B54B9BE93F6C70DED506D9225CDC6BB04473A4 (void);
// 0x000000E8 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_RoundTripTime()
extern void PhotonPeer_get_RoundTripTime_mB2C7F0E48E15FBDE4A35F54727EF780EB66E8537 (void);
// 0x000000E9 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_RoundTripTimeVariance()
extern void PhotonPeer_get_RoundTripTimeVariance_m717D452F39723AA178E842021E2F05ABC906DCAE (void);
// 0x000000EA System.Int32 ExitGames.Client.Photon.PhotonPeer::get_TimestampOfLastSocketReceive()
extern void PhotonPeer_get_TimestampOfLastSocketReceive_m24EAC4237BEBAEE71EB5C7BE8524FE4A1A359306 (void);
// 0x000000EB System.String ExitGames.Client.Photon.PhotonPeer::get_ServerAddress()
extern void PhotonPeer_get_ServerAddress_mBB7F348D12881D815323E331CCB89023E6522E01 (void);
// 0x000000EC System.String ExitGames.Client.Photon.PhotonPeer::get_ServerIpAddress()
extern void PhotonPeer_get_ServerIpAddress_mFC78501DEA47D127CC7537DE02E33B7FFDA65813 (void);
// 0x000000ED ExitGames.Client.Photon.ConnectionProtocol ExitGames.Client.Photon.PhotonPeer::get_UsedProtocol()
extern void PhotonPeer_get_UsedProtocol_mEC9186551B89986D3F4E69B0879D4B438EF939EB (void);
// 0x000000EE ExitGames.Client.Photon.ConnectionProtocol ExitGames.Client.Photon.PhotonPeer::get_TransportProtocol()
extern void PhotonPeer_get_TransportProtocol_m42215E2D4E23E475F9D83429F264AF2D60CE58F5 (void);
// 0x000000EF System.Void ExitGames.Client.Photon.PhotonPeer::set_TransportProtocol(ExitGames.Client.Photon.ConnectionProtocol)
extern void PhotonPeer_set_TransportProtocol_mE069BC52388CE1326BCE1975071CE4448A474B96 (void);
// 0x000000F0 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_IsSimulationEnabled()
extern void PhotonPeer_get_IsSimulationEnabled_m064D29504C891742E6E7DA97885D09D82709D7B1 (void);
// 0x000000F1 System.Void ExitGames.Client.Photon.PhotonPeer::set_IsSimulationEnabled(System.Boolean)
extern void PhotonPeer_set_IsSimulationEnabled_mB7346CA2D4877A6C10307C86C2A4C169C27D8FEE (void);
// 0x000000F2 ExitGames.Client.Photon.NetworkSimulationSet ExitGames.Client.Photon.PhotonPeer::get_NetworkSimulationSettings()
extern void PhotonPeer_get_NetworkSimulationSettings_m9D56217E285F8AA05F457944B972933FE130C9B1 (void);
// 0x000000F3 System.Int32 ExitGames.Client.Photon.PhotonPeer::get_MaximumTransferUnit()
extern void PhotonPeer_get_MaximumTransferUnit_m56C95F2C407F6651E90649B358EE6BB97CC0F8C8 (void);
// 0x000000F4 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_IsEncryptionAvailable()
extern void PhotonPeer_get_IsEncryptionAvailable_mAF1CA0B63AC560C23B6DBC28610459493F19E38E (void);
// 0x000000F5 System.Boolean ExitGames.Client.Photon.PhotonPeer::get_IsSendingOnlyAcks()
extern void PhotonPeer_get_IsSendingOnlyAcks_m75DBEC8A91E747583C831BDBFB53CFBEE7444906 (void);
// 0x000000F6 System.Void ExitGames.Client.Photon.PhotonPeer::set_IsSendingOnlyAcks(System.Boolean)
extern void PhotonPeer_set_IsSendingOnlyAcks_m4215E2BF08B62B48A56036BA9592FE2270D7D521 (void);
// 0x000000F7 ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsIncoming()
extern void PhotonPeer_get_TrafficStatsIncoming_mE489191C0F0EE515D543343AFB1322B647E92955 (void);
// 0x000000F8 System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsIncoming(ExitGames.Client.Photon.TrafficStats)
extern void PhotonPeer_set_TrafficStatsIncoming_m9A227393E7933D8C5EA409655AEA372F61FE36EE (void);
// 0x000000F9 ExitGames.Client.Photon.TrafficStats ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsOutgoing()
extern void PhotonPeer_get_TrafficStatsOutgoing_mE63D4D8E6AC3AB4AE621843CDDB430EE9FD22868 (void);
// 0x000000FA System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsOutgoing(ExitGames.Client.Photon.TrafficStats)
extern void PhotonPeer_set_TrafficStatsOutgoing_m7BA4DEBBF17060079E2378748C78DD4350BCD70B (void);
// 0x000000FB ExitGames.Client.Photon.TrafficStatsGameLevel ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsGameLevel()
extern void PhotonPeer_get_TrafficStatsGameLevel_m8C48190CE0E673E2324EA8CAFED724A275937D6A (void);
// 0x000000FC System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsGameLevel(ExitGames.Client.Photon.TrafficStatsGameLevel)
extern void PhotonPeer_set_TrafficStatsGameLevel_mBF18554262AC79E6D6E962D2EA396CC7FA4AAC32 (void);
// 0x000000FD System.Int64 ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsElapsedMs()
extern void PhotonPeer_get_TrafficStatsElapsedMs_m1553EE4411AD40BAB0DE48CC1009D3AE4AF313E5 (void);
// 0x000000FE System.Boolean ExitGames.Client.Photon.PhotonPeer::get_TrafficStatsEnabled()
extern void PhotonPeer_get_TrafficStatsEnabled_m0BA2DC98AA2C68F52C9D13B048502B2CE6268133 (void);
// 0x000000FF System.Void ExitGames.Client.Photon.PhotonPeer::set_TrafficStatsEnabled(System.Boolean)
extern void PhotonPeer_set_TrafficStatsEnabled_m15BB505352D6C540C9FD08C7666A9924E3EF9E41 (void);
// 0x00000100 System.Void ExitGames.Client.Photon.PhotonPeer::TrafficStatsReset()
extern void PhotonPeer_TrafficStatsReset_m426BBDEB554907511A529EBC825C076EF6D2FE60 (void);
// 0x00000101 System.Void ExitGames.Client.Photon.PhotonPeer::InitializeTrafficStats()
extern void PhotonPeer_InitializeTrafficStats_m14DA45B17837824714ED804DBD622FA21783B2FB (void);
// 0x00000102 System.String ExitGames.Client.Photon.PhotonPeer::VitalStatsToString(System.Boolean)
extern void PhotonPeer_VitalStatsToString_m9386A123547ED7CE61E5D190BB78BE5089723CE6 (void);
// 0x00000103 System.Type ExitGames.Client.Photon.PhotonPeer::get_EncryptorType()
extern void PhotonPeer_get_EncryptorType_mAB31EA062341BD3B1C7FEA3BBCE02B8E204C7760 (void);
// 0x00000104 System.Void ExitGames.Client.Photon.PhotonPeer::.ctor(ExitGames.Client.Photon.ConnectionProtocol)
extern void PhotonPeer__ctor_m92ED9A9BF0751052903EAA9C8493917AECBE08EB (void);
// 0x00000105 System.Void ExitGames.Client.Photon.PhotonPeer::.ctor(ExitGames.Client.Photon.IPhotonPeerListener,ExitGames.Client.Photon.ConnectionProtocol)
extern void PhotonPeer__ctor_mB20C8325EAE88C51D67CA6DA281F2CA4EE14A2D7 (void);
// 0x00000106 System.Boolean ExitGames.Client.Photon.PhotonPeer::Connect(System.String,System.String)
extern void PhotonPeer_Connect_mCFC5413C2AD95093FC307766120F849DDD3A47E4 (void);
// 0x00000107 System.Boolean ExitGames.Client.Photon.PhotonPeer::Connect(System.String,System.String,System.Object)
extern void PhotonPeer_Connect_mBACE18AF206DBE3AD38DE0ECFA93FB5CB2957122 (void);
// 0x00000108 System.Boolean ExitGames.Client.Photon.PhotonPeer::Connect(System.String,System.String,System.String,System.Object)
extern void PhotonPeer_Connect_m95D317D017B91A95C291811C4D59280067368B05 (void);
// 0x00000109 System.Void ExitGames.Client.Photon.PhotonPeer::CreatePeerBase()
extern void PhotonPeer_CreatePeerBase_m28FEA13E0262F68E8B52EA38B0DF145C61D5C338 (void);
// 0x0000010A System.Void ExitGames.Client.Photon.PhotonPeer::Disconnect()
extern void PhotonPeer_Disconnect_m968012B14C25E1DE812ECD86B446A936C43A9E72 (void);
// 0x0000010B System.Void ExitGames.Client.Photon.PhotonPeer::StopThread()
extern void PhotonPeer_StopThread_m8C0D35143F5EFD72FA671DB1E36FF0176EB34CC2 (void);
// 0x0000010C System.Void ExitGames.Client.Photon.PhotonPeer::FetchServerTimestamp()
extern void PhotonPeer_FetchServerTimestamp_m1F2AC9035AF8C12B1AC320C4FF38C749934D3060 (void);
// 0x0000010D System.Boolean ExitGames.Client.Photon.PhotonPeer::EstablishEncryption()
extern void PhotonPeer_EstablishEncryption_m76CE5CB0A665120AC8843B965C9D505D55444672 (void);
// 0x0000010E System.Boolean ExitGames.Client.Photon.PhotonPeer::InitDatagramEncryption(System.Byte[],System.Byte[],System.Boolean,System.Boolean)
extern void PhotonPeer_InitDatagramEncryption_m5D49E268B8A4C4170D0905A1C5E824FA024E12E5 (void);
// 0x0000010F System.Void ExitGames.Client.Photon.PhotonPeer::InitPayloadEncryption(System.Byte[])
extern void PhotonPeer_InitPayloadEncryption_m6FE431BFD9197857B69489B455803C10E3F2D27E (void);
// 0x00000110 System.Void ExitGames.Client.Photon.PhotonPeer::Service()
extern void PhotonPeer_Service_m39B069A605E287E5C36559B21013FECF3073F636 (void);
// 0x00000111 System.Boolean ExitGames.Client.Photon.PhotonPeer::SendOutgoingCommands()
extern void PhotonPeer_SendOutgoingCommands_mE0CB9F4E532A641301981AC25B6D83C7E80024E0 (void);
// 0x00000112 System.Boolean ExitGames.Client.Photon.PhotonPeer::SendAcksOnly()
extern void PhotonPeer_SendAcksOnly_mF501EFC23C320777EB3D278D9CCAFDC4D8EABCBE (void);
// 0x00000113 System.Boolean ExitGames.Client.Photon.PhotonPeer::DispatchIncomingCommands()
extern void PhotonPeer_DispatchIncomingCommands_m446C69A18AC54B21DFDA0AD516511E879F4CB396 (void);
// 0x00000114 System.Boolean ExitGames.Client.Photon.PhotonPeer::SendOperation(System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,ExitGames.Client.Photon.SendOptions)
extern void PhotonPeer_SendOperation_mAC1A459B6CD4583322861372B7C118CE4A43EB77 (void);
// 0x00000115 System.Boolean ExitGames.Client.Photon.PhotonPeer::RegisterType(System.Type,System.Byte,ExitGames.Client.Photon.SerializeStreamMethod,ExitGames.Client.Photon.DeserializeStreamMethod)
extern void PhotonPeer_RegisterType_m8AFB40794A941D8CA85CC32112F13083745B0A39 (void);
// 0x00000116 System.Void ExitGames.Client.Photon.PhotonPeer::.cctor()
extern void PhotonPeer__cctor_m6456F52D9A9FFA83653E6AA02C68C218E6CC7072 (void);
// 0x00000117 System.Boolean ExitGames.Client.Photon.PhotonPeer::<EstablishEncryption>b__194_0()
extern void PhotonPeer_U3CEstablishEncryptionU3Eb__194_0_m2D8199131F628C75D753BBA44F07FAF52F52BDF3 (void);
// 0x00000118 System.Void ExitGames.Client.Photon.OperationRequest::.ctor()
extern void OperationRequest__ctor_m558FD94094B2EC1618E0EA7338D9541B132E9C3E (void);
// 0x00000119 System.Object ExitGames.Client.Photon.OperationResponse::get_Item(System.Byte)
extern void OperationResponse_get_Item_m5DE0E22A3D043CEBB7096DE04D02AD0F263CE469 (void);
// 0x0000011A System.String ExitGames.Client.Photon.OperationResponse::ToString()
extern void OperationResponse_ToString_m61134CDCA9CA4086787D6CFB33FA44B34B5C0C94 (void);
// 0x0000011B System.String ExitGames.Client.Photon.OperationResponse::ToStringFull()
extern void OperationResponse_ToStringFull_m16B15A498C495871A46643587A5AB33E261CD2F9 (void);
// 0x0000011C System.Void ExitGames.Client.Photon.OperationResponse::.ctor()
extern void OperationResponse__ctor_m9C9E8D6BA280F3D9B3893A9FC6885FDB680F14F9 (void);
// 0x0000011D System.Object ExitGames.Client.Photon.EventData::get_Item(System.Byte)
extern void EventData_get_Item_mF48FFDF3F59813E5E59A3A04A795651783D30978 (void);
// 0x0000011E System.Int32 ExitGames.Client.Photon.EventData::get_Sender()
extern void EventData_get_Sender_m3A2B20535525F98209A86C8AB91A5DAA605B5BF0 (void);
// 0x0000011F System.Object ExitGames.Client.Photon.EventData::get_CustomData()
extern void EventData_get_CustomData_mFFB6E0B7B69D4213C2D3D778A6BE32E2066219A8 (void);
// 0x00000120 System.Void ExitGames.Client.Photon.EventData::Reset()
extern void EventData_Reset_m5F15AD8005FD6E97859AE2EEA08F9F58E4B655C6 (void);
// 0x00000121 System.String ExitGames.Client.Photon.EventData::ToString()
extern void EventData_ToString_m7610A07F707964140A5CF67A45942186E5288899 (void);
// 0x00000122 System.Void ExitGames.Client.Photon.EventData::.ctor()
extern void EventData__ctor_m0A29174EE1871C0A76457A9EE9986D8DF3F2B6C0 (void);
// 0x00000123 System.Void ExitGames.Client.Photon.SerializeMethod::.ctor(System.Object,System.IntPtr)
extern void SerializeMethod__ctor_m05F829B54880798A4C16F40AF0F2704FBAE0B3E2 (void);
// 0x00000124 System.Byte[] ExitGames.Client.Photon.SerializeMethod::Invoke(System.Object)
extern void SerializeMethod_Invoke_m5D82F77EDFED6712B5CCD9B8267D8812A52FA797 (void);
// 0x00000125 System.IAsyncResult ExitGames.Client.Photon.SerializeMethod::BeginInvoke(System.Object,System.AsyncCallback,System.Object)
extern void SerializeMethod_BeginInvoke_m5FB247CA51C894E6BDEDCCE88AD94AE34BA86299 (void);
// 0x00000126 System.Byte[] ExitGames.Client.Photon.SerializeMethod::EndInvoke(System.IAsyncResult)
extern void SerializeMethod_EndInvoke_m7FBF157D17B5601F57E0A02945C3F8FB2F016C3B (void);
// 0x00000127 System.Void ExitGames.Client.Photon.SerializeStreamMethod::.ctor(System.Object,System.IntPtr)
extern void SerializeStreamMethod__ctor_m99B0F5D72C1825F034D5D6A1C1E82CFED031023C (void);
// 0x00000128 System.Int16 ExitGames.Client.Photon.SerializeStreamMethod::Invoke(ExitGames.Client.Photon.StreamBuffer,System.Object)
extern void SerializeStreamMethod_Invoke_m0E0608BA04378C3B1BEBFBE0C6B70C41973BA336 (void);
// 0x00000129 System.IAsyncResult ExitGames.Client.Photon.SerializeStreamMethod::BeginInvoke(ExitGames.Client.Photon.StreamBuffer,System.Object,System.AsyncCallback,System.Object)
extern void SerializeStreamMethod_BeginInvoke_m560932042E32DD6CD2B52C2AF87E29564A805944 (void);
// 0x0000012A System.Int16 ExitGames.Client.Photon.SerializeStreamMethod::EndInvoke(System.IAsyncResult)
extern void SerializeStreamMethod_EndInvoke_mD835B1A3D9125ED7B3F003FC41F7791EE0997A14 (void);
// 0x0000012B System.Void ExitGames.Client.Photon.DeserializeMethod::.ctor(System.Object,System.IntPtr)
extern void DeserializeMethod__ctor_m1FB0F48921E57D98FBAAAC6511CC61998673A595 (void);
// 0x0000012C System.Object ExitGames.Client.Photon.DeserializeMethod::Invoke(System.Byte[])
extern void DeserializeMethod_Invoke_m5F1E915187AE9C7F5B79135241E1A123B503FD0D (void);
// 0x0000012D System.IAsyncResult ExitGames.Client.Photon.DeserializeMethod::BeginInvoke(System.Byte[],System.AsyncCallback,System.Object)
extern void DeserializeMethod_BeginInvoke_m368779D8F2FAF9A642B6AAE5B7D9F55384B3A0BD (void);
// 0x0000012E System.Object ExitGames.Client.Photon.DeserializeMethod::EndInvoke(System.IAsyncResult)
extern void DeserializeMethod_EndInvoke_m2F042098630BBBA26FEAA212B5D64E47C13CB59F (void);
// 0x0000012F System.Void ExitGames.Client.Photon.DeserializeStreamMethod::.ctor(System.Object,System.IntPtr)
extern void DeserializeStreamMethod__ctor_m423531504E0910E3A0E9DF05FFA1C62B36C628A0 (void);
// 0x00000130 System.Object ExitGames.Client.Photon.DeserializeStreamMethod::Invoke(ExitGames.Client.Photon.StreamBuffer,System.Int16)
extern void DeserializeStreamMethod_Invoke_m7A4C6C2B6E783981E817171F52E2EF67207432D7 (void);
// 0x00000131 System.IAsyncResult ExitGames.Client.Photon.DeserializeStreamMethod::BeginInvoke(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.AsyncCallback,System.Object)
extern void DeserializeStreamMethod_BeginInvoke_m8CD2DBE40F0BC0FD7230AC077CAA49B169D14177 (void);
// 0x00000132 System.Object ExitGames.Client.Photon.DeserializeStreamMethod::EndInvoke(System.IAsyncResult)
extern void DeserializeStreamMethod_EndInvoke_mD9EFA76BB7BB3760A9964BC0FDDAEAABBB751470 (void);
// 0x00000133 System.Void ExitGames.Client.Photon.CustomType::.ctor(System.Type,System.Byte,ExitGames.Client.Photon.SerializeStreamMethod,ExitGames.Client.Photon.DeserializeStreamMethod)
extern void CustomType__ctor_mC977818960FE75497DC34F0F8494BA648D1C9519 (void);
// 0x00000134 System.Boolean ExitGames.Client.Photon.Protocol::TryRegisterType(System.Type,System.Byte,ExitGames.Client.Photon.SerializeStreamMethod,ExitGames.Client.Photon.DeserializeStreamMethod)
extern void Protocol_TryRegisterType_m4BD2C2AA7A5DC71A5BFF3D5B9625A0AC5485BA7F (void);
// 0x00000135 System.Void ExitGames.Client.Photon.Protocol::Serialize(System.Int16,System.Byte[],System.Int32&)
extern void Protocol_Serialize_mFF18601715D23ADFADEC816F75BE00A9959D40FD (void);
// 0x00000136 System.Void ExitGames.Client.Photon.Protocol::Serialize(System.Int32,System.Byte[],System.Int32&)
extern void Protocol_Serialize_m6A88DC8FC36B9BFA82F30885428013A3EDD82ECD (void);
// 0x00000137 System.Void ExitGames.Client.Photon.Protocol::Serialize(System.Single,System.Byte[],System.Int32&)
extern void Protocol_Serialize_m30A6CF08BB9445E47360B6F4C2970575ECAC4924 (void);
// 0x00000138 System.Void ExitGames.Client.Photon.Protocol::Deserialize(System.Int32&,System.Byte[],System.Int32&)
extern void Protocol_Deserialize_m1DCDC0130758DDA4AFA98ABF65A1A1C5898CA2CC (void);
// 0x00000139 System.Void ExitGames.Client.Photon.Protocol::Deserialize(System.Int16&,System.Byte[],System.Int32&)
extern void Protocol_Deserialize_m0AE978257FD9D79D505C3759E56A6C60C7C10F6C (void);
// 0x0000013A System.Void ExitGames.Client.Photon.Protocol::Deserialize(System.Single&,System.Byte[],System.Int32&)
extern void Protocol_Deserialize_mCF061AE34C52C0D1CB1B823AA19AEEAD8B39F759 (void);
// 0x0000013B System.Void ExitGames.Client.Photon.Protocol::.cctor()
extern void Protocol__cctor_mAE16A8D36C4E4DD0A830D6A7D2427F17B57EC0A2 (void);
// 0x0000013C System.String ExitGames.Client.Photon.Protocol16::get_ProtocolType()
extern void Protocol16_get_ProtocolType_m36A0C545A9FA66EF2C2ECCF3F2F49B0808303728 (void);
// 0x0000013D System.Byte[] ExitGames.Client.Photon.Protocol16::get_VersionBytes()
extern void Protocol16_get_VersionBytes_mCF1C6DB63EE0DD617645715C3FEEBC54E02C5CB2 (void);
// 0x0000013E System.Boolean ExitGames.Client.Photon.Protocol16::SerializeCustom(ExitGames.Client.Photon.StreamBuffer,System.Object)
extern void Protocol16_SerializeCustom_mD5D82F6DA9C4829EF2267539A5EAF66711C90429 (void);
// 0x0000013F System.Object ExitGames.Client.Photon.Protocol16::DeserializeCustom(ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void Protocol16_DeserializeCustom_m104CD761F2F2A8BC60AAB4512CD978223B9B0C85 (void);
// 0x00000140 System.Type ExitGames.Client.Photon.Protocol16::GetTypeOfCode(System.Byte)
extern void Protocol16_GetTypeOfCode_m306BC9AD71CD95AEE5D6FF5131616925B89E4835 (void);
// 0x00000141 ExitGames.Client.Photon.Protocol16/GpType ExitGames.Client.Photon.Protocol16::GetCodeOfType(System.Type)
extern void Protocol16_GetCodeOfType_mDF59211C9A1DCADE11300713BD3D3CE0CA9849ED (void);
// 0x00000142 System.Array ExitGames.Client.Photon.Protocol16::CreateArrayByType(System.Byte,System.Int16)
extern void Protocol16_CreateArrayByType_m1FD5DAA212AF1BD1745F7CC514C5B9145D95A56E (void);
// 0x00000143 System.Void ExitGames.Client.Photon.Protocol16::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationRequest,System.Boolean)
extern void Protocol16_SerializeOperationRequest_mBFD78D7EC642BF0E33EFD8D9CD3946BA1F5B2991 (void);
// 0x00000144 System.Void ExitGames.Client.Photon.Protocol16::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Boolean)
extern void Protocol16_SerializeOperationRequest_m75C3C7E786D6566E207D0719E523343493D1A8FA (void);
// 0x00000145 ExitGames.Client.Photon.OperationRequest ExitGames.Client.Photon.Protocol16::DeserializeOperationRequest(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeOperationRequest_mD16C7A8E87F57AC15143B15C877FD6F9015C3292 (void);
// 0x00000146 System.Void ExitGames.Client.Photon.Protocol16::SerializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationResponse,System.Boolean)
extern void Protocol16_SerializeOperationResponse_m357B3EB3BDFA132DBE22273434DA1569275C55E4 (void);
// 0x00000147 ExitGames.Client.Photon.OperationResponse ExitGames.Client.Photon.Protocol16::DeserializeOperationResponse(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeOperationResponse_m59672AEB3CA52EF8C9F65B62F7A1EDA2011E2471 (void);
// 0x00000148 System.Void ExitGames.Client.Photon.Protocol16::SerializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,System.Boolean)
extern void Protocol16_SerializeEventData_m02A1F1AAB3FF33B495B2D2A9510E690E8AA3B5A9 (void);
// 0x00000149 ExitGames.Client.Photon.EventData ExitGames.Client.Photon.Protocol16::DeserializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData)
extern void Protocol16_DeserializeEventData_mF18E6D29E8A24646F4B73A07A144338E7A8B0497 (void);
// 0x0000014A System.Void ExitGames.Client.Photon.Protocol16::SerializeParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>)
extern void Protocol16_SerializeParameterTable_m4EAFAA241D126EB0C0193694BBD39027C2DF9595 (void);
// 0x0000014B System.Collections.Generic.Dictionary`2<System.Byte,System.Object> ExitGames.Client.Photon.Protocol16::DeserializeParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>)
extern void Protocol16_DeserializeParameterTable_mEF5D0C19D0D936F6D44B937D53619742189C8E19 (void);
// 0x0000014C System.Void ExitGames.Client.Photon.Protocol16::Serialize(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol16_Serialize_mD343ECD18CAA50AB0AE67ADF66AC708BBBA44FCD (void);
// 0x0000014D System.Void ExitGames.Client.Photon.Protocol16::SerializeByte(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Boolean)
extern void Protocol16_SerializeByte_m7FDFAFFE9232EE3E6C253FB6784037CD2E6D7FC4 (void);
// 0x0000014E System.Void ExitGames.Client.Photon.Protocol16::SerializeBoolean(ExitGames.Client.Photon.StreamBuffer,System.Boolean,System.Boolean)
extern void Protocol16_SerializeBoolean_m9C81392E4FF706173FB508F6FE1D1727D01C4997 (void);
// 0x0000014F System.Void ExitGames.Client.Photon.Protocol16::SerializeShort(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
extern void Protocol16_SerializeShort_m9079947190930FBB4C3180ED7CA0DA355081F98A (void);
// 0x00000150 System.Void ExitGames.Client.Photon.Protocol16::SerializeInteger(ExitGames.Client.Photon.StreamBuffer,System.Int32,System.Boolean)
extern void Protocol16_SerializeInteger_m8541B6C6737E11D75B70D443DC981C6A64B703FF (void);
// 0x00000151 System.Void ExitGames.Client.Photon.Protocol16::SerializeLong(ExitGames.Client.Photon.StreamBuffer,System.Int64,System.Boolean)
extern void Protocol16_SerializeLong_m3B9AB9AC5126003C68956512BEE8D2318C064F1A (void);
// 0x00000152 System.Void ExitGames.Client.Photon.Protocol16::SerializeFloat(ExitGames.Client.Photon.StreamBuffer,System.Single,System.Boolean)
extern void Protocol16_SerializeFloat_m8BA329AFC958B70097CBDDC3168F24FB2193AA25 (void);
// 0x00000153 System.Void ExitGames.Client.Photon.Protocol16::SerializeDouble(ExitGames.Client.Photon.StreamBuffer,System.Double,System.Boolean)
extern void Protocol16_SerializeDouble_m3BFB64989BEAC743A2618B28FA4F679A648B85DB (void);
// 0x00000154 System.Void ExitGames.Client.Photon.Protocol16::SerializeString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
extern void Protocol16_SerializeString_m6F81D2EB51D05DF9E3AA9D11146BE882BDF7ED56 (void);
// 0x00000155 System.Void ExitGames.Client.Photon.Protocol16::SerializeArray(ExitGames.Client.Photon.StreamBuffer,System.Array,System.Boolean)
extern void Protocol16_SerializeArray_mDBB4A3B2612C0F355A4E41C2F5690CD3317A32A1 (void);
// 0x00000156 System.Void ExitGames.Client.Photon.Protocol16::SerializeByteArray(ExitGames.Client.Photon.StreamBuffer,System.Byte[],System.Boolean)
extern void Protocol16_SerializeByteArray_mB9BDD72F524BC2F8E020108206E36FA2E9569ADC (void);
// 0x00000157 System.Void ExitGames.Client.Photon.Protocol16::SerializeByteArraySegment(ExitGames.Client.Photon.StreamBuffer,System.Byte[],System.Int32,System.Int32,System.Boolean)
extern void Protocol16_SerializeByteArraySegment_mD96CB6ADF9348C06A717815D6678906AD2D11B41 (void);
// 0x00000158 System.Void ExitGames.Client.Photon.Protocol16::SerializeIntArrayOptimized(ExitGames.Client.Photon.StreamBuffer,System.Int32[],System.Boolean)
extern void Protocol16_SerializeIntArrayOptimized_m350F2106E4797294E81E45E88F45B9E391B19E59 (void);
// 0x00000159 System.Void ExitGames.Client.Photon.Protocol16::SerializeObjectArray(ExitGames.Client.Photon.StreamBuffer,System.Collections.IList,System.Boolean)
extern void Protocol16_SerializeObjectArray_m34EA9CC7EBEAFEABD511BC1F7221FFEA2E60D524 (void);
// 0x0000015A System.Void ExitGames.Client.Photon.Protocol16::SerializeHashTable(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.Hashtable,System.Boolean)
extern void Protocol16_SerializeHashTable_m38BED9BD9C29E36F4C9D49644EB6C893A780DDA1 (void);
// 0x0000015B System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionary(ExitGames.Client.Photon.StreamBuffer,System.Collections.IDictionary,System.Boolean)
extern void Protocol16_SerializeDictionary_m2B8AE49B2C6F59EA2F69F813B375BD0C68C0CF01 (void);
// 0x0000015C System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionaryHeader(ExitGames.Client.Photon.StreamBuffer,System.Type)
extern void Protocol16_SerializeDictionaryHeader_m96B4EED3BB00C7179142F55F5C6DF87E2130734B (void);
// 0x0000015D System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionaryHeader(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean&,System.Boolean&)
extern void Protocol16_SerializeDictionaryHeader_m9177457118A5D6BDDA6510329AF346C3697EC1C8 (void);
// 0x0000015E System.Void ExitGames.Client.Photon.Protocol16::SerializeDictionaryElements(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean,System.Boolean)
extern void Protocol16_SerializeDictionaryElements_m9E6E4602D1CFAA8D0F94750541AC11EEF7F6ECA2 (void);
// 0x0000015F System.Object ExitGames.Client.Photon.Protocol16::Deserialize(ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void Protocol16_Deserialize_mDD04F9283094D2170D9E2213A301E6C6ECBB7EC7 (void);
// 0x00000160 System.Byte ExitGames.Client.Photon.Protocol16::DeserializeByte(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeByte_mA0D0FED288302060E7F3CD2FD242C04AE2EAD36E (void);
// 0x00000161 System.Boolean ExitGames.Client.Photon.Protocol16::DeserializeBoolean(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeBoolean_mAE87B8CB95931881EB9CC72DE2834E9255FC29D7 (void);
// 0x00000162 System.Int16 ExitGames.Client.Photon.Protocol16::DeserializeShort(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeShort_m5A9FB633FF841A4CC1F2282832BF12B7BA1D51FE (void);
// 0x00000163 System.Int32 ExitGames.Client.Photon.Protocol16::DeserializeInteger(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeInteger_mAFF4BAC660E688CC207DD74E9AEDA0FEE31C8323 (void);
// 0x00000164 System.Int64 ExitGames.Client.Photon.Protocol16::DeserializeLong(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeLong_mCBFA4A8D080BA04E9FFDE7A8211159C3116B08F5 (void);
// 0x00000165 System.Single ExitGames.Client.Photon.Protocol16::DeserializeFloat(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeFloat_m49FEA20CC2B7685998323A89D7FE9EAC5FFBB52E (void);
// 0x00000166 System.Double ExitGames.Client.Photon.Protocol16::DeserializeDouble(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeDouble_mF5AC7B143DD0E5BA9F2543076BCB84188ADFAA50 (void);
// 0x00000167 System.String ExitGames.Client.Photon.Protocol16::DeserializeString(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeString_m61AE125487A2B41983AF8926EFFEC206916F81F9 (void);
// 0x00000168 System.Array ExitGames.Client.Photon.Protocol16::DeserializeArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeArray_mF123A162CC775F03ADCD776940645CAA7E13D649 (void);
// 0x00000169 System.Byte[] ExitGames.Client.Photon.Protocol16::DeserializeByteArray(ExitGames.Client.Photon.StreamBuffer,System.Int32)
extern void Protocol16_DeserializeByteArray_m480A75BE3782B83A559C0D04E72BA73F8D7F2936 (void);
// 0x0000016A System.Int32[] ExitGames.Client.Photon.Protocol16::DeserializeIntArray(ExitGames.Client.Photon.StreamBuffer,System.Int32)
extern void Protocol16_DeserializeIntArray_m12C8A70E4D006E1224DFC029FC4ED737D93A0C56 (void);
// 0x0000016B System.String[] ExitGames.Client.Photon.Protocol16::DeserializeStringArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeStringArray_mFEECC1EB75D43D02739D7D9E81EAC45F852A531A (void);
// 0x0000016C System.Object[] ExitGames.Client.Photon.Protocol16::DeserializeObjectArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeObjectArray_mC94160BFD4731A1021184EB055556DC49A968482 (void);
// 0x0000016D ExitGames.Client.Photon.Hashtable ExitGames.Client.Photon.Protocol16::DeserializeHashTable(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeHashTable_m4296E24DE127BCE514E7875FF9CBD169F5CC3B20 (void);
// 0x0000016E System.Collections.IDictionary ExitGames.Client.Photon.Protocol16::DeserializeDictionary(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol16_DeserializeDictionary_mF7FAD9858D41886C3F43C73EA9B3217CDA436D8E (void);
// 0x0000016F System.Boolean ExitGames.Client.Photon.Protocol16::DeserializeDictionaryArray(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Array&)
extern void Protocol16_DeserializeDictionaryArray_m626F6271DCA7271C9066C5D41E9315BF4D041B8A (void);
// 0x00000170 System.Type ExitGames.Client.Photon.Protocol16::DeserializeDictionaryType(ExitGames.Client.Photon.StreamBuffer,System.Byte&,System.Byte&)
extern void Protocol16_DeserializeDictionaryType_m49BCA1199412793EC115D08ACFBD30A9E7F44944 (void);
// 0x00000171 System.Void ExitGames.Client.Photon.Protocol16::.ctor()
extern void Protocol16__ctor_m3E2C54818724006FEDA059851DAD57F2FD3AFDD0 (void);
// 0x00000172 System.Void ExitGames.Client.Photon.Protocol16::.cctor()
extern void Protocol16__cctor_mA4572C6B7C60BB32B8AF9F08608B02A380424315 (void);
// 0x00000173 System.Void ExitGames.Client.Photon.InvalidDataException::.ctor(System.String)
extern void InvalidDataException__ctor_m81178A38375C9B75D0A8A02CF67F83C25D054E98 (void);
// 0x00000174 System.String ExitGames.Client.Photon.Protocol18::get_ProtocolType()
extern void Protocol18_get_ProtocolType_mB6CAC8AD444569ADD180CFE33B5A3FE626539891 (void);
// 0x00000175 System.Byte[] ExitGames.Client.Photon.Protocol18::get_VersionBytes()
extern void Protocol18_get_VersionBytes_m5AC09738DAA62689D0819433A0C99C5D17781EEF (void);
// 0x00000176 System.Void ExitGames.Client.Photon.Protocol18::Serialize(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_Serialize_m9E06746AB0FEEBF2DFE4AF2F7D7C1413CB426ACC (void);
// 0x00000177 System.Void ExitGames.Client.Photon.Protocol18::SerializeShort(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
extern void Protocol18_SerializeShort_mE585C7802A260DC15800E4357831793F733E111A (void);
// 0x00000178 System.Void ExitGames.Client.Photon.Protocol18::SerializeString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
extern void Protocol18_SerializeString_mF552363C2AAC83E1196E976F58D52AEB8EF4FB51 (void);
// 0x00000179 System.Object ExitGames.Client.Photon.Protocol18::Deserialize(ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void Protocol18_Deserialize_m51739F38B47938D4275B362341D5FA91467D0D73 (void);
// 0x0000017A System.Int16 ExitGames.Client.Photon.Protocol18::DeserializeShort(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_DeserializeShort_m1A9C543A3D59D608160A661A5666AD30364709ED (void);
// 0x0000017B System.Byte ExitGames.Client.Photon.Protocol18::DeserializeByte(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_DeserializeByte_mFF20379D454DEEF8C95ADFF9E21FB1F76DED2AAF (void);
// 0x0000017C System.Type ExitGames.Client.Photon.Protocol18::GetAllowedDictionaryKeyTypes(ExitGames.Client.Photon.Protocol18/GpType)
extern void Protocol18_GetAllowedDictionaryKeyTypes_mCA648AD6BF893DD43A2C2E8E109DA3C3EE2A6C9D (void);
// 0x0000017D System.Type ExitGames.Client.Photon.Protocol18::GetClrArrayType(ExitGames.Client.Photon.Protocol18/GpType)
extern void Protocol18_GetClrArrayType_m737EFCD75F6F931CBD2B8291507F55AA70D85CC0 (void);
// 0x0000017E ExitGames.Client.Photon.Protocol18/GpType ExitGames.Client.Photon.Protocol18::GetCodeOfType(System.Type)
extern void Protocol18_GetCodeOfType_m55903BBB57342E20C5FF64A8385CF30E8A2FAE18 (void);
// 0x0000017F ExitGames.Client.Photon.Protocol18/GpType ExitGames.Client.Photon.Protocol18::GetCodeOfTypeCode(System.TypeCode)
extern void Protocol18_GetCodeOfTypeCode_m953C03BE673096D699DCDE2F80544E882F2F5213 (void);
// 0x00000180 System.Object ExitGames.Client.Photon.Protocol18::Read(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_Read_m7059C3280F6F7325827D153FEC6A1FFB54BD9B6B (void);
// 0x00000181 System.Object ExitGames.Client.Photon.Protocol18::Read(ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void Protocol18_Read_m9A2D18821864CFE9ADD2708FE6F1B33846F254D3 (void);
// 0x00000182 System.Boolean ExitGames.Client.Photon.Protocol18::ReadBoolean(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadBoolean_m1F375812F41A0D259872B4C2B2434D62AA700E2B (void);
// 0x00000183 System.Byte ExitGames.Client.Photon.Protocol18::ReadByte(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadByte_mB5AD872C97BC94A14E3F81DDDDEEA1A8E9B88A3B (void);
// 0x00000184 System.Int16 ExitGames.Client.Photon.Protocol18::ReadInt16(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadInt16_m1E8D82A489148C3DD8B3FE0DEEBB91A84862284D (void);
// 0x00000185 System.UInt16 ExitGames.Client.Photon.Protocol18::ReadUShort(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadUShort_m231CBC712D3853893ACE5459605FABE8964E2730 (void);
// 0x00000186 System.Single ExitGames.Client.Photon.Protocol18::ReadSingle(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadSingle_m47B24A0185EBF6F35F1A93AEE578971499356B47 (void);
// 0x00000187 System.Double ExitGames.Client.Photon.Protocol18::ReadDouble(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDouble_mE49110C219C934196256EA1C5E9D40B098D054C4 (void);
// 0x00000188 System.Byte[] ExitGames.Client.Photon.Protocol18::ReadByteArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadByteArray_m4779CF2B899E7D6FB72E1B9C8344F82ECF631F21 (void);
// 0x00000189 System.Object ExitGames.Client.Photon.Protocol18::ReadCustomType(ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void Protocol18_ReadCustomType_mC16DF617C8D25B1076B29B5E0A746951DEFF0195 (void);
// 0x0000018A ExitGames.Client.Photon.EventData ExitGames.Client.Photon.Protocol18::DeserializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData)
extern void Protocol18_DeserializeEventData_mA305928E335EBA6F05B7F7EF7A571011B3842FDA (void);
// 0x0000018B System.Collections.Generic.Dictionary`2<System.Byte,System.Object> ExitGames.Client.Photon.Protocol18::ReadParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>)
extern void Protocol18_ReadParameterTable_mA9BE287D615BDEB546AC01DBEF2CB8F740572B7B (void);
// 0x0000018C ExitGames.Client.Photon.Hashtable ExitGames.Client.Photon.Protocol18::ReadHashtable(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadHashtable_m5A48A6A1ED736E05608AED6FAA8294ABCFBE8F41 (void);
// 0x0000018D ExitGames.Client.Photon.OperationRequest ExitGames.Client.Photon.Protocol18::DeserializeOperationRequest(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_DeserializeOperationRequest_m9EFF7B1A31625B0443CD9DA4A7D1DEAC255DB3DE (void);
// 0x0000018E ExitGames.Client.Photon.OperationResponse ExitGames.Client.Photon.Protocol18::DeserializeOperationResponse(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_DeserializeOperationResponse_m19984E8A54B1EBB3790348D32A5F7D3C792B4802 (void);
// 0x0000018F System.String ExitGames.Client.Photon.Protocol18::ReadString(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadString_mD35A027F8B88121F9F97F44734175025593A5871 (void);
// 0x00000190 System.Object ExitGames.Client.Photon.Protocol18::ReadCustomTypeArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCustomTypeArray_m834C15348EEB3A4CB1F692BC400FF0218D9EBA68 (void);
// 0x00000191 System.Type ExitGames.Client.Photon.Protocol18::ReadDictionaryType(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.Protocol18/GpType&,ExitGames.Client.Photon.Protocol18/GpType&)
extern void Protocol18_ReadDictionaryType_m011E733E05E80A048A2AA61E0CBB5B1D45AFD75D (void);
// 0x00000192 System.Type ExitGames.Client.Photon.Protocol18::ReadDictionaryType(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDictionaryType_m4D54B811BCCE0F5C68C5212BE63CFF95C800B71D (void);
// 0x00000193 System.Type ExitGames.Client.Photon.Protocol18::GetDictArrayType(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_GetDictArrayType_m6958868B92063D226BA0A2429B2CE43B8956F78A (void);
// 0x00000194 System.Collections.IDictionary ExitGames.Client.Photon.Protocol18::ReadDictionary(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDictionary_m960E700659F0DD54907FDCA24917A7C3D3AA275E (void);
// 0x00000195 System.Boolean ExitGames.Client.Photon.Protocol18::ReadDictionaryElements(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.Protocol18/GpType,ExitGames.Client.Photon.Protocol18/GpType,System.Collections.IDictionary)
extern void Protocol18_ReadDictionaryElements_m91B7CE3DC8A765BF3D536F1CC647A1E186C0D3D4 (void);
// 0x00000196 System.Object[] ExitGames.Client.Photon.Protocol18::ReadObjectArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadObjectArray_mB1A56EEB51FA30EB5FA3F39F30B770A945AD14CE (void);
// 0x00000197 System.Boolean[] ExitGames.Client.Photon.Protocol18::ReadBooleanArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadBooleanArray_mC166C14CFFE8B41FC8414641A1B01FEFD93A367A (void);
// 0x00000198 System.Int16[] ExitGames.Client.Photon.Protocol18::ReadInt16Array(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadInt16Array_m3C7388939224BA497C23D1172CB1CB4F948F0F0F (void);
// 0x00000199 System.Single[] ExitGames.Client.Photon.Protocol18::ReadSingleArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadSingleArray_m1C65D526E0B5900287C4144BCBEF69F22A9A10D8 (void);
// 0x0000019A System.Double[] ExitGames.Client.Photon.Protocol18::ReadDoubleArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDoubleArray_mED49F1B57143F1EA7CCD9F0CDB75315F0A9CC3FC (void);
// 0x0000019B System.String[] ExitGames.Client.Photon.Protocol18::ReadStringArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadStringArray_m13AE31355812823E5A5E25FB8FEA6E4BA90A12F1 (void);
// 0x0000019C ExitGames.Client.Photon.Hashtable[] ExitGames.Client.Photon.Protocol18::ReadHashtableArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadHashtableArray_mEF8537B34173F93EB3726CB9C773E5C89F74FAAB (void);
// 0x0000019D System.Collections.IDictionary[] ExitGames.Client.Photon.Protocol18::ReadDictionaryArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadDictionaryArray_m0168075FB317DFC6B6A1D6FE8FC18E560313EA4D (void);
// 0x0000019E System.Array ExitGames.Client.Photon.Protocol18::ReadArrayInArray(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadArrayInArray_m76DD6B90669BEA1A02174D0C23D942080A1BCA0C (void);
// 0x0000019F System.Int32 ExitGames.Client.Photon.Protocol18::ReadInt1(ExitGames.Client.Photon.StreamBuffer,System.Boolean)
extern void Protocol18_ReadInt1_mFECDC50F317393B38DDAD2F2A2610ABED7495F3C (void);
// 0x000001A0 System.Int32 ExitGames.Client.Photon.Protocol18::ReadInt2(ExitGames.Client.Photon.StreamBuffer,System.Boolean)
extern void Protocol18_ReadInt2_m7DDF259C50D6B4E8FFECADC8C3117678F0AC9BA4 (void);
// 0x000001A1 System.Int32 ExitGames.Client.Photon.Protocol18::ReadCompressedInt32(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt32_m7F1D509C598B6D168FF05BC2B5636F4C41453707 (void);
// 0x000001A2 System.UInt32 ExitGames.Client.Photon.Protocol18::ReadCompressedUInt32(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedUInt32_mEAC07F2EDEE8B9B596178000BC6BFAE9A76EBE8F (void);
// 0x000001A3 System.Int64 ExitGames.Client.Photon.Protocol18::ReadCompressedInt64(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt64_m28B2B547184EBFB182E05A6610FC6CA8819852B5 (void);
// 0x000001A4 System.UInt64 ExitGames.Client.Photon.Protocol18::ReadCompressedUInt64(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedUInt64_mD3A47078DB813D95843A7219F7443EE5FFFFB6DA (void);
// 0x000001A5 System.Int32[] ExitGames.Client.Photon.Protocol18::ReadCompressedInt32Array(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt32Array_mBFF9331A05B308E4D8A51F4522E3D773445676F2 (void);
// 0x000001A6 System.Int64[] ExitGames.Client.Photon.Protocol18::ReadCompressedInt64Array(ExitGames.Client.Photon.StreamBuffer)
extern void Protocol18_ReadCompressedInt64Array_mA7D9294953EA992B0DC04729A4313BDC9C413D29 (void);
// 0x000001A7 System.Int32 ExitGames.Client.Photon.Protocol18::DecodeZigZag32(System.UInt32)
extern void Protocol18_DecodeZigZag32_m38102EA03172F0D9767E25D31F576D4B254FFA08 (void);
// 0x000001A8 System.Int64 ExitGames.Client.Photon.Protocol18::DecodeZigZag64(System.UInt64)
extern void Protocol18_DecodeZigZag64_m94B1391D0D006C2CE4A7D5F009E023CC06B8A5BA (void);
// 0x000001A9 System.Void ExitGames.Client.Photon.Protocol18::Write(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_Write_mA0BC0B4D385A797C5455A742E32975855A54BBCB (void);
// 0x000001AA System.Void ExitGames.Client.Photon.Protocol18::Write(ExitGames.Client.Photon.StreamBuffer,System.Object,ExitGames.Client.Photon.Protocol18/GpType,System.Boolean)
extern void Protocol18_Write_m918F660E69F3DE4CFE3217CBBC8B42D6634CA996 (void);
// 0x000001AB System.Void ExitGames.Client.Photon.Protocol18::SerializeEventData(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.EventData,System.Boolean)
extern void Protocol18_SerializeEventData_mF4ED5EE2023608F158D9A6F267E7A0DD6EB9A9BE (void);
// 0x000001AC System.Void ExitGames.Client.Photon.Protocol18::WriteParameterTable(ExitGames.Client.Photon.StreamBuffer,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>)
extern void Protocol18_WriteParameterTable_mE671B34D9599A37AE95D422C3A5F4FA255795C39 (void);
// 0x000001AD System.Void ExitGames.Client.Photon.Protocol18::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationRequest,System.Boolean)
extern void Protocol18_SerializeOperationRequest_m3C7F777239F252C8FAA243E64D43EB3A9943516D (void);
// 0x000001AE System.Void ExitGames.Client.Photon.Protocol18::SerializeOperationRequest(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Boolean)
extern void Protocol18_SerializeOperationRequest_mFB589BEFCA057FBC403AD2B2ADEDDF2BEA24B523 (void);
// 0x000001AF System.Void ExitGames.Client.Photon.Protocol18::SerializeOperationResponse(ExitGames.Client.Photon.StreamBuffer,ExitGames.Client.Photon.OperationResponse,System.Boolean)
extern void Protocol18_SerializeOperationResponse_m6EFB003C0233CEAD72C250E36499302E5F6319DC (void);
// 0x000001B0 System.Void ExitGames.Client.Photon.Protocol18::WriteByte(ExitGames.Client.Photon.StreamBuffer,System.Byte,System.Boolean)
extern void Protocol18_WriteByte_m00B3AEE4458EAA96D570414817DB389216B9FEAE (void);
// 0x000001B1 System.Void ExitGames.Client.Photon.Protocol18::WriteBoolean(ExitGames.Client.Photon.StreamBuffer,System.Boolean,System.Boolean)
extern void Protocol18_WriteBoolean_mCF8995E7C4C5E3DD1D9F787A032724E16F3BC6DA (void);
// 0x000001B2 System.Void ExitGames.Client.Photon.Protocol18::WriteUShort(ExitGames.Client.Photon.StreamBuffer,System.UInt16)
extern void Protocol18_WriteUShort_m922ACA38B59B167C850BA0649480B5E38FAD68E1 (void);
// 0x000001B3 System.Void ExitGames.Client.Photon.Protocol18::WriteInt16(ExitGames.Client.Photon.StreamBuffer,System.Int16,System.Boolean)
extern void Protocol18_WriteInt16_mCC952A1BC9FF4AC34DE6631746BAA02EEEA7FA71 (void);
// 0x000001B4 System.Void ExitGames.Client.Photon.Protocol18::WriteDouble(ExitGames.Client.Photon.StreamBuffer,System.Double,System.Boolean)
extern void Protocol18_WriteDouble_m253D034B6A1A393A117F4D8710889680915E3176 (void);
// 0x000001B5 System.Void ExitGames.Client.Photon.Protocol18::WriteSingle(ExitGames.Client.Photon.StreamBuffer,System.Single,System.Boolean)
extern void Protocol18_WriteSingle_m07354CFB497134F4161E08F35C8EA5BC8B041B90 (void);
// 0x000001B6 System.Void ExitGames.Client.Photon.Protocol18::WriteString(ExitGames.Client.Photon.StreamBuffer,System.String,System.Boolean)
extern void Protocol18_WriteString_m864B4B009174F93032AB74BA797B2563323F9A5D (void);
// 0x000001B7 System.Void ExitGames.Client.Photon.Protocol18::WriteHashtable(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteHashtable_m060F9803CE47495B63211590AAB889945BCEAF4E (void);
// 0x000001B8 System.Void ExitGames.Client.Photon.Protocol18::WriteByteArray(ExitGames.Client.Photon.StreamBuffer,System.Byte[],System.Boolean)
extern void Protocol18_WriteByteArray_m7CBCF95BA36FED016A644B7C651031B65DF840F7 (void);
// 0x000001B9 System.Void ExitGames.Client.Photon.Protocol18::WriteByteArraySegment(ExitGames.Client.Photon.StreamBuffer,System.Byte[],System.Int32,System.Int32,System.Boolean)
extern void Protocol18_WriteByteArraySegment_m523ED9BCAF0CCE33D6280A55394A92E15AF16AC2 (void);
// 0x000001BA System.Void ExitGames.Client.Photon.Protocol18::WriteInt32ArrayCompressed(ExitGames.Client.Photon.StreamBuffer,System.Int32[],System.Boolean)
extern void Protocol18_WriteInt32ArrayCompressed_mCCA9CB1418677B1DF0C4C6222FEC9AFCBE64B492 (void);
// 0x000001BB System.Void ExitGames.Client.Photon.Protocol18::WriteInt64ArrayCompressed(ExitGames.Client.Photon.StreamBuffer,System.Int64[],System.Boolean)
extern void Protocol18_WriteInt64ArrayCompressed_mABC5495DD97ECE38982E418EE33ECC30C52ED4AE (void);
// 0x000001BC System.Void ExitGames.Client.Photon.Protocol18::WriteBoolArray(ExitGames.Client.Photon.StreamBuffer,System.Boolean[],System.Boolean)
extern void Protocol18_WriteBoolArray_m18CDD32FF33AC035E0A248B5496C642122E1E21E (void);
// 0x000001BD System.Void ExitGames.Client.Photon.Protocol18::WriteInt16Array(ExitGames.Client.Photon.StreamBuffer,System.Int16[],System.Boolean)
extern void Protocol18_WriteInt16Array_m499087207ADE3DF69A123DF16FE1EF65A403223D (void);
// 0x000001BE System.Void ExitGames.Client.Photon.Protocol18::WriteSingleArray(ExitGames.Client.Photon.StreamBuffer,System.Single[],System.Boolean)
extern void Protocol18_WriteSingleArray_mB8675F2CE34122CD11CFF3AC767F9259562353E2 (void);
// 0x000001BF System.Void ExitGames.Client.Photon.Protocol18::WriteDoubleArray(ExitGames.Client.Photon.StreamBuffer,System.Double[],System.Boolean)
extern void Protocol18_WriteDoubleArray_mAB44D72CF286B0DF9789109F5FDEA56F47BC1413 (void);
// 0x000001C0 System.Void ExitGames.Client.Photon.Protocol18::WriteStringArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteStringArray_mC830B96A2690C2DEA137FD89EC873058BC49E384 (void);
// 0x000001C1 System.Void ExitGames.Client.Photon.Protocol18::WriteObjectArray(ExitGames.Client.Photon.StreamBuffer,System.Collections.IList,System.Boolean)
extern void Protocol18_WriteObjectArray_m672D006CBE2568D62984DD06273F545C13452CCD (void);
// 0x000001C2 System.Void ExitGames.Client.Photon.Protocol18::WriteArrayInArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteArrayInArray_mFFB12A953BC182649713710598B96635DC003D5C (void);
// 0x000001C3 System.Void ExitGames.Client.Photon.Protocol18::WriteCustomTypeBody(ExitGames.Client.Photon.CustomType,ExitGames.Client.Photon.StreamBuffer,System.Object)
extern void Protocol18_WriteCustomTypeBody_mAA46C38B50DCEFD5B20F93B1310E4F8C1D9A6154 (void);
// 0x000001C4 System.Void ExitGames.Client.Photon.Protocol18::WriteCustomType(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteCustomType_mA88D115352E548C72560A9F864683318790B710E (void);
// 0x000001C5 System.Void ExitGames.Client.Photon.Protocol18::WriteCustomTypeArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteCustomTypeArray_m8D64614FA25259E37D4DAD30560C76C961011E3C (void);
// 0x000001C6 System.Boolean ExitGames.Client.Photon.Protocol18::WriteArrayHeader(ExitGames.Client.Photon.StreamBuffer,System.Type)
extern void Protocol18_WriteArrayHeader_mA18AA3DB6ECBF90E008C79466C412F0C7E286990 (void);
// 0x000001C7 System.Void ExitGames.Client.Photon.Protocol18::WriteDictionaryElements(ExitGames.Client.Photon.StreamBuffer,System.Collections.IDictionary,ExitGames.Client.Photon.Protocol18/GpType,ExitGames.Client.Photon.Protocol18/GpType)
extern void Protocol18_WriteDictionaryElements_m0131096FCC844D7CA0DF8A59F3C2EEB6360D5F7C (void);
// 0x000001C8 System.Void ExitGames.Client.Photon.Protocol18::WriteDictionary(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteDictionary_m24BBE4A01999FD64DD9DE73970F748DECEC2096C (void);
// 0x000001C9 System.Void ExitGames.Client.Photon.Protocol18::WriteDictionaryHeader(ExitGames.Client.Photon.StreamBuffer,System.Type,ExitGames.Client.Photon.Protocol18/GpType&,ExitGames.Client.Photon.Protocol18/GpType&)
extern void Protocol18_WriteDictionaryHeader_mC5D03394FFAADBC1E7A96A8A8E8A9261F4C3BCC5 (void);
// 0x000001CA System.Boolean ExitGames.Client.Photon.Protocol18::WriteArrayType(ExitGames.Client.Photon.StreamBuffer,System.Type,ExitGames.Client.Photon.Protocol18/GpType&)
extern void Protocol18_WriteArrayType_mD9BB08A4E357EA7F5DC1A8BA8A2BC31C846EE033 (void);
// 0x000001CB System.Void ExitGames.Client.Photon.Protocol18::WriteHashtableArray(ExitGames.Client.Photon.StreamBuffer,System.Object,System.Boolean)
extern void Protocol18_WriteHashtableArray_m63E4F8C2AF7AD56E9460A2CFB510716003CB248D (void);
// 0x000001CC System.Void ExitGames.Client.Photon.Protocol18::WriteDictionaryArray(ExitGames.Client.Photon.StreamBuffer,System.Collections.IDictionary[],System.Boolean)
extern void Protocol18_WriteDictionaryArray_mD64C386B4F480340E268C0EBCCF4C556EF96D553 (void);
// 0x000001CD System.Void ExitGames.Client.Photon.Protocol18::WriteIntLength(ExitGames.Client.Photon.StreamBuffer,System.Int32)
extern void Protocol18_WriteIntLength_m200F7A277EF2DB4CE69034009092A06FE8DA7216 (void);
// 0x000001CE System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedInt32(ExitGames.Client.Photon.StreamBuffer,System.Int32,System.Boolean)
extern void Protocol18_WriteCompressedInt32_mE69F42C00D1AFB06E1BF880751A35DEF11B34DB2 (void);
// 0x000001CF System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedInt64(ExitGames.Client.Photon.StreamBuffer,System.Int64,System.Boolean)
extern void Protocol18_WriteCompressedInt64_m09A9B3025D3E0529FA370D121F0328B722488285 (void);
// 0x000001D0 System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedUInt32(ExitGames.Client.Photon.StreamBuffer,System.UInt32)
extern void Protocol18_WriteCompressedUInt32_m452EB51CDF0C5AE9D3587A68F54F9821471C398B (void);
// 0x000001D1 System.Int32 ExitGames.Client.Photon.Protocol18::WriteCompressedUInt32(System.Byte[],System.UInt32)
extern void Protocol18_WriteCompressedUInt32_m029C8B07A0C9E4A92C31D9CDC53E40DDC9E574C8 (void);
// 0x000001D2 System.Void ExitGames.Client.Photon.Protocol18::WriteCompressedUInt64(ExitGames.Client.Photon.StreamBuffer,System.UInt64)
extern void Protocol18_WriteCompressedUInt64_mA96BAF6BF08CA8469EF7E53F3DD7A7FF0143F171 (void);
// 0x000001D3 System.UInt32 ExitGames.Client.Photon.Protocol18::EncodeZigZag32(System.Int32)
extern void Protocol18_EncodeZigZag32_m5882ED668DA1624F6CBF9800E3161E8B41C1158F (void);
// 0x000001D4 System.UInt64 ExitGames.Client.Photon.Protocol18::EncodeZigZag64(System.Int64)
extern void Protocol18_EncodeZigZag64_mF163F0713937E1E7D76036C65059C897ED5375FE (void);
// 0x000001D5 System.Void ExitGames.Client.Photon.Protocol18::.ctor()
extern void Protocol18__ctor_mC0EC83CCF94784FFFBFC459C091E72C4E2997756 (void);
// 0x000001D6 System.Void ExitGames.Client.Photon.Protocol18::.cctor()
extern void Protocol18__cctor_mA9DE54AABD414B8CA2F2D3DBE9911C9B9E14ADB6 (void);
// 0x000001D7 System.Void ExitGames.Client.Photon.SendOptions::set_Reliability(System.Boolean)
extern void SendOptions_set_Reliability_m2DE41348D40DD9703AB284E030692368894EA747 (void);
// 0x000001D8 System.Void ExitGames.Client.Photon.SendOptions::.cctor()
extern void SendOptions__cctor_m3D388D99A3C33DC3A0CDCC5A47A7E2F61D75651E (void);
// 0x000001D9 System.Void ExitGames.Client.Photon.SocketNative::egdisconnect(System.IntPtr)
extern void SocketNative_egdisconnect_mF8FEEBA7D2BB208415152157F2D9EE879FA421EA (void);
// 0x000001DA System.Boolean ExitGames.Client.Photon.SocketNative::egsend(System.IntPtr,System.Byte[],System.UInt32)
extern void SocketNative_egsend_mF5D62FEB7DB3E53445DBFA87BBC84D047B7A8C35 (void);
// 0x000001DB System.Boolean ExitGames.Client.Photon.SocketNative::Disconnect()
extern void SocketNative_Disconnect_m13FA3F0CDEECD70A07E9D48069DB802E08A0202E (void);
// 0x000001DC ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketNative::Send(System.Byte[],System.Int32)
extern void SocketNative_Send_mEAC3196AF2D87F3A900B36FA3A54CF9128CF9DBC (void);
// 0x000001DD System.Void ExitGames.Client.Photon.SocketNative::.cctor()
extern void SocketNative__cctor_mC32B324EDE80A2C6FA672BF8A482D60E13C6096B (void);
// 0x000001DE System.Void ExitGames.Client.Photon.SocketTcp::.ctor(ExitGames.Client.Photon.PeerBase)
extern void SocketTcp__ctor_mBCD572AED3E64F2539349DF04C1E8DC198910AA9 (void);
// 0x000001DF System.Void ExitGames.Client.Photon.SocketTcp::Finalize()
extern void SocketTcp_Finalize_mED838AC8605C7C6EAC8FDDAC548CC64F29A55EA3 (void);
// 0x000001E0 System.Void ExitGames.Client.Photon.SocketTcp::Dispose()
extern void SocketTcp_Dispose_mBE978CB6C782FD183B316C14029E4083C3F69361 (void);
// 0x000001E1 System.Boolean ExitGames.Client.Photon.SocketTcp::Connect()
extern void SocketTcp_Connect_m7A81C2857B486510B476429F73C1DC481BC5A959 (void);
// 0x000001E2 System.Boolean ExitGames.Client.Photon.SocketTcp::Disconnect()
extern void SocketTcp_Disconnect_mCA255FC8E164A1B3E1F6AF7AA697C6E640FF9125 (void);
// 0x000001E3 ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketTcp::Send(System.Byte[],System.Int32)
extern void SocketTcp_Send_m2E483FE295B814FC49AD4C63918FB652D8399997 (void);
// 0x000001E4 System.Void ExitGames.Client.Photon.SocketTcp::DnsAndConnect()
extern void SocketTcp_DnsAndConnect_m974933A0A896914C9713848480385E7AF17CD326 (void);
// 0x000001E5 System.Void ExitGames.Client.Photon.SocketTcp::ReceiveLoop()
extern void SocketTcp_ReceiveLoop_m9DCD031CA6418C88D08F5A611FDBAA43C15D45E5 (void);
// 0x000001E6 System.Void ExitGames.Client.Photon.SocketUdp::.ctor(ExitGames.Client.Photon.PeerBase)
extern void SocketUdp__ctor_m1F48A1DA974EF490D2A7F6AEFD3D09BCEB713F3E (void);
// 0x000001E7 System.Void ExitGames.Client.Photon.SocketUdp::Finalize()
extern void SocketUdp_Finalize_mD81C63AD9AC5B94592EA8F49A7FBDA54F19430CA (void);
// 0x000001E8 System.Void ExitGames.Client.Photon.SocketUdp::Dispose()
extern void SocketUdp_Dispose_m354C5CF4E098CDBAE4BF11608B1531974D7995DE (void);
// 0x000001E9 System.Boolean ExitGames.Client.Photon.SocketUdp::Connect()
extern void SocketUdp_Connect_mD1040468677B2F090C5CECE155A492423E40CFDD (void);
// 0x000001EA System.Boolean ExitGames.Client.Photon.SocketUdp::Disconnect()
extern void SocketUdp_Disconnect_m7ED7B0E26DE3DB8E312561880FF452C723C00A45 (void);
// 0x000001EB ExitGames.Client.Photon.PhotonSocketError ExitGames.Client.Photon.SocketUdp::Send(System.Byte[],System.Int32)
extern void SocketUdp_Send_m9E56B1DFE659E3095B2DEB1ED405EF825EDBBFD9 (void);
// 0x000001EC System.Void ExitGames.Client.Photon.SocketUdp::DnsAndConnect()
extern void SocketUdp_DnsAndConnect_m0F3D36439299F3FC649B9BEEB7DF7046581C587E (void);
// 0x000001ED System.Void ExitGames.Client.Photon.SocketUdp::ReceiveLoop()
extern void SocketUdp_ReceiveLoop_m4C7CE7205AE7DFEBEA5F403DB6862745280274EC (void);
// 0x000001EE System.Void ExitGames.Client.Photon.StreamBuffer::.ctor(System.Int32)
extern void StreamBuffer__ctor_m6AA501ACB9EC321AF30614A0450D647F4B2E6F22 (void);
// 0x000001EF System.Void ExitGames.Client.Photon.StreamBuffer::.ctor(System.Byte[])
extern void StreamBuffer__ctor_m5E90BF2ED8958947442D9288EFF60CA18C26F8B2 (void);
// 0x000001F0 System.Byte[] ExitGames.Client.Photon.StreamBuffer::ToArray()
extern void StreamBuffer_ToArray_m7BA05D71D11901351ECEEBF746DCCCD0C74BEEFB (void);
// 0x000001F1 System.Byte[] ExitGames.Client.Photon.StreamBuffer::ToArrayFromPos()
extern void StreamBuffer_ToArrayFromPos_mDF0C5E2AE61A557B0396B30DA1A6954A55D02C35 (void);
// 0x000001F2 System.Void ExitGames.Client.Photon.StreamBuffer::Compact()
extern void StreamBuffer_Compact_m34257EC4826AEF6E458507FDBDEECEDE468933EB (void);
// 0x000001F3 System.Byte[] ExitGames.Client.Photon.StreamBuffer::GetBuffer()
extern void StreamBuffer_GetBuffer_mAF3A17FE29BCDF100CED9DABA67F7312F99731C8 (void);
// 0x000001F4 System.Byte[] ExitGames.Client.Photon.StreamBuffer::GetBufferAndAdvance(System.Int32,System.Int32&)
extern void StreamBuffer_GetBufferAndAdvance_m751933D7166DEFDE378203D55DBCA4F5C820181F (void);
// 0x000001F5 System.Int32 ExitGames.Client.Photon.StreamBuffer::get_Length()
extern void StreamBuffer_get_Length_m0BC8EBC3532BCBD9C23DD9A2F825A9134AF9AC1A (void);
// 0x000001F6 System.Int32 ExitGames.Client.Photon.StreamBuffer::get_Position()
extern void StreamBuffer_get_Position_m5F2E9D48BFFEFE1204AA7BDCE1141CA4D1AEAB16 (void);
// 0x000001F7 System.Void ExitGames.Client.Photon.StreamBuffer::set_Position(System.Int32)
extern void StreamBuffer_set_Position_m988A295E5925654EA9ABB5AAB3B9EA36D3CAC434 (void);
// 0x000001F8 System.Int64 ExitGames.Client.Photon.StreamBuffer::Seek(System.Int64,System.IO.SeekOrigin)
extern void StreamBuffer_Seek_m56B8CF2C36D879B6BDCB0AD2D761FAB04330BBF2 (void);
// 0x000001F9 System.Void ExitGames.Client.Photon.StreamBuffer::SetLength(System.Int64)
extern void StreamBuffer_SetLength_m965133EECBBC5EF6BE2AF192D6ADFE4D02583E8E (void);
// 0x000001FA System.Void ExitGames.Client.Photon.StreamBuffer::SetCapacityMinimum(System.Int32)
extern void StreamBuffer_SetCapacityMinimum_m06E4962AB2092B6EB88FF1EC8A78C94A37E5E863 (void);
// 0x000001FB System.Int32 ExitGames.Client.Photon.StreamBuffer::Read(System.Byte[],System.Int32,System.Int32)
extern void StreamBuffer_Read_mF72ACB683E59D6431A4736B0075579A1CF68E5E8 (void);
// 0x000001FC System.Void ExitGames.Client.Photon.StreamBuffer::Write(System.Byte[],System.Int32,System.Int32)
extern void StreamBuffer_Write_mE4E73C10800C8571AA75F280C7D8CA039D242238 (void);
// 0x000001FD System.Byte ExitGames.Client.Photon.StreamBuffer::ReadByte()
extern void StreamBuffer_ReadByte_mC0A59C08E5076B896A2450A754209AC0B386879F (void);
// 0x000001FE System.Void ExitGames.Client.Photon.StreamBuffer::WriteByte(System.Byte)
extern void StreamBuffer_WriteByte_m76C6B7F811675D1C52816B075BF88F54A12D6DD3 (void);
// 0x000001FF System.Void ExitGames.Client.Photon.StreamBuffer::WriteBytes(System.Byte,System.Byte)
extern void StreamBuffer_WriteBytes_m954D5825882D68BB8969C55AA84454A6C77F128F (void);
// 0x00000200 System.Boolean ExitGames.Client.Photon.StreamBuffer::CheckSize(System.Int32)
extern void StreamBuffer_CheckSize_m1D18E972883CC055E67D5AC803262C6D1A8AD2A0 (void);
// 0x00000201 System.Collections.Generic.List`1<System.Reflection.MethodInfo> ExitGames.Client.Photon.SupportClass::GetMethods(System.Type,System.Type)
extern void SupportClass_GetMethods_mF25119B2B22C85FBB6700C4B75126828740C488B (void);
// 0x00000202 System.Int32 ExitGames.Client.Photon.SupportClass::GetTickCount()
extern void SupportClass_GetTickCount_m86D7A82D67971EB3F53A3A1A0D9EAE0445A7B428 (void);
// 0x00000203 System.Byte ExitGames.Client.Photon.SupportClass::StartBackgroundCalls(System.Func`1<System.Boolean>,System.Int32,System.String)
extern void SupportClass_StartBackgroundCalls_m067C1439458F31743309A83C4D2EB02CA1703D7F (void);
// 0x00000204 System.Boolean ExitGames.Client.Photon.SupportClass::StopBackgroundCalls(System.Byte)
extern void SupportClass_StopBackgroundCalls_m85FD0FB179C2E08B33657530EF374DE83A9A5101 (void);
// 0x00000205 System.Boolean ExitGames.Client.Photon.SupportClass::StopAllBackgroundCalls()
extern void SupportClass_StopAllBackgroundCalls_m03C22CB34DB3152AD0CC56CB39AF7B75A63A69ED (void);
// 0x00000206 System.Void ExitGames.Client.Photon.SupportClass::WriteStackTrace(System.Exception,System.IO.TextWriter)
extern void SupportClass_WriteStackTrace_mC705997C05A4C509352711045B40A7CE19A1D027 (void);
// 0x00000207 System.Void ExitGames.Client.Photon.SupportClass::WriteStackTrace(System.Exception)
extern void SupportClass_WriteStackTrace_m9407D20BA90833A249FDE0770A6842D4FEB949A6 (void);
// 0x00000208 System.String ExitGames.Client.Photon.SupportClass::DictionaryToString(System.Collections.IDictionary)
extern void SupportClass_DictionaryToString_m659349B6F6C0C9D1D98FD1A48057A38437BEBFB2 (void);
// 0x00000209 System.String ExitGames.Client.Photon.SupportClass::DictionaryToString(System.Collections.IDictionary,System.Boolean)
extern void SupportClass_DictionaryToString_mDD00BDC89B8ECFC3941BDDCAD207372C2DBBD991 (void);
// 0x0000020A System.String ExitGames.Client.Photon.SupportClass::ByteArrayToString(System.Byte[])
extern void SupportClass_ByteArrayToString_m6B0EA9DC5E151D7B6E58C5DCEC0F1851CC55FC39 (void);
// 0x0000020B System.UInt32[] ExitGames.Client.Photon.SupportClass::InitializeTable(System.UInt32)
extern void SupportClass_InitializeTable_m208B588E73228DF399A708221E985C28FBE3A945 (void);
// 0x0000020C System.UInt32 ExitGames.Client.Photon.SupportClass::CalculateCrc(System.Byte[],System.Int32)
extern void SupportClass_CalculateCrc_m2639AFA32CFDCCF5D7458BC8A369403D72FDE564 (void);
// 0x0000020D System.Void ExitGames.Client.Photon.SupportClass::.cctor()
extern void SupportClass__cctor_m201AB2836D6D3BEABD0352D2B3C37B641CAD41FF (void);
// 0x0000020E System.Void ExitGames.Client.Photon.SupportClass/IntegerMillisecondsDelegate::.ctor(System.Object,System.IntPtr)
extern void IntegerMillisecondsDelegate__ctor_m383E646BE0C901C440DAA32FC8AF2C3BC1FA8751 (void);
// 0x0000020F System.Int32 ExitGames.Client.Photon.SupportClass/IntegerMillisecondsDelegate::Invoke()
extern void IntegerMillisecondsDelegate_Invoke_mB055A8D85231662C6618AF843DED426EC7DC7F25 (void);
// 0x00000210 System.IAsyncResult ExitGames.Client.Photon.SupportClass/IntegerMillisecondsDelegate::BeginInvoke(System.AsyncCallback,System.Object)
extern void IntegerMillisecondsDelegate_BeginInvoke_m477222D6E9AE6DBDEDEF73F65CCE7C4E74421396 (void);
// 0x00000211 System.Int32 ExitGames.Client.Photon.SupportClass/IntegerMillisecondsDelegate::EndInvoke(System.IAsyncResult)
extern void IntegerMillisecondsDelegate_EndInvoke_mAEA8D7EAAB128EB34BB3041CB7AD91096AC2DD8D (void);
// 0x00000212 System.Int32 ExitGames.Client.Photon.SupportClass/ThreadSafeRandom::Next()
extern void ThreadSafeRandom_Next_m7F4CDD86DF12176086FE5CE3C29E3DD16A82D040 (void);
// 0x00000213 System.Void ExitGames.Client.Photon.SupportClass/ThreadSafeRandom::.cctor()
extern void ThreadSafeRandom__cctor_m9779C2E1B647793177D1EF9F4D58EBD1C78E0844 (void);
// 0x00000214 System.Void ExitGames.Client.Photon.SupportClass/<>c__DisplayClass6_0::.ctor()
extern void U3CU3Ec__DisplayClass6_0__ctor_m907991E8495D59111972A70E2BE33F5E2D8C64CF (void);
// 0x00000215 System.Void ExitGames.Client.Photon.SupportClass/<>c__DisplayClass6_0::<StartBackgroundCalls>b__0()
extern void U3CU3Ec__DisplayClass6_0_U3CStartBackgroundCallsU3Eb__0_mE492D622F246ED034B6591BAC529E76EE0010CC4 (void);
// 0x00000216 System.Void ExitGames.Client.Photon.SupportClass/<>c::.cctor()
extern void U3CU3Ec__cctor_m013D76315073D8134274F6E228EF554F4C5A1DA8 (void);
// 0x00000217 System.Void ExitGames.Client.Photon.SupportClass/<>c::.ctor()
extern void U3CU3Ec__ctor_m92F34BD7E75F8A18C24C007DBFA7A4AE88A84E47 (void);
// 0x00000218 System.Int32 ExitGames.Client.Photon.SupportClass/<>c::<.cctor>b__20_0()
extern void U3CU3Ec_U3C_cctorU3Eb__20_0_m36C734F49528AA1C54C87692334369E74B006886 (void);
// 0x00000219 System.Void ExitGames.Client.Photon.Pool`1::.ctor(System.Func`1<T>,System.Action`1<T>,System.Int32)
// 0x0000021A System.Void ExitGames.Client.Photon.Pool`1::CreatePoolItems(System.Int32)
// 0x0000021B System.Void ExitGames.Client.Photon.Pool`1::Push(T)
// 0x0000021C T ExitGames.Client.Photon.Pool`1::Pop()
// 0x0000021D System.Void ExitGames.Client.Photon.TPeer::.ctor()
extern void TPeer__ctor_mC7FDA4D069FCBE872BC849C1B0AA3067E7FD6A8D (void);
// 0x0000021E System.Void ExitGames.Client.Photon.TPeer::InitPeerBase()
extern void TPeer_InitPeerBase_m7AD79682FB333F996C618B830B820676A7BABBCB (void);
// 0x0000021F System.Boolean ExitGames.Client.Photon.TPeer::Connect(System.String,System.String,System.String,System.Object)
extern void TPeer_Connect_m186FA91BD2FFFB557F608E8E601217B62DBA0775 (void);
// 0x00000220 System.Void ExitGames.Client.Photon.TPeer::OnConnect()
extern void TPeer_OnConnect_m2F089B5AC61FF8DFDB1E055D7CEB59F9838E2D36 (void);
// 0x00000221 System.Void ExitGames.Client.Photon.TPeer::Disconnect()
extern void TPeer_Disconnect_mA6B288FCED18FA6A7ED8442B4BEDB82E9D38E5CA (void);
// 0x00000222 System.Void ExitGames.Client.Photon.TPeer::StopConnection()
extern void TPeer_StopConnection_mB35A9D83E5B4EA2B4FAECE6FDD980EDA535B4FC8 (void);
// 0x00000223 System.Void ExitGames.Client.Photon.TPeer::FetchServerTimestamp()
extern void TPeer_FetchServerTimestamp_m899CF2CC6C321F5E0C62B1B0D4C6D9C74BC145C8 (void);
// 0x00000224 System.Void ExitGames.Client.Photon.TPeer::EnqueueInit(System.Byte[])
extern void TPeer_EnqueueInit_m349A1CB758AD8351C943D40A4D06150FF6118073 (void);
// 0x00000225 System.Boolean ExitGames.Client.Photon.TPeer::DispatchIncomingCommands()
extern void TPeer_DispatchIncomingCommands_m2AEB28DE2FB5804A8FEC7E688920E68A329A40DA (void);
// 0x00000226 System.Boolean ExitGames.Client.Photon.TPeer::SendOutgoingCommands()
extern void TPeer_SendOutgoingCommands_mEB08DEB0702123BE966B96BC361A69FDEE768BAB (void);
// 0x00000227 System.Boolean ExitGames.Client.Photon.TPeer::SendAcksOnly()
extern void TPeer_SendAcksOnly_m0F4412F76E22B55EF83BE77C465BC5367D551138 (void);
// 0x00000228 System.Boolean ExitGames.Client.Photon.TPeer::EnqueueOperation(System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,System.Byte,ExitGames.Client.Photon.SendOptions,ExitGames.Client.Photon.EgMessageType)
extern void TPeer_EnqueueOperation_mF431B13FC3F13B1E999CA50474DE21D90CD63F88 (void);
// 0x00000229 ExitGames.Client.Photon.StreamBuffer ExitGames.Client.Photon.TPeer::SerializeOperationToMessage(System.Byte,System.Collections.Generic.Dictionary`2<System.Byte,System.Object>,ExitGames.Client.Photon.EgMessageType,System.Boolean)
extern void TPeer_SerializeOperationToMessage_m114605630FA8B39C8A0D8FD20DEF9CB218C509B1 (void);
// 0x0000022A System.Boolean ExitGames.Client.Photon.TPeer::EnqueueMessageAsPayload(ExitGames.Client.Photon.DeliveryMode,ExitGames.Client.Photon.StreamBuffer,System.Byte)
extern void TPeer_EnqueueMessageAsPayload_mAC9E94FC531A7E31D8EA84A80354B45F13F674B8 (void);
// 0x0000022B System.Void ExitGames.Client.Photon.TPeer::SendPing()
extern void TPeer_SendPing_mC61A197F0A033314C94453F25A36F3B8093B015C (void);
// 0x0000022C System.Void ExitGames.Client.Photon.TPeer::SendData(System.Byte[],System.Int32)
extern void TPeer_SendData_m8EEFAFB4AC331A2BCCC7C687D2B7030D9A0895E8 (void);
// 0x0000022D System.Void ExitGames.Client.Photon.TPeer::ReceiveIncomingCommands(System.Byte[],System.Int32)
extern void TPeer_ReceiveIncomingCommands_mF79D64514D0668899EE843C8EF0979AC1B363473 (void);
// 0x0000022E System.Void ExitGames.Client.Photon.TPeer::ReadPingResult(System.Byte[])
extern void TPeer_ReadPingResult_mE9525CE5BE58EFD447D6DB9283149C19219FB310 (void);
// 0x0000022F System.Void ExitGames.Client.Photon.TPeer::ReadPingResult(ExitGames.Client.Photon.OperationResponse)
extern void TPeer_ReadPingResult_m04CF51006F7CF5FB8C2250076A8F0CF2556BEA9A (void);
// 0x00000230 System.Void ExitGames.Client.Photon.TPeer::.cctor()
extern void TPeer__cctor_m92F74E3D4C80554EBC8402A21C0F4A301AFFE6D5 (void);
// 0x00000231 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_OperationByteCount()
extern void TrafficStatsGameLevel_get_OperationByteCount_mD36F0967AB9FA289B8730A47DBC04509C400AF38 (void);
// 0x00000232 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_OperationByteCount(System.Int32)
extern void TrafficStatsGameLevel_set_OperationByteCount_mEB8BBC06F6B1C30BEE31F8C6C05AEE5634EC50DE (void);
// 0x00000233 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_OperationCount()
extern void TrafficStatsGameLevel_get_OperationCount_m9D287EEB14A67CC31A7844C7CA95B5F9903DEA25 (void);
// 0x00000234 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_OperationCount(System.Int32)
extern void TrafficStatsGameLevel_set_OperationCount_m822E26E11DF41BD4E83678BF823424E89C96CA38 (void);
// 0x00000235 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_ResultByteCount()
extern void TrafficStatsGameLevel_get_ResultByteCount_mCB181D9216DCA659768EB2DAD3587FCC82F77163 (void);
// 0x00000236 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_ResultByteCount(System.Int32)
extern void TrafficStatsGameLevel_set_ResultByteCount_mF14E3379356786E8027BAD5967F9748F2AB151E3 (void);
// 0x00000237 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_ResultCount()
extern void TrafficStatsGameLevel_get_ResultCount_m39471FBF961775F46B951507B40293224A364768 (void);
// 0x00000238 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_ResultCount(System.Int32)
extern void TrafficStatsGameLevel_set_ResultCount_mEF1CC47A9F417228B1C18ECA7F87ED8F3508540C (void);
// 0x00000239 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_EventByteCount()
extern void TrafficStatsGameLevel_get_EventByteCount_m9216D9D3BBCF1D800FB408567D13BF1491A0992F (void);
// 0x0000023A System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_EventByteCount(System.Int32)
extern void TrafficStatsGameLevel_set_EventByteCount_m2A4542252EFDA0C465DAC8EC9E1FFB3B1DBDCFFC (void);
// 0x0000023B System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_EventCount()
extern void TrafficStatsGameLevel_get_EventCount_m02982105191217B759C33E55FEC15DDF46DF2168 (void);
// 0x0000023C System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_EventCount(System.Int32)
extern void TrafficStatsGameLevel_set_EventCount_mDBDF4A95C1691D5DF8020FB1D21C5ED818EF842A (void);
// 0x0000023D System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestOpResponseCallback()
extern void TrafficStatsGameLevel_get_LongestOpResponseCallback_m5A86D417C4EA4BEE4E828A5196F9D14E03354A38 (void);
// 0x0000023E System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestOpResponseCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestOpResponseCallback_mEA1FEA3030C42B728A9405FFB55DD72E3CBADEA8 (void);
// 0x0000023F System.Byte ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestOpResponseCallbackOpCode()
extern void TrafficStatsGameLevel_get_LongestOpResponseCallbackOpCode_m19BDC5C9C71BBFECED33F5D6505801548D076C8B (void);
// 0x00000240 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestOpResponseCallbackOpCode(System.Byte)
extern void TrafficStatsGameLevel_set_LongestOpResponseCallbackOpCode_m5A14A23C68D5E350648085779C0EAC33188154F1 (void);
// 0x00000241 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestEventCallback()
extern void TrafficStatsGameLevel_get_LongestEventCallback_m25B1F55FE6859D98CDB537907A6C8577DA404C3D (void);
// 0x00000242 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestEventCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestEventCallback_m7E287D0BBFF3C1B505C5C578E97143AE1391B6D8 (void);
// 0x00000243 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestMessageCallback()
extern void TrafficStatsGameLevel_get_LongestMessageCallback_m7EA3E82B832183127637A35219417B3668DBDB77 (void);
// 0x00000244 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestMessageCallback_mBEC606A400B07A1600A3D85EEE9216082513B106 (void);
// 0x00000245 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestRawMessageCallback()
extern void TrafficStatsGameLevel_get_LongestRawMessageCallback_m25DFE44EDA3F081544419C7958CE0263C68A623F (void);
// 0x00000246 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestRawMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_set_LongestRawMessageCallback_m4395A72951E86C0FC82DF924EFBE281F15AFF39D (void);
// 0x00000247 System.Byte ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestEventCallbackCode()
extern void TrafficStatsGameLevel_get_LongestEventCallbackCode_m827959DEF3BC0FDD7028DBAEC5243D96006690EF (void);
// 0x00000248 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestEventCallbackCode(System.Byte)
extern void TrafficStatsGameLevel_set_LongestEventCallbackCode_m7A57BAF532587C77701EC0F8F702A93C7D759564 (void);
// 0x00000249 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestDeltaBetweenDispatching()
extern void TrafficStatsGameLevel_get_LongestDeltaBetweenDispatching_m294DC62F603164580F1F59609F8440CB5B1C763C (void);
// 0x0000024A System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestDeltaBetweenDispatching(System.Int32)
extern void TrafficStatsGameLevel_set_LongestDeltaBetweenDispatching_mDEFE0A4E1B04B23544A86A08C1E2EB61F402ED58 (void);
// 0x0000024B System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_LongestDeltaBetweenSending()
extern void TrafficStatsGameLevel_get_LongestDeltaBetweenSending_m675DEF48EE25023050368C69C6B747694CBE1963 (void);
// 0x0000024C System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_LongestDeltaBetweenSending(System.Int32)
extern void TrafficStatsGameLevel_set_LongestDeltaBetweenSending_mA60D3535A64B0791325E9D05F1D90F8D41BAF17D (void);
// 0x0000024D System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_DispatchIncomingCommandsCalls()
extern void TrafficStatsGameLevel_get_DispatchIncomingCommandsCalls_mF3176605CDE3F9C704F0B8235F11E12E6F501103 (void);
// 0x0000024E System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_DispatchIncomingCommandsCalls(System.Int32)
extern void TrafficStatsGameLevel_set_DispatchIncomingCommandsCalls_m30C11455B9A50569D45D662FF82574F7FEB05B1E (void);
// 0x0000024F System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_SendOutgoingCommandsCalls()
extern void TrafficStatsGameLevel_get_SendOutgoingCommandsCalls_m3D54DA247DE03932774A6BD4CC1A823B19E422D7 (void);
// 0x00000250 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::set_SendOutgoingCommandsCalls(System.Int32)
extern void TrafficStatsGameLevel_set_SendOutgoingCommandsCalls_mEEAED432152F6D5F3F2D873F112EF922853D242B (void);
// 0x00000251 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalMessageCount()
extern void TrafficStatsGameLevel_get_TotalMessageCount_m1B0CE91DBC922F45227B40DCC437A84A6FC68C65 (void);
// 0x00000252 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalIncomingMessageCount()
extern void TrafficStatsGameLevel_get_TotalIncomingMessageCount_m3D08A03FA1A826688AB384164166EA725617D3AC (void);
// 0x00000253 System.Int32 ExitGames.Client.Photon.TrafficStatsGameLevel::get_TotalOutgoingMessageCount()
extern void TrafficStatsGameLevel_get_TotalOutgoingMessageCount_m92AD09E734F469B48A1A348CC660472DABEEA9B3 (void);
// 0x00000254 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::CountOperation(System.Int32)
extern void TrafficStatsGameLevel_CountOperation_m1978498FE0AC17C2551B7431AA6639E0BB86BA39 (void);
// 0x00000255 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::CountResult(System.Int32)
extern void TrafficStatsGameLevel_CountResult_m6C3347973810BDC6281AACF12D258865A2ACCD39 (void);
// 0x00000256 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::CountEvent(System.Int32)
extern void TrafficStatsGameLevel_CountEvent_mE1C1B1971133466558A658426F1FED0DFECCC374 (void);
// 0x00000257 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForResponseCallback(System.Byte,System.Int32)
extern void TrafficStatsGameLevel_TimeForResponseCallback_m34F52354671761AA9B1A344C2F7C0392756E0FE2 (void);
// 0x00000258 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForEventCallback(System.Byte,System.Int32)
extern void TrafficStatsGameLevel_TimeForEventCallback_mD4AC8FB89EC142A210DD2625E6F75EA945FE8E93 (void);
// 0x00000259 System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_TimeForMessageCallback_m82800528AF5EEBC3A53DCD30B98A99932F32D0EA (void);
// 0x0000025A System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::TimeForRawMessageCallback(System.Int32)
extern void TrafficStatsGameLevel_TimeForRawMessageCallback_m7FE042DB346346E72A9C648B923B4C79899BA04B (void);
// 0x0000025B System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::DispatchIncomingCommandsCalled()
extern void TrafficStatsGameLevel_DispatchIncomingCommandsCalled_m7B5BFFF9A9544FB660C59DA55782819075417704 (void);
// 0x0000025C System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::SendOutgoingCommandsCalled()
extern void TrafficStatsGameLevel_SendOutgoingCommandsCalled_m131E7F8B19A1EE0B7F74BDA5E79A4A04AEE7E886 (void);
// 0x0000025D System.String ExitGames.Client.Photon.TrafficStatsGameLevel::ToString()
extern void TrafficStatsGameLevel_ToString_m4F4264BCC76A5505EE914975C9BECB2EFBD19BA6 (void);
// 0x0000025E System.String ExitGames.Client.Photon.TrafficStatsGameLevel::ToStringVitalStats()
extern void TrafficStatsGameLevel_ToStringVitalStats_m033B5DFFBEE36E0538F6476DA877A9DCBA230256 (void);
// 0x0000025F System.Void ExitGames.Client.Photon.TrafficStatsGameLevel::.ctor()
extern void TrafficStatsGameLevel__ctor_mEFF2D95A3BA6A7DC6458CE8CE4B8C41A577CB888 (void);
// 0x00000260 System.Int32 ExitGames.Client.Photon.TrafficStats::get_PackageHeaderSize()
extern void TrafficStats_get_PackageHeaderSize_mC8F43401532DD17DB3B94D9DCB55034E4A175FE6 (void);
// 0x00000261 System.Void ExitGames.Client.Photon.TrafficStats::set_PackageHeaderSize(System.Int32)
extern void TrafficStats_set_PackageHeaderSize_mDD901580B42E887068F44747210B0CBFFF98DAD1 (void);
// 0x00000262 System.Int32 ExitGames.Client.Photon.TrafficStats::get_ReliableCommandCount()
extern void TrafficStats_get_ReliableCommandCount_m82C319A09B69382CAF519AD2BF878A9654689978 (void);
// 0x00000263 System.Void ExitGames.Client.Photon.TrafficStats::set_ReliableCommandCount(System.Int32)
extern void TrafficStats_set_ReliableCommandCount_mF72DA410542927C318DD243780A0E5EA7B30B262 (void);
// 0x00000264 System.Int32 ExitGames.Client.Photon.TrafficStats::get_UnreliableCommandCount()
extern void TrafficStats_get_UnreliableCommandCount_mE175600DD1E94A8F087420FBBE414BCA5ED5BF63 (void);
// 0x00000265 System.Void ExitGames.Client.Photon.TrafficStats::set_UnreliableCommandCount(System.Int32)
extern void TrafficStats_set_UnreliableCommandCount_mCBFE32A119C55D7374595726AC6241C7ED1AADAB (void);
// 0x00000266 System.Int32 ExitGames.Client.Photon.TrafficStats::get_FragmentCommandCount()
extern void TrafficStats_get_FragmentCommandCount_m3DAA945288D68EEB812897CA4537C50EC5A28229 (void);
// 0x00000267 System.Void ExitGames.Client.Photon.TrafficStats::set_FragmentCommandCount(System.Int32)
extern void TrafficStats_set_FragmentCommandCount_mCC0A808614E88CC8FBAB0D35E47D34F98A1C725F (void);
// 0x00000268 System.Int32 ExitGames.Client.Photon.TrafficStats::get_ControlCommandCount()
extern void TrafficStats_get_ControlCommandCount_m26887BA8399B36172047FC1CF4DFFCD938401FA1 (void);
// 0x00000269 System.Void ExitGames.Client.Photon.TrafficStats::set_ControlCommandCount(System.Int32)
extern void TrafficStats_set_ControlCommandCount_m803FA9105EDC4AB9BD69865B633DA2DA1A1C21CD (void);
// 0x0000026A System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalPacketCount()
extern void TrafficStats_get_TotalPacketCount_m2BCB84FB5487EFE19158B0AAF8429EB7418AA47D (void);
// 0x0000026B System.Void ExitGames.Client.Photon.TrafficStats::set_TotalPacketCount(System.Int32)
extern void TrafficStats_set_TotalPacketCount_m1A589CF125AC455EB7DE5DBBEC89CE71F55C25CB (void);
// 0x0000026C System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalCommandsInPackets()
extern void TrafficStats_get_TotalCommandsInPackets_mE06A09EDC23CD462AB1AD43DBF471993F4CBEAE0 (void);
// 0x0000026D System.Void ExitGames.Client.Photon.TrafficStats::set_TotalCommandsInPackets(System.Int32)
extern void TrafficStats_set_TotalCommandsInPackets_m37C6A81C9AFF05F43261F9B373DEC9C7C5C563F2 (void);
// 0x0000026E System.Int32 ExitGames.Client.Photon.TrafficStats::get_ReliableCommandBytes()
extern void TrafficStats_get_ReliableCommandBytes_m95A2737B1B3652097B3A41D57B45548A35AFC637 (void);
// 0x0000026F System.Void ExitGames.Client.Photon.TrafficStats::set_ReliableCommandBytes(System.Int32)
extern void TrafficStats_set_ReliableCommandBytes_m3CA101326578FDD1F77833CF46DD4A5FFC758471 (void);
// 0x00000270 System.Int32 ExitGames.Client.Photon.TrafficStats::get_UnreliableCommandBytes()
extern void TrafficStats_get_UnreliableCommandBytes_m24D44D1617EF516F8C8ADD6FFC471825E5D4F26D (void);
// 0x00000271 System.Void ExitGames.Client.Photon.TrafficStats::set_UnreliableCommandBytes(System.Int32)
extern void TrafficStats_set_UnreliableCommandBytes_mA3BFEE6AA9A33093BEEC90E2B9D9EEB1370F6CE0 (void);
// 0x00000272 System.Int32 ExitGames.Client.Photon.TrafficStats::get_FragmentCommandBytes()
extern void TrafficStats_get_FragmentCommandBytes_mE7EF443243CEA2E028E6897FA4D677FE2D198B02 (void);
// 0x00000273 System.Void ExitGames.Client.Photon.TrafficStats::set_FragmentCommandBytes(System.Int32)
extern void TrafficStats_set_FragmentCommandBytes_mD2875A679AC0F101EFED31347E01C99F7E225ED9 (void);
// 0x00000274 System.Int32 ExitGames.Client.Photon.TrafficStats::get_ControlCommandBytes()
extern void TrafficStats_get_ControlCommandBytes_m2C84CFED50C85EB307085C855CD35C47EEFC158D (void);
// 0x00000275 System.Void ExitGames.Client.Photon.TrafficStats::set_ControlCommandBytes(System.Int32)
extern void TrafficStats_set_ControlCommandBytes_m859E1B417FF9CB13F5220E45E129B1A6C58263A5 (void);
// 0x00000276 System.Void ExitGames.Client.Photon.TrafficStats::.ctor(System.Int32)
extern void TrafficStats__ctor_m74760CBC6FC879433FFEECDEC58DA40DD22B7138 (void);
// 0x00000277 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalCommandBytes()
extern void TrafficStats_get_TotalCommandBytes_m05D589E8CA9DEE28D8CEF8F80D3EEEF47FCB10E8 (void);
// 0x00000278 System.Int32 ExitGames.Client.Photon.TrafficStats::get_TotalPacketBytes()
extern void TrafficStats_get_TotalPacketBytes_m515A4E07ABAEADA280BF5914673338B3CFC2382D (void);
// 0x00000279 System.Void ExitGames.Client.Photon.TrafficStats::set_TimestampOfLastAck(System.Int32)
extern void TrafficStats_set_TimestampOfLastAck_mFDF32B290DAAC187CF695CEC0105F76B7916A046 (void);
// 0x0000027A System.Void ExitGames.Client.Photon.TrafficStats::set_TimestampOfLastReliableCommand(System.Int32)
extern void TrafficStats_set_TimestampOfLastReliableCommand_m8C8435D5A9784C958A958EF338635344A6D2B603 (void);
// 0x0000027B System.Void ExitGames.Client.Photon.TrafficStats::CountControlCommand(System.Int32)
extern void TrafficStats_CountControlCommand_m8598F324FC4A122FE4068CC81FB9F5249F08E26F (void);
// 0x0000027C System.Void ExitGames.Client.Photon.TrafficStats::CountReliableOpCommand(System.Int32)
extern void TrafficStats_CountReliableOpCommand_mC8B66F09A1AF75ED670754C9122F5103D1A06E76 (void);
// 0x0000027D System.Void ExitGames.Client.Photon.TrafficStats::CountUnreliableOpCommand(System.Int32)
extern void TrafficStats_CountUnreliableOpCommand_m01CC1FC4FF861C4681913C06AB154E8636478E22 (void);
// 0x0000027E System.Void ExitGames.Client.Photon.TrafficStats::CountFragmentOpCommand(System.Int32)
extern void TrafficStats_CountFragmentOpCommand_mFE125B1013CE19873AF8B72C9A26C2062541230B (void);
// 0x0000027F System.String ExitGames.Client.Photon.TrafficStats::ToString()
extern void TrafficStats_ToString_mC13AD2F6906193D18E66215DED412C4220AC03FB (void);
// 0x00000280 System.Void ExitGames.Client.Photon.Version::.cctor()
extern void Version__cctor_mEAD3A016931403E5309479529B0B0CA687E92734 (void);
// 0x00000281 System.Void ExitGames.Client.Photon.Encryption.IPhotonEncryptor::Init(System.Byte[],System.Byte[],System.Byte[],System.Boolean)
// 0x00000282 System.Void ExitGames.Client.Photon.Encryption.IPhotonEncryptor::Encrypt(System.Byte[],System.Int32,System.Byte[],System.Int32&,System.Boolean)
// 0x00000283 System.Byte[] ExitGames.Client.Photon.Encryption.IPhotonEncryptor::Decrypt(System.Byte[],System.Int32,System.Int32,System.Int32&,System.Boolean)
// 0x00000284 System.Byte[] ExitGames.Client.Photon.Encryption.IPhotonEncryptor::CreateHMAC(System.Byte[],System.Int32,System.Int32)
// 0x00000285 System.Boolean ExitGames.Client.Photon.Encryption.IPhotonEncryptor::CheckHMAC(System.Byte[],System.Int32)
// 0x00000286 System.Void ExitGames.Client.Photon.Encryption.EncryptorNet::Init(System.Byte[],System.Byte[],System.Byte[],System.Boolean)
extern void EncryptorNet_Init_m5F6CFA6B08FCCB4021149F12116314D2200921BD (void);
// 0x00000287 System.Void ExitGames.Client.Photon.Encryption.EncryptorNet::Encrypt(System.Byte[],System.Int32,System.Byte[],System.Int32&,System.Boolean)
extern void EncryptorNet_Encrypt_mC0DB8C4AAABE824AFB3A1913CE44A36EC652252A (void);
// 0x00000288 System.Byte[] ExitGames.Client.Photon.Encryption.EncryptorNet::Decrypt(System.Byte[],System.Int32,System.Int32,System.Int32&,System.Boolean)
extern void EncryptorNet_Decrypt_m9588E87A5E2E9062268574904B0349FDF7879122 (void);
// 0x00000289 System.Byte[] ExitGames.Client.Photon.Encryption.EncryptorNet::CreateHMAC(System.Byte[],System.Int32,System.Int32)
extern void EncryptorNet_CreateHMAC_mB0A07BFCD9D4913BC080A528D5F79E8FF886FC65 (void);
// 0x0000028A System.Boolean ExitGames.Client.Photon.Encryption.EncryptorNet::CheckHMAC(System.Byte[],System.Int32)
extern void EncryptorNet_CheckHMAC_m35DFAD06493B31110F40928961B6BB5F7D104BE9 (void);
// 0x0000028B System.Void ExitGames.Client.Photon.Encryption.EncryptorNet::.ctor()
extern void EncryptorNet__ctor_m8A505ABEBAF2EB1C4C8AA81F9494F98742A88339 (void);
// 0x0000028C System.IntPtr ExitGames.Client.Photon.Encryption.EncryptorNative::egconstructEncryptor(System.Byte[],System.Byte[])
extern void EncryptorNative_egconstructEncryptor_m611BE74A9EF4812922E1D3D29E56079ADB5C0207 (void);
// 0x0000028D System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egdestructEncryptor(System.IntPtr)
extern void EncryptorNative_egdestructEncryptor_m631AF7F1E250383CD75D23B55D1D6D2879AD64F8 (void);
// 0x0000028E System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egencrypt(System.IntPtr,System.Byte[],System.Int32,System.Byte[],System.Int32&,System.Int32&)
extern void EncryptorNative_egencrypt_m9DE6712C092984D351F26BBDC99EA181D76F4C1E (void);
// 0x0000028F System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egdecrypt(System.IntPtr,System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32&)
extern void EncryptorNative_egdecrypt_mF6ACAF97927ACC2D9B4A09391599CC77C6877372 (void);
// 0x00000290 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egHMAC(System.IntPtr,System.Byte[],System.Int32,System.Int32,System.Byte[],System.Int32&)
extern void EncryptorNative_egHMAC_m094A98369F250ED14616883D9699F7E0A386C4C9 (void);
// 0x00000291 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::egsetEncryptorLoggingCallback(System.IntPtr,ExitGames.Client.Photon.Encryption.EncryptorNative/LogCallbackDelegate)
extern void EncryptorNative_egsetEncryptorLoggingCallback_mB04851719F9B0ADCF75E94DB159B22E451FA34F1 (void);
// 0x00000292 System.Boolean ExitGames.Client.Photon.Encryption.EncryptorNative::egsetEncryptorLoggingLevel(System.Int32)
extern void EncryptorNative_egsetEncryptorLoggingLevel_m59647D34F104EB3A3C11AFE3B651E6CF3524A4E6 (void);
// 0x00000293 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Finalize()
extern void EncryptorNative_Finalize_m3DF1A9A04A1DB0573CC782F4A44344E30C7C861C (void);
// 0x00000294 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::OnNativeLog(System.IntPtr,System.Int32,System.String)
extern void EncryptorNative_OnNativeLog_m07553F096F482149F7B3DCEED091CD30B3245822 (void);
// 0x00000295 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Init(System.Byte[],System.Byte[],System.Byte[],System.Boolean)
extern void EncryptorNative_Init_m1C06D6143758FDF555D48EA92CBF5B843C9B17D4 (void);
// 0x00000296 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Dispose(System.Boolean)
extern void EncryptorNative_Dispose_m286A4F3419BED882BB8EFFF18B272A3A563D968B (void);
// 0x00000297 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::Encrypt(System.Byte[],System.Int32,System.Byte[],System.Int32&,System.Boolean)
extern void EncryptorNative_Encrypt_m968D613F2B33F7693BA1926FC17163B52D84ED8A (void);
// 0x00000298 System.Byte[] ExitGames.Client.Photon.Encryption.EncryptorNative::CreateHMAC(System.Byte[],System.Int32,System.Int32)
extern void EncryptorNative_CreateHMAC_mF757CF57FEE0D7F3A5DEEFCA3211EAA59CF59F18 (void);
// 0x00000299 System.Byte[] ExitGames.Client.Photon.Encryption.EncryptorNative::Decrypt(System.Byte[],System.Int32,System.Int32,System.Int32&,System.Boolean)
extern void EncryptorNative_Decrypt_m6199FACE445D4F7AA43A6A966AAC97AA0ECA3F6D (void);
// 0x0000029A System.Boolean ExitGames.Client.Photon.Encryption.EncryptorNative::CheckHMAC(System.Byte[],System.Int32)
extern void EncryptorNative_CheckHMAC_mCD1C1F1FB85F703C594C6565EA2CD73B9700F931 (void);
// 0x0000029B System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::.ctor()
extern void EncryptorNative__ctor_m99922896136A49F96E0607B285567C36CFF93428 (void);
// 0x0000029C System.Void ExitGames.Client.Photon.Encryption.EncryptorNative::.cctor()
extern void EncryptorNative__cctor_m314CC518177DDE2D06B9D9F14FA4B7C35C61340B (void);
// 0x0000029D System.Void ExitGames.Client.Photon.Encryption.EncryptorNative/LogCallbackDelegate::.ctor(System.Object,System.IntPtr)
extern void LogCallbackDelegate__ctor_m405DE18391497B7414002B125D005A397B0BA606 (void);
// 0x0000029E System.Void ExitGames.Client.Photon.Encryption.EncryptorNative/LogCallbackDelegate::Invoke(System.IntPtr,System.Int32,System.String)
extern void LogCallbackDelegate_Invoke_mE3BAF225183593AD68E35F2F3FA8ACB5D8B153B2 (void);
// 0x0000029F System.IAsyncResult ExitGames.Client.Photon.Encryption.EncryptorNative/LogCallbackDelegate::BeginInvoke(System.IntPtr,System.Int32,System.String,System.AsyncCallback,System.Object)
extern void LogCallbackDelegate_BeginInvoke_mDEF9BFF610C8E789516C6DAF436888D708511F24 (void);
// 0x000002A0 System.Void ExitGames.Client.Photon.Encryption.EncryptorNative/LogCallbackDelegate::EndInvoke(System.IAsyncResult)
extern void LogCallbackDelegate_EndInvoke_mFB75C206528C735ADA4D88BF62050A5E1B068C92 (void);
// 0x000002A1 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::.ctor()
extern void DiffieHellmanCryptoProvider__ctor_m6CF48A427A6A4C1C73A275AE4601B5FC832B0D90 (void);
// 0x000002A2 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::.ctor(System.Byte[])
extern void DiffieHellmanCryptoProvider__ctor_mC63A4FAC78CF54D921BD95CCB506185D0F5F5B30 (void);
// 0x000002A3 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::get_PublicKey()
extern void DiffieHellmanCryptoProvider_get_PublicKey_m7889CCF54E358285333FAAB35D841CC55389951A (void);
// 0x000002A4 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::DeriveSharedKey(System.Byte[])
extern void DiffieHellmanCryptoProvider_DeriveSharedKey_mFAB2F5C83C17484F076254DC1F1478A118E47B05 (void);
// 0x000002A5 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Encrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProvider_Encrypt_mC0DCCDD9900D600B8D3D75C3F2ED86EF5F4FAA7F (void);
// 0x000002A6 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Decrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProvider_Decrypt_m0302814E0FC8562866A4B1B604D046C9710BF44C (void);
// 0x000002A7 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Dispose()
extern void DiffieHellmanCryptoProvider_Dispose_mBD5F473D0A0BE5F36552E9683348212978378446 (void);
// 0x000002A8 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::Dispose(System.Boolean)
extern void DiffieHellmanCryptoProvider_Dispose_m5D41514ED2BE6D46D5C206965983C1DF659E1937 (void);
// 0x000002A9 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Security.DiffieHellmanCryptoProvider::CalculatePublicKey()
extern void DiffieHellmanCryptoProvider_CalculatePublicKey_m2AFCFD031702DCC95554E7D279D4CF60F06BE20A (void);
// 0x000002AA Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Security.DiffieHellmanCryptoProvider::CalculateSharedKey(Photon.SocketServer.Numeric.BigInteger)
extern void DiffieHellmanCryptoProvider_CalculateSharedKey_mCE56E80F87EFD02B6BAF0B94EA62448989418093 (void);
// 0x000002AB Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Security.DiffieHellmanCryptoProvider::GenerateRandomSecret(System.Int32)
extern void DiffieHellmanCryptoProvider_GenerateRandomSecret_m2B772416A7C2B6E69BA50C8751A2462D001303BD (void);
// 0x000002AC System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProvider::.cctor()
extern void DiffieHellmanCryptoProvider__cctor_m1BEDC648C12C1BF9C0E689CB141E8FF2D5F462FA (void);
// 0x000002AD System.IntPtr Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorCreate()
extern void DiffieHellmanCryptoProviderNative_egCryptorCreate_m9D70E98A5086A1AE6478CBED61F5465BF41AC272 (void);
// 0x000002AE System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorPublicKey(System.IntPtr,System.IntPtr&,System.Int32&)
extern void DiffieHellmanCryptoProviderNative_egCryptorPublicKey_m3112F58DD0528D891EFF3A1636206EABAED864D9 (void);
// 0x000002AF System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorDeriveSharedKey(System.IntPtr,System.Byte[],System.Int32)
extern void DiffieHellmanCryptoProviderNative_egCryptorDeriveSharedKey_mAB7ABC8930144442D374A9EB2E87695E8760944F (void);
// 0x000002B0 System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorEncrypt(System.IntPtr,System.Byte[],System.Int32,System.Int32,System.Byte[],System.IntPtr&,System.Int32&)
extern void DiffieHellmanCryptoProviderNative_egCryptorEncrypt_mFBA022B3510C210650EA61E121940DB9CA09F71F (void);
// 0x000002B1 System.Int32 Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorDecrypt(System.IntPtr,System.Byte[],System.Int32,System.Int32,System.Byte[],System.IntPtr&,System.Int32&)
extern void DiffieHellmanCryptoProviderNative_egCryptorDecrypt_m0107A08B8F06A60212B08977B2E9E6B5012EE642 (void);
// 0x000002B2 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::egCryptorDispose(System.IntPtr)
extern void DiffieHellmanCryptoProviderNative_egCryptorDispose_m8265B1FB3537F000A5E86D0FA1005349F76A4919 (void);
// 0x000002B3 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::.ctor()
extern void DiffieHellmanCryptoProviderNative__ctor_mAF125EE0ECC98869D2A50EB7C0F62238E6213C13 (void);
// 0x000002B4 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::.ctor(System.Byte[])
extern void DiffieHellmanCryptoProviderNative__ctor_m327AC0160F2C34C338DE706B8A6E633328E8EE1C (void);
// 0x000002B5 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::get_PublicKey()
extern void DiffieHellmanCryptoProviderNative_get_PublicKey_mDDB7904407CED428B620E51274D758587E4C95F0 (void);
// 0x000002B6 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::DeriveSharedKey(System.Byte[])
extern void DiffieHellmanCryptoProviderNative_DeriveSharedKey_m21ED699256730D0B659C5BE2EADDAE0FAA99BFCC (void);
// 0x000002B7 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Encrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProviderNative_Encrypt_m70E5AA9BD3D88D518ADEA6FADFBC60326A0168F1 (void);
// 0x000002B8 System.Byte[] Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Decrypt(System.Byte[],System.Int32,System.Int32)
extern void DiffieHellmanCryptoProviderNative_Decrypt_m2A39F81F7396796DAF8BE8C8B8F6CA71608B5F6D (void);
// 0x000002B9 System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Dispose()
extern void DiffieHellmanCryptoProviderNative_Dispose_mD27CBB090AA565A7E884D4DD44211E3C191177FD (void);
// 0x000002BA System.Void Photon.SocketServer.Security.DiffieHellmanCryptoProviderNative::Dispose(System.Boolean)
extern void DiffieHellmanCryptoProviderNative_Dispose_mA690B9A2EB85D0C3B95D1166771AD8A8B77D0612 (void);
// 0x000002BB System.Byte[] Photon.SocketServer.Security.ICryptoProvider::get_PublicKey()
// 0x000002BC System.Void Photon.SocketServer.Security.ICryptoProvider::DeriveSharedKey(System.Byte[])
// 0x000002BD System.Byte[] Photon.SocketServer.Security.ICryptoProvider::Encrypt(System.Byte[],System.Int32,System.Int32)
// 0x000002BE System.Byte[] Photon.SocketServer.Security.ICryptoProvider::Decrypt(System.Byte[],System.Int32,System.Int32)
// 0x000002BF System.Void Photon.SocketServer.Security.OakleyGroups::.cctor()
extern void OakleyGroups__cctor_m8DFF1D2E3A13CBF70F3417B4DB00CFE68BB36DDF (void);
// 0x000002C0 System.Void Photon.SocketServer.Numeric.BigInteger::.ctor()
extern void BigInteger__ctor_m4A81832FF842D3ACA6ABB1C87D5EF115EAC92BE4 (void);
// 0x000002C1 System.Void Photon.SocketServer.Numeric.BigInteger::.ctor(System.Int64)
extern void BigInteger__ctor_m1604AA86CCA9ED9954C0250B09834D5BC01199A6 (void);
// 0x000002C2 System.Void Photon.SocketServer.Numeric.BigInteger::.ctor(Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger__ctor_m3E4E128A4D2CC596D46B9474FE107EC5BC149294 (void);
// 0x000002C3 System.Void Photon.SocketServer.Numeric.BigInteger::.ctor(System.Byte[])
extern void BigInteger__ctor_mAD286D5A8256FB3CC684588654ADD704D43B3D33 (void);
// 0x000002C4 System.Void Photon.SocketServer.Numeric.BigInteger::.ctor(System.UInt32[])
extern void BigInteger__ctor_m0C152120EACBA5C9D6587E199D7195C7E4B21CFF (void);
// 0x000002C5 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_Implicit(System.Int64)
extern void BigInteger_op_Implicit_mDE241FC8616FA43B99B3C3F500C493CC5CB733F0 (void);
// 0x000002C6 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_Implicit(System.Int32)
extern void BigInteger_op_Implicit_m8BD70B68E1CE38BB36014E0DF471832BFD804D83 (void);
// 0x000002C7 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_Addition(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_Addition_m0681302AE8D6287FC6AC7E88BC27A814E5D7AFF5 (void);
// 0x000002C8 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_Subtraction(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_Subtraction_mC059BDDE7ACBB0CA0E43FE01817D84C74F71E95A (void);
// 0x000002C9 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_Multiply(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_Multiply_mCBBDB1F307D18146E21429491217DAFE3B7A9A39 (void);
// 0x000002CA Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_LeftShift(Photon.SocketServer.Numeric.BigInteger,System.Int32)
extern void BigInteger_op_LeftShift_mD2E9EDEAD8BFFFE62D99BA9E8EF41F86F02E743F (void);
// 0x000002CB System.Int32 Photon.SocketServer.Numeric.BigInteger::shiftLeft(System.UInt32[],System.Int32)
extern void BigInteger_shiftLeft_m6501D28220631506827B8AB34550C371C28EBA07 (void);
// 0x000002CC System.Int32 Photon.SocketServer.Numeric.BigInteger::shiftRight(System.UInt32[],System.Int32)
extern void BigInteger_shiftRight_mCB5A3430D16B363DA046BF61DCAF44D8F2EB1D3B (void);
// 0x000002CD Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_UnaryNegation(Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_UnaryNegation_m78D54F56AC2443BD97ABCAF386CBC4687AC74CA5 (void);
// 0x000002CE System.Boolean Photon.SocketServer.Numeric.BigInteger::op_Equality(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_Equality_m81339D9D8CFAE84507FF6D65F8013AB65FBFA0B5 (void);
// 0x000002CF System.Boolean Photon.SocketServer.Numeric.BigInteger::Equals(System.Object)
extern void BigInteger_Equals_m9B56D96D055E74B292AFF7B0E8D851725E3086AC (void);
// 0x000002D0 System.Int32 Photon.SocketServer.Numeric.BigInteger::GetHashCode()
extern void BigInteger_GetHashCode_m8CEAD78D9FA3C820184A99C2CE52BB78AB2FD077 (void);
// 0x000002D1 System.Boolean Photon.SocketServer.Numeric.BigInteger::op_GreaterThan(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_GreaterThan_m94E79FD68D5D87BAB3A7BB3A827D1B3B6AD602CE (void);
// 0x000002D2 System.Boolean Photon.SocketServer.Numeric.BigInteger::op_LessThan(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_LessThan_m702AE96EA0FAD8852777B1E07FF74EC81BBCEBEE (void);
// 0x000002D3 System.Boolean Photon.SocketServer.Numeric.BigInteger::op_GreaterThanOrEqual(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_GreaterThanOrEqual_m9D3AE2A70E6D545CE2A7E100209BCA002F57FDE9 (void);
// 0x000002D4 System.Void Photon.SocketServer.Numeric.BigInteger::multiByteDivide(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_multiByteDivide_m26933DCF73440FFF5F9D9F24DA7A3B6BFD1F690E (void);
// 0x000002D5 System.Void Photon.SocketServer.Numeric.BigInteger::singleByteDivide(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_singleByteDivide_mCF244291334D52E9CF40FEC48C8932F3AE7133D6 (void);
// 0x000002D6 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_Division(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_Division_m1329FDD2E3A0EEAEA8699D4EAEE1A8886C241154 (void);
// 0x000002D7 Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::op_Modulus(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_op_Modulus_mC21260AD99EA5397CABEB1CBF6AE79056AE8C4C9 (void);
// 0x000002D8 System.String Photon.SocketServer.Numeric.BigInteger::ToString()
extern void BigInteger_ToString_m8164313123568AA7F354772CC0A2A3712877DD4F (void);
// 0x000002D9 System.String Photon.SocketServer.Numeric.BigInteger::ToString(System.Int32)
extern void BigInteger_ToString_mB463B4064CC8AF3BA028F81BB814DF1A6A581128 (void);
// 0x000002DA Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::ModPow(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_ModPow_m678E3DF24BA08E874EC8B5C46FECB1E41D90F09A (void);
// 0x000002DB Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::BarrettReduction(Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger,Photon.SocketServer.Numeric.BigInteger)
extern void BigInteger_BarrettReduction_m5A72352138BFD6D10096EE775637FA257060022C (void);
// 0x000002DC Photon.SocketServer.Numeric.BigInteger Photon.SocketServer.Numeric.BigInteger::GenerateRandom(System.Int32)
extern void BigInteger_GenerateRandom_m2195DB5797B263923FFAACBF25871E760F30106D (void);
// 0x000002DD System.Void Photon.SocketServer.Numeric.BigInteger::genRandomBits(System.Int32,System.Random)
extern void BigInteger_genRandomBits_m8AF00642701E4F4D91179C496AA7A67FC07E3049 (void);
// 0x000002DE System.Int32 Photon.SocketServer.Numeric.BigInteger::bitCount()
extern void BigInteger_bitCount_m5DF34C9D04CCEE6038817E2A35EB7C1365E20353 (void);
// 0x000002DF System.Byte[] Photon.SocketServer.Numeric.BigInteger::GetBytes()
extern void BigInteger_GetBytes_m963C6A22411F913586528ABB89DA6640DB1B34CC (void);
// 0x000002E0 System.Void Photon.SocketServer.Numeric.BigInteger::.cctor()
extern void BigInteger__cctor_m102646DF3DD11FE6AE6206CFA12BCA43F3491833 (void);
static Il2CppMethodPointer s_methodPointers[736] = 
{
	Hashtable__ctor_mE996A03E5E1B26FE2BBBD341FD9A2136BE9B6CFA,
	Hashtable__ctor_mCB9C9F7759F7E1E5CC8D849BF738138602743386,
	Hashtable_get_Item_mEA0BC15131E914D1F8A751B2F267BB5E7EF53CCB,
	Hashtable_set_Item_m8F5609AF5DD4CF7409FA6D7D5AD2EE5E62175790,
	Hashtable_ToString_m93A67EB6E2A579D0E2A0B96BD536414ED986A501,
	EnetChannel__ctor_mD5AA95DE1F09EE5180201EB7D326B6548E587344,
	EnetChannel_ContainsUnreliableSequenceNumber_mBF6ED1BEDB8495A2B3285347F1815D2596ED9940,
	EnetChannel_ContainsReliableSequenceNumber_m4501E29890B5655E75FE717003FE2D120BAC308D,
	EnetChannel_FetchReliableSequenceNumber_m7A31D3584F4A1669D44AF0F14D59B2581B776D18,
	EnetChannel_TryGetFragment_m95F2CDF2572BBA651A812841FAF0C2BE19FE1B9E,
	EnetChannel_RemoveFragment_m60744DC70D856AF6C654C09970CB7CC85A9B0D3C,
	EnetChannel_clearAll_m8FA93E8874A0672CCF5D29CDFBDE9774E73A773A,
	EnetChannel_QueueIncomingReliableUnsequenced_m3EC60A99FD70DE943971BA33E87EE85113554370,
	EnetPeer__ctor_mCE63D7CB59AEB131437E902E7AAC67BC3BB505CC,
	EnetPeer_InitPeerBase_m85AA8DA6A4FFD733D8F4299D13E6E193F881AE54,
	EnetPeer_ApplyRandomizedSequenceNumbers_m59E5779349F0EFD409FB36B80A3560C51F940DA7,
	EnetPeer_Connect_m38BAE9D792D1C322666E9DABA70962EBC600892E,
	EnetPeer_OnConnect_m25EF6747DF94590FF8DF0D942CC3D682AE97F559,
	EnetPeer_Disconnect_m316F3FD8FE8C3A8F75CDA3FCD56FBD85E0404FCF,
	EnetPeer_StopConnection_m0172B66F705B5B12222C083D09E22E745A29ED85,
	EnetPeer_FetchServerTimestamp_m912C5F1C67AFAD32F1FEDC8FCA7E5FEA3A506F49,
	EnetPeer_DispatchIncomingCommands_m1FA4DE76E9BC048D6DC7FA27226648A743113037,
	EnetPeer_GetFragmentLength_mBC348352267884C3B3283B69AB80A42EA591073F,
	EnetPeer_CalculateBufferLen_m7A060E811EFD72438DC0F286A9EDEB7D8B9A4732,
	EnetPeer_CalculateInitialOffset_m7A30AF7A5034D7F4A2160CD7399722D50BFC504D,
	EnetPeer_SendAcksOnly_m1623304367333BE3803F2E25E0858A043BE66F4B,
	EnetPeer_SendOutgoingCommands_mF3F86D00646EC75199BA15C482ADE4820191496D,
	EnetPeer_AreReliableCommandsInTransit_mC3BC52833C11BBE15655E4D0B63473C63D820E17,
	EnetPeer_EnqueueOperation_mE7FE6B857DD15D5D9EB73A60657E9CD5A906B7B6,
	EnetPeer_GetChannel_m82A687D7F53D89ED9EDB9160B5FFB2E81EE9F1BD,
	EnetPeer_CreateAndEnqueueCommand_m44445FE28F0BC9EC382F60685CC09BD3C4D7629F,
	EnetPeer_SerializeOperationToMessage_m8EFF9E19D2CF89BED7E0C759B1BB4F0DE49AF3A5,
	EnetPeer_SerializeAckToBuffer_m8A3A046FFED87990F9C4DE1F7C4FC3D7290132F9,
	EnetPeer_SerializeToBuffer_mEBA817BB85D0F6DD134BE5FF5CF32BF3B0C45D49,
	EnetPeer_SendData_mA5006A34962108D600817991CD75170503CEE17A,
	EnetPeer_SendToSocket_m821575DAE15FC8F916B850C47B6E8F4FB168DAC6,
	EnetPeer_SendDataEncrypted_mD99B483D427FEE4E4CFA60DF95B571AA4A64D983,
	EnetPeer_QueueSentCommand_m664D85D8193D1AFE6A0302F289F492D17F6E1B97,
	EnetPeer_QueueOutgoingReliableCommand_m98D7F09F9B884D9D037FA2E5E61BE807390B6166,
	EnetPeer_QueueOutgoingUnreliableCommand_m5CF1EF701DEB2B71285DACA057AC5C5DB87C237E,
	EnetPeer_QueueOutgoingAcknowledgement_mDDD093B4F54337D1A2D6CE6403DB009E779C2348,
	EnetPeer_ReceiveIncomingCommands_m5BF5FB27E5C214C92ACCB7ED89B60126F3FA66B7,
	EnetPeer_ExecuteCommand_m92DB23388C5C65057DC4B4D27544C06C9BB84A05,
	EnetPeer_QueueIncomingCommand_mB28BDEBFC64477E00B2CE4F8EECA237894F6C616,
	EnetPeer_RemoveSentReliableCommand_mBCE5ACB35DC4D1F4FE7D9F45E2C9E3515864A9E0,
	EnetPeer__cctor_mA3A9B9F56C2296527DCABCA215C25C2955F78CC5,
	EnetPeer_U3CExecuteCommandU3Eb__72_0_m1A94B84A917D13000370466AA81DAF46AABCDAE5,
	NULL,
	NULL,
	NULL,
	NULL,
	IPhotonSocket_get_Listener_m42B3B576D85944C0D6EC569FDACF2FD2604017DF,
	IPhotonSocket_get_MTU_mA8D3FA4922F611A8C54E85007CCDF656EC10E56D,
	IPhotonSocket_get_State_m7C108A9426B1A81D9946D6EE1F376C2F006CD785,
	IPhotonSocket_set_State_mF63814C2EBE87B57C3DC2E514F1CB8A43AF7FEF4,
	IPhotonSocket_get_Connected_mECF6D474468E6B2BE842BBA125FB8F27E8277651,
	IPhotonSocket_get_ServerAddress_mFB4E6BE4A79451E9407B42EB0DC3CE0A1E4326FA,
	IPhotonSocket_set_ServerAddress_mA3D1A26F820B0775BC5FBFF598D633E730E396F4,
	IPhotonSocket_get_ServerIpAddress_m4B9AC8676D7C400D533D086D1C2880639B9D1DC3,
	IPhotonSocket_set_ServerIpAddress_mB5195CBE6E1C5DFA4D40B7E2FA51B3A0EF47E3A5,
	IPhotonSocket_get_ServerPort_mD39890926FFB3F6E0E0F71CFF2377D65B2C4FAAF,
	IPhotonSocket_set_ServerPort_m2509605DE841239A20AA9666AF23D95A9014C7E3,
	IPhotonSocket_get_AddressResolvedAsIpv6_m4C993135DF9E667DFFE644628D5FF29CA3D22CD7,
	IPhotonSocket_set_AddressResolvedAsIpv6_m885AE7F2D7FE54C0D48E0442A8D7F21C98B7EFEE,
	IPhotonSocket_set_UrlProtocol_mAAAD44B5C7D42AA907B9A7488615613682889122,
	IPhotonSocket_set_UrlPath_mE8654D2807954FF2F6D25A843E29C6DD161108F5,
	IPhotonSocket__ctor_mBE9765771BEEBAAE76EE017AA030185C18FECA02,
	IPhotonSocket_Connect_m5B79987D3BB75DDCDFE52583DDB72F87524F1023,
	NULL,
	NULL,
	IPhotonSocket_HandleReceivedDatagram_m1F3614CC07BB483DACCEF4043587A8F5BC0058BA,
	IPhotonSocket_ReportDebugOfLevel_mF56809B21066361C527C94E529A4B91D1720A51D,
	IPhotonSocket_EnqueueDebugReturn_m119928C26BAEA000979E9C2EE58A885C255FE439,
	IPhotonSocket_HandleException_m75AA4120B6C98820119D858576E2C34686BD7A20,
	IPhotonSocket_TryParseAddress_mA2CA500D39BD7BB97054547629DAD611A19E79A3,
	IPhotonSocket_GetIpAddresses_m5895ED8BB9047D28A723298C54E71A6B7E6F82B8,
	IPhotonSocket_AddressSortComparer_m6710F2ECEA18A4EBFA0F2A9B31DEF036FB41E9C6,
	IPhotonSocket_U3CHandleExceptionU3Eb__53_0_m666844A68BB1EA44524E991216C64C6F910E4B84,
	U3CU3Ec__cctor_m6F2C5F7846EBC1241902A246937BACD023D842E4,
	U3CU3Ec__ctor_m5A72A7C8355FC7164FE9806B865F77AEEF50AE88,
	U3CU3Ec_U3CGetIpAddressesU3Eb__56_0_m25F77E111DE5514D204D5EE1D022EC164EE21AA4,
	SerializationProtocolFactory_Create_m9E5DE950F95A8DECD7106887DA1790FB25E21083,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	IProtocol_Serialize_mC977A6746116FE416BB9F048172624B9F56F8F39,
	IProtocol_DeserializeMessage_m13E9C362585D067DAE26E734A61F081B2FFADE30,
	IProtocol__ctor_m9D9A2EE05167D6292F77844D52995C1434CDE48D,
	NCommand_get_SizeOfPayload_m0FD3319AC6CAEDCE05F213904543A2AE2F20C4B3,
	NCommand_get_IsFlaggedUnsequenced_mF1332E8836A22D0F9352C4C09E52E4AF0DFBF573,
	NCommand_get_IsFlaggedReliable_m227B4D4EB21524B5E54EBE4485A27CAFA01D4D1D,
	NCommand__ctor_mEE92BFA5F4278B1E592CAFFCBE83F2ACD04A19FB,
	NCommand_CreateAck_mBD6D99BFE232A6005E235725FCD0F30693C9624D,
	NCommand__ctor_m0E88EA02D5DD11F9B617C0FC5963DE9D05DD1C73,
	NCommand_SerializeHeader_m56AC0DC2386330E02974B00A27DFF4EDCA8F9DA1,
	NCommand_Serialize_m280130DDB13815ED1564B79394D34E0C8ECBA449,
	NCommand_FreePayload_mDFA6213C58D735B9D4D294FD0D914B26FA025038,
	NCommand_CompareTo_m3C742BEA3081D254E10ADFA1281B1B85C5D30671,
	NCommand_ToString_mE06145D36BDFABEB191A2B4F35FA9CC91C8A3A64,
	SimulationItem__ctor_mF16E045A79B0C3E232A8846CFD5FE59B11F5FA45,
	SimulationItem_get_Delay_m0E2FC38D9E81BED2A9407CB30645CFC3707C787E,
	SimulationItem_set_Delay_m39FAC59EAB036F41C43FE9B194F1FC85917662D1,
	NetworkSimulationSet_get_IsSimulationEnabled_mCB4BF4ACF44CC41C0F47C6DE208151BD81F562E6,
	NetworkSimulationSet_set_IsSimulationEnabled_mFE15FB897F3CD1AAEF08BDBE63B130C963662B56,
	NetworkSimulationSet_get_OutgoingLag_mCA1AEEAEB69B816D2FB864A765883EBBD944AC6D,
	NetworkSimulationSet_set_OutgoingLag_m09A073E0A2BEFE65952953E7200E744040F3E48F,
	NetworkSimulationSet_get_OutgoingJitter_mDA8191F4B5FCF1CCAEBF48868B6FB8932281BC06,
	NetworkSimulationSet_set_OutgoingJitter_mE095935EFFDF02170CCA916EFD6DE55C15CA9946,
	NetworkSimulationSet_get_OutgoingLossPercentage_m1A1043A839517A7326FB7D9AD7C9DAC1644D2C42,
	NetworkSimulationSet_set_OutgoingLossPercentage_mA06F42FF1E2271BCE03C9829FBC20D50A7DB356B,
	NetworkSimulationSet_get_IncomingLag_mA8B2D8A009AB453F54B1116E71FB8B69B4552779,
	NetworkSimulationSet_set_IncomingLag_m047633C5F701A5673649BAF8B58D0CC3D586D6F9,
	NetworkSimulationSet_get_IncomingJitter_m0FB33F0E94C8361BF6FABA0FE941FB4A57937A26,
	NetworkSimulationSet_set_IncomingJitter_mCC7B8E71388AB95021A6ED88CBE1D71D62A815A7,
	NetworkSimulationSet_get_IncomingLossPercentage_mDE273AC243857A219A0A0549408E755FED2E704B,
	NetworkSimulationSet_set_IncomingLossPercentage_mDB4DC5D690394D381A8FD9083FF2C3C15E130F82,
	NetworkSimulationSet_get_LostPackagesOut_m1A8F0D3C9A902FD15A1F1F6338AEFC3293DF358F,
	NetworkSimulationSet_set_LostPackagesOut_mF38EA104FB9D97E7B07E18E9F184ACC8E19B7AB7,
	NetworkSimulationSet_get_LostPackagesIn_m45D6DFEA7C2CC7D3EC203C5ECB11964074775920,
	NetworkSimulationSet_set_LostPackagesIn_m3F5B6837BEA117DAE4FED4D5733B4575B47E6EEC,
	NetworkSimulationSet_ToString_m536403BE9F8814AB501AA0DF47AB713ECD60A183,
	NetworkSimulationSet__ctor_mE71120E1103214BBAF889A9ED5F68007B4BE0E96,
	PhotonCodes__cctor_mB31F92BB81E94E996A36550AFC40C60ACE0D01A9,
	PeerBase_get_SocketImplementation_m9F3C1F4CA732965FAE27FB983365A8BD1C669ABA,
	PeerBase_get_ServerAddress_m547C81E080C9FF6D567E3F66E723305408D7473F,
	PeerBase_set_ServerAddress_mBD5D8F2743EF4730AD4F13984D5EFB72A942535F,
	PeerBase_set_ProxyServerAddress_m266D46979760AFFDCF9D8B67B169C5F4515DD747,
	PeerBase_get_Listener_m15B7DA6F4AE0A75F6D3133144396A964163DE2F7,
	PeerBase_get_debugOut_m85AA81B1BE53EEC17724817886B3AF998313B1CD,
	PeerBase_get_DisconnectTimeout_m088E0B5FCEDE4039B8229380B0A3E2E287BB2F3F,
	PeerBase_get_timePingInterval_m396C87462BB003CDA00356D16226C027E86DD874,
	PeerBase_get_ChannelCount_mDC5EC382F24DB9B2B45F46378EBC963D2D9F47A8,
	PeerBase_get_PeerID_m497C3DFBC699F00585313439A97758F4E8849382,
	PeerBase_get_timeInt_m30F9D55FD178CD2391A3A6B4C4783010436162F7,
	PeerBase_get_IsSendingOnlyAcks_m22C40193C9B7EA43ACAFC41D519A1D11CB1AECA5,
	PeerBase_get_mtu_m9A35C168D308FF1EE9270C91C093FA5ED37BBD18,
	PeerBase_get_IsIpv6_mB388AFC08E48745F47FF73FCA3715C264C960B2A,
	PeerBase__ctor_mDD91134C7C88054893923483996ECC4CE8C0940F,
	PeerBase_MessageBufferPoolGet_m376289B1E0D6220C57074C24969E9F0A5B121530,
	PeerBase_MessageBufferPoolPut_m3DC3182B7F8F31CB2E48142A8AB69D5D7459EBD9,
	PeerBase_InitPeerBase_m4471E86AB037FB7722190DF8645A033E5DFC54C0,
	NULL,
	PeerBase_GetHttpKeyValueString_m8E17295D2A49FAFEAA604F2ECE7105B3FA22999B,
	PeerBase_PrepareConnectData_mADEDD363795949D3BF00A3FB1374C3255B711739,
	PeerBase_PepareWebSocketUrl_m7B031D20E62843BF0E8021884044F1EBC57BF948,
	NULL,
	PeerBase_InitCallback_mBA8F524B7A19E5B85E99D6447BE1127A04B3CC73,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	PeerBase_SendAcksOnly_m2CA1C6C0E01F97AB7B8B96C9F9597CBDE90BBF67,
	NULL,
	NULL,
	PeerBase_DeserializeMessageAndCallback_mDCF4AD0E0E18347D08373E4076083EC4C628A244,
	PeerBase_UpdateRoundTripTimeAndVariance_mCC9D4AC8FB60CEB13DEB975FD5C387FB224D0988,
	PeerBase_ExchangeKeysForEncryption_m4BC57B47EAAC798B40125E8F54534E38253AA451,
	PeerBase_DeriveSharedKey_mE28F6EA79ADC9EC7A27B83EF2416A2172FBFC6AE,
	PeerBase_InitEncryption_mDDC0BD75FF470934CF68B90B25308C509B43BA88,
	PeerBase_EnqueueActionForDispatch_mD3DFD4B13F0BCDD43A444C3F5AD006177537A5C7,
	PeerBase_EnqueueDebugReturn_m9DA0EAA11DBB1970C201233242AA998DC44B5918,
	PeerBase_EnqueueStatusCallback_m1E30B68E57E2A9F7B548638A099E611FF9403BC7,
	PeerBase_get_NetworkSimulationSettings_mA8D2730E66EA668B75A5A05B2574A319C4EA9E46,
	PeerBase_SendNetworkSimulated_m7DD3FF6CF309207A5FDCE8DD23A3852BB4668868,
	PeerBase_ReceiveNetworkSimulated_m1C15257E16D0782F7E0ACA920EA2A241D3EB21F8,
	PeerBase_NetworkSimRun_mB944274AC2069696E6A3C6926D1C82685EC9952B,
	PeerBase_get_TrafficStatsEnabled_m9ABD7B9A6061867C58FCDCE994B0973BEB473C4E,
	PeerBase_get_TrafficStatsIncoming_mA1F80DA24CB9F1931B431982BC4488D7549E195C,
	PeerBase_get_TrafficStatsOutgoing_mEE011226E87871A511F8A0630B6AC5686979F529,
	PeerBase_get_TrafficStatsGameLevel_m86D11A93B3DFDCAB7922B57F0D65B831658DC5AB,
	PeerBase_get_CommandLogSize_mF2CCBE304C7488BD15445B364AB7699F1A6EB0F6,
	PeerBase_CommandLogResize_m346E3B2DA1A8BD157704FFD924D63C3FC4CC6D86,
	PeerBase_CommandLogInit_mF7639859C4647F1632A963F95AC9D0B3614CB50C,
	PeerBase__cctor_m44BC665131F8496CDF82E4543209AF7C011DB7BD,
	MyAction__ctor_m3B63B36D6AA83D0CCB5CCCC873F54001FE59FC93,
	MyAction_Invoke_mE6FE7CEE6F0B88C67258AA4C7664CA7C3FA8E6DD,
	MyAction_BeginInvoke_m0A36566266D3C5EB748AA90C4A639C8E2B9510B5,
	MyAction_EndInvoke_m64D79A798A43CF4867E9A2C25A705A8F78EC3308,
	U3CU3Ec__DisplayClass108_0__ctor_m09D5D5821D4FB1914CB2DD456671F3246FDBB898,
	U3CU3Ec__DisplayClass108_0_U3CEnqueueDebugReturnU3Eb__0_mADB0EC8A6BC58D1C685B326CFDFEA6310EC019AD,
	U3CU3Ec__DisplayClass109_0__ctor_m9EE64486D6DA63BB2BFD6A4F5DF2FC6002ED8516,
	U3CU3Ec__DisplayClass109_0_U3CEnqueueStatusCallbackU3Eb__0_m0B1C6713321761A24A3E4DCC5FD3C1F4BF397C44,
	CmdLogItem__ctor_mA65C4CC55316E90AC1E5E2D61AACAE54350DAD71,
	CmdLogItem__ctor_mC61DFEDF6C3A5FD00790D54D6BA362EE5DF90C62,
	CmdLogItem_ToString_mBC6DDDF48224B905A195FB9B887CDF6BB145151F,
	CmdLogReceivedReliable__ctor_m9ECDAA2CD8FD8E6930A5E98D5104A70AD4EC8F3D,
	CmdLogReceivedReliable_ToString_m32C689910BB130652566B36C4FA6D892A5447EF8,
	CmdLogReceivedAck__ctor_m6EF325F6B4403CE97F1BCAE4482E75820C8A0D35,
	CmdLogReceivedAck_ToString_m383B7CB1CD007EEB0D949CD7DF5A0F87C44419C8,
	CmdLogSentReliable__ctor_mDB9400C85E4060467E963763294D97125DD27EE4,
	CmdLogSentReliable_ToString_m424424F12945CD24F9A242667F2081DBCCF1CF2B,
	PhotonPeer_get_ClientSdkIdShifted_m5E09AE4034A5F0454E813BD34E1F65C1C8A97A48,
	PhotonPeer_get_ClientVersion_m9585B88FAE81DE7FDF03CD2631F9FF1AA458AD37,
	PhotonPeer_get_NativeSocketLibAvailable_m6ADA8FCE1DB070EEB3A7D0DBCB326C73C5013070,
	PhotonPeer_get_NativePayloadEncryptionLibAvailable_m22F9866A06FA63CBC7C4EC0DBF85531E2C302FD1,
	PhotonPeer_get_NativeDatagramEncryptionLibAvailable_mC368038B4D73DDFF2FF95CC9AE6DF1E42510103C,
	PhotonPeer_CheckNativeLibsAvailability_m63925E53F65B93E61982330DE242DA9CDE7154D4,
	PhotonPeer_get_SerializationProtocolType_m244DBA83394266249CF1AF8331F63CFEE3EA2A44,
	PhotonPeer_set_SerializationProtocolType_m9141765EA0AA102D96F41A345D48111E0B5408B9,
	PhotonPeer_get_SocketImplementation_mDF36FAFEB15F2F490E704EAF7CBDE199BDCAD32A,
	PhotonPeer_set_SocketImplementation_m1B5A0C941576402378C6EE476052164B5D798ED0,
	PhotonPeer_get_Listener_m92E5CDF7E18EA95E6FA89FA130DCE92ADD2413C9,
	PhotonPeer_set_Listener_m6E6CBA1288754723528C3107D0BB546B1EB1FCC9,
	PhotonPeer_get_ReuseEventInstance_m7E7E3745396E3DB82D4D7D970F4135DAE110BF2E,
	PhotonPeer_get_EnableServerTracing_m9ADAD471B11BECBF171E1225B2BE9628935E1B08,
	PhotonPeer_get_QuickResendAttempts_m4754366FAE7A652996F981B047B8F7596CE486B5,
	PhotonPeer_set_QuickResendAttempts_mAFA68057A93CBCA88E4B6C4006EBD29CB61B97E0,
	PhotonPeer_get_PeerState_mAD6503E3F6464FEFD6DDD8736A04B2A7F3B04A82,
	PhotonPeer_get_PeerID_m11C6195468D5AE4C90B1220E1C5AEF3C1A84DB0C,
	PhotonPeer_get_CrcEnabled_m2FAF075107150C695D89498334A40C55943898F7,
	PhotonPeer_set_CrcEnabled_m780993C1E41BAD5F9675B59C3043A627DCA810D3,
	PhotonPeer_get_PacketLossByCrc_m9FFDD111129E2A002F30B3A565975391999FC4F0,
	PhotonPeer_get_ResentReliableCommands_mB65EA7CF4DED0AB3BC91559AD15BB48B941F3C48,
	PhotonPeer_get_ServerTimeInMilliSeconds_m7545C8B086D1D787926F3EE0D911EC5A93580319,
	PhotonPeer_set_LocalMsTimestampDelegate_mEA7C28C9927F3AFD449F721CC227B5D7B5F46A68,
	PhotonPeer_get_ConnectionTime_m02CE9C692F480249E64ECA62525B6BD6522ED78B,
	PhotonPeer_get_LastSendOutgoingTime_mBE2D01726CB005A1BC8B535523EF86E461107925,
	PhotonPeer_get_LongestSentCall_mE4B54B9BE93F6C70DED506D9225CDC6BB04473A4,
	PhotonPeer_get_RoundTripTime_mB2C7F0E48E15FBDE4A35F54727EF780EB66E8537,
	PhotonPeer_get_RoundTripTimeVariance_m717D452F39723AA178E842021E2F05ABC906DCAE,
	PhotonPeer_get_TimestampOfLastSocketReceive_m24EAC4237BEBAEE71EB5C7BE8524FE4A1A359306,
	PhotonPeer_get_ServerAddress_mBB7F348D12881D815323E331CCB89023E6522E01,
	PhotonPeer_get_ServerIpAddress_mFC78501DEA47D127CC7537DE02E33B7FFDA65813,
	PhotonPeer_get_UsedProtocol_mEC9186551B89986D3F4E69B0879D4B438EF939EB,
	PhotonPeer_get_TransportProtocol_m42215E2D4E23E475F9D83429F264AF2D60CE58F5,
	PhotonPeer_set_TransportProtocol_mE069BC52388CE1326BCE1975071CE4448A474B96,
	PhotonPeer_get_IsSimulationEnabled_m064D29504C891742E6E7DA97885D09D82709D7B1,
	PhotonPeer_set_IsSimulationEnabled_mB7346CA2D4877A6C10307C86C2A4C169C27D8FEE,
	PhotonPeer_get_NetworkSimulationSettings_m9D56217E285F8AA05F457944B972933FE130C9B1,
	PhotonPeer_get_MaximumTransferUnit_m56C95F2C407F6651E90649B358EE6BB97CC0F8C8,
	PhotonPeer_get_IsEncryptionAvailable_mAF1CA0B63AC560C23B6DBC28610459493F19E38E,
	PhotonPeer_get_IsSendingOnlyAcks_m75DBEC8A91E747583C831BDBFB53CFBEE7444906,
	PhotonPeer_set_IsSendingOnlyAcks_m4215E2BF08B62B48A56036BA9592FE2270D7D521,
	PhotonPeer_get_TrafficStatsIncoming_mE489191C0F0EE515D543343AFB1322B647E92955,
	PhotonPeer_set_TrafficStatsIncoming_m9A227393E7933D8C5EA409655AEA372F61FE36EE,
	PhotonPeer_get_TrafficStatsOutgoing_mE63D4D8E6AC3AB4AE621843CDDB430EE9FD22868,
	PhotonPeer_set_TrafficStatsOutgoing_m7BA4DEBBF17060079E2378748C78DD4350BCD70B,
	PhotonPeer_get_TrafficStatsGameLevel_m8C48190CE0E673E2324EA8CAFED724A275937D6A,
	PhotonPeer_set_TrafficStatsGameLevel_mBF18554262AC79E6D6E962D2EA396CC7FA4AAC32,
	PhotonPeer_get_TrafficStatsElapsedMs_m1553EE4411AD40BAB0DE48CC1009D3AE4AF313E5,
	PhotonPeer_get_TrafficStatsEnabled_m0BA2DC98AA2C68F52C9D13B048502B2CE6268133,
	PhotonPeer_set_TrafficStatsEnabled_m15BB505352D6C540C9FD08C7666A9924E3EF9E41,
	PhotonPeer_TrafficStatsReset_m426BBDEB554907511A529EBC825C076EF6D2FE60,
	PhotonPeer_InitializeTrafficStats_m14DA45B17837824714ED804DBD622FA21783B2FB,
	PhotonPeer_VitalStatsToString_m9386A123547ED7CE61E5D190BB78BE5089723CE6,
	PhotonPeer_get_EncryptorType_mAB31EA062341BD3B1C7FEA3BBCE02B8E204C7760,
	PhotonPeer__ctor_m92ED9A9BF0751052903EAA9C8493917AECBE08EB,
	PhotonPeer__ctor_mB20C8325EAE88C51D67CA6DA281F2CA4EE14A2D7,
	PhotonPeer_Connect_mCFC5413C2AD95093FC307766120F849DDD3A47E4,
	PhotonPeer_Connect_mBACE18AF206DBE3AD38DE0ECFA93FB5CB2957122,
	PhotonPeer_Connect_m95D317D017B91A95C291811C4D59280067368B05,
	PhotonPeer_CreatePeerBase_m28FEA13E0262F68E8B52EA38B0DF145C61D5C338,
	PhotonPeer_Disconnect_m968012B14C25E1DE812ECD86B446A936C43A9E72,
	PhotonPeer_StopThread_m8C0D35143F5EFD72FA671DB1E36FF0176EB34CC2,
	PhotonPeer_FetchServerTimestamp_m1F2AC9035AF8C12B1AC320C4FF38C749934D3060,
	PhotonPeer_EstablishEncryption_m76CE5CB0A665120AC8843B965C9D505D55444672,
	PhotonPeer_InitDatagramEncryption_m5D49E268B8A4C4170D0905A1C5E824FA024E12E5,
	PhotonPeer_InitPayloadEncryption_m6FE431BFD9197857B69489B455803C10E3F2D27E,
	PhotonPeer_Service_m39B069A605E287E5C36559B21013FECF3073F636,
	PhotonPeer_SendOutgoingCommands_mE0CB9F4E532A641301981AC25B6D83C7E80024E0,
	PhotonPeer_SendAcksOnly_mF501EFC23C320777EB3D278D9CCAFDC4D8EABCBE,
	PhotonPeer_DispatchIncomingCommands_m446C69A18AC54B21DFDA0AD516511E879F4CB396,
	PhotonPeer_SendOperation_mAC1A459B6CD4583322861372B7C118CE4A43EB77,
	PhotonPeer_RegisterType_m8AFB40794A941D8CA85CC32112F13083745B0A39,
	PhotonPeer__cctor_m6456F52D9A9FFA83653E6AA02C68C218E6CC7072,
	PhotonPeer_U3CEstablishEncryptionU3Eb__194_0_m2D8199131F628C75D753BBA44F07FAF52F52BDF3,
	OperationRequest__ctor_m558FD94094B2EC1618E0EA7338D9541B132E9C3E,
	OperationResponse_get_Item_m5DE0E22A3D043CEBB7096DE04D02AD0F263CE469,
	OperationResponse_ToString_m61134CDCA9CA4086787D6CFB33FA44B34B5C0C94,
	OperationResponse_ToStringFull_m16B15A498C495871A46643587A5AB33E261CD2F9,
	OperationResponse__ctor_m9C9E8D6BA280F3D9B3893A9FC6885FDB680F14F9,
	EventData_get_Item_mF48FFDF3F59813E5E59A3A04A795651783D30978,
	EventData_get_Sender_m3A2B20535525F98209A86C8AB91A5DAA605B5BF0,
	EventData_get_CustomData_mFFB6E0B7B69D4213C2D3D778A6BE32E2066219A8,
	EventData_Reset_m5F15AD8005FD6E97859AE2EEA08F9F58E4B655C6,
	EventData_ToString_m7610A07F707964140A5CF67A45942186E5288899,
	EventData__ctor_m0A29174EE1871C0A76457A9EE9986D8DF3F2B6C0,
	SerializeMethod__ctor_m05F829B54880798A4C16F40AF0F2704FBAE0B3E2,
	SerializeMethod_Invoke_m5D82F77EDFED6712B5CCD9B8267D8812A52FA797,
	SerializeMethod_BeginInvoke_m5FB247CA51C894E6BDEDCCE88AD94AE34BA86299,
	SerializeMethod_EndInvoke_m7FBF157D17B5601F57E0A02945C3F8FB2F016C3B,
	SerializeStreamMethod__ctor_m99B0F5D72C1825F034D5D6A1C1E82CFED031023C,
	SerializeStreamMethod_Invoke_m0E0608BA04378C3B1BEBFBE0C6B70C41973BA336,
	SerializeStreamMethod_BeginInvoke_m560932042E32DD6CD2B52C2AF87E29564A805944,
	SerializeStreamMethod_EndInvoke_mD835B1A3D9125ED7B3F003FC41F7791EE0997A14,
	DeserializeMethod__ctor_m1FB0F48921E57D98FBAAAC6511CC61998673A595,
	DeserializeMethod_Invoke_m5F1E915187AE9C7F5B79135241E1A123B503FD0D,
	DeserializeMethod_BeginInvoke_m368779D8F2FAF9A642B6AAE5B7D9F55384B3A0BD,
	DeserializeMethod_EndInvoke_m2F042098630BBBA26FEAA212B5D64E47C13CB59F,
	DeserializeStreamMethod__ctor_m423531504E0910E3A0E9DF05FFA1C62B36C628A0,
	DeserializeStreamMethod_Invoke_m7A4C6C2B6E783981E817171F52E2EF67207432D7,
	DeserializeStreamMethod_BeginInvoke_m8CD2DBE40F0BC0FD7230AC077CAA49B169D14177,
	DeserializeStreamMethod_EndInvoke_mD9EFA76BB7BB3760A9964BC0FDDAEAABBB751470,
	CustomType__ctor_mC977818960FE75497DC34F0F8494BA648D1C9519,
	Protocol_TryRegisterType_m4BD2C2AA7A5DC71A5BFF3D5B9625A0AC5485BA7F,
	Protocol_Serialize_mFF18601715D23ADFADEC816F75BE00A9959D40FD,
	Protocol_Serialize_m6A88DC8FC36B9BFA82F30885428013A3EDD82ECD,
	Protocol_Serialize_m30A6CF08BB9445E47360B6F4C2970575ECAC4924,
	Protocol_Deserialize_m1DCDC0130758DDA4AFA98ABF65A1A1C5898CA2CC,
	Protocol_Deserialize_m0AE978257FD9D79D505C3759E56A6C60C7C10F6C,
	Protocol_Deserialize_mCF061AE34C52C0D1CB1B823AA19AEEAD8B39F759,
	Protocol__cctor_mAE16A8D36C4E4DD0A830D6A7D2427F17B57EC0A2,
	Protocol16_get_ProtocolType_m36A0C545A9FA66EF2C2ECCF3F2F49B0808303728,
	Protocol16_get_VersionBytes_mCF1C6DB63EE0DD617645715C3FEEBC54E02C5CB2,
	Protocol16_SerializeCustom_mD5D82F6DA9C4829EF2267539A5EAF66711C90429,
	Protocol16_DeserializeCustom_m104CD761F2F2A8BC60AAB4512CD978223B9B0C85,
	Protocol16_GetTypeOfCode_m306BC9AD71CD95AEE5D6FF5131616925B89E4835,
	Protocol16_GetCodeOfType_mDF59211C9A1DCADE11300713BD3D3CE0CA9849ED,
	Protocol16_CreateArrayByType_m1FD5DAA212AF1BD1745F7CC514C5B9145D95A56E,
	Protocol16_SerializeOperationRequest_mBFD78D7EC642BF0E33EFD8D9CD3946BA1F5B2991,
	Protocol16_SerializeOperationRequest_m75C3C7E786D6566E207D0719E523343493D1A8FA,
	Protocol16_DeserializeOperationRequest_mD16C7A8E87F57AC15143B15C877FD6F9015C3292,
	Protocol16_SerializeOperationResponse_m357B3EB3BDFA132DBE22273434DA1569275C55E4,
	Protocol16_DeserializeOperationResponse_m59672AEB3CA52EF8C9F65B62F7A1EDA2011E2471,
	Protocol16_SerializeEventData_m02A1F1AAB3FF33B495B2D2A9510E690E8AA3B5A9,
	Protocol16_DeserializeEventData_mF18E6D29E8A24646F4B73A07A144338E7A8B0497,
	Protocol16_SerializeParameterTable_m4EAFAA241D126EB0C0193694BBD39027C2DF9595,
	Protocol16_DeserializeParameterTable_mEF5D0C19D0D936F6D44B937D53619742189C8E19,
	Protocol16_Serialize_mD343ECD18CAA50AB0AE67ADF66AC708BBBA44FCD,
	Protocol16_SerializeByte_m7FDFAFFE9232EE3E6C253FB6784037CD2E6D7FC4,
	Protocol16_SerializeBoolean_m9C81392E4FF706173FB508F6FE1D1727D01C4997,
	Protocol16_SerializeShort_m9079947190930FBB4C3180ED7CA0DA355081F98A,
	Protocol16_SerializeInteger_m8541B6C6737E11D75B70D443DC981C6A64B703FF,
	Protocol16_SerializeLong_m3B9AB9AC5126003C68956512BEE8D2318C064F1A,
	Protocol16_SerializeFloat_m8BA329AFC958B70097CBDDC3168F24FB2193AA25,
	Protocol16_SerializeDouble_m3BFB64989BEAC743A2618B28FA4F679A648B85DB,
	Protocol16_SerializeString_m6F81D2EB51D05DF9E3AA9D11146BE882BDF7ED56,
	Protocol16_SerializeArray_mDBB4A3B2612C0F355A4E41C2F5690CD3317A32A1,
	Protocol16_SerializeByteArray_mB9BDD72F524BC2F8E020108206E36FA2E9569ADC,
	Protocol16_SerializeByteArraySegment_mD96CB6ADF9348C06A717815D6678906AD2D11B41,
	Protocol16_SerializeIntArrayOptimized_m350F2106E4797294E81E45E88F45B9E391B19E59,
	Protocol16_SerializeObjectArray_m34EA9CC7EBEAFEABD511BC1F7221FFEA2E60D524,
	Protocol16_SerializeHashTable_m38BED9BD9C29E36F4C9D49644EB6C893A780DDA1,
	Protocol16_SerializeDictionary_m2B8AE49B2C6F59EA2F69F813B375BD0C68C0CF01,
	Protocol16_SerializeDictionaryHeader_m96B4EED3BB00C7179142F55F5C6DF87E2130734B,
	Protocol16_SerializeDictionaryHeader_m9177457118A5D6BDDA6510329AF346C3697EC1C8,
	Protocol16_SerializeDictionaryElements_m9E6E4602D1CFAA8D0F94750541AC11EEF7F6ECA2,
	Protocol16_Deserialize_mDD04F9283094D2170D9E2213A301E6C6ECBB7EC7,
	Protocol16_DeserializeByte_mA0D0FED288302060E7F3CD2FD242C04AE2EAD36E,
	Protocol16_DeserializeBoolean_mAE87B8CB95931881EB9CC72DE2834E9255FC29D7,
	Protocol16_DeserializeShort_m5A9FB633FF841A4CC1F2282832BF12B7BA1D51FE,
	Protocol16_DeserializeInteger_mAFF4BAC660E688CC207DD74E9AEDA0FEE31C8323,
	Protocol16_DeserializeLong_mCBFA4A8D080BA04E9FFDE7A8211159C3116B08F5,
	Protocol16_DeserializeFloat_m49FEA20CC2B7685998323A89D7FE9EAC5FFBB52E,
	Protocol16_DeserializeDouble_mF5AC7B143DD0E5BA9F2543076BCB84188ADFAA50,
	Protocol16_DeserializeString_m61AE125487A2B41983AF8926EFFEC206916F81F9,
	Protocol16_DeserializeArray_mF123A162CC775F03ADCD776940645CAA7E13D649,
	Protocol16_DeserializeByteArray_m480A75BE3782B83A559C0D04E72BA73F8D7F2936,
	Protocol16_DeserializeIntArray_m12C8A70E4D006E1224DFC029FC4ED737D93A0C56,
	Protocol16_DeserializeStringArray_mFEECC1EB75D43D02739D7D9E81EAC45F852A531A,
	Protocol16_DeserializeObjectArray_mC94160BFD4731A1021184EB055556DC49A968482,
	Protocol16_DeserializeHashTable_m4296E24DE127BCE514E7875FF9CBD169F5CC3B20,
	Protocol16_DeserializeDictionary_mF7FAD9858D41886C3F43C73EA9B3217CDA436D8E,
	Protocol16_DeserializeDictionaryArray_m626F6271DCA7271C9066C5D41E9315BF4D041B8A,
	Protocol16_DeserializeDictionaryType_m49BCA1199412793EC115D08ACFBD30A9E7F44944,
	Protocol16__ctor_m3E2C54818724006FEDA059851DAD57F2FD3AFDD0,
	Protocol16__cctor_mA4572C6B7C60BB32B8AF9F08608B02A380424315,
	InvalidDataException__ctor_m81178A38375C9B75D0A8A02CF67F83C25D054E98,
	Protocol18_get_ProtocolType_mB6CAC8AD444569ADD180CFE33B5A3FE626539891,
	Protocol18_get_VersionBytes_m5AC09738DAA62689D0819433A0C99C5D17781EEF,
	Protocol18_Serialize_m9E06746AB0FEEBF2DFE4AF2F7D7C1413CB426ACC,
	Protocol18_SerializeShort_mE585C7802A260DC15800E4357831793F733E111A,
	Protocol18_SerializeString_mF552363C2AAC83E1196E976F58D52AEB8EF4FB51,
	Protocol18_Deserialize_m51739F38B47938D4275B362341D5FA91467D0D73,
	Protocol18_DeserializeShort_m1A9C543A3D59D608160A661A5666AD30364709ED,
	Protocol18_DeserializeByte_mFF20379D454DEEF8C95ADFF9E21FB1F76DED2AAF,
	Protocol18_GetAllowedDictionaryKeyTypes_mCA648AD6BF893DD43A2C2E8E109DA3C3EE2A6C9D,
	Protocol18_GetClrArrayType_m737EFCD75F6F931CBD2B8291507F55AA70D85CC0,
	Protocol18_GetCodeOfType_m55903BBB57342E20C5FF64A8385CF30E8A2FAE18,
	Protocol18_GetCodeOfTypeCode_m953C03BE673096D699DCDE2F80544E882F2F5213,
	Protocol18_Read_m7059C3280F6F7325827D153FEC6A1FFB54BD9B6B,
	Protocol18_Read_m9A2D18821864CFE9ADD2708FE6F1B33846F254D3,
	Protocol18_ReadBoolean_m1F375812F41A0D259872B4C2B2434D62AA700E2B,
	Protocol18_ReadByte_mB5AD872C97BC94A14E3F81DDDDEEA1A8E9B88A3B,
	Protocol18_ReadInt16_m1E8D82A489148C3DD8B3FE0DEEBB91A84862284D,
	Protocol18_ReadUShort_m231CBC712D3853893ACE5459605FABE8964E2730,
	Protocol18_ReadSingle_m47B24A0185EBF6F35F1A93AEE578971499356B47,
	Protocol18_ReadDouble_mE49110C219C934196256EA1C5E9D40B098D054C4,
	Protocol18_ReadByteArray_m4779CF2B899E7D6FB72E1B9C8344F82ECF631F21,
	Protocol18_ReadCustomType_mC16DF617C8D25B1076B29B5E0A746951DEFF0195,
	Protocol18_DeserializeEventData_mA305928E335EBA6F05B7F7EF7A571011B3842FDA,
	Protocol18_ReadParameterTable_mA9BE287D615BDEB546AC01DBEF2CB8F740572B7B,
	Protocol18_ReadHashtable_m5A48A6A1ED736E05608AED6FAA8294ABCFBE8F41,
	Protocol18_DeserializeOperationRequest_m9EFF7B1A31625B0443CD9DA4A7D1DEAC255DB3DE,
	Protocol18_DeserializeOperationResponse_m19984E8A54B1EBB3790348D32A5F7D3C792B4802,
	Protocol18_ReadString_mD35A027F8B88121F9F97F44734175025593A5871,
	Protocol18_ReadCustomTypeArray_m834C15348EEB3A4CB1F692BC400FF0218D9EBA68,
	Protocol18_ReadDictionaryType_m011E733E05E80A048A2AA61E0CBB5B1D45AFD75D,
	Protocol18_ReadDictionaryType_m4D54B811BCCE0F5C68C5212BE63CFF95C800B71D,
	Protocol18_GetDictArrayType_m6958868B92063D226BA0A2429B2CE43B8956F78A,
	Protocol18_ReadDictionary_m960E700659F0DD54907FDCA24917A7C3D3AA275E,
	Protocol18_ReadDictionaryElements_m91B7CE3DC8A765BF3D536F1CC647A1E186C0D3D4,
	Protocol18_ReadObjectArray_mB1A56EEB51FA30EB5FA3F39F30B770A945AD14CE,
	Protocol18_ReadBooleanArray_mC166C14CFFE8B41FC8414641A1B01FEFD93A367A,
	Protocol18_ReadInt16Array_m3C7388939224BA497C23D1172CB1CB4F948F0F0F,
	Protocol18_ReadSingleArray_m1C65D526E0B5900287C4144BCBEF69F22A9A10D8,
	Protocol18_ReadDoubleArray_mED49F1B57143F1EA7CCD9F0CDB75315F0A9CC3FC,
	Protocol18_ReadStringArray_m13AE31355812823E5A5E25FB8FEA6E4BA90A12F1,
	Protocol18_ReadHashtableArray_mEF8537B34173F93EB3726CB9C773E5C89F74FAAB,
	Protocol18_ReadDictionaryArray_m0168075FB317DFC6B6A1D6FE8FC18E560313EA4D,
	Protocol18_ReadArrayInArray_m76DD6B90669BEA1A02174D0C23D942080A1BCA0C,
	Protocol18_ReadInt1_mFECDC50F317393B38DDAD2F2A2610ABED7495F3C,
	Protocol18_ReadInt2_m7DDF259C50D6B4E8FFECADC8C3117678F0AC9BA4,
	Protocol18_ReadCompressedInt32_m7F1D509C598B6D168FF05BC2B5636F4C41453707,
	Protocol18_ReadCompressedUInt32_mEAC07F2EDEE8B9B596178000BC6BFAE9A76EBE8F,
	Protocol18_ReadCompressedInt64_m28B2B547184EBFB182E05A6610FC6CA8819852B5,
	Protocol18_ReadCompressedUInt64_mD3A47078DB813D95843A7219F7443EE5FFFFB6DA,
	Protocol18_ReadCompressedInt32Array_mBFF9331A05B308E4D8A51F4522E3D773445676F2,
	Protocol18_ReadCompressedInt64Array_mA7D9294953EA992B0DC04729A4313BDC9C413D29,
	Protocol18_DecodeZigZag32_m38102EA03172F0D9767E25D31F576D4B254FFA08,
	Protocol18_DecodeZigZag64_m94B1391D0D006C2CE4A7D5F009E023CC06B8A5BA,
	Protocol18_Write_mA0BC0B4D385A797C5455A742E32975855A54BBCB,
	Protocol18_Write_m918F660E69F3DE4CFE3217CBBC8B42D6634CA996,
	Protocol18_SerializeEventData_mF4ED5EE2023608F158D9A6F267E7A0DD6EB9A9BE,
	Protocol18_WriteParameterTable_mE671B34D9599A37AE95D422C3A5F4FA255795C39,
	Protocol18_SerializeOperationRequest_m3C7F777239F252C8FAA243E64D43EB3A9943516D,
	Protocol18_SerializeOperationRequest_mFB589BEFCA057FBC403AD2B2ADEDDF2BEA24B523,
	Protocol18_SerializeOperationResponse_m6EFB003C0233CEAD72C250E36499302E5F6319DC,
	Protocol18_WriteByte_m00B3AEE4458EAA96D570414817DB389216B9FEAE,
	Protocol18_WriteBoolean_mCF8995E7C4C5E3DD1D9F787A032724E16F3BC6DA,
	Protocol18_WriteUShort_m922ACA38B59B167C850BA0649480B5E38FAD68E1,
	Protocol18_WriteInt16_mCC952A1BC9FF4AC34DE6631746BAA02EEEA7FA71,
	Protocol18_WriteDouble_m253D034B6A1A393A117F4D8710889680915E3176,
	Protocol18_WriteSingle_m07354CFB497134F4161E08F35C8EA5BC8B041B90,
	Protocol18_WriteString_m864B4B009174F93032AB74BA797B2563323F9A5D,
	Protocol18_WriteHashtable_m060F9803CE47495B63211590AAB889945BCEAF4E,
	Protocol18_WriteByteArray_m7CBCF95BA36FED016A644B7C651031B65DF840F7,
	Protocol18_WriteByteArraySegment_m523ED9BCAF0CCE33D6280A55394A92E15AF16AC2,
	Protocol18_WriteInt32ArrayCompressed_mCCA9CB1418677B1DF0C4C6222FEC9AFCBE64B492,
	Protocol18_WriteInt64ArrayCompressed_mABC5495DD97ECE38982E418EE33ECC30C52ED4AE,
	Protocol18_WriteBoolArray_m18CDD32FF33AC035E0A248B5496C642122E1E21E,
	Protocol18_WriteInt16Array_m499087207ADE3DF69A123DF16FE1EF65A403223D,
	Protocol18_WriteSingleArray_mB8675F2CE34122CD11CFF3AC767F9259562353E2,
	Protocol18_WriteDoubleArray_mAB44D72CF286B0DF9789109F5FDEA56F47BC1413,
	Protocol18_WriteStringArray_mC830B96A2690C2DEA137FD89EC873058BC49E384,
	Protocol18_WriteObjectArray_m672D006CBE2568D62984DD06273F545C13452CCD,
	Protocol18_WriteArrayInArray_mFFB12A953BC182649713710598B96635DC003D5C,
	Protocol18_WriteCustomTypeBody_mAA46C38B50DCEFD5B20F93B1310E4F8C1D9A6154,
	Protocol18_WriteCustomType_mA88D115352E548C72560A9F864683318790B710E,
	Protocol18_WriteCustomTypeArray_m8D64614FA25259E37D4DAD30560C76C961011E3C,
	Protocol18_WriteArrayHeader_mA18AA3DB6ECBF90E008C79466C412F0C7E286990,
	Protocol18_WriteDictionaryElements_m0131096FCC844D7CA0DF8A59F3C2EEB6360D5F7C,
	Protocol18_WriteDictionary_m24BBE4A01999FD64DD9DE73970F748DECEC2096C,
	Protocol18_WriteDictionaryHeader_mC5D03394FFAADBC1E7A96A8A8E8A9261F4C3BCC5,
	Protocol18_WriteArrayType_mD9BB08A4E357EA7F5DC1A8BA8A2BC31C846EE033,
	Protocol18_WriteHashtableArray_m63E4F8C2AF7AD56E9460A2CFB510716003CB248D,
	Protocol18_WriteDictionaryArray_mD64C386B4F480340E268C0EBCCF4C556EF96D553,
	Protocol18_WriteIntLength_m200F7A277EF2DB4CE69034009092A06FE8DA7216,
	Protocol18_WriteCompressedInt32_mE69F42C00D1AFB06E1BF880751A35DEF11B34DB2,
	Protocol18_WriteCompressedInt64_m09A9B3025D3E0529FA370D121F0328B722488285,
	Protocol18_WriteCompressedUInt32_m452EB51CDF0C5AE9D3587A68F54F9821471C398B,
	Protocol18_WriteCompressedUInt32_m029C8B07A0C9E4A92C31D9CDC53E40DDC9E574C8,
	Protocol18_WriteCompressedUInt64_mA96BAF6BF08CA8469EF7E53F3DD7A7FF0143F171,
	Protocol18_EncodeZigZag32_m5882ED668DA1624F6CBF9800E3161E8B41C1158F,
	Protocol18_EncodeZigZag64_mF163F0713937E1E7D76036C65059C897ED5375FE,
	Protocol18__ctor_mC0EC83CCF94784FFFBFC459C091E72C4E2997756,
	Protocol18__cctor_mA9DE54AABD414B8CA2F2D3DBE9911C9B9E14ADB6,
	SendOptions_set_Reliability_m2DE41348D40DD9703AB284E030692368894EA747,
	SendOptions__cctor_m3D388D99A3C33DC3A0CDCC5A47A7E2F61D75651E,
	SocketNative_egdisconnect_mF8FEEBA7D2BB208415152157F2D9EE879FA421EA,
	SocketNative_egsend_mF5D62FEB7DB3E53445DBFA87BBC84D047B7A8C35,
	SocketNative_Disconnect_m13FA3F0CDEECD70A07E9D48069DB802E08A0202E,
	SocketNative_Send_mEAC3196AF2D87F3A900B36FA3A54CF9128CF9DBC,
	SocketNative__cctor_mC32B324EDE80A2C6FA672BF8A482D60E13C6096B,
	SocketTcp__ctor_mBCD572AED3E64F2539349DF04C1E8DC198910AA9,
	SocketTcp_Finalize_mED838AC8605C7C6EAC8FDDAC548CC64F29A55EA3,
	SocketTcp_Dispose_mBE978CB6C782FD183B316C14029E4083C3F69361,
	SocketTcp_Connect_m7A81C2857B486510B476429F73C1DC481BC5A959,
	SocketTcp_Disconnect_mCA255FC8E164A1B3E1F6AF7AA697C6E640FF9125,
	SocketTcp_Send_m2E483FE295B814FC49AD4C63918FB652D8399997,
	SocketTcp_DnsAndConnect_m974933A0A896914C9713848480385E7AF17CD326,
	SocketTcp_ReceiveLoop_m9DCD031CA6418C88D08F5A611FDBAA43C15D45E5,
	SocketUdp__ctor_m1F48A1DA974EF490D2A7F6AEFD3D09BCEB713F3E,
	SocketUdp_Finalize_mD81C63AD9AC5B94592EA8F49A7FBDA54F19430CA,
	SocketUdp_Dispose_m354C5CF4E098CDBAE4BF11608B1531974D7995DE,
	SocketUdp_Connect_mD1040468677B2F090C5CECE155A492423E40CFDD,
	SocketUdp_Disconnect_m7ED7B0E26DE3DB8E312561880FF452C723C00A45,
	SocketUdp_Send_m9E56B1DFE659E3095B2DEB1ED405EF825EDBBFD9,
	SocketUdp_DnsAndConnect_m0F3D36439299F3FC649B9BEEB7DF7046581C587E,
	SocketUdp_ReceiveLoop_m4C7CE7205AE7DFEBEA5F403DB6862745280274EC,
	StreamBuffer__ctor_m6AA501ACB9EC321AF30614A0450D647F4B2E6F22,
	StreamBuffer__ctor_m5E90BF2ED8958947442D9288EFF60CA18C26F8B2,
	StreamBuffer_ToArray_m7BA05D71D11901351ECEEBF746DCCCD0C74BEEFB,
	StreamBuffer_ToArrayFromPos_mDF0C5E2AE61A557B0396B30DA1A6954A55D02C35,
	StreamBuffer_Compact_m34257EC4826AEF6E458507FDBDEECEDE468933EB,
	StreamBuffer_GetBuffer_mAF3A17FE29BCDF100CED9DABA67F7312F99731C8,
	StreamBuffer_GetBufferAndAdvance_m751933D7166DEFDE378203D55DBCA4F5C820181F,
	StreamBuffer_get_Length_m0BC8EBC3532BCBD9C23DD9A2F825A9134AF9AC1A,
	StreamBuffer_get_Position_m5F2E9D48BFFEFE1204AA7BDCE1141CA4D1AEAB16,
	StreamBuffer_set_Position_m988A295E5925654EA9ABB5AAB3B9EA36D3CAC434,
	StreamBuffer_Seek_m56B8CF2C36D879B6BDCB0AD2D761FAB04330BBF2,
	StreamBuffer_SetLength_m965133EECBBC5EF6BE2AF192D6ADFE4D02583E8E,
	StreamBuffer_SetCapacityMinimum_m06E4962AB2092B6EB88FF1EC8A78C94A37E5E863,
	StreamBuffer_Read_mF72ACB683E59D6431A4736B0075579A1CF68E5E8,
	StreamBuffer_Write_mE4E73C10800C8571AA75F280C7D8CA039D242238,
	StreamBuffer_ReadByte_mC0A59C08E5076B896A2450A754209AC0B386879F,
	StreamBuffer_WriteByte_m76C6B7F811675D1C52816B075BF88F54A12D6DD3,
	StreamBuffer_WriteBytes_m954D5825882D68BB8969C55AA84454A6C77F128F,
	StreamBuffer_CheckSize_m1D18E972883CC055E67D5AC803262C6D1A8AD2A0,
	SupportClass_GetMethods_mF25119B2B22C85FBB6700C4B75126828740C488B,
	SupportClass_GetTickCount_m86D7A82D67971EB3F53A3A1A0D9EAE0445A7B428,
	SupportClass_StartBackgroundCalls_m067C1439458F31743309A83C4D2EB02CA1703D7F,
	SupportClass_StopBackgroundCalls_m85FD0FB179C2E08B33657530EF374DE83A9A5101,
	SupportClass_StopAllBackgroundCalls_m03C22CB34DB3152AD0CC56CB39AF7B75A63A69ED,
	SupportClass_WriteStackTrace_mC705997C05A4C509352711045B40A7CE19A1D027,
	SupportClass_WriteStackTrace_m9407D20BA90833A249FDE0770A6842D4FEB949A6,
	SupportClass_DictionaryToString_m659349B6F6C0C9D1D98FD1A48057A38437BEBFB2,
	SupportClass_DictionaryToString_mDD00BDC89B8ECFC3941BDDCAD207372C2DBBD991,
	SupportClass_ByteArrayToString_m6B0EA9DC5E151D7B6E58C5DCEC0F1851CC55FC39,
	SupportClass_InitializeTable_m208B588E73228DF399A708221E985C28FBE3A945,
	SupportClass_CalculateCrc_m2639AFA32CFDCCF5D7458BC8A369403D72FDE564,
	SupportClass__cctor_m201AB2836D6D3BEABD0352D2B3C37B641CAD41FF,
	IntegerMillisecondsDelegate__ctor_m383E646BE0C901C440DAA32FC8AF2C3BC1FA8751,
	IntegerMillisecondsDelegate_Invoke_mB055A8D85231662C6618AF843DED426EC7DC7F25,
	IntegerMillisecondsDelegate_BeginInvoke_m477222D6E9AE6DBDEDEF73F65CCE7C4E74421396,
	IntegerMillisecondsDelegate_EndInvoke_mAEA8D7EAAB128EB34BB3041CB7AD91096AC2DD8D,
	ThreadSafeRandom_Next_m7F4CDD86DF12176086FE5CE3C29E3DD16A82D040,
	ThreadSafeRandom__cctor_m9779C2E1B647793177D1EF9F4D58EBD1C78E0844,
	U3CU3Ec__DisplayClass6_0__ctor_m907991E8495D59111972A70E2BE33F5E2D8C64CF,
	U3CU3Ec__DisplayClass6_0_U3CStartBackgroundCallsU3Eb__0_mE492D622F246ED034B6591BAC529E76EE0010CC4,
	U3CU3Ec__cctor_m013D76315073D8134274F6E228EF554F4C5A1DA8,
	U3CU3Ec__ctor_m92F34BD7E75F8A18C24C007DBFA7A4AE88A84E47,
	U3CU3Ec_U3C_cctorU3Eb__20_0_m36C734F49528AA1C54C87692334369E74B006886,
	NULL,
	NULL,
	NULL,
	NULL,
	TPeer__ctor_mC7FDA4D069FCBE872BC849C1B0AA3067E7FD6A8D,
	TPeer_InitPeerBase_m7AD79682FB333F996C618B830B820676A7BABBCB,
	TPeer_Connect_m186FA91BD2FFFB557F608E8E601217B62DBA0775,
	TPeer_OnConnect_m2F089B5AC61FF8DFDB1E055D7CEB59F9838E2D36,
	TPeer_Disconnect_mA6B288FCED18FA6A7ED8442B4BEDB82E9D38E5CA,
	TPeer_StopConnection_mB35A9D83E5B4EA2B4FAECE6FDD980EDA535B4FC8,
	TPeer_FetchServerTimestamp_m899CF2CC6C321F5E0C62B1B0D4C6D9C74BC145C8,
	TPeer_EnqueueInit_m349A1CB758AD8351C943D40A4D06150FF6118073,
	TPeer_DispatchIncomingCommands_m2AEB28DE2FB5804A8FEC7E688920E68A329A40DA,
	TPeer_SendOutgoingCommands_mEB08DEB0702123BE966B96BC361A69FDEE768BAB,
	TPeer_SendAcksOnly_m0F4412F76E22B55EF83BE77C465BC5367D551138,
	TPeer_EnqueueOperation_mF431B13FC3F13B1E999CA50474DE21D90CD63F88,
	TPeer_SerializeOperationToMessage_m114605630FA8B39C8A0D8FD20DEF9CB218C509B1,
	TPeer_EnqueueMessageAsPayload_mAC9E94FC531A7E31D8EA84A80354B45F13F674B8,
	TPeer_SendPing_mC61A197F0A033314C94453F25A36F3B8093B015C,
	TPeer_SendData_m8EEFAFB4AC331A2BCCC7C687D2B7030D9A0895E8,
	TPeer_ReceiveIncomingCommands_mF79D64514D0668899EE843C8EF0979AC1B363473,
	TPeer_ReadPingResult_mE9525CE5BE58EFD447D6DB9283149C19219FB310,
	TPeer_ReadPingResult_m04CF51006F7CF5FB8C2250076A8F0CF2556BEA9A,
	TPeer__cctor_m92F74E3D4C80554EBC8402A21C0F4A301AFFE6D5,
	TrafficStatsGameLevel_get_OperationByteCount_mD36F0967AB9FA289B8730A47DBC04509C400AF38,
	TrafficStatsGameLevel_set_OperationByteCount_mEB8BBC06F6B1C30BEE31F8C6C05AEE5634EC50DE,
	TrafficStatsGameLevel_get_OperationCount_m9D287EEB14A67CC31A7844C7CA95B5F9903DEA25,
	TrafficStatsGameLevel_set_OperationCount_m822E26E11DF41BD4E83678BF823424E89C96CA38,
	TrafficStatsGameLevel_get_ResultByteCount_mCB181D9216DCA659768EB2DAD3587FCC82F77163,
	TrafficStatsGameLevel_set_ResultByteCount_mF14E3379356786E8027BAD5967F9748F2AB151E3,
	TrafficStatsGameLevel_get_ResultCount_m39471FBF961775F46B951507B40293224A364768,
	TrafficStatsGameLevel_set_ResultCount_mEF1CC47A9F417228B1C18ECA7F87ED8F3508540C,
	TrafficStatsGameLevel_get_EventByteCount_m9216D9D3BBCF1D800FB408567D13BF1491A0992F,
	TrafficStatsGameLevel_set_EventByteCount_m2A4542252EFDA0C465DAC8EC9E1FFB3B1DBDCFFC,
	TrafficStatsGameLevel_get_EventCount_m02982105191217B759C33E55FEC15DDF46DF2168,
	TrafficStatsGameLevel_set_EventCount_mDBDF4A95C1691D5DF8020FB1D21C5ED818EF842A,
	TrafficStatsGameLevel_get_LongestOpResponseCallback_m5A86D417C4EA4BEE4E828A5196F9D14E03354A38,
	TrafficStatsGameLevel_set_LongestOpResponseCallback_mEA1FEA3030C42B728A9405FFB55DD72E3CBADEA8,
	TrafficStatsGameLevel_get_LongestOpResponseCallbackOpCode_m19BDC5C9C71BBFECED33F5D6505801548D076C8B,
	TrafficStatsGameLevel_set_LongestOpResponseCallbackOpCode_m5A14A23C68D5E350648085779C0EAC33188154F1,
	TrafficStatsGameLevel_get_LongestEventCallback_m25B1F55FE6859D98CDB537907A6C8577DA404C3D,
	TrafficStatsGameLevel_set_LongestEventCallback_m7E287D0BBFF3C1B505C5C578E97143AE1391B6D8,
	TrafficStatsGameLevel_get_LongestMessageCallback_m7EA3E82B832183127637A35219417B3668DBDB77,
	TrafficStatsGameLevel_set_LongestMessageCallback_mBEC606A400B07A1600A3D85EEE9216082513B106,
	TrafficStatsGameLevel_get_LongestRawMessageCallback_m25DFE44EDA3F081544419C7958CE0263C68A623F,
	TrafficStatsGameLevel_set_LongestRawMessageCallback_m4395A72951E86C0FC82DF924EFBE281F15AFF39D,
	TrafficStatsGameLevel_get_LongestEventCallbackCode_m827959DEF3BC0FDD7028DBAEC5243D96006690EF,
	TrafficStatsGameLevel_set_LongestEventCallbackCode_m7A57BAF532587C77701EC0F8F702A93C7D759564,
	TrafficStatsGameLevel_get_LongestDeltaBetweenDispatching_m294DC62F603164580F1F59609F8440CB5B1C763C,
	TrafficStatsGameLevel_set_LongestDeltaBetweenDispatching_mDEFE0A4E1B04B23544A86A08C1E2EB61F402ED58,
	TrafficStatsGameLevel_get_LongestDeltaBetweenSending_m675DEF48EE25023050368C69C6B747694CBE1963,
	TrafficStatsGameLevel_set_LongestDeltaBetweenSending_mA60D3535A64B0791325E9D05F1D90F8D41BAF17D,
	TrafficStatsGameLevel_get_DispatchIncomingCommandsCalls_mF3176605CDE3F9C704F0B8235F11E12E6F501103,
	TrafficStatsGameLevel_set_DispatchIncomingCommandsCalls_m30C11455B9A50569D45D662FF82574F7FEB05B1E,
	TrafficStatsGameLevel_get_SendOutgoingCommandsCalls_m3D54DA247DE03932774A6BD4CC1A823B19E422D7,
	TrafficStatsGameLevel_set_SendOutgoingCommandsCalls_mEEAED432152F6D5F3F2D873F112EF922853D242B,
	TrafficStatsGameLevel_get_TotalMessageCount_m1B0CE91DBC922F45227B40DCC437A84A6FC68C65,
	TrafficStatsGameLevel_get_TotalIncomingMessageCount_m3D08A03FA1A826688AB384164166EA725617D3AC,
	TrafficStatsGameLevel_get_TotalOutgoingMessageCount_m92AD09E734F469B48A1A348CC660472DABEEA9B3,
	TrafficStatsGameLevel_CountOperation_m1978498FE0AC17C2551B7431AA6639E0BB86BA39,
	TrafficStatsGameLevel_CountResult_m6C3347973810BDC6281AACF12D258865A2ACCD39,
	TrafficStatsGameLevel_CountEvent_mE1C1B1971133466558A658426F1FED0DFECCC374,
	TrafficStatsGameLevel_TimeForResponseCallback_m34F52354671761AA9B1A344C2F7C0392756E0FE2,
	TrafficStatsGameLevel_TimeForEventCallback_mD4AC8FB89EC142A210DD2625E6F75EA945FE8E93,
	TrafficStatsGameLevel_TimeForMessageCallback_m82800528AF5EEBC3A53DCD30B98A99932F32D0EA,
	TrafficStatsGameLevel_TimeForRawMessageCallback_m7FE042DB346346E72A9C648B923B4C79899BA04B,
	TrafficStatsGameLevel_DispatchIncomingCommandsCalled_m7B5BFFF9A9544FB660C59DA55782819075417704,
	TrafficStatsGameLevel_SendOutgoingCommandsCalled_m131E7F8B19A1EE0B7F74BDA5E79A4A04AEE7E886,
	TrafficStatsGameLevel_ToString_m4F4264BCC76A5505EE914975C9BECB2EFBD19BA6,
	TrafficStatsGameLevel_ToStringVitalStats_m033B5DFFBEE36E0538F6476DA877A9DCBA230256,
	TrafficStatsGameLevel__ctor_mEFF2D95A3BA6A7DC6458CE8CE4B8C41A577CB888,
	TrafficStats_get_PackageHeaderSize_mC8F43401532DD17DB3B94D9DCB55034E4A175FE6,
	TrafficStats_set_PackageHeaderSize_mDD901580B42E887068F44747210B0CBFFF98DAD1,
	TrafficStats_get_ReliableCommandCount_m82C319A09B69382CAF519AD2BF878A9654689978,
	TrafficStats_set_ReliableCommandCount_mF72DA410542927C318DD243780A0E5EA7B30B262,
	TrafficStats_get_UnreliableCommandCount_mE175600DD1E94A8F087420FBBE414BCA5ED5BF63,
	TrafficStats_set_UnreliableCommandCount_mCBFE32A119C55D7374595726AC6241C7ED1AADAB,
	TrafficStats_get_FragmentCommandCount_m3DAA945288D68EEB812897CA4537C50EC5A28229,
	TrafficStats_set_FragmentCommandCount_mCC0A808614E88CC8FBAB0D35E47D34F98A1C725F,
	TrafficStats_get_ControlCommandCount_m26887BA8399B36172047FC1CF4DFFCD938401FA1,
	TrafficStats_set_ControlCommandCount_m803FA9105EDC4AB9BD69865B633DA2DA1A1C21CD,
	TrafficStats_get_TotalPacketCount_m2BCB84FB5487EFE19158B0AAF8429EB7418AA47D,
	TrafficStats_set_TotalPacketCount_m1A589CF125AC455EB7DE5DBBEC89CE71F55C25CB,
	TrafficStats_get_TotalCommandsInPackets_mE06A09EDC23CD462AB1AD43DBF471993F4CBEAE0,
	TrafficStats_set_TotalCommandsInPackets_m37C6A81C9AFF05F43261F9B373DEC9C7C5C563F2,
	TrafficStats_get_ReliableCommandBytes_m95A2737B1B3652097B3A41D57B45548A35AFC637,
	TrafficStats_set_ReliableCommandBytes_m3CA101326578FDD1F77833CF46DD4A5FFC758471,
	TrafficStats_get_UnreliableCommandBytes_m24D44D1617EF516F8C8ADD6FFC471825E5D4F26D,
	TrafficStats_set_UnreliableCommandBytes_mA3BFEE6AA9A33093BEEC90E2B9D9EEB1370F6CE0,
	TrafficStats_get_FragmentCommandBytes_mE7EF443243CEA2E028E6897FA4D677FE2D198B02,
	TrafficStats_set_FragmentCommandBytes_mD2875A679AC0F101EFED31347E01C99F7E225ED9,
	TrafficStats_get_ControlCommandBytes_m2C84CFED50C85EB307085C855CD35C47EEFC158D,
	TrafficStats_set_ControlCommandBytes_m859E1B417FF9CB13F5220E45E129B1A6C58263A5,
	TrafficStats__ctor_m74760CBC6FC879433FFEECDEC58DA40DD22B7138,
	TrafficStats_get_TotalCommandBytes_m05D589E8CA9DEE28D8CEF8F80D3EEEF47FCB10E8,
	TrafficStats_get_TotalPacketBytes_m515A4E07ABAEADA280BF5914673338B3CFC2382D,
	TrafficStats_set_TimestampOfLastAck_mFDF32B290DAAC187CF695CEC0105F76B7916A046,
	TrafficStats_set_TimestampOfLastReliableCommand_m8C8435D5A9784C958A958EF338635344A6D2B603,
	TrafficStats_CountControlCommand_m8598F324FC4A122FE4068CC81FB9F5249F08E26F,
	TrafficStats_CountReliableOpCommand_mC8B66F09A1AF75ED670754C9122F5103D1A06E76,
	TrafficStats_CountUnreliableOpCommand_m01CC1FC4FF861C4681913C06AB154E8636478E22,
	TrafficStats_CountFragmentOpCommand_mFE125B1013CE19873AF8B72C9A26C2062541230B,
	TrafficStats_ToString_mC13AD2F6906193D18E66215DED412C4220AC03FB,
	Version__cctor_mEAD3A016931403E5309479529B0B0CA687E92734,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	EncryptorNet_Init_m5F6CFA6B08FCCB4021149F12116314D2200921BD,
	EncryptorNet_Encrypt_mC0DB8C4AAABE824AFB3A1913CE44A36EC652252A,
	EncryptorNet_Decrypt_m9588E87A5E2E9062268574904B0349FDF7879122,
	EncryptorNet_CreateHMAC_mB0A07BFCD9D4913BC080A528D5F79E8FF886FC65,
	EncryptorNet_CheckHMAC_m35DFAD06493B31110F40928961B6BB5F7D104BE9,
	EncryptorNet__ctor_m8A505ABEBAF2EB1C4C8AA81F9494F98742A88339,
	EncryptorNative_egconstructEncryptor_m611BE74A9EF4812922E1D3D29E56079ADB5C0207,
	EncryptorNative_egdestructEncryptor_m631AF7F1E250383CD75D23B55D1D6D2879AD64F8,
	EncryptorNative_egencrypt_m9DE6712C092984D351F26BBDC99EA181D76F4C1E,
	EncryptorNative_egdecrypt_mF6ACAF97927ACC2D9B4A09391599CC77C6877372,
	EncryptorNative_egHMAC_m094A98369F250ED14616883D9699F7E0A386C4C9,
	EncryptorNative_egsetEncryptorLoggingCallback_mB04851719F9B0ADCF75E94DB159B22E451FA34F1,
	EncryptorNative_egsetEncryptorLoggingLevel_m59647D34F104EB3A3C11AFE3B651E6CF3524A4E6,
	EncryptorNative_Finalize_m3DF1A9A04A1DB0573CC782F4A44344E30C7C861C,
	EncryptorNative_OnNativeLog_m07553F096F482149F7B3DCEED091CD30B3245822,
	EncryptorNative_Init_m1C06D6143758FDF555D48EA92CBF5B843C9B17D4,
	EncryptorNative_Dispose_m286A4F3419BED882BB8EFFF18B272A3A563D968B,
	EncryptorNative_Encrypt_m968D613F2B33F7693BA1926FC17163B52D84ED8A,
	EncryptorNative_CreateHMAC_mF757CF57FEE0D7F3A5DEEFCA3211EAA59CF59F18,
	EncryptorNative_Decrypt_m6199FACE445D4F7AA43A6A966AAC97AA0ECA3F6D,
	EncryptorNative_CheckHMAC_mCD1C1F1FB85F703C594C6565EA2CD73B9700F931,
	EncryptorNative__ctor_m99922896136A49F96E0607B285567C36CFF93428,
	EncryptorNative__cctor_m314CC518177DDE2D06B9D9F14FA4B7C35C61340B,
	LogCallbackDelegate__ctor_m405DE18391497B7414002B125D005A397B0BA606,
	LogCallbackDelegate_Invoke_mE3BAF225183593AD68E35F2F3FA8ACB5D8B153B2,
	LogCallbackDelegate_BeginInvoke_mDEF9BFF610C8E789516C6DAF436888D708511F24,
	LogCallbackDelegate_EndInvoke_mFB75C206528C735ADA4D88BF62050A5E1B068C92,
	DiffieHellmanCryptoProvider__ctor_m6CF48A427A6A4C1C73A275AE4601B5FC832B0D90,
	DiffieHellmanCryptoProvider__ctor_mC63A4FAC78CF54D921BD95CCB506185D0F5F5B30,
	DiffieHellmanCryptoProvider_get_PublicKey_m7889CCF54E358285333FAAB35D841CC55389951A,
	DiffieHellmanCryptoProvider_DeriveSharedKey_mFAB2F5C83C17484F076254DC1F1478A118E47B05,
	DiffieHellmanCryptoProvider_Encrypt_mC0DCCDD9900D600B8D3D75C3F2ED86EF5F4FAA7F,
	DiffieHellmanCryptoProvider_Decrypt_m0302814E0FC8562866A4B1B604D046C9710BF44C,
	DiffieHellmanCryptoProvider_Dispose_mBD5F473D0A0BE5F36552E9683348212978378446,
	DiffieHellmanCryptoProvider_Dispose_m5D41514ED2BE6D46D5C206965983C1DF659E1937,
	DiffieHellmanCryptoProvider_CalculatePublicKey_m2AFCFD031702DCC95554E7D279D4CF60F06BE20A,
	DiffieHellmanCryptoProvider_CalculateSharedKey_mCE56E80F87EFD02B6BAF0B94EA62448989418093,
	DiffieHellmanCryptoProvider_GenerateRandomSecret_m2B772416A7C2B6E69BA50C8751A2462D001303BD,
	DiffieHellmanCryptoProvider__cctor_m1BEDC648C12C1BF9C0E689CB141E8FF2D5F462FA,
	DiffieHellmanCryptoProviderNative_egCryptorCreate_m9D70E98A5086A1AE6478CBED61F5465BF41AC272,
	DiffieHellmanCryptoProviderNative_egCryptorPublicKey_m3112F58DD0528D891EFF3A1636206EABAED864D9,
	DiffieHellmanCryptoProviderNative_egCryptorDeriveSharedKey_mAB7ABC8930144442D374A9EB2E87695E8760944F,
	DiffieHellmanCryptoProviderNative_egCryptorEncrypt_mFBA022B3510C210650EA61E121940DB9CA09F71F,
	DiffieHellmanCryptoProviderNative_egCryptorDecrypt_m0107A08B8F06A60212B08977B2E9E6B5012EE642,
	DiffieHellmanCryptoProviderNative_egCryptorDispose_m8265B1FB3537F000A5E86D0FA1005349F76A4919,
	DiffieHellmanCryptoProviderNative__ctor_mAF125EE0ECC98869D2A50EB7C0F62238E6213C13,
	DiffieHellmanCryptoProviderNative__ctor_m327AC0160F2C34C338DE706B8A6E633328E8EE1C,
	DiffieHellmanCryptoProviderNative_get_PublicKey_mDDB7904407CED428B620E51274D758587E4C95F0,
	DiffieHellmanCryptoProviderNative_DeriveSharedKey_m21ED699256730D0B659C5BE2EADDAE0FAA99BFCC,
	DiffieHellmanCryptoProviderNative_Encrypt_m70E5AA9BD3D88D518ADEA6FADFBC60326A0168F1,
	DiffieHellmanCryptoProviderNative_Decrypt_m2A39F81F7396796DAF8BE8C8B8F6CA71608B5F6D,
	DiffieHellmanCryptoProviderNative_Dispose_mD27CBB090AA565A7E884D4DD44211E3C191177FD,
	DiffieHellmanCryptoProviderNative_Dispose_mA690B9A2EB85D0C3B95D1166771AD8A8B77D0612,
	NULL,
	NULL,
	NULL,
	NULL,
	OakleyGroups__cctor_m8DFF1D2E3A13CBF70F3417B4DB00CFE68BB36DDF,
	BigInteger__ctor_m4A81832FF842D3ACA6ABB1C87D5EF115EAC92BE4,
	BigInteger__ctor_m1604AA86CCA9ED9954C0250B09834D5BC01199A6,
	BigInteger__ctor_m3E4E128A4D2CC596D46B9474FE107EC5BC149294,
	BigInteger__ctor_mAD286D5A8256FB3CC684588654ADD704D43B3D33,
	BigInteger__ctor_m0C152120EACBA5C9D6587E199D7195C7E4B21CFF,
	BigInteger_op_Implicit_mDE241FC8616FA43B99B3C3F500C493CC5CB733F0,
	BigInteger_op_Implicit_m8BD70B68E1CE38BB36014E0DF471832BFD804D83,
	BigInteger_op_Addition_m0681302AE8D6287FC6AC7E88BC27A814E5D7AFF5,
	BigInteger_op_Subtraction_mC059BDDE7ACBB0CA0E43FE01817D84C74F71E95A,
	BigInteger_op_Multiply_mCBBDB1F307D18146E21429491217DAFE3B7A9A39,
	BigInteger_op_LeftShift_mD2E9EDEAD8BFFFE62D99BA9E8EF41F86F02E743F,
	BigInteger_shiftLeft_m6501D28220631506827B8AB34550C371C28EBA07,
	BigInteger_shiftRight_mCB5A3430D16B363DA046BF61DCAF44D8F2EB1D3B,
	BigInteger_op_UnaryNegation_m78D54F56AC2443BD97ABCAF386CBC4687AC74CA5,
	BigInteger_op_Equality_m81339D9D8CFAE84507FF6D65F8013AB65FBFA0B5,
	BigInteger_Equals_m9B56D96D055E74B292AFF7B0E8D851725E3086AC,
	BigInteger_GetHashCode_m8CEAD78D9FA3C820184A99C2CE52BB78AB2FD077,
	BigInteger_op_GreaterThan_m94E79FD68D5D87BAB3A7BB3A827D1B3B6AD602CE,
	BigInteger_op_LessThan_m702AE96EA0FAD8852777B1E07FF74EC81BBCEBEE,
	BigInteger_op_GreaterThanOrEqual_m9D3AE2A70E6D545CE2A7E100209BCA002F57FDE9,
	BigInteger_multiByteDivide_m26933DCF73440FFF5F9D9F24DA7A3B6BFD1F690E,
	BigInteger_singleByteDivide_mCF244291334D52E9CF40FEC48C8932F3AE7133D6,
	BigInteger_op_Division_m1329FDD2E3A0EEAEA8699D4EAEE1A8886C241154,
	BigInteger_op_Modulus_mC21260AD99EA5397CABEB1CBF6AE79056AE8C4C9,
	BigInteger_ToString_m8164313123568AA7F354772CC0A2A3712877DD4F,
	BigInteger_ToString_mB463B4064CC8AF3BA028F81BB814DF1A6A581128,
	BigInteger_ModPow_m678E3DF24BA08E874EC8B5C46FECB1E41D90F09A,
	BigInteger_BarrettReduction_m5A72352138BFD6D10096EE775637FA257060022C,
	BigInteger_GenerateRandom_m2195DB5797B263923FFAACBF25871E760F30106D,
	BigInteger_genRandomBits_m8AF00642701E4F4D91179C496AA7A67FC07E3049,
	BigInteger_bitCount_m5DF34C9D04CCEE6038817E2A35EB7C1365E20353,
	BigInteger_GetBytes_m963C6A22411F913586528ABB89DA6640DB1B34CC,
	BigInteger__cctor_m102646DF3DD11FE6AE6206CFA12BCA43F3491833,
};
extern void SendOptions_set_Reliability_m2DE41348D40DD9703AB284E030692368894EA747_AdjustorThunk (void);
static Il2CppTokenAdjustorThunkPair s_adjustorThunks[1] = 
{
	{ 0x060001D7, SendOptions_set_Reliability_m2DE41348D40DD9703AB284E030692368894EA747_AdjustorThunk },
};
static const int32_t s_InvokerIndices[736] = 
{
	23,
	32,
	28,
	27,
	14,
	828,
	30,
	30,
	34,
	1805,
	139,
	23,
	9,
	23,
	23,
	23,
	1001,
	23,
	23,
	23,
	23,
	89,
	10,
	10,
	10,
	89,
	89,
	89,
	1806,
	130,
	1807,
	1808,
	10,
	112,
	137,
	137,
	137,
	26,
	26,
	26,
	137,
	137,
	9,
	9,
	780,
	3,
	23,
	88,
	26,
	32,
	26,
	14,
	10,
	10,
	32,
	89,
	14,
	26,
	4,
	159,
	10,
	32,
	89,
	31,
	26,
	26,
	26,
	89,
	89,
	507,
	362,
	218,
	88,
	32,
	1809,
	28,
	41,
	23,
	3,
	23,
	28,
	43,
	14,
	14,
	152,
	1234,
	152,
	152,
	1810,
	152,
	153,
	221,
	9,
	105,
	28,
	28,
	28,
	28,
	23,
	10,
	89,
	89,
	1810,
	1811,
	619,
	634,
	14,
	23,
	112,
	14,
	23,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	14,
	23,
	3,
	14,
	14,
	26,
	26,
	14,
	89,
	10,
	10,
	89,
	14,
	10,
	89,
	10,
	89,
	23,
	4,
	159,
	23,
	1001,
	28,
	209,
	209,
	23,
	23,
	23,
	23,
	23,
	1806,
	1808,
	89,
	89,
	137,
	89,
	9,
	32,
	9,
	26,
	26,
	26,
	88,
	32,
	14,
	26,
	26,
	23,
	89,
	14,
	14,
	14,
	10,
	23,
	23,
	3,
	131,
	23,
	105,
	26,
	23,
	23,
	23,
	23,
	23,
	197,
	14,
	751,
	14,
	197,
	14,
	1812,
	14,
	89,
	14,
	49,
	49,
	49,
	3,
	10,
	32,
	14,
	26,
	14,
	26,
	89,
	89,
	89,
	31,
	89,
	14,
	89,
	31,
	10,
	10,
	10,
	26,
	10,
	10,
	10,
	10,
	10,
	10,
	14,
	14,
	89,
	89,
	31,
	89,
	31,
	14,
	10,
	89,
	89,
	31,
	14,
	26,
	14,
	26,
	14,
	26,
	177,
	89,
	31,
	23,
	23,
	130,
	14,
	31,
	457,
	90,
	935,
	1001,
	23,
	23,
	23,
	23,
	89,
	1813,
	26,
	23,
	89,
	89,
	89,
	1814,
	1815,
	3,
	89,
	23,
	130,
	14,
	14,
	23,
	130,
	10,
	14,
	23,
	14,
	23,
	131,
	28,
	209,
	28,
	131,
	1816,
	132,
	221,
	131,
	28,
	209,
	28,
	131,
	1817,
	1818,
	28,
	944,
	1815,
	1178,
	1819,
	1820,
	1059,
	1059,
	1059,
	3,
	14,
	14,
	90,
	153,
	130,
	9,
	1821,
	152,
	1810,
	28,
	152,
	28,
	152,
	105,
	27,
	105,
	152,
	812,
	812,
	1234,
	362,
	1822,
	1823,
	1824,
	152,
	152,
	152,
	1825,
	152,
	152,
	152,
	152,
	27,
	585,
	1826,
	153,
	9,
	9,
	221,
	112,
	222,
	223,
	224,
	28,
	28,
	58,
	58,
	28,
	28,
	28,
	28,
	1827,
	1284,
	23,
	3,
	26,
	14,
	14,
	152,
	1234,
	152,
	153,
	221,
	9,
	823,
	823,
	9,
	30,
	28,
	153,
	9,
	9,
	221,
	221,
	223,
	224,
	28,
	153,
	105,
	105,
	28,
	28,
	28,
	28,
	28,
	1284,
	28,
	28,
	28,
	1828,
	28,
	28,
	28,
	28,
	28,
	28,
	28,
	28,
	28,
	1272,
	1272,
	112,
	112,
	222,
	222,
	28,
	28,
	37,
	993,
	152,
	1826,
	152,
	27,
	152,
	1810,
	152,
	812,
	812,
	959,
	1234,
	1824,
	1823,
	152,
	152,
	152,
	1825,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	152,
	202,
	152,
	152,
	90,
	1826,
	152,
	585,
	1227,
	152,
	152,
	137,
	362,
	1822,
	137,
	507,
	176,
	37,
	993,
	23,
	3,
	31,
	3,
	25,
	1829,
	89,
	507,
	3,
	26,
	23,
	23,
	89,
	89,
	507,
	23,
	23,
	26,
	23,
	23,
	89,
	89,
	507,
	23,
	23,
	32,
	26,
	14,
	14,
	23,
	14,
	690,
	10,
	10,
	32,
	734,
	204,
	32,
	508,
	35,
	89,
	31,
	42,
	30,
	1,
	106,
	232,
	5,
	49,
	142,
	159,
	0,
	158,
	0,
	43,
	114,
	3,
	131,
	10,
	105,
	112,
	106,
	3,
	23,
	23,
	3,
	23,
	10,
	-1,
	-1,
	-1,
	-1,
	23,
	23,
	1001,
	23,
	23,
	23,
	23,
	26,
	89,
	89,
	89,
	1806,
	1808,
	1830,
	23,
	137,
	137,
	26,
	26,
	3,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	89,
	31,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	10,
	10,
	32,
	32,
	32,
	828,
	828,
	32,
	32,
	23,
	23,
	14,
	14,
	23,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	10,
	32,
	32,
	10,
	10,
	32,
	32,
	32,
	32,
	32,
	32,
	14,
	3,
	976,
	1831,
	1832,
	54,
	146,
	976,
	1831,
	1832,
	54,
	146,
	23,
	1671,
	25,
	1833,
	1834,
	1834,
	1194,
	46,
	23,
	1835,
	976,
	31,
	1831,
	54,
	1832,
	146,
	23,
	3,
	131,
	1836,
	1837,
	26,
	23,
	26,
	14,
	26,
	54,
	54,
	23,
	31,
	14,
	28,
	34,
	3,
	768,
	1838,
	1839,
	1840,
	1840,
	25,
	23,
	26,
	14,
	26,
	54,
	54,
	23,
	31,
	14,
	26,
	54,
	54,
	3,
	23,
	204,
	26,
	26,
	26,
	943,
	43,
	1,
	1,
	1,
	115,
	114,
	114,
	0,
	121,
	9,
	10,
	121,
	121,
	121,
	1841,
	1841,
	1,
	1,
	14,
	34,
	105,
	209,
	43,
	62,
	10,
	14,
	3,
};
static const Il2CppTokenIndexMethodTuple s_reversePInvokeIndices[1] = 
{
	{ 0x06000294, 7,  (void**)&EncryptorNative_OnNativeLog_m07553F096F482149F7B3DCEED091CD30B3245822_RuntimeMethod_var, 0 },
};
static const Il2CppTokenRangePair s_rgctxIndices[1] = 
{
	{ 0x02000039, { 0, 9 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[9] = 
{
	{ (Il2CppRGCTXDataType)2, 21284 },
	{ (Il2CppRGCTXDataType)3, 12647 },
	{ (Il2CppRGCTXDataType)3, 12648 },
	{ (Il2CppRGCTXDataType)3, 12649 },
	{ (Il2CppRGCTXDataType)3, 12650 },
	{ (Il2CppRGCTXDataType)2, 18625 },
	{ (Il2CppRGCTXDataType)3, 12651 },
	{ (Il2CppRGCTXDataType)3, 12652 },
	{ (Il2CppRGCTXDataType)3, 12653 },
};
extern const Il2CppCodeGenModule g_Photon3Unity3DCodeGenModule;
const Il2CppCodeGenModule g_Photon3Unity3DCodeGenModule = 
{
	"Photon3Unity3D.dll",
	736,
	s_methodPointers,
	1,
	s_adjustorThunks,
	s_InvokerIndices,
	1,
	s_reversePInvokeIndices,
	1,
	s_rgctxIndices,
	9,
	s_rgctxValues,
	NULL,
};
