﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"





IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void Actif::Start()
extern void Actif_Start_mF52ABF049AA1B6C645034695194E6C6862B10ED7 (void);
// 0x00000002 System.Void Actif::Update()
extern void Actif_Update_mD55E1C2564F5E3BA986DDDEBC767B485DB6B025F (void);
// 0x00000003 System.Void Actif::.ctor()
extern void Actif__ctor_mC6B5084C8B6F01F4D67389297A5E8241BEBF224C (void);
// 0x00000004 System.Void ConvertToLineMesh::Update()
extern void ConvertToLineMesh_Update_m221417ECE795D58A804C0CC2CEDA11735D428131 (void);
// 0x00000005 System.Void ConvertToLineMesh::GeneratePointMesh()
extern void ConvertToLineMesh_GeneratePointMesh_m129685FC426FFB85842249C0ED5BDA78ABA49BC5 (void);
// 0x00000006 System.Void ConvertToLineMesh::.ctor()
extern void ConvertToLineMesh__ctor_mDE919BFC4905670D98B0D1CCBD1B3D7F31BC94A7 (void);
// 0x00000007 System.Void ConvertToPointMesh::Update()
extern void ConvertToPointMesh_Update_m4D2D60118B6E8ACED9F3B7F200C7DA4425AE59B2 (void);
// 0x00000008 System.Void ConvertToPointMesh::GeneratePointMesh()
extern void ConvertToPointMesh_GeneratePointMesh_m7D331DDB086E5A926E1C47BB2BE62012A51B1EE5 (void);
// 0x00000009 System.Void ConvertToPointMesh::.ctor()
extern void ConvertToPointMesh__ctor_m87954E0B2719F2C5B97F945F161B32CE45787DC0 (void);
// 0x0000000A System.Void RotateTowardsCamera::Update()
extern void RotateTowardsCamera_Update_mADF3DD94EF3BEBB150EE5B76DF924B2ECD98DBE8 (void);
// 0x0000000B System.Void RotateTowardsCamera::.ctor()
extern void RotateTowardsCamera__ctor_mFDFE62D079ED20BCC78A5880A7D974FE41D982F2 (void);
// 0x0000000C System.Void ChangeTheme::Start()
extern void ChangeTheme_Start_mD5BFBBDA90B98D61693AD22B0762256F4A2453A8 (void);
// 0x0000000D System.Void ChangeTheme::DochangeTheme(System.Int32)
extern void ChangeTheme_DochangeTheme_m0B57BE28036D45FCFC39E5AC27F327E8679B3EEB (void);
// 0x0000000E System.Void ChangeTheme::.ctor()
extern void ChangeTheme__ctor_m7F70ADD63C986E5BDFD1897C8955BDA575AC1BCD (void);
// 0x0000000F System.Void DIDIDI::ShowHideMenu()
extern void DIDIDI_ShowHideMenu_m000A016FBFB5D7539FC9BE6A393A567D9757F480 (void);
// 0x00000010 System.Void DIDIDI::.ctor()
extern void DIDIDI__ctor_m1B459C1989CABEA2124F519A75B610D7F53CD7CC (void);
// 0x00000011 System.Void OwnerShipTransfer::HideInputName_Panel(System.String)
extern void OwnerShipTransfer_HideInputName_Panel_m543BCF8A85850C40AF8E6588582B68BFFA5090A2 (void);
// 0x00000012 System.Void OwnerShipTransfer::IN()
extern void OwnerShipTransfer_IN_mEBFB0DAE72E3492594406ADB2A449F0C40262FC4 (void);
// 0x00000013 System.Void OwnerShipTransfer::CheckPhotonViewOwner(Photon.Realtime.Player[])
extern void OwnerShipTransfer_CheckPhotonViewOwner_mB4F92E5A83C678880AC2958EC4F226AD58F94B67 (void);
// 0x00000014 System.Void OwnerShipTransfer::setOn(System.Boolean)
extern void OwnerShipTransfer_setOn_m1AA23B24267A14A5E9CB9782E5DA7062BDEBA39E (void);
// 0x00000015 System.Void OwnerShipTransfer::Update()
extern void OwnerShipTransfer_Update_mEC1D4D26D5850B71578B483013E1EE8A5F7A2C6E (void);
// 0x00000016 System.Void OwnerShipTransfer::SetText(Photon.Realtime.Player[],System.Int32[])
extern void OwnerShipTransfer_SetText_m9453E9A8F2D6D03E5ACB8CF72959036672592389 (void);
// 0x00000017 System.Void OwnerShipTransfer::OverrideHost(System.Single,System.Single)
extern void OwnerShipTransfer_OverrideHost_m373D11302F12DD680AA694572310CD4A30002154 (void);
// 0x00000018 System.Void OwnerShipTransfer::.ctor()
extern void OwnerShipTransfer__ctor_m1FB7E6B0506E16B942F048ACDA694DF8D728ED8A (void);
// 0x00000019 System.Void SimpleControl::Update()
extern void SimpleControl_Update_m6CDE5FB77FABCFBC70D1D09F7D68C36D0F9CFE58 (void);
// 0x0000001A System.Void SimpleControl::.ctor()
extern void SimpleControl__ctor_mF2770C5E6A99D69953CCC1242C1F1A431DB7C514 (void);
// 0x0000001B System.Void SimpleControl2::Update()
extern void SimpleControl2_Update_mE7A75C065A622F012D5BB6FD0A036AA88B0615CD (void);
// 0x0000001C System.Void SimpleControl2::.ctor()
extern void SimpleControl2__ctor_m4DCA63858ACAF74529E78A679B40F2FFAB00E242 (void);
// 0x0000001D System.Void ADS::Start()
extern void ADS_Start_mA68EB8813892C5F0AD75F44CD88C9982A7674624 (void);
// 0x0000001E System.Void ADS::ShowInterstitialAd()
extern void ADS_ShowInterstitialAd_mFC83EF727D32E5E9FFE51B0D94A0F712F9D6F50C (void);
// 0x0000001F System.Collections.IEnumerator ADS::ShowBannerWhenInitialized()
extern void ADS_ShowBannerWhenInitialized_m34628FC6B1456576C8089DE49E75AE0A1F93A9F0 (void);
// 0x00000020 System.Void ADS::.ctor()
extern void ADS__ctor_m09273B53A1B0C3C60AC5D2958E9B2BD161372A7E (void);
// 0x00000021 System.Void AddForce::start()
extern void AddForce_start_m50CCA7957AD1A07E18D98DDD69DECD6B1947B8DC (void);
// 0x00000022 System.Void AddForce::OnMouseDrag()
extern void AddForce_OnMouseDrag_m3D0EEA8817F2CA652EFB9DC2CA3AB445DEF0CE3D (void);
// 0x00000023 System.Void AddForce::Update()
extern void AddForce_Update_m2D7DEA766F7EC7A01CBD04DEC115CA979AC0227B (void);
// 0x00000024 System.Void AddForce::FixedUpdate()
extern void AddForce_FixedUpdate_m448B02E7F8E12B95FC141F8B1B0D80C23CEDA0EE (void);
// 0x00000025 System.Void AddForce::.ctor()
extern void AddForce__ctor_mD145641C9B9DE20A1DF1F26C929FB6560E736F09 (void);
// 0x00000026 System.Void Zoom::Start()
extern void Zoom_Start_mA42CFFF6B9D92AFF162D6EE0EE7FDAF481F69203 (void);
// 0x00000027 System.Void Zoom::.ctor()
extern void Zoom__ctor_m48EC87C1D84179E33EFD99EA35B82C25F3574238 (void);
// 0x00000028 System.Void a::Start()
extern void a_Start_m63227AC9295B3784F99C8D3EAEFF038C0BFCBF1F (void);
// 0x00000029 System.Collections.IEnumerator a::ShowBannerWhenInitialized()
extern void a_ShowBannerWhenInitialized_mC65521D0CDA0F1665916B1E6C886BB816D4B38E8 (void);
// 0x0000002A System.Void a::.ctor()
extern void a__ctor_mB4A142985402040FBF1A5F2339C3A8D394A61004 (void);
// 0x0000002B System.Void Gun::Use()
// 0x0000002C System.Void Gun::.ctor()
extern void Gun__ctor_mC9C3C6BB532D28E4A18097E833645FB45888F87B (void);
// 0x0000002D System.Void GunInfo::.ctor()
extern void GunInfo__ctor_mDE2950671035172277FD7DE5D4A3FF008793AB07 (void);
// 0x0000002E System.Void IDamageable::TakeDamage(System.Single)
// 0x0000002F System.Void Item::Use()
// 0x00000030 System.Void Item::.ctor()
extern void Item__ctor_mDD5CE3191836C8F404C284F0DC5C87394F78E84B (void);
// 0x00000031 System.Void ItemInfo::.ctor()
extern void ItemInfo__ctor_m003DCEDBC674D1078485730A2E99662D1B4E42DA (void);
// 0x00000032 System.Void Launcher::Awake()
extern void Launcher_Awake_mBE44C29C9ABCBA09F0089E2C1F008FFED84C2A3F (void);
// 0x00000033 System.Void Launcher::Start()
extern void Launcher_Start_mB785B8C7AD443649D3A8030352990E194FB22DE8 (void);
// 0x00000034 System.Void Launcher::OnConnectedToMaster()
extern void Launcher_OnConnectedToMaster_m983E3D84ED222F36B555BB29F609990265F61C03 (void);
// 0x00000035 System.Void Launcher::OnJoinedLobby()
extern void Launcher_OnJoinedLobby_m68167B6F0642E60D1BF4335BEC526BF7B32B4DB3 (void);
// 0x00000036 System.Void Launcher::CreateRoom()
extern void Launcher_CreateRoom_mBDE023EC6A9A761CAD0D5709340E0006636B7965 (void);
// 0x00000037 System.Void Launcher::OnJoinedRoom()
extern void Launcher_OnJoinedRoom_mA980BB15177B8E0BBBC5BF74F059F03B555EBEFF (void);
// 0x00000038 System.Void Launcher::OnMasterClientSwitched(Photon.Realtime.Player)
extern void Launcher_OnMasterClientSwitched_mF0D3467CEBC9910696D694708A4CE9072739497F (void);
// 0x00000039 System.Void Launcher::OnCreateRoomFailed(System.Int16,System.String)
extern void Launcher_OnCreateRoomFailed_m305254A650520122D67E66B8566D2CC1CBA4748F (void);
// 0x0000003A System.Void Launcher::StartGame()
extern void Launcher_StartGame_mD32628C64EC2C4DFAA065DD02D4B2E2DFB8153D3 (void);
// 0x0000003B System.Void Launcher::LeaveRoom()
extern void Launcher_LeaveRoom_mC5E8162D72AB21EE997DC2B074B4FE0BCEA887B5 (void);
// 0x0000003C System.Void Launcher::JoinRoom(Photon.Realtime.RoomInfo)
extern void Launcher_JoinRoom_m9488E87A9E6713795FC6DF2040D54014CEDCDEB2 (void);
// 0x0000003D System.Void Launcher::OnLeftRoom()
extern void Launcher_OnLeftRoom_mB0EB1CCAC9232941AD6C67B86A6BEEEA1CAC2F45 (void);
// 0x0000003E System.Void Launcher::OnRoomListUpdate(System.Collections.Generic.List`1<Photon.Realtime.RoomInfo>)
extern void Launcher_OnRoomListUpdate_m901025C882658EB3152DF30719A93FF86AF49A7F (void);
// 0x0000003F System.Void Launcher::OnPlayerEnteredRoom(Photon.Realtime.Player)
extern void Launcher_OnPlayerEnteredRoom_m245D4B5F41F7C85E6921955E4EF50280D8856C46 (void);
// 0x00000040 System.Void Launcher::.ctor()
extern void Launcher__ctor_m5E3C1ED0409DFB8090A7820B3322EDD6C771845D (void);
// 0x00000041 System.Void Menu::Open()
extern void Menu_Open_mB25514E8FE3D2C26D274B58EB5C1EC8A742DA869 (void);
// 0x00000042 System.Void Menu::Close()
extern void Menu_Close_m6ABFF54072F3527CC37871ED1B6A4A8E34157E14 (void);
// 0x00000043 System.Void Menu::.ctor()
extern void Menu__ctor_mD372D109F6554E1F9A25291964C852C9F6BFC463 (void);
// 0x00000044 System.Void MenuManager::Awake()
extern void MenuManager_Awake_m509E86B86EE3FD70E7831B2B0B421F9826B1D184 (void);
// 0x00000045 System.Void MenuManager::OpenMenu(System.String)
extern void MenuManager_OpenMenu_mDC79E1407E5157CE953463A6D6CF8B3ADAF5E632 (void);
// 0x00000046 System.Void MenuManager::OpenMenu(Menu)
extern void MenuManager_OpenMenu_m1BFE39E135FAB6BBD17AA215B75CCD99CF544347 (void);
// 0x00000047 System.Void MenuManager::CloseMenu(Menu)
extern void MenuManager_CloseMenu_m2C26269D235C4027E7CE4A5E3EDA6633605271E8 (void);
// 0x00000048 System.Void MenuManager::.ctor()
extern void MenuManager__ctor_mF9508A23E828387B76DB818A2E34D3A8AC9063EF (void);
// 0x00000049 System.Void PlayerController::Awake()
extern void PlayerController_Awake_m118C1D205A374B627E1EC963E5837E23CF554573 (void);
// 0x0000004A System.Void PlayerController::Start()
extern void PlayerController_Start_mC0C9B9461D0BDAC48EC43715818A4BA63C4F45EF (void);
// 0x0000004B System.Void PlayerController::Update()
extern void PlayerController_Update_m38903EF1C8F12B9388303741F8040EE26C33DC33 (void);
// 0x0000004C System.Void PlayerController::Look()
extern void PlayerController_Look_m0A973768C9C0EFAF29B9B6E6D48DE7FD1BDC8A65 (void);
// 0x0000004D System.Void PlayerController::Move()
extern void PlayerController_Move_m0CD456A5EA1116F1B4EA5A731C7EAC46D26B598F (void);
// 0x0000004E System.Void PlayerController::Jump()
extern void PlayerController_Jump_m3056E2DF0CD8445804DCDAB6521E81541F0218A1 (void);
// 0x0000004F System.Void PlayerController::EquipItem(System.Int32)
extern void PlayerController_EquipItem_m1322B70356CB44651260E1449AE0285B1BE8BDC7 (void);
// 0x00000050 System.Void PlayerController::OnPlayerPropertiesUpdate(Photon.Realtime.Player,ExitGames.Client.Photon.Hashtable)
extern void PlayerController_OnPlayerPropertiesUpdate_m9659F27002514187A768F0356707B049B1E28FE3 (void);
// 0x00000051 System.Void PlayerController::SetGroundedState(System.Boolean)
extern void PlayerController_SetGroundedState_m22C1F6A5A43405EA167EBC18CCAE03007AB8BA34 (void);
// 0x00000052 System.Void PlayerController::FixedUpdate()
extern void PlayerController_FixedUpdate_m914EA3E3CCE4DF6AEB2E78317FFC1D507DACEBDE (void);
// 0x00000053 System.Void PlayerController::TakeDamage(System.Single)
extern void PlayerController_TakeDamage_m65FA43A04541D6C86BD5BAB74A6CC8FCA8AAEFAF (void);
// 0x00000054 System.Void PlayerController::RPC_TakeDamage(System.Single)
extern void PlayerController_RPC_TakeDamage_m41A1A5DDDCA1AF5F00617D86ACF4E18AAC8DBB2F (void);
// 0x00000055 System.Void PlayerController::Die()
extern void PlayerController_Die_m5293C32D23350D28D5F7466E7BE49E8165AB7224 (void);
// 0x00000056 System.Void PlayerController::.ctor()
extern void PlayerController__ctor_m648E40092E37395F4307411E855445886113CD60 (void);
// 0x00000057 System.Void PlayerGroundCheck::Awake()
extern void PlayerGroundCheck_Awake_m36EE07E428348599E3727959C76D402D79FA07EF (void);
// 0x00000058 System.Void PlayerGroundCheck::OnTriggerEnter(UnityEngine.Collider)
extern void PlayerGroundCheck_OnTriggerEnter_m6B50610ABBB08642992AC330CFB3E728BE3DC237 (void);
// 0x00000059 System.Void PlayerGroundCheck::OnTriggerExit(UnityEngine.Collider)
extern void PlayerGroundCheck_OnTriggerExit_m0B9A071704BEDB0D39208165A499F3AEC4AE5B0A (void);
// 0x0000005A System.Void PlayerGroundCheck::OnTriggerStay(UnityEngine.Collider)
extern void PlayerGroundCheck_OnTriggerStay_m99DC3BE18E1058A61E5FA959EBF9AC0B25445137 (void);
// 0x0000005B System.Void PlayerGroundCheck::.ctor()
extern void PlayerGroundCheck__ctor_m4E3D61425004DCD63469198CAE187866C0405CA9 (void);
// 0x0000005C System.Void PlayerListItem::SetUp(Photon.Realtime.Player)
extern void PlayerListItem_SetUp_m1C6390C932D02AA99B3A3C11D2B0E03EC767CEEB (void);
// 0x0000005D System.Void PlayerListItem::OnPlayerLeftRoom(Photon.Realtime.Player)
extern void PlayerListItem_OnPlayerLeftRoom_m5F5EA99F615B44A25DDBBBAA9FFB64615B2CF1D2 (void);
// 0x0000005E System.Void PlayerListItem::OnLeftRoom()
extern void PlayerListItem_OnLeftRoom_m8453AFEA487748F2D047FD1C6AAF2D851E38C02D (void);
// 0x0000005F System.Void PlayerListItem::.ctor()
extern void PlayerListItem__ctor_m5066BDA3D1AB0786E49BB61ED077EADEED903D4C (void);
// 0x00000060 System.Void PlayerManager::Awake()
extern void PlayerManager_Awake_mED34BFB5AC87623E77EC44EC1E9881604F4851E6 (void);
// 0x00000061 System.Void PlayerManager::Start()
extern void PlayerManager_Start_m5969CE13735048121AC12C6C4D41B52C1B996E56 (void);
// 0x00000062 System.Void PlayerManager::CreateController()
extern void PlayerManager_CreateController_m8EB6C1724955124A0CD17A5720705B469586A9EB (void);
// 0x00000063 System.Void PlayerManager::Die()
extern void PlayerManager_Die_m75C93CC4A75E4B9105A0019BFEE978967FCFF512 (void);
// 0x00000064 System.Void PlayerManager::.ctor()
extern void PlayerManager__ctor_mE56F430BAC9016609685221F2A5B7C018A00ADAE (void);
// 0x00000065 System.Void RoomListItem::SetUp(Photon.Realtime.RoomInfo)
extern void RoomListItem_SetUp_m302822AB8CDCF1E8A01E3FB320C78EFC64325885 (void);
// 0x00000066 System.Void RoomListItem::OnClick()
extern void RoomListItem_OnClick_m960A620D179224589B3AB197D4FFC8E2C5311E09 (void);
// 0x00000067 System.Void RoomListItem::.ctor()
extern void RoomListItem__ctor_mAA396EAADBE8FC3E83B660225D271A39B194C117 (void);
// 0x00000068 System.Void RoomManager::Awake()
extern void RoomManager_Awake_mF88A6570DF44FCAD111987A861556E034E9D1BC9 (void);
// 0x00000069 System.Void RoomManager::OnEnable()
extern void RoomManager_OnEnable_mB358C3A46698171DF465CF95D605D4CD03028C05 (void);
// 0x0000006A System.Void RoomManager::OnDisable()
extern void RoomManager_OnDisable_mEEDE4F57B633F5F079021AE698EC9342869A4F75 (void);
// 0x0000006B System.Void RoomManager::OnSceneLoaded(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.LoadSceneMode)
extern void RoomManager_OnSceneLoaded_m35280C2883C6C63A8B83DD0EA3BE6F5E2ED28933 (void);
// 0x0000006C System.Void RoomManager::.ctor()
extern void RoomManager__ctor_m647CD75713362D4AE755130C4C3148F47AF980C3 (void);
// 0x0000006D System.Void SingleShotGun::Awake()
extern void SingleShotGun_Awake_mBD1001FA17F85394EAE92FB9E60571F2AD9EC87E (void);
// 0x0000006E System.Void SingleShotGun::Use()
extern void SingleShotGun_Use_m518C9D255972C04CC5E6A79DE46B4B3E032A5D3A (void);
// 0x0000006F System.Void SingleShotGun::Shoot()
extern void SingleShotGun_Shoot_m940FC6312E3C23835B8F357CBFF29E430DA9CD19 (void);
// 0x00000070 System.Void SingleShotGun::RPC_Shoot(UnityEngine.Vector3,UnityEngine.Vector3)
extern void SingleShotGun_RPC_Shoot_mB04E734FD3FF2EDEE85F0DE102D4F997735C708C (void);
// 0x00000071 System.Void SingleShotGun::.ctor()
extern void SingleShotGun__ctor_mA04B340EA5BB326827D4E492C0CCF09D369308D0 (void);
// 0x00000072 System.Void SpawnManager::Awake()
extern void SpawnManager_Awake_m6C18AC22045742445D37B45F609C218A47A06322 (void);
// 0x00000073 UnityEngine.Transform SpawnManager::GetSpawnpoint()
extern void SpawnManager_GetSpawnpoint_m6DEAAEEF29BA08B04B298061917DE55D42EB0BB4 (void);
// 0x00000074 System.Void SpawnManager::.ctor()
extern void SpawnManager__ctor_m7DCC863664A8B146149D9C23833658ED3BDC8DF5 (void);
// 0x00000075 System.Void Spawnpoint::Awake()
extern void Spawnpoint_Awake_mA7ABB39DEB7323B9AE0C56BB5576790C269A8AEE (void);
// 0x00000076 System.Void Spawnpoint::.ctor()
extern void Spawnpoint__ctor_mFDB9FF2B781E8A8CCBBD734BEB0EC3A255846AEA (void);
// 0x00000077 System.Void requestOwner::OnMouseDown()
extern void requestOwner_OnMouseDown_m83B3CD7D15FD9853AA230D5288DAFE5EDB0DDA8D (void);
// 0x00000078 System.Void requestOwner::.ctor()
extern void requestOwner__ctor_m904076799ED4888E9E2B0325FE1E7BF68F873ADC (void);
// 0x00000079 System.Void SphereRotationCopy::Start()
extern void SphereRotationCopy_Start_m7BD8A03EE8C0674CE9CC577C9532C7029195C931 (void);
// 0x0000007A System.Void SphereRotationCopy::Update()
extern void SphereRotationCopy_Update_m67B5E1165C0EA8B429C9D009A553129F5CC71AC2 (void);
// 0x0000007B System.Void SphereRotationCopy::.ctor()
extern void SphereRotationCopy__ctor_mCF6DA51CFFE64E7879272562C2096D7F35DD633C (void);
// 0x0000007C System.Void TestScript::Start()
extern void TestScript_Start_m37FFC63451F28F640DBC8E81F6921CA912BCF9BE (void);
// 0x0000007D System.Void TestScript::Update()
extern void TestScript_Update_mF00A4D69B7E86CF3061303B401FBCF2CB433F44C (void);
// 0x0000007E System.Void TestScript::Change()
extern void TestScript_Change_mDEAA9F4EA63257AD29B85FF01461D964F425C4C3 (void);
// 0x0000007F System.Void TestScript::.ctor()
extern void TestScript__ctor_mAF795D5D902560987B93306D9BB0169F4CD0CF18 (void);
// 0x00000080 System.Void Try::Awake()
extern void Try_Awake_m84F234E4C3E41BAC92540482A382863E6A1BB37D (void);
// 0x00000081 System.Void Try::Update()
extern void Try_Update_m0A0CDCEC34F921E403FAE59FEC4F74FAB60B75A2 (void);
// 0x00000082 System.Void Try::.ctor()
extern void Try__ctor_m17D029E7B5721BFF27701E579B38EA87F6EBBACF (void);
// 0x00000083 System.Void SliderMenuAnim::Start()
extern void SliderMenuAnim_Start_m73AE2B603B2A0BD95EF2C9D55722E8B8144BD487 (void);
// 0x00000084 System.Void SliderMenuAnim::ShowHideMenu()
extern void SliderMenuAnim_ShowHideMenu_mE19AF5B471CD1FCC880230433B2800F491F78EFC (void);
// 0x00000085 System.Void SliderMenuAnim::TaskOnClick()
extern void SliderMenuAnim_TaskOnClick_m2871F04D722815586595A4B109775782C9A4E4AC (void);
// 0x00000086 System.Void SliderMenuAnim::Update()
extern void SliderMenuAnim_Update_m15931CB9D192BC3E481A4BE05244C5A1418601A1 (void);
// 0x00000087 System.Void SliderMenuAnim::.ctor()
extern void SliderMenuAnim__ctor_m6073C281A6191217FC659A6703CF93C68D09EF3C (void);
// 0x00000088 System.Void UIController::Start()
extern void UIController_Start_m25C8537A29A929C6B8BB8AD754CC846D444822EE (void);
// 0x00000089 System.Void UIController::Update()
extern void UIController_Update_mA639146623182EEFE585BB46CD8ED3D5739FBF2B (void);
// 0x0000008A System.Void UIController::Violet()
extern void UIController_Violet_mB24E63FAE4BE78666BE43D00AEF0DA424B22DF97 (void);
// 0x0000008B System.Void UIController::Blue()
extern void UIController_Blue_mC38911C5A8E5687035B761CA64D2D8694CAFBF0C (void);
// 0x0000008C System.Void UIController::T2()
extern void UIController_T2_m2F63ECE4CF2689B57C0C82F88A24076293E861AD (void);
// 0x0000008D System.Void UIController::T3()
extern void UIController_T3_m3A1ACDB43925A76DF937AE30B155592BEDC8FB5E (void);
// 0x0000008E System.Void UIController::T4()
extern void UIController_T4_m54C95E4DA3B75212930598EBC32B527BCA0E9DAF (void);
// 0x0000008F System.Void UIController::.ctor()
extern void UIController__ctor_m218DB9E5110A9E50B5F9C61416BB83F05FBBD4EA (void);
// 0x00000090 System.Void autoRotate::Start()
extern void autoRotate_Start_m9363279D08053EEB673436AC190003177F8D3A90 (void);
// 0x00000091 System.Void autoRotate::Update()
extern void autoRotate_Update_m3D4D109E5362717DAC05CE5266D311E82BB7E961 (void);
// 0x00000092 System.Void autoRotate::.ctor()
extern void autoRotate__ctor_m5C0D326F57791805343C13CF60E50A49DFEA61D4 (void);
// 0x00000093 System.Void checkSpeed::Start()
extern void checkSpeed_Start_m722A1142423CADA051D34F44954C8C3A9915F33F (void);
// 0x00000094 System.Void checkSpeed::Update()
extern void checkSpeed_Update_m6A830F6EC7B4B1655775D6F0DD3E6820E8572638 (void);
// 0x00000095 System.Void checkSpeed::setOff()
extern void checkSpeed_setOff_m055A893FA07F16038C392F678B42A2250FDB7F4C (void);
// 0x00000096 System.Void checkSpeed::ShowDelayResult()
extern void checkSpeed_ShowDelayResult_m2CD16A00FBD6C795A488F74DA88DD462A19EEF60 (void);
// 0x00000097 System.Void checkSpeed::HideDelayResult()
extern void checkSpeed_HideDelayResult_mAE700EE2CAFE68D553D407B79DE37C2FF561F2FC (void);
// 0x00000098 System.Void checkSpeed::ShowPanel()
extern void checkSpeed_ShowPanel_m25EF319423D104189F43850EED85CF1EF55ADDA1 (void);
// 0x00000099 System.Void checkSpeed::TaskOnClick()
extern void checkSpeed_TaskOnClick_m2009252AAD804EC64978F00B9363B33B79317850 (void);
// 0x0000009A System.Void checkSpeed::Count()
extern void checkSpeed_Count_m39A95CAFA26200810D6F13B6C7673F5F67D2771E (void);
// 0x0000009B System.Void checkSpeed::ShowAds()
extern void checkSpeed_ShowAds_m5AA89B6CE52A03B92D424D49E733821D5C6A54CC (void);
// 0x0000009C System.Collections.IEnumerator checkSpeed::ExampleCoroutine()
extern void checkSpeed_ExampleCoroutine_mDABBFB8CB4FDB0C17F01555CD70F919A9DBC694B (void);
// 0x0000009D System.Void checkSpeed::.ctor()
extern void checkSpeed__ctor_m81BA37C44B493F9B765E6AE5A1D9E53C06C1BE8E (void);
// 0x0000009E System.Void music::start()
extern void music_start_mE225EFF996F99C34D930819F83DDB7C28E5A03BC (void);
// 0x0000009F System.Void music::Update()
extern void music_Update_m95568B9C3E26D7EE11F461BF39CF60E80456FD06 (void);
// 0x000000A0 System.Void music::OnTriggerEnter(UnityEngine.Collider)
extern void music_OnTriggerEnter_mC9BE77BCCF7B047549CEDF40156C690B76C7A60B (void);
// 0x000000A1 System.Void music::.ctor()
extern void music__ctor_m09A10B55B29748150FC90AF118B0EF64309ECBA2 (void);
// 0x000000A2 System.Void quayImage::ShowHideMenu()
extern void quayImage_ShowHideMenu_m6F1C2D7C82B28331419397268658BCEA769D21E8 (void);
// 0x000000A3 System.Void quayImage::.ctor()
extern void quayImage__ctor_m1918A22F261B94C2F9A394B631324CAEC154EEAB (void);
// 0x000000A4 System.Void quayOb::ShowHideMenu()
extern void quayOb_ShowHideMenu_mF399E9573304E6A972F5B037D8566133BB21B05B (void);
// 0x000000A5 System.Void quayOb::.ctor()
extern void quayOb__ctor_mFA6E9E51EE55AF3581484FF08BF5E7890D4965D1 (void);
// 0x000000A6 System.Boolean TrailsFX.TrailStyleProperties::supportsColor(TrailsFX.TrailStyle)
extern void TrailStyleProperties_supportsColor_m74C64ED9A5FF4FAB30FE7983EB4832EBBA7274D9 (void);
// 0x000000A7 System.Boolean TrailsFX.TrailEffect::get_active()
extern void TrailEffect_get_active_m43D2115A024DA2A036C428FD4AA847D108FF9576 (void);
// 0x000000A8 System.Void TrailsFX.TrailEffect::set_active(System.Boolean)
extern void TrailEffect_set_active_mBC53600CB75EC165C601BFC3626B7CED5BA56366 (void);
// 0x000000A9 System.Void TrailsFX.TrailEffect::OnEnable()
extern void TrailEffect_OnEnable_mE98FD1EB5F5F002AB3A9005EE5F04A09BB26ABB2 (void);
// 0x000000AA System.Void TrailsFX.TrailEffect::DestroyMaterial(UnityEngine.Material)
extern void TrailEffect_DestroyMaterial_mC8099DC8807AEDEE8642615D1ADA5C4DA1C9E6C7 (void);
// 0x000000AB System.Void TrailsFX.TrailEffect::OnDestroy()
extern void TrailEffect_OnDestroy_m6F0B7050334218166F8FC81A41B9DAA634800215 (void);
// 0x000000AC System.Void TrailsFX.TrailEffect::OnValidate()
extern void TrailEffect_OnValidate_m81C4CF0EBE1D2BEEA27B304646FD5D38F80FAEC2 (void);
// 0x000000AD System.Void TrailsFX.TrailEffect::Start()
extern void TrailEffect_Start_m111C99E6B44D84A596A92F45E9E6648040FB5323 (void);
// 0x000000AE System.Void TrailsFX.TrailEffect::LateUpdate()
extern void TrailEffect_LateUpdate_m4DB3B616F525A5294B2CDBCC48E2283D5F871DC2 (void);
// 0x000000AF System.Void TrailsFX.TrailEffect::OnCollisionEnter(UnityEngine.Collision)
extern void TrailEffect_OnCollisionEnter_m823C59480FEBAD55F8B5F2033AE734ABB67964D6 (void);
// 0x000000B0 System.Void TrailsFX.TrailEffect::CheckEditorSettings()
extern void TrailEffect_CheckEditorSettings_m6A8D0E9EA54773660B89C707A427AA92DBCB70A2 (void);
// 0x000000B1 System.Void TrailsFX.TrailEffect::Clear()
extern void TrailEffect_Clear_mC3F0032209A756B27ABCEA92765A13A2C091C5CB (void);
// 0x000000B2 System.Void TrailsFX.TrailEffect::UpdateMaterialProperties()
extern void TrailEffect_UpdateMaterialProperties_m2F474EC36B4CAA1BB1ACCC75C7A1B93981F4F63D (void);
// 0x000000B3 UnityEngine.Material TrailsFX.TrailEffect::GetEffectMaterial(System.String)
extern void TrailEffect_GetEffectMaterial_m51E16EB143E92887CCBD6A11D9C5A2E24CDBD7FA (void);
// 0x000000B4 UnityEngine.Mesh TrailsFX.TrailEffect::BuildQuadMesh()
extern void TrailEffect_BuildQuadMesh_m7CC3BB3C477626EF4763A3EA07324FED5B025891 (void);
// 0x000000B5 UnityEngine.Vector3 TrailsFX.TrailEffect::GetSnapshotScale()
extern void TrailEffect_GetSnapshotScale_m7B8D5E8CF29CFE38ABC0E4B75F9111539249407E (void);
// 0x000000B6 UnityEngine.Vector3 TrailsFX.TrailEffect::GetRandomizedPosition()
extern void TrailEffect_GetRandomizedPosition_m6E8CCF7614439CFA12BC51AB24214AEE66270A25 (void);
// 0x000000B7 UnityEngine.Color TrailsFX.TrailEffect::GetSnapshotColor()
extern void TrailEffect_GetSnapshotColor_mAC00415914A73CE662331C48E378C22FE7580FF8 (void);
// 0x000000B8 System.Void TrailsFX.TrailEffect::StoreCurrentPositions()
extern void TrailEffect_StoreCurrentPositions_mBE6727D1DF19CCC12C58FADFB695472E48D0039E (void);
// 0x000000B9 System.Void TrailsFX.TrailEffect::AddSnapshot()
extern void TrailEffect_AddSnapshot_mEE91DB9D36E4D49EF5C5163752904539A81F0156 (void);
// 0x000000BA System.Void TrailsFX.TrailEffect::AddSnapshot(UnityEngine.Vector3,UnityEngine.Quaternion)
extern void TrailEffect_AddSnapshot_mE0BAAE73DF4EBA8A85EE1246372CFAA6C9EFD17A (void);
// 0x000000BB System.Void TrailsFX.TrailEffect::RenderTrail()
extern void TrailEffect_RenderTrail_mF849F085C7281A473BC3584B3099FA3118E77157 (void);
// 0x000000BC System.Void TrailsFX.TrailEffect::SendToGPU(System.Int32,System.Int32,System.Int32)
extern void TrailEffect_SendToGPU_m8B47A8C5185376A0E0D8A0D3D094E8AA95F12B8E (void);
// 0x000000BD UnityEngine.Mesh TrailsFX.TrailEffect::SetupMesh()
extern void TrailEffect_SetupMesh_m9B25E5B036B49C841049C5313E350A05D7C7DC16 (void);
// 0x000000BE System.Void TrailsFX.TrailEffect::QuickSort(System.Int32,System.Int32)
extern void TrailEffect_QuickSort_mEB9022C6DA66B0F661288624E298C0401D7705E9 (void);
// 0x000000BF System.Void TrailsFX.TrailEffect::.ctor()
extern void TrailEffect__ctor_m146C6456AF05CC091935F15510FC6196ADA12575 (void);
// 0x000000C0 System.Void TrailsFX.TrailEffect::.cctor()
extern void TrailEffect__cctor_m51B15A6306C5EADA96E3897937483A8CA35EE80A (void);
// 0x000000C1 System.Void TrailsFX.TrailEffectProfile::Load(TrailsFX.TrailEffect)
extern void TrailEffectProfile_Load_m1923C8C017E9296FD265CE1698AF9B6602BFEFA2 (void);
// 0x000000C2 System.Void TrailsFX.TrailEffectProfile::Save(TrailsFX.TrailEffect)
extern void TrailEffectProfile_Save_mAA050027DEE769FE3C0920B1F740E825365613E6 (void);
// 0x000000C3 System.Void TrailsFX.TrailEffectProfile::.ctor()
extern void TrailEffectProfile__ctor_m2078430C15C9BB093D02A63DE0CF6B7DD1983CB7 (void);
// 0x000000C4 System.Void TrailsFX.Demos.MoveObject::Update()
extern void MoveObject_Update_m2DEB375B198277A6C6FFE22018DFFE9BD27BA474 (void);
// 0x000000C5 System.Void TrailsFX.Demos.MoveObject::.ctor()
extern void MoveObject__ctor_m8DBB58DC0E376E16F6CF29896EDAFA7F5EDB64FC (void);
// 0x000000C6 System.Void TrailsFX.Demos.RotateObject::Start()
extern void RotateObject_Start_m11202E3F7EFD21D8AE43E1A85C9FACF79AB02E88 (void);
// 0x000000C7 System.Void TrailsFX.Demos.RotateObject::Update()
extern void RotateObject_Update_mB2B0381F3994D60E9587DCA76F1B65E65D7D3DD2 (void);
// 0x000000C8 System.Void TrailsFX.Demos.RotateObject::SetAngles()
extern void RotateObject_SetAngles_mDC778E57D2F780F9D1E92258D4DCCD87A497AACC (void);
// 0x000000C9 System.Void TrailsFX.Demos.RotateObject::.ctor()
extern void RotateObject__ctor_m9AD1C26C2C387C3A57DD9020CD35C4EC48B5F25C (void);
// 0x000000CA System.Void TrailsFX.Demos.Shooter::Start()
extern void Shooter_Start_m449703F2EF2E040C688F96CB2E0F1E069FA13966 (void);
// 0x000000CB System.Void TrailsFX.Demos.Shooter::Update()
extern void Shooter_Update_mDEB0C852272F71C07F718BB3F9E6E19E048FD4BA (void);
// 0x000000CC System.Void TrailsFX.Demos.Shooter::NewTarget()
extern void Shooter_NewTarget_m4988EAFF66BFE8DCF060243F510EC7A7DA2F7361 (void);
// 0x000000CD System.Void TrailsFX.Demos.Shooter::Shoot()
extern void Shooter_Shoot_m45165A30E96836110D79DFC4A8552E288615FB51 (void);
// 0x000000CE System.Void TrailsFX.Demos.Shooter::.ctor()
extern void Shooter__ctor_m20C9CEB0B4E71E680793568285D229337D82F2D7 (void);
// 0x000000CF System.Void TrailsFX.Demos.quay::Start()
extern void quay_Start_m438EFEF9F20ED8BFEBDAA081DCBC9C99590F4ABC (void);
// 0x000000D0 System.Void TrailsFX.Demos.quay::Update()
extern void quay_Update_m787D3FFBE3C127921BD4E999B446EB6AABA755F6 (void);
// 0x000000D1 System.Void TrailsFX.Demos.quay::SetAngles()
extern void quay_SetAngles_mDEA4E425F24840427EEBB5553A78FF904A0FCAA4 (void);
// 0x000000D2 System.Void TrailsFX.Demos.quay::.ctor()
extern void quay__ctor_m6DB84E087354AF43F2C288AED6D9125E23D28ECA (void);
// 0x000000D3 System.Void CodeStage.AdvancedFPSCounter.APITester::Start()
extern void APITester_Start_mAB25FF60FEF44B2DA7EE42C1535059A051F698FE (void);
// 0x000000D4 System.Void CodeStage.AdvancedFPSCounter.APITester::OnFPSLevelChanged(CodeStage.AdvancedFPSCounter.FPSLevel)
extern void APITester_OnFPSLevelChanged_m851238E35C8B8D7670E300FAD89FFE521BB3BFD7 (void);
// 0x000000D5 System.Void CodeStage.AdvancedFPSCounter.APITester::OnGUI()
extern void APITester_OnGUI_m5B2FB1710DE4A96BB44729BD123D6FBFD5207165 (void);
// 0x000000D6 System.Void CodeStage.AdvancedFPSCounter.APITester::DrawCommonTab()
extern void APITester_DrawCommonTab_m64CC0E9C76F058F390CA7CDDED1AB1FFE954FA81 (void);
// 0x000000D7 System.Void CodeStage.AdvancedFPSCounter.APITester::DrawLookFeelTab()
extern void APITester_DrawLookFeelTab_m5902D4039EDD5022B73D05BB40BA7B57F0AB6196 (void);
// 0x000000D8 System.Void CodeStage.AdvancedFPSCounter.APITester::DrawFPSCounterTab()
extern void APITester_DrawFPSCounterTab_mD46A16333641FD2C06B597561E826235E04FB2C5 (void);
// 0x000000D9 System.Void CodeStage.AdvancedFPSCounter.APITester::DrawMemoryCounterTab()
extern void APITester_DrawMemoryCounterTab_m71EF1325D86A29A70C1078CEF3843F175A6143AC (void);
// 0x000000DA System.Void CodeStage.AdvancedFPSCounter.APITester::DrawDeviceInfoTab()
extern void APITester_DrawDeviceInfoTab_m3E28DA3D4FB1E1377AB986401E794F0FC5AAC3FA (void);
// 0x000000DB System.Single CodeStage.AdvancedFPSCounter.APITester::SliderLabel(System.Single,System.Single,System.Single)
extern void APITester_SliderLabel_m9C74C6CC30C44FADEEDE460B9F64FC695C0C1391 (void);
// 0x000000DC UnityEngine.Color CodeStage.AdvancedFPSCounter.APITester::ColorSliders(System.String,UnityEngine.Color)
extern void APITester_ColorSliders_m2F5CB92F1EF22953468DDD92FDD6379093778597 (void);
// 0x000000DD UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.APITester::Vector2Slider(UnityEngine.Vector2,System.String)
extern void APITester_Vector2Slider_m21A8FAE4E48EB46EC0D14DA2F9FEE953AA6751EA (void);
// 0x000000DE System.Void CodeStage.AdvancedFPSCounter.APITester::.ctor()
extern void APITester__ctor_m3D281F191D6C0262EDA5C55DF6755BB9A2B67D53 (void);
// 0x000000DF System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::get_KeepAlive()
extern void AFPSCounter_get_KeepAlive_m5A8C6CD23ED12F2A9382B59558E2EC7B65309BEC (void);
// 0x000000E0 CodeStage.AdvancedFPSCounter.OperationMode CodeStage.AdvancedFPSCounter.AFPSCounter::get_OperationMode()
extern void AFPSCounter_get_OperationMode_m4DD7F6CA23CE8BC215363539D784371CF366C9EB (void);
// 0x000000E1 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_OperationMode(CodeStage.AdvancedFPSCounter.OperationMode)
extern void AFPSCounter_set_OperationMode_m890A124B66509F2AF1464DF70171AAE846465EC0 (void);
// 0x000000E2 System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::get_ForceFrameRate()
extern void AFPSCounter_get_ForceFrameRate_m4542BF0F18A295F5E19A6091ED7F5D6C55A4E6ED (void);
// 0x000000E3 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_ForceFrameRate(System.Boolean)
extern void AFPSCounter_set_ForceFrameRate_m275BDEDF18EAA087D7C15EEFEC26AF76EE70A307 (void);
// 0x000000E4 System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::get_ForcedFrameRate()
extern void AFPSCounter_get_ForcedFrameRate_mA2F6EDAA8DDBDE34BFDA7DC22B65CBC6861D9802 (void);
// 0x000000E5 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_ForcedFrameRate(System.Int32)
extern void AFPSCounter_set_ForcedFrameRate_mC12E6CDF83E19908176079CF0961B208E909C12E (void);
// 0x000000E6 System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::get_Background()
extern void AFPSCounter_get_Background_m83FADE568C99A13383B584021364711FB144F37F (void);
// 0x000000E7 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_Background(System.Boolean)
extern void AFPSCounter_set_Background_m04A6B707AD8F4CE004BE9182190BC37BF95CA263 (void);
// 0x000000E8 UnityEngine.Color CodeStage.AdvancedFPSCounter.AFPSCounter::get_BackgroundColor()
extern void AFPSCounter_get_BackgroundColor_m7FDA699DC12AE7C2D619457EAE1CABC18ADB03B0 (void);
// 0x000000E9 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_BackgroundColor(UnityEngine.Color)
extern void AFPSCounter_set_BackgroundColor_mC4B10F36F79A5C17602ED5EECA85B48393627605 (void);
// 0x000000EA System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::get_BackgroundPadding()
extern void AFPSCounter_get_BackgroundPadding_mFCC91C5DB5D07256A122B9D62CD3F396385479F0 (void);
// 0x000000EB System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_BackgroundPadding(System.Int32)
extern void AFPSCounter_set_BackgroundPadding_mA6FE0BA934CFB433ED03FF0A974B27418B287FE8 (void);
// 0x000000EC System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::get_Shadow()
extern void AFPSCounter_get_Shadow_mAF551B893EE03C0BF963F20D8224E15DEBBE1DF1 (void);
// 0x000000ED System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_Shadow(System.Boolean)
extern void AFPSCounter_set_Shadow_m05CAB4367EFAD74F5DCC0A0DF75ABB10F249EEB1 (void);
// 0x000000EE UnityEngine.Color CodeStage.AdvancedFPSCounter.AFPSCounter::get_ShadowColor()
extern void AFPSCounter_get_ShadowColor_mCF2DE635A0F431BDA818F86147AB18A4CC07C2AB (void);
// 0x000000EF System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_ShadowColor(UnityEngine.Color)
extern void AFPSCounter_set_ShadowColor_mEA0F297E58FD1DB32E94E5439E2B68590B1D02A9 (void);
// 0x000000F0 UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.AFPSCounter::get_ShadowDistance()
extern void AFPSCounter_get_ShadowDistance_m63238D38AB7A477F3640BFC8D536AC1761CED800 (void);
// 0x000000F1 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_ShadowDistance(UnityEngine.Vector2)
extern void AFPSCounter_set_ShadowDistance_m952714D486CF9469A7A26593E72B845B81913160 (void);
// 0x000000F2 System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::get_Outline()
extern void AFPSCounter_get_Outline_m61E32DDD03826D1ECD02EBC7BD765F88A0F6CB92 (void);
// 0x000000F3 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_Outline(System.Boolean)
extern void AFPSCounter_set_Outline_mCEDCA93957857EE392E8CAF9F35A15B1997D3903 (void);
// 0x000000F4 UnityEngine.Color CodeStage.AdvancedFPSCounter.AFPSCounter::get_OutlineColor()
extern void AFPSCounter_get_OutlineColor_mCC2022E391E67513F2FA9EE419752DC600744B3F (void);
// 0x000000F5 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_OutlineColor(UnityEngine.Color)
extern void AFPSCounter_set_OutlineColor_mCEBB14D3347629591E58403B7D5E1AEFB01C3CE0 (void);
// 0x000000F6 UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.AFPSCounter::get_OutlineDistance()
extern void AFPSCounter_get_OutlineDistance_m8D48D954B84C96DCB6D61E3F999C276E950682EE (void);
// 0x000000F7 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_OutlineDistance(UnityEngine.Vector2)
extern void AFPSCounter_set_OutlineDistance_m6274A354C99030B493924C6188B9017DEA9DE81C (void);
// 0x000000F8 System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::get_AutoScale()
extern void AFPSCounter_get_AutoScale_m47BAFE805420D18B95C3E2E92E11BB9BA1D113DD (void);
// 0x000000F9 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_AutoScale(System.Boolean)
extern void AFPSCounter_set_AutoScale_m734A44DE54640562E4051AA7EC9080B03BC1BA93 (void);
// 0x000000FA System.Single CodeStage.AdvancedFPSCounter.AFPSCounter::get_ScaleFactor()
extern void AFPSCounter_get_ScaleFactor_m4FE3403E95E66BD2CE6650DC4F8933BE162387E8 (void);
// 0x000000FB System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_ScaleFactor(System.Single)
extern void AFPSCounter_set_ScaleFactor_m775F1679ECEFC295A816B3DDB841931428D9FD4F (void);
// 0x000000FC UnityEngine.Font CodeStage.AdvancedFPSCounter.AFPSCounter::get_LabelsFont()
extern void AFPSCounter_get_LabelsFont_mB787B64AB5C89818FDC2FDE7BB44630EF4BF9DCC (void);
// 0x000000FD System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_LabelsFont(UnityEngine.Font)
extern void AFPSCounter_set_LabelsFont_m5D7E5E3E54C815180B85CC8BBD0514DF1FE9CD38 (void);
// 0x000000FE System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::get_FontSize()
extern void AFPSCounter_get_FontSize_m40ABC3E716B629A4FD1888A2307C6429663072C5 (void);
// 0x000000FF System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_FontSize(System.Int32)
extern void AFPSCounter_set_FontSize_m57F5736592B01C0BA34934C60BEEBDF34657D15C (void);
// 0x00000100 System.Single CodeStage.AdvancedFPSCounter.AFPSCounter::get_LineSpacing()
extern void AFPSCounter_get_LineSpacing_m72F025A02AB338FD925BBD79C5F29BCA652F1D9A (void);
// 0x00000101 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_LineSpacing(System.Single)
extern void AFPSCounter_set_LineSpacing_m9F14E09ACBB4B9AC54A24536F0215C64CDC5469B (void);
// 0x00000102 System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::get_CountersSpacing()
extern void AFPSCounter_get_CountersSpacing_m085DA79359030BAAB59FC2715727500860AD62B8 (void);
// 0x00000103 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_CountersSpacing(System.Int32)
extern void AFPSCounter_set_CountersSpacing_mEB585A80541A8C0F294D62171727FBAA0690CA91 (void);
// 0x00000104 UnityEngine.Vector2 CodeStage.AdvancedFPSCounter.AFPSCounter::get_PaddingOffset()
extern void AFPSCounter_get_PaddingOffset_mE21673488D8F487490821F26265A403BE157ABC6 (void);
// 0x00000105 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_PaddingOffset(UnityEngine.Vector2)
extern void AFPSCounter_set_PaddingOffset_m08A97FFA6F202AA33041B53A5E83B37D74C0C3C0 (void);
// 0x00000106 System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::get_PixelPerfect()
extern void AFPSCounter_get_PixelPerfect_m7208225279AE5E0CE976C9C61F5B50182F685BE3 (void);
// 0x00000107 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_PixelPerfect(System.Boolean)
extern void AFPSCounter_set_PixelPerfect_mDCACB07A6377D3D31F523943C8B63F6FA5FB47AB (void);
// 0x00000108 System.Int32 CodeStage.AdvancedFPSCounter.AFPSCounter::get_SortingOrder()
extern void AFPSCounter_get_SortingOrder_mD850F1156B9149E9863038E8842A30BBDB432999 (void);
// 0x00000109 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_SortingOrder(System.Int32)
extern void AFPSCounter_set_SortingOrder_mA58F1653A581002AE7312252068E53CD1FE92786 (void);
// 0x0000010A System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::.ctor()
extern void AFPSCounter__ctor_m832FB20EA8D3D0CD4723CD75CF4AED5A915CDE69 (void);
// 0x0000010B CodeStage.AdvancedFPSCounter.AFPSCounter CodeStage.AdvancedFPSCounter.AFPSCounter::get_Instance()
extern void AFPSCounter_get_Instance_m25999F071293B98B6A6055B992D5852C253B6551 (void);
// 0x0000010C System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::set_Instance(CodeStage.AdvancedFPSCounter.AFPSCounter)
extern void AFPSCounter_set_Instance_m5E73D5651F3B2538533D9527BA89DF389ADE606F (void);
// 0x0000010D CodeStage.AdvancedFPSCounter.AFPSCounter CodeStage.AdvancedFPSCounter.AFPSCounter::GetOrCreateInstance(System.Boolean)
extern void AFPSCounter_GetOrCreateInstance_mE4CA579C7C1383F114A2AD83438B559E5292C023 (void);
// 0x0000010E CodeStage.AdvancedFPSCounter.AFPSCounter CodeStage.AdvancedFPSCounter.AFPSCounter::AddToScene()
extern void AFPSCounter_AddToScene_mCBA906A87E07E059B5BF2E290A54B80A415A2ED9 (void);
// 0x0000010F CodeStage.AdvancedFPSCounter.AFPSCounter CodeStage.AdvancedFPSCounter.AFPSCounter::AddToScene(System.Boolean)
extern void AFPSCounter_AddToScene_m5C85E859666E6D84ED6605AC60A88F0EF6DD1A1C (void);
// 0x00000110 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::Dispose()
extern void AFPSCounter_Dispose_m6B61A94CD658A57F8692DCE97E257243672F01EE (void);
// 0x00000111 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::SelfDestroy()
extern void AFPSCounter_SelfDestroy_mB55351A9D20DE980ABA05BF3C9C5C75F4E5287FD (void);
// 0x00000112 System.String CodeStage.AdvancedFPSCounter.AFPSCounter::Color32ToHex(UnityEngine.Color32)
extern void AFPSCounter_Color32ToHex_m391758187A4FAAAC7BAEB809234D72579BE52995 (void);
// 0x00000113 CodeStage.AdvancedFPSCounter.AFPSCounter CodeStage.AdvancedFPSCounter.AFPSCounter::CreateInScene(System.Boolean)
extern void AFPSCounter_CreateInScene_m65F42CBF2499AAA4CAD0F181996248B1CB9E914E (void);
// 0x00000114 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::Awake()
extern void AFPSCounter_Awake_m8B83738138B66339AF9E65646C94D13753D2DDDB (void);
// 0x00000115 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::Start()
extern void AFPSCounter_Start_m7EDDBD16A86E236A217488D86F052AA796FD99D5 (void);
// 0x00000116 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::Update()
extern void AFPSCounter_Update_m6729648743EB953A01A9160CC03ED1837327C57E (void);
// 0x00000117 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::OnLevelWasLoadedNew(UnityEngine.SceneManagement.Scene,UnityEngine.SceneManagement.LoadSceneMode)
extern void AFPSCounter_OnLevelWasLoadedNew_m7FA557326BC065F0FAE5F83E62147CF561FF09F9 (void);
// 0x00000118 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::OnLevelLoadedCallback()
extern void AFPSCounter_OnLevelLoadedCallback_mEA70846C38CAD3C3B8988C2F1946B8D902B64059 (void);
// 0x00000119 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::OnEnable()
extern void AFPSCounter_OnEnable_m4C614B23FEAB650C6A0D9733A7FD094A5A4740A0 (void);
// 0x0000011A System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::OnDisable()
extern void AFPSCounter_OnDisable_m440B23337FFD0E14E1B0B25CB6DADFC93A0BBB2F (void);
// 0x0000011B System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::OnDestroy()
extern void AFPSCounter_OnDestroy_mD51B182BA2F66F4F9A21B4EF7D025D3C436C74F1 (void);
// 0x0000011C System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::MakeDrawableLabelDirty(CodeStage.AdvancedFPSCounter.Labels.LabelAnchor)
extern void AFPSCounter_MakeDrawableLabelDirty_mC69A00CD17F827610B99B5B56FA4599F705C7235 (void);
// 0x0000011D System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::UpdateTexts()
extern void AFPSCounter_UpdateTexts_m4615BA3CEFD143BDC5FF31AB6EF3BE29DDD83608 (void);
// 0x0000011E System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::ConfigureCanvas()
extern void AFPSCounter_ConfigureCanvas_mE2929F4CD52CAFE8FC5E12DB0FE67FD0452A4CFE (void);
// 0x0000011F System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::ConfigureLabels()
extern void AFPSCounter_ConfigureLabels_mDD8AD5D440A2DF19A672BBD559AE13623428CBCD (void);
// 0x00000120 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::DisposeInternal()
extern void AFPSCounter_DisposeInternal_mB6143DFC1BF978EEB9CF738B8787974BE18E943E (void);
// 0x00000121 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::ProcessHotKey()
extern void AFPSCounter_ProcessHotKey_mABE7B7E1E3A967A09210459D446BA23D58118C7F (void);
// 0x00000122 System.Boolean CodeStage.AdvancedFPSCounter.AFPSCounter::CircleGestureMade()
extern void AFPSCounter_CircleGestureMade_mFB0A43EFE4838B85AF9AC14E08392148B11F256D (void);
// 0x00000123 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::SwitchCounter()
extern void AFPSCounter_SwitchCounter_m4D397CDB57146D6C4F88FFE6161F37D448C56DB1 (void);
// 0x00000124 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::ActivateCounters()
extern void AFPSCounter_ActivateCounters_m34DA74D2EEFE0FBC707E0C0B533AA8647015C443 (void);
// 0x00000125 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::DeactivateCounters()
extern void AFPSCounter_DeactivateCounters_m4888302BB0CA2A7A9D24C9E83C03488B9E053C12 (void);
// 0x00000126 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::RefreshForcedFrameRate()
extern void AFPSCounter_RefreshForcedFrameRate_mE0DCC065A416B13A5EEC6C41B34687E8E05BD5DB (void);
// 0x00000127 System.Void CodeStage.AdvancedFPSCounter.AFPSCounter::RefreshForcedFrameRate(System.Boolean)
extern void AFPSCounter_RefreshForcedFrameRate_m48DEF4BDA5E42768AC6F19160C217B4E9F04C6ED (void);
// 0x00000128 System.Void CodeStage.AdvancedFPSCounter.Utils.AFPSRenderRecorder::OnPreCull()
extern void AFPSRenderRecorder_OnPreCull_m03B0C133CD6E408E925AE8E0A8B2ED53E3444B9F (void);
// 0x00000129 System.Void CodeStage.AdvancedFPSCounter.Utils.AFPSRenderRecorder::OnPostRender()
extern void AFPSRenderRecorder_OnPostRender_m7F026054A791EA575A094DFCD71004C9BAD5B447 (void);
// 0x0000012A System.Void CodeStage.AdvancedFPSCounter.Utils.AFPSRenderRecorder::.ctor()
extern void AFPSRenderRecorder__ctor_m01D1679EB490DDFB5887AE93BDFEF5733F8849A8 (void);
// 0x0000012B System.String CodeStage.AdvancedFPSCounter.Utils.CachedNumbers::ToStringLookup(System.Int64,System.Boolean)
extern void CachedNumbers_ToStringLookup_m874AA28CC1DD3591D02E9385A9054D2614503C9C (void);
// 0x0000012C System.Text.StringBuilder CodeStage.AdvancedFPSCounter.Utils.CachedNumbers::AppendLookup(System.Text.StringBuilder,System.Int32)
extern void CachedNumbers_AppendLookup_m1C8C702F5F0F594F2F1F9CE3960CE39F53FD2DB7 (void);
// 0x0000012D System.Text.StringBuilder CodeStage.AdvancedFPSCounter.Utils.CachedNumbers::AppendLookup(System.Text.StringBuilder,System.Int64)
extern void CachedNumbers_AppendLookup_mA043ADCA836B25E9ECAFC6CCD727B8D4BC5C0FFC (void);
// 0x0000012E System.Text.StringBuilder CodeStage.AdvancedFPSCounter.Utils.CachedNumbers::AppendLookup(System.Text.StringBuilder,System.Single)
extern void CachedNumbers_AppendLookup_mFBA88774EE7882CA127F7785EF4B727339E6DF76 (void);
// 0x0000012F System.Void CodeStage.AdvancedFPSCounter.Utils.CachedNumbers::.cctor()
extern void CachedNumbers__cctor_m6E3D14BF3D05AD44A79D541028993308D6FFDBC3 (void);
// 0x00000130 System.Void CodeStage.AdvancedFPSCounter.Utils.UIUtils::ResetRectTransform(UnityEngine.RectTransform)
extern void UIUtils_ResetRectTransform_m81621830AA325D07663D772F955D5EBC7B8CC28A (void);
// 0x00000131 System.Void CodeStage.AdvancedFPSCounter.Utils.UIUtils::.ctor()
extern void UIUtils__ctor_mDDEF4C8AF620EBD49498C504DC0A37DECDA980A6 (void);
// 0x00000132 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::.ctor(UnityEngine.GameObject,CodeStage.AdvancedFPSCounter.Labels.LabelAnchor,CodeStage.AdvancedFPSCounter.Labels.LabelEffect,CodeStage.AdvancedFPSCounter.Labels.LabelEffect,CodeStage.AdvancedFPSCounter.Labels.LabelEffect,UnityEngine.Font,System.Int32,System.Single,UnityEngine.Vector2)
extern void DrawableLabel__ctor_mC66608C93362955855FC69EC80EC1AED3487BA60 (void);
// 0x00000133 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::CheckAndUpdate()
extern void DrawableLabel_CheckAndUpdate_mF4B40592B517A250EAD810FD1C1673FDAE8E2142 (void);
// 0x00000134 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::Clear()
extern void DrawableLabel_Clear_m360F53B1609E9825D820AE05ED9B89AA530C9C68 (void);
// 0x00000135 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::Destroy()
extern void DrawableLabel_Destroy_m2D5E8B65616392BBB3C1DBD084EABCE896F942E1 (void);
// 0x00000136 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeFont(UnityEngine.Font)
extern void DrawableLabel_ChangeFont_mCBED015B24BFB01B03F823549586C761A5083471 (void);
// 0x00000137 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeFontSize(System.Int32)
extern void DrawableLabel_ChangeFontSize_m0CF54CA5E31D52A2802FFFDD740AAA30984DF230 (void);
// 0x00000138 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeOffset(UnityEngine.Vector2)
extern void DrawableLabel_ChangeOffset_mF42912E6A9469DFEAABD0A1967F63EBD8C411918 (void);
// 0x00000139 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeLineSpacing(System.Single)
extern void DrawableLabel_ChangeLineSpacing_m0BE1F2B15B4F7BA66C9E41D2D12E3AA4ECED6099 (void);
// 0x0000013A System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeBackground(System.Boolean)
extern void DrawableLabel_ChangeBackground_m63C79858DFE39DA1E62A912651D52A212BA62FD4 (void);
// 0x0000013B System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeBackgroundColor(UnityEngine.Color)
extern void DrawableLabel_ChangeBackgroundColor_m95DAE299E3FD5942EFA3CEE3D5ED27C260D9A6D2 (void);
// 0x0000013C System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeBackgroundPadding(System.Int32)
extern void DrawableLabel_ChangeBackgroundPadding_m241A7EB8875B7A4553E23DD905997CB688DDC748 (void);
// 0x0000013D System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeShadow(System.Boolean)
extern void DrawableLabel_ChangeShadow_m7A19B3947C222198595F441B8C3672D82013E097 (void);
// 0x0000013E System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeShadowColor(UnityEngine.Color)
extern void DrawableLabel_ChangeShadowColor_mB330A41DF2C0A45E2B75CE17D3A170C5B9A5D1D6 (void);
// 0x0000013F System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeShadowDistance(UnityEngine.Vector2)
extern void DrawableLabel_ChangeShadowDistance_m511217DB8EE48403E7C9B27158A33D4D8CFA2750 (void);
// 0x00000140 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeOutline(System.Boolean)
extern void DrawableLabel_ChangeOutline_mF919EBBD492F7B6733D98C23A17AAB8EEB45AE82 (void);
// 0x00000141 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeOutlineColor(UnityEngine.Color)
extern void DrawableLabel_ChangeOutlineColor_m6A4C83343BA13F0C03AC4AC51733D8671F683113 (void);
// 0x00000142 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ChangeOutlineDistance(UnityEngine.Vector2)
extern void DrawableLabel_ChangeOutlineDistance_mB0987F8A4DD711866C2A84197D019D5A4F71A6F6 (void);
// 0x00000143 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::UpdateTextPosition()
extern void DrawableLabel_UpdateTextPosition_m6379D1D7EEAAD01CF1D80BC1A9C828A5301F133E (void);
// 0x00000144 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::NormalizeOffset()
extern void DrawableLabel_NormalizeOffset_mE2C143FB22CE2F820F005EA645DF6063DC25F7D7 (void);
// 0x00000145 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ApplyBackground()
extern void DrawableLabel_ApplyBackground_m1F1B5108D0C945FE1D20D35093FBFC0293736E2F (void);
// 0x00000146 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ApplyShadow()
extern void DrawableLabel_ApplyShadow_m69219D73BF1AB8C35603DE4FC7EDC2310B228305 (void);
// 0x00000147 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ApplyOutline()
extern void DrawableLabel_ApplyOutline_m8C2A0757FB05A4434C22EBAE6C3902DF2EAF352E (void);
// 0x00000148 System.Void CodeStage.AdvancedFPSCounter.Labels.DrawableLabel::ApplyFont()
extern void DrawableLabel_ApplyFont_m8BD23047628EAA99F876F793AEB0111B8CE72322 (void);
// 0x00000149 System.Void CodeStage.AdvancedFPSCounter.Labels.LabelEffect::.ctor(System.Boolean,UnityEngine.Color,System.Int32)
extern void LabelEffect__ctor_mBF98A97961C4ECC28EE4CCC4A3A58D1D835EA655 (void);
// 0x0000014A System.Void CodeStage.AdvancedFPSCounter.Labels.LabelEffect::.ctor(System.Boolean,UnityEngine.Color,UnityEngine.Vector2)
extern void LabelEffect__ctor_mDC574AF0661D68903C2B65A175ABF2FB41EB172D (void);
// 0x0000014B System.Boolean CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::get_Enabled()
extern void BaseCounterData_get_Enabled_mCE6C02FC29A3507F2839AD864C36AA9991ECCA69 (void);
// 0x0000014C System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::set_Enabled(System.Boolean)
extern void BaseCounterData_set_Enabled_m6D84859FD1F2AF8C008D46DA424BB95B9C2F0F2E (void);
// 0x0000014D CodeStage.AdvancedFPSCounter.Labels.LabelAnchor CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::get_Anchor()
extern void BaseCounterData_get_Anchor_mB730844CD84018967D155DF8794DAA03398A7DBE (void);
// 0x0000014E System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::set_Anchor(CodeStage.AdvancedFPSCounter.Labels.LabelAnchor)
extern void BaseCounterData_set_Anchor_m3D38369B40499AB0D8093E90ED8BC161F4262B6A (void);
// 0x0000014F UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::get_Color()
extern void BaseCounterData_get_Color_mE2CD8365ECCA3147BFA085A9146E78FEC7EFC490 (void);
// 0x00000150 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::set_Color(UnityEngine.Color)
extern void BaseCounterData_set_Color_mA481BCCA8DC98A8893BCBA537B22F582F8FF8397 (void);
// 0x00000151 UnityEngine.FontStyle CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::get_Style()
extern void BaseCounterData_get_Style_m9800563C6D72D152D5326D0DB409B7FF58F1387E (void);
// 0x00000152 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::set_Style(UnityEngine.FontStyle)
extern void BaseCounterData_set_Style_mBF96D3D5FBF979E1D9C1324243A7A61A3D55CD7F (void);
// 0x00000153 System.String CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::get_ExtraText()
extern void BaseCounterData_get_ExtraText_m5055EB58C09C71B843BB316EF29EDB13209AD729 (void);
// 0x00000154 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::set_ExtraText(System.String)
extern void BaseCounterData_set_ExtraText_m263FBB6F9804DE07D8D11906A5A20C91CD1598A9 (void);
// 0x00000155 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::Refresh()
extern void BaseCounterData_Refresh_mDDB172CCBE6C5AFC37174F42949269490D64DBC1 (void);
// 0x00000156 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::UpdateValue()
extern void BaseCounterData_UpdateValue_mDDB4304D4492A2A46EB0F28C4A98C19C8911B80D (void);
// 0x00000157 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::UpdateValue(System.Boolean)
// 0x00000158 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::Init(CodeStage.AdvancedFPSCounter.AFPSCounter)
extern void BaseCounterData_Init_m82E1579FBC12C981C261E11F933FD5FBF1124FF8 (void);
// 0x00000159 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::Destroy()
extern void BaseCounterData_Destroy_mC5AB0741DE461BFE2527B1CD0F3F84840EF07EF3 (void);
// 0x0000015A System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::Activate()
extern void BaseCounterData_Activate_m2BE9D4570B7AC1AC094C3A6A52AD8994293693FB (void);
// 0x0000015B System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::Deactivate()
extern void BaseCounterData_Deactivate_m83B94FF102C5C14FAC6A9F7BFAD591F6FCA5287C (void);
// 0x0000015C System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::PerformInitActions()
extern void BaseCounterData_PerformInitActions_mCD8A7F827CEC0C6685B2FFE6650D7425FB5DBD1B (void);
// 0x0000015D System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::PerformActivationActions()
extern void BaseCounterData_PerformActivationActions_m9CECE1A10E5C447DC598C396DFAD3D56C246FD6E (void);
// 0x0000015E System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::PerformDeActivationActions()
extern void BaseCounterData_PerformDeActivationActions_m809C1825166442678A76676A9A772B670AA4D46B (void);
// 0x0000015F System.Boolean CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::HasData()
// 0x00000160 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::CacheCurrentColor()
// 0x00000161 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::ApplyTextStyles()
extern void BaseCounterData_ApplyTextStyles_m04893D5C643278E072C504D233087579886193AD (void);
// 0x00000162 System.Void CodeStage.AdvancedFPSCounter.CountersData.BaseCounterData::.ctor()
extern void BaseCounterData__ctor_mBEA3D85FDCE56703BE080CFDAA24F1EFE12453D9 (void);
// 0x00000163 System.Single CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::get_UpdateInterval()
extern void UpdatableCounterData_get_UpdateInterval_m3AB6F672A9D8D05F76C087AFC6E9FE1631789CC9 (void);
// 0x00000164 System.Void CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::set_UpdateInterval(System.Single)
extern void UpdatableCounterData_set_UpdateInterval_mE32E14C27DE8A2BB4351A18646BC861407D93FE9 (void);
// 0x00000165 System.Void CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::PerformInitActions()
extern void UpdatableCounterData_PerformInitActions_m70FCF767225CC9E58836EF3F4BA1C6AADA01BF52 (void);
// 0x00000166 System.Void CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::PerformDeActivationActions()
extern void UpdatableCounterData_PerformDeActivationActions_mFF02982D491975F13158E984531C1999FBA87F98 (void);
// 0x00000167 System.Collections.IEnumerator CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::UpdateCounter()
// 0x00000168 System.Void CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::StartUpdateCoroutine()
extern void UpdatableCounterData_StartUpdateCoroutine_m7E62E6A62EA83BE8B224C7698CEC967B52A98C32 (void);
// 0x00000169 System.Void CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::StopUpdateCoroutine()
extern void UpdatableCounterData_StopUpdateCoroutine_m4CF0359A3756076100ACB53490FE44A9EFC24773 (void);
// 0x0000016A System.Void CodeStage.AdvancedFPSCounter.CountersData.UpdatableCounterData::.ctor()
extern void UpdatableCounterData__ctor_m1394C5615BB26CF154D97CBEF1C2449F78981E45 (void);
// 0x0000016B System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_Platform()
extern void DeviceInfoCounterData_get_Platform_m017CBA4A4CDD3F2AB1B19308A8D8C3032B7BD0DA (void);
// 0x0000016C System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_Platform(System.Boolean)
extern void DeviceInfoCounterData_set_Platform_mE6B0157BBB34019A640B32F15D43B7A2B006B782 (void);
// 0x0000016D System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_CpuModel()
extern void DeviceInfoCounterData_get_CpuModel_m40BF570350E6CFBA26CFD1CCF87558F56A6A686F (void);
// 0x0000016E System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_CpuModel(System.Boolean)
extern void DeviceInfoCounterData_set_CpuModel_m57EA85426464112F41BD9D6C1E14AD48D5E470CC (void);
// 0x0000016F System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_CpuModelNewLine()
extern void DeviceInfoCounterData_get_CpuModelNewLine_m361667B089B4CE2D4D9111F6F4C014C39CBBDD12 (void);
// 0x00000170 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_CpuModelNewLine(System.Boolean)
extern void DeviceInfoCounterData_set_CpuModelNewLine_m3F4C700B3CC84B3882A47654C78CD671EE264EE3 (void);
// 0x00000171 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_GpuModel()
extern void DeviceInfoCounterData_get_GpuModel_mB1660E43B3FBCDBFEFD60F98D92E174D6C68B3C3 (void);
// 0x00000172 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_GpuModel(System.Boolean)
extern void DeviceInfoCounterData_set_GpuModel_m078F9CF2CA5AE54D0A9515C627B03ACD7C60C498 (void);
// 0x00000173 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_GpuModelNewLine()
extern void DeviceInfoCounterData_get_GpuModelNewLine_m8FEB82B89B09F8B7C5E47FBE7CE14057A06012BC (void);
// 0x00000174 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_GpuModelNewLine(System.Boolean)
extern void DeviceInfoCounterData_set_GpuModelNewLine_m0D20B993AB7577C236BC7F48924DB5F5DAA361CB (void);
// 0x00000175 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_GpuApi()
extern void DeviceInfoCounterData_get_GpuApi_m9593D818F6FE663FF715198FCE303950368C6278 (void);
// 0x00000176 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_GpuApi(System.Boolean)
extern void DeviceInfoCounterData_set_GpuApi_m144D34998071A4203843256C61FE5F3C520897EB (void);
// 0x00000177 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_GpuApiNewLine()
extern void DeviceInfoCounterData_get_GpuApiNewLine_m1B059735FDFFC72F6306EC0C6D2475F361984746 (void);
// 0x00000178 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_GpuApiNewLine(System.Boolean)
extern void DeviceInfoCounterData_set_GpuApiNewLine_m880703910389A22D97DC64D147D7DAA3956C4AEA (void);
// 0x00000179 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_GpuSpec()
extern void DeviceInfoCounterData_get_GpuSpec_m5F396C83B7812E6F72AC7C1ECB32EB5E0FB0B91A (void);
// 0x0000017A System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_GpuSpec(System.Boolean)
extern void DeviceInfoCounterData_set_GpuSpec_m6B57C03B8F4F91220198DFD0DF4C55F8D9CD4C1D (void);
// 0x0000017B System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_GpuSpecNewLine()
extern void DeviceInfoCounterData_get_GpuSpecNewLine_m0AB0E2DC1A7699DB9083F2F0165104B8DC67A708 (void);
// 0x0000017C System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_GpuSpecNewLine(System.Boolean)
extern void DeviceInfoCounterData_set_GpuSpecNewLine_mA89F2052A26454F34D68551B3F721CD108B235C3 (void);
// 0x0000017D System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_RamSize()
extern void DeviceInfoCounterData_get_RamSize_m1967659DD4488E9600B8AAF4FC3D1160F86E22C6 (void);
// 0x0000017E System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_RamSize(System.Boolean)
extern void DeviceInfoCounterData_set_RamSize_m28111203323B34DC25C1BAF3DA8E0587CB5E0F6F (void);
// 0x0000017F System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_RamSizeNewLine()
extern void DeviceInfoCounterData_get_RamSizeNewLine_mE867B4DC7810DC9FF4CAD8C63601895450BA57B8 (void);
// 0x00000180 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_RamSizeNewLine(System.Boolean)
extern void DeviceInfoCounterData_set_RamSizeNewLine_m8CECF583D17AE9844BA0B6C9C241EB56BF3DD31C (void);
// 0x00000181 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_ScreenData()
extern void DeviceInfoCounterData_get_ScreenData_m4FF126F032515B276FABF43B0FEAB5B9542172DC (void);
// 0x00000182 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_ScreenData(System.Boolean)
extern void DeviceInfoCounterData_set_ScreenData_m2740BDE8E7C27D0EDB1A8EA9BE14726677A8AC6F (void);
// 0x00000183 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_ScreenDataNewLine()
extern void DeviceInfoCounterData_get_ScreenDataNewLine_m7AD3CDCE799D9B0A28C2A1C7CE3C4B6E06B0BBD4 (void);
// 0x00000184 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_ScreenDataNewLine(System.Boolean)
extern void DeviceInfoCounterData_set_ScreenDataNewLine_m47C1FCFBA96815638B75B7F02DD2537D68E84DFB (void);
// 0x00000185 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_DeviceModel()
extern void DeviceInfoCounterData_get_DeviceModel_mFD9DF4B197209E31648E225EFA5975721C4008B0 (void);
// 0x00000186 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_DeviceModel(System.Boolean)
extern void DeviceInfoCounterData_set_DeviceModel_mFFA202BA5C922E18B6C0A2ECAB43F2C15D3EF423 (void);
// 0x00000187 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_DeviceModelNewLine()
extern void DeviceInfoCounterData_get_DeviceModelNewLine_mEAA79D861DE8B26CE8D2E0A8C19380C9117ECCDC (void);
// 0x00000188 System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_DeviceModelNewLine(System.Boolean)
extern void DeviceInfoCounterData_set_DeviceModelNewLine_m3EEEF2F64B02B4C8E978F523552F4C9093434CFE (void);
// 0x00000189 System.String CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::get_LastValue()
extern void DeviceInfoCounterData_get_LastValue_mBF5DB5DE6A8F8A58C45F8AE7DBAA172D0ED93F84 (void);
// 0x0000018A System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::set_LastValue(System.String)
extern void DeviceInfoCounterData_set_LastValue_m461D44BE044B7BE8B6A4E6748D6B27898547723D (void);
// 0x0000018B System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::.ctor()
extern void DeviceInfoCounterData__ctor_mD412BAA57075C3C09CD1B44750C3BDE1481F15A8 (void);
// 0x0000018C System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::UpdateValue(System.Boolean)
extern void DeviceInfoCounterData_UpdateValue_m841067C9DB4FB83F876E0412CDEE12A07B9DDAF7 (void);
// 0x0000018D System.Boolean CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::HasData()
extern void DeviceInfoCounterData_HasData_m1B73320008BDFB065C20B16E51C0FD39CD62FC03 (void);
// 0x0000018E System.Void CodeStage.AdvancedFPSCounter.CountersData.DeviceInfoCounterData::CacheCurrentColor()
extern void DeviceInfoCounterData_CacheCurrentColor_m557BF2F061736F269943BDB6D885BDB6C085332C (void);
// 0x0000018F System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::add_OnFPSLevelChange(System.Action`1<CodeStage.AdvancedFPSCounter.FPSLevel>)
extern void FPSCounterData_add_OnFPSLevelChange_m7585CDC194A6928D8DBCDF971A593C92737C648E (void);
// 0x00000190 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::remove_OnFPSLevelChange(System.Action`1<CodeStage.AdvancedFPSCounter.FPSLevel>)
extern void FPSCounterData_remove_OnFPSLevelChange_mD231157491CAE742FEC17BE3BB52B399715B29BD (void);
// 0x00000191 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_RealtimeFPS()
extern void FPSCounterData_get_RealtimeFPS_mBD46DCC15D876C8ADFC8FD8B60E6EB5176ED124A (void);
// 0x00000192 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_RealtimeFPS(System.Boolean)
extern void FPSCounterData_set_RealtimeFPS_mB6CFC7BF7E78C1F96F0500DB4269F80097DB5A15 (void);
// 0x00000193 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_Milliseconds()
extern void FPSCounterData_get_Milliseconds_mAED803B889B76DCFF34BBED0471D2626E0E7F10F (void);
// 0x00000194 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_Milliseconds(System.Boolean)
extern void FPSCounterData_set_Milliseconds_m412AC8AA6634941AFDBD572F6EB5C5B52832104F (void);
// 0x00000195 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_Average()
extern void FPSCounterData_get_Average_m201622A0C48860DF263EE87A220969FA0249AEA7 (void);
// 0x00000196 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_Average(System.Boolean)
extern void FPSCounterData_set_Average_mF727E43B57274692A2344F6E674500793B7D1859 (void);
// 0x00000197 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_AverageMilliseconds()
extern void FPSCounterData_get_AverageMilliseconds_m32B0AFAD501769417AC80D3816420DCBB07B985A (void);
// 0x00000198 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_AverageMilliseconds(System.Boolean)
extern void FPSCounterData_set_AverageMilliseconds_mD11099D5DCE3BD9F0A37507752E8FB54849047AD (void);
// 0x00000199 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_AverageNewLine()
extern void FPSCounterData_get_AverageNewLine_m93A7ECB57DD0E9E8BB1B1CAE0C26381C716903FA (void);
// 0x0000019A System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_AverageNewLine(System.Boolean)
extern void FPSCounterData_set_AverageNewLine_m579FA5E435BDB5AFA57D1097238A6160E2D2AD72 (void);
// 0x0000019B System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_AverageSamples()
extern void FPSCounterData_get_AverageSamples_m4C85A2EB0DD5041BD9114D7172FE13CD9FA44EFB (void);
// 0x0000019C System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_AverageSamples(System.Int32)
extern void FPSCounterData_set_AverageSamples_mB5F36EC428D73DDDA965C10BDA0D731EF09AD2C7 (void);
// 0x0000019D System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_MinMax()
extern void FPSCounterData_get_MinMax_m6F3B4FA06836A9776B90FCCF13B5D64F3C330D04 (void);
// 0x0000019E System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_MinMax(System.Boolean)
extern void FPSCounterData_set_MinMax_mE490075353D00A92C90C123EABFE1164C3E3A45A (void);
// 0x0000019F System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_MinMaxMilliseconds()
extern void FPSCounterData_get_MinMaxMilliseconds_m915F44EC51D1DCA63DA4984CBFD6905270AC10D1 (void);
// 0x000001A0 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_MinMaxMilliseconds(System.Boolean)
extern void FPSCounterData_set_MinMaxMilliseconds_mB6FAEA26369A1AD95BC068446E31D90506F737C0 (void);
// 0x000001A1 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_MinMaxNewLine()
extern void FPSCounterData_get_MinMaxNewLine_m16C9504F57DFB716BAE901F436872BCF27A5C1C1 (void);
// 0x000001A2 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_MinMaxNewLine(System.Boolean)
extern void FPSCounterData_set_MinMaxNewLine_mA3EB09735E5B6D1B656332EBAF9F635F0BBB403A (void);
// 0x000001A3 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_MinMaxTwoLines()
extern void FPSCounterData_get_MinMaxTwoLines_mBD3EA827B415A15E5D2433F665020146AC1EA0F5 (void);
// 0x000001A4 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_MinMaxTwoLines(System.Boolean)
extern void FPSCounterData_set_MinMaxTwoLines_m5BA0A778034BD53FCA6F00E56854C785F04ECA84 (void);
// 0x000001A5 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_Render()
extern void FPSCounterData_get_Render_m0885B41F9FDECEDC486BD98352E2D9308FAA8B5E (void);
// 0x000001A6 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_Render(System.Boolean)
extern void FPSCounterData_set_Render_mAFDD188A468510624409190556F47F238E004384 (void);
// 0x000001A7 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_RenderNewLine()
extern void FPSCounterData_get_RenderNewLine_m5889E0319FCFA2D094909A26CB8DFFABD50EA6A3 (void);
// 0x000001A8 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_RenderNewLine(System.Boolean)
extern void FPSCounterData_set_RenderNewLine_m53FFF25C4E633F26B67F6974A7DFB2AC1B8D8F14 (void);
// 0x000001A9 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_RenderAutoAdd()
extern void FPSCounterData_get_RenderAutoAdd_mC44A1ED59065A8A562E160C991335451E80A0DA9 (void);
// 0x000001AA System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_RenderAutoAdd(System.Boolean)
extern void FPSCounterData_set_RenderAutoAdd_m480610443C01288657995BEFAEC761EBC5BF3A69 (void);
// 0x000001AB UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_ColorWarning()
extern void FPSCounterData_get_ColorWarning_m360523333AC6DDD562D5C757CD40B4B9DF388978 (void);
// 0x000001AC System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_ColorWarning(UnityEngine.Color)
extern void FPSCounterData_set_ColorWarning_mB53D394580014AA8B5F128A73C2D68A253D6BBE9 (void);
// 0x000001AD UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_ColorCritical()
extern void FPSCounterData_get_ColorCritical_m4EF384BC88234387C39374A412C36933E70A5C0C (void);
// 0x000001AE System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_ColorCritical(UnityEngine.Color)
extern void FPSCounterData_set_ColorCritical_mD31F4A354D53C1BE4F5C8477E52D990339E04468 (void);
// 0x000001AF UnityEngine.Color CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_ColorRender()
extern void FPSCounterData_get_ColorRender_mC0253E52EBFF3692D3BF14B20002C051EF9C28C2 (void);
// 0x000001B0 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_ColorRender(UnityEngine.Color)
extern void FPSCounterData_set_ColorRender_mA578FD848ABA6E0115EA7B2E3F316AC71CAD4E60 (void);
// 0x000001B1 System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastValue()
extern void FPSCounterData_get_LastValue_m39CA894A3E874CC1B71C9F1AE493BE754C466D0A (void);
// 0x000001B2 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastValue(System.Int32)
extern void FPSCounterData_set_LastValue_m0563BD6D231C4A587354CC29C11A5BC36AD632B3 (void);
// 0x000001B3 System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastMillisecondsValue()
extern void FPSCounterData_get_LastMillisecondsValue_m922B8E6DF8C707420D28F5C4002B0264A9C658CB (void);
// 0x000001B4 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastMillisecondsValue(System.Single)
extern void FPSCounterData_set_LastMillisecondsValue_mE67A01A5592A4BBFDE59D74D40BB92FED6C44FD8 (void);
// 0x000001B5 System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastRenderValue()
extern void FPSCounterData_get_LastRenderValue_m2766C4B231755458C04607E9E0ED811B6C2F00C1 (void);
// 0x000001B6 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastRenderValue(System.Single)
extern void FPSCounterData_set_LastRenderValue_mC0FBAA0A34FF9A8F388F3D08A8A9FF198A1D81A1 (void);
// 0x000001B7 System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastAverageValue()
extern void FPSCounterData_get_LastAverageValue_m00CAB1D9063E9138E39B0BE0391244A43CEADA68 (void);
// 0x000001B8 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastAverageValue(System.Int32)
extern void FPSCounterData_set_LastAverageValue_m64918AE4A95CEC0B6FF368B1E0E8980E1B528459 (void);
// 0x000001B9 System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastAverageMillisecondsValue()
extern void FPSCounterData_get_LastAverageMillisecondsValue_m197762D13BAD8DC3A1132EFEAEE010E135F7D0FB (void);
// 0x000001BA System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastAverageMillisecondsValue(System.Single)
extern void FPSCounterData_set_LastAverageMillisecondsValue_mFCCD3FC93BC678EE6692D9E4DBDB36CC9F306FDC (void);
// 0x000001BB System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastMinimumValue()
extern void FPSCounterData_get_LastMinimumValue_mA5D56209FAC6735B25B121280493F4F91365ECF8 (void);
// 0x000001BC System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastMinimumValue(System.Int32)
extern void FPSCounterData_set_LastMinimumValue_m7CB562861E8FD7EFE38F521787AED0785D830EAA (void);
// 0x000001BD System.Int32 CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastMaximumValue()
extern void FPSCounterData_get_LastMaximumValue_m6F66B92422B5488E16FA012964DE33F2F3A2B8BD (void);
// 0x000001BE System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastMaximumValue(System.Int32)
extern void FPSCounterData_set_LastMaximumValue_m3161C0C6D289880D86E774520B5823A299B91C8C (void);
// 0x000001BF System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastMinMillisecondsValue()
extern void FPSCounterData_get_LastMinMillisecondsValue_m45FA26E32AAE674308AA61CB4BD9E45F0B508988 (void);
// 0x000001C0 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastMinMillisecondsValue(System.Single)
extern void FPSCounterData_set_LastMinMillisecondsValue_mE65A3B7CAC66633F057FBA5E230394056C2E2317 (void);
// 0x000001C1 System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_LastMaxMillisecondsValue()
extern void FPSCounterData_get_LastMaxMillisecondsValue_mA9CAF13FEB2B3D8D5E3920AC14C43B0E1B0F4F8A (void);
// 0x000001C2 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_LastMaxMillisecondsValue(System.Single)
extern void FPSCounterData_set_LastMaxMillisecondsValue_m42829B94916C24D71B5D230825B953C3F50F1B7D (void);
// 0x000001C3 CodeStage.AdvancedFPSCounter.FPSLevel CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::get_CurrentFpsLevel()
extern void FPSCounterData_get_CurrentFpsLevel_m463F5E4468FC5E4332B2D6C77F0C00517E9C82EA (void);
// 0x000001C4 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::set_CurrentFpsLevel(CodeStage.AdvancedFPSCounter.FPSLevel)
extern void FPSCounterData_set_CurrentFpsLevel_m4B1411AE8CA69C8656F5FAF8277DDEFBE48295B9 (void);
// 0x000001C5 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::.ctor()
extern void FPSCounterData__ctor_m754F045BF9CB506FA16A5799D5F2A56FA84B0701 (void);
// 0x000001C6 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::ResetAverage()
extern void FPSCounterData_ResetAverage_m3BC1CC7F2EAC545724AEE5CBF4E3080C5F1735F5 (void);
// 0x000001C7 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::ResetMinMax(System.Boolean)
extern void FPSCounterData_ResetMinMax_m74B0C068B21016F173151830061A0C285F939383 (void);
// 0x000001C8 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::OnLevelLoadedCallback()
extern void FPSCounterData_OnLevelLoadedCallback_mC359DABBE419B124F839628100F64328511D102B (void);
// 0x000001C9 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::AddRenderTime(System.Single)
extern void FPSCounterData_AddRenderTime_mA394B787687F183D6B14E6086FAA47E9B1FC8CF3 (void);
// 0x000001CA System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::UpdateValue(System.Boolean)
extern void FPSCounterData_UpdateValue_m6284DEE2CD58FE628D79CD1F9272E2D5F4B50322 (void);
// 0x000001CB System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::PerformActivationActions()
extern void FPSCounterData_PerformActivationActions_m8EBA9D98C239C575AC378C80648BE97A24FCBC3A (void);
// 0x000001CC System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::PerformDeActivationActions()
extern void FPSCounterData_PerformDeActivationActions_mFACC0BD50B3C3CCAF1C568DEAFBABE12464FDCC7 (void);
// 0x000001CD System.Collections.IEnumerator CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::UpdateCounter()
extern void FPSCounterData_UpdateCounter_mE219B1F1D671D3711059185761267A118A1E5676 (void);
// 0x000001CE System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::HasData()
extern void FPSCounterData_HasData_mB349675A62E5E9624025101BB582299FD8AD3BF9 (void);
// 0x000001CF System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::CacheCurrentColor()
extern void FPSCounterData_CacheCurrentColor_mC6E20B5A46621C75F26A2EC363E4F074542CB130 (void);
// 0x000001D0 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::CacheWarningColor()
extern void FPSCounterData_CacheWarningColor_mCBCD7BC25AADA85E0637019894CEFFF9883DA48C (void);
// 0x000001D1 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::CacheCriticalColor()
extern void FPSCounterData_CacheCriticalColor_mB5DA038566F3789E4AF666D5D998E72AB4D60721 (void);
// 0x000001D2 System.Single CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::GetAverageFromAccumulatedSamples()
extern void FPSCounterData_GetAverageFromAccumulatedSamples_mDBF340F83AB59EB86F6A08BA33060BCB63541E19 (void);
// 0x000001D3 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::TryToAddRenderRecorder()
extern void FPSCounterData_TryToAddRenderRecorder_mEECDEE1E013DA4EF86695052B49C69B8BE522BAF (void);
// 0x000001D4 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData::TryToRemoveRenderRecorder()
extern void FPSCounterData_TryToRemoveRenderRecorder_mB9D188E702DDBADC00451AC43F2C29F4BF103747 (void);
// 0x000001D5 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_Precise()
extern void MemoryCounterData_get_Precise_m5D1643FEB81798E7462763301B21C0A2F18C3BD0 (void);
// 0x000001D6 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_Precise(System.Boolean)
extern void MemoryCounterData_set_Precise_m2F3EC102D54F95D9784C83CD9E04BF0B2E9E0C55 (void);
// 0x000001D7 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_Total()
extern void MemoryCounterData_get_Total_mC3B79CE65394A8D3B1A06AA5908A5CDC00BB8DFB (void);
// 0x000001D8 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_Total(System.Boolean)
extern void MemoryCounterData_set_Total_mFC96803584D8BC207CDAB9518896023D948CED9C (void);
// 0x000001D9 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_Allocated()
extern void MemoryCounterData_get_Allocated_m93C09D6DECD4822472BD7B2ECCE8E2A39CEECC6D (void);
// 0x000001DA System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_Allocated(System.Boolean)
extern void MemoryCounterData_set_Allocated_m93B94D3770B3E370300BFC0ED48EFECF4F19D94F (void);
// 0x000001DB System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_MonoUsage()
extern void MemoryCounterData_get_MonoUsage_mE610658F234B8147369D9096D4E3D3CA90F7E855 (void);
// 0x000001DC System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_MonoUsage(System.Boolean)
extern void MemoryCounterData_set_MonoUsage_m23E13002E78331227E1EEE3D5FDF625FFE047BBE (void);
// 0x000001DD System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_Gfx()
extern void MemoryCounterData_get_Gfx_m5F71EA66B668E07EE8F9C3DCD42E25307EA9BA65 (void);
// 0x000001DE System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_Gfx(System.Boolean)
extern void MemoryCounterData_set_Gfx_m8ECE8704AC39B4306375A7DF2C6E414BCC0BDCA8 (void);
// 0x000001DF System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_LastTotalValue()
extern void MemoryCounterData_get_LastTotalValue_mC3FA6D93FAA711C4DF036433D402549840C48470 (void);
// 0x000001E0 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_LastTotalValue(System.Int64)
extern void MemoryCounterData_set_LastTotalValue_mACB28C8F1462CEE2BA3A7025D96FAB6EBAC33DCA (void);
// 0x000001E1 System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_LastAllocatedValue()
extern void MemoryCounterData_get_LastAllocatedValue_m04179F2A2411345C34C2E288525D21DD311C8EF9 (void);
// 0x000001E2 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_LastAllocatedValue(System.Int64)
extern void MemoryCounterData_set_LastAllocatedValue_m22DD873AB4437050253CCDBDA68C57B7FEF15C32 (void);
// 0x000001E3 System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_LastMonoValue()
extern void MemoryCounterData_get_LastMonoValue_mD473805AC6C76B55FE906516034D3B755942EA9F (void);
// 0x000001E4 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_LastMonoValue(System.Int64)
extern void MemoryCounterData_set_LastMonoValue_m1B163B304D9D8F99BA638E19012AFADA7518D667 (void);
// 0x000001E5 System.Int64 CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::get_LastGfxValue()
extern void MemoryCounterData_get_LastGfxValue_mA1F4607105F5424C8D0A33AF2DD4430C7F1F4094 (void);
// 0x000001E6 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::set_LastGfxValue(System.Int64)
extern void MemoryCounterData_set_LastGfxValue_mDBFBC87ECE94678BB5ADFD128A246E1D950ADD67 (void);
// 0x000001E7 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::.ctor()
extern void MemoryCounterData__ctor_m84637F746FF1B81581645C75A0654520D1D8417F (void);
// 0x000001E8 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::UpdateValue(System.Boolean)
extern void MemoryCounterData_UpdateValue_mC2ECC67FDF37AD6F4BB563E439C7A6056BEACCED (void);
// 0x000001E9 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::PerformActivationActions()
extern void MemoryCounterData_PerformActivationActions_mA145517DC2422898BB5EC5F788FDB8AD3458CF56 (void);
// 0x000001EA System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::PerformDeActivationActions()
extern void MemoryCounterData_PerformDeActivationActions_m29AC51AF1E311FA7A66C2F36199A0B298C4609A0 (void);
// 0x000001EB System.Collections.IEnumerator CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::UpdateCounter()
extern void MemoryCounterData_UpdateCounter_m843E7A64DAC22D9F33CAC644239336D0808CFE6B (void);
// 0x000001EC System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::HasData()
extern void MemoryCounterData_HasData_m0DD3A405B790AF0DA21773862657303BC16406AB (void);
// 0x000001ED System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData::CacheCurrentColor()
extern void MemoryCounterData_CacheCurrentColor_m67BCCE53C36916E28D413338DB90D43C32E09E5B (void);
// 0x000001EE System.Void ADS/<ShowBannerWhenInitialized>d__5::.ctor(System.Int32)
extern void U3CShowBannerWhenInitializedU3Ed__5__ctor_mA88EAE8C984717338C2878F95EB55B8DCAE33F26 (void);
// 0x000001EF System.Void ADS/<ShowBannerWhenInitialized>d__5::System.IDisposable.Dispose()
extern void U3CShowBannerWhenInitializedU3Ed__5_System_IDisposable_Dispose_mFC1D58F2F3B15F569923387609A4A6364F6D1441 (void);
// 0x000001F0 System.Boolean ADS/<ShowBannerWhenInitialized>d__5::MoveNext()
extern void U3CShowBannerWhenInitializedU3Ed__5_MoveNext_m0069192D726CB966FF7C417E2C46C022CB95A67C (void);
// 0x000001F1 System.Object ADS/<ShowBannerWhenInitialized>d__5::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CShowBannerWhenInitializedU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m78D172B313675722DCCDDAF745FB62EAE97BF726 (void);
// 0x000001F2 System.Void ADS/<ShowBannerWhenInitialized>d__5::System.Collections.IEnumerator.Reset()
extern void U3CShowBannerWhenInitializedU3Ed__5_System_Collections_IEnumerator_Reset_mFA252E29C63DC1B3320FB55AC07FAC066FFBE328 (void);
// 0x000001F3 System.Object ADS/<ShowBannerWhenInitialized>d__5::System.Collections.IEnumerator.get_Current()
extern void U3CShowBannerWhenInitializedU3Ed__5_System_Collections_IEnumerator_get_Current_mF5C066EF95515B4E2DD38C4139FC4C52A8705B6C (void);
// 0x000001F4 System.Void a/<ShowBannerWhenInitialized>d__4::.ctor(System.Int32)
extern void U3CShowBannerWhenInitializedU3Ed__4__ctor_mD73E44C0243C69C4599459C4D562146A6A57E539 (void);
// 0x000001F5 System.Void a/<ShowBannerWhenInitialized>d__4::System.IDisposable.Dispose()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_IDisposable_Dispose_m5CF45BD21A14FE3615504B8AA01308C4C6B94D28 (void);
// 0x000001F6 System.Boolean a/<ShowBannerWhenInitialized>d__4::MoveNext()
extern void U3CShowBannerWhenInitializedU3Ed__4_MoveNext_mB55F1BA8591B14C8754DEC4B598C042731549612 (void);
// 0x000001F7 System.Object a/<ShowBannerWhenInitialized>d__4::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B6332F0D0D4B37EC68C4F0F0C4D92190C6A770E (void);
// 0x000001F8 System.Void a/<ShowBannerWhenInitialized>d__4::System.Collections.IEnumerator.Reset()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_Reset_m9A7D3DECACF5FEC4B02349B56EE620D5F08913DF (void);
// 0x000001F9 System.Object a/<ShowBannerWhenInitialized>d__4::System.Collections.IEnumerator.get_Current()
extern void U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_get_Current_m87DE22D9156CA19C6CD47214B7FE08DD417340A2 (void);
// 0x000001FA System.Void checkSpeed/<ExampleCoroutine>d__34::.ctor(System.Int32)
extern void U3CExampleCoroutineU3Ed__34__ctor_mC506945B0390F81DACDD1DAB824FC88D3F3149AF (void);
// 0x000001FB System.Void checkSpeed/<ExampleCoroutine>d__34::System.IDisposable.Dispose()
extern void U3CExampleCoroutineU3Ed__34_System_IDisposable_Dispose_mDD49C433332AFB8593053903EEFCA7140C3D7EE1 (void);
// 0x000001FC System.Boolean checkSpeed/<ExampleCoroutine>d__34::MoveNext()
extern void U3CExampleCoroutineU3Ed__34_MoveNext_m8D88167669EB21EF9AA6F85F102C51D7ABA5A0DB (void);
// 0x000001FD System.Object checkSpeed/<ExampleCoroutine>d__34::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CExampleCoroutineU3Ed__34_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA2192D2D4E742050B2B9A0691539170715660BC1 (void);
// 0x000001FE System.Void checkSpeed/<ExampleCoroutine>d__34::System.Collections.IEnumerator.Reset()
extern void U3CExampleCoroutineU3Ed__34_System_Collections_IEnumerator_Reset_m542AFC9D999F08380138158C01DF39ECEBD6962B (void);
// 0x000001FF System.Object checkSpeed/<ExampleCoroutine>d__34::System.Collections.IEnumerator.get_Current()
extern void U3CExampleCoroutineU3Ed__34_System_Collections_IEnumerator_get_Current_m0EB2D7E0EB3721883F1699F0642D1E5B1CC01A77 (void);
// 0x00000200 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::.ctor(System.Int32)
extern void U3CUpdateCounterU3Ed__151__ctor_mF5F3418D0DC6964868A5372983FEE83196DC0F59 (void);
// 0x00000201 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::System.IDisposable.Dispose()
extern void U3CUpdateCounterU3Ed__151_System_IDisposable_Dispose_m6CD3CF8E44532CEF678B24641F8E2C1C848093DD (void);
// 0x00000202 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::MoveNext()
extern void U3CUpdateCounterU3Ed__151_MoveNext_m6861156104B6349925476103F01B51CCB531721B (void);
// 0x00000203 System.Object CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CUpdateCounterU3Ed__151_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB371302E75CE1B142F88BED56C239A3841CA4BEC (void);
// 0x00000204 System.Void CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::System.Collections.IEnumerator.Reset()
extern void U3CUpdateCounterU3Ed__151_System_Collections_IEnumerator_Reset_m3A5EFF1CF0A101DBCF1AB67834086FCA2B11A33F (void);
// 0x00000205 System.Object CodeStage.AdvancedFPSCounter.CountersData.FPSCounterData/<UpdateCounter>d__151::System.Collections.IEnumerator.get_Current()
extern void U3CUpdateCounterU3Ed__151_System_Collections_IEnumerator_get_Current_m7D0B4BB248BFCC7A4CE1E37223BF5E232F0646E7 (void);
// 0x00000206 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::.ctor(System.Int32)
extern void U3CUpdateCounterU3Ed__48__ctor_m1AE440D5F8067F0C9CD2DB32337887D124AE12E9 (void);
// 0x00000207 System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::System.IDisposable.Dispose()
extern void U3CUpdateCounterU3Ed__48_System_IDisposable_Dispose_m019A4B31FEA587F323FF2192DBCCAE552CF5D0B8 (void);
// 0x00000208 System.Boolean CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::MoveNext()
extern void U3CUpdateCounterU3Ed__48_MoveNext_m62FA9C5D8F4361846B77789E28E40BA82B9CEFE8 (void);
// 0x00000209 System.Object CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::System.Collections.Generic.IEnumerator<System.Object>.get_Current()
extern void U3CUpdateCounterU3Ed__48_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1602D234FADE2A2EE994831AF5E79614BAFC463B (void);
// 0x0000020A System.Void CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::System.Collections.IEnumerator.Reset()
extern void U3CUpdateCounterU3Ed__48_System_Collections_IEnumerator_Reset_m1BC14925698F9D3424B4E758A6230A61A992EC57 (void);
// 0x0000020B System.Object CodeStage.AdvancedFPSCounter.CountersData.MemoryCounterData/<UpdateCounter>d__48::System.Collections.IEnumerator.get_Current()
extern void U3CUpdateCounterU3Ed__48_System_Collections_IEnumerator_get_Current_m983C3345D2C76D37903FBE2FA708D29E55E1329F (void);
static Il2CppMethodPointer s_methodPointers[523] = 
{
	Actif_Start_mF52ABF049AA1B6C645034695194E6C6862B10ED7,
	Actif_Update_mD55E1C2564F5E3BA986DDDEBC767B485DB6B025F,
	Actif__ctor_mC6B5084C8B6F01F4D67389297A5E8241BEBF224C,
	ConvertToLineMesh_Update_m221417ECE795D58A804C0CC2CEDA11735D428131,
	ConvertToLineMesh_GeneratePointMesh_m129685FC426FFB85842249C0ED5BDA78ABA49BC5,
	ConvertToLineMesh__ctor_mDE919BFC4905670D98B0D1CCBD1B3D7F31BC94A7,
	ConvertToPointMesh_Update_m4D2D60118B6E8ACED9F3B7F200C7DA4425AE59B2,
	ConvertToPointMesh_GeneratePointMesh_m7D331DDB086E5A926E1C47BB2BE62012A51B1EE5,
	ConvertToPointMesh__ctor_m87954E0B2719F2C5B97F945F161B32CE45787DC0,
	RotateTowardsCamera_Update_mADF3DD94EF3BEBB150EE5B76DF924B2ECD98DBE8,
	RotateTowardsCamera__ctor_mFDFE62D079ED20BCC78A5880A7D974FE41D982F2,
	ChangeTheme_Start_mD5BFBBDA90B98D61693AD22B0762256F4A2453A8,
	ChangeTheme_DochangeTheme_m0B57BE28036D45FCFC39E5AC27F327E8679B3EEB,
	ChangeTheme__ctor_m7F70ADD63C986E5BDFD1897C8955BDA575AC1BCD,
	DIDIDI_ShowHideMenu_m000A016FBFB5D7539FC9BE6A393A567D9757F480,
	DIDIDI__ctor_m1B459C1989CABEA2124F519A75B610D7F53CD7CC,
	OwnerShipTransfer_HideInputName_Panel_m543BCF8A85850C40AF8E6588582B68BFFA5090A2,
	OwnerShipTransfer_IN_mEBFB0DAE72E3492594406ADB2A449F0C40262FC4,
	OwnerShipTransfer_CheckPhotonViewOwner_mB4F92E5A83C678880AC2958EC4F226AD58F94B67,
	OwnerShipTransfer_setOn_m1AA23B24267A14A5E9CB9782E5DA7062BDEBA39E,
	OwnerShipTransfer_Update_mEC1D4D26D5850B71578B483013E1EE8A5F7A2C6E,
	OwnerShipTransfer_SetText_m9453E9A8F2D6D03E5ACB8CF72959036672592389,
	OwnerShipTransfer_OverrideHost_m373D11302F12DD680AA694572310CD4A30002154,
	OwnerShipTransfer__ctor_m1FB7E6B0506E16B942F048ACDA694DF8D728ED8A,
	SimpleControl_Update_m6CDE5FB77FABCFBC70D1D09F7D68C36D0F9CFE58,
	SimpleControl__ctor_mF2770C5E6A99D69953CCC1242C1F1A431DB7C514,
	SimpleControl2_Update_mE7A75C065A622F012D5BB6FD0A036AA88B0615CD,
	SimpleControl2__ctor_m4DCA63858ACAF74529E78A679B40F2FFAB00E242,
	ADS_Start_mA68EB8813892C5F0AD75F44CD88C9982A7674624,
	ADS_ShowInterstitialAd_mFC83EF727D32E5E9FFE51B0D94A0F712F9D6F50C,
	ADS_ShowBannerWhenInitialized_m34628FC6B1456576C8089DE49E75AE0A1F93A9F0,
	ADS__ctor_m09273B53A1B0C3C60AC5D2958E9B2BD161372A7E,
	AddForce_start_m50CCA7957AD1A07E18D98DDD69DECD6B1947B8DC,
	AddForce_OnMouseDrag_m3D0EEA8817F2CA652EFB9DC2CA3AB445DEF0CE3D,
	AddForce_Update_m2D7DEA766F7EC7A01CBD04DEC115CA979AC0227B,
	AddForce_FixedUpdate_m448B02E7F8E12B95FC141F8B1B0D80C23CEDA0EE,
	AddForce__ctor_mD145641C9B9DE20A1DF1F26C929FB6560E736F09,
	Zoom_Start_mA42CFFF6B9D92AFF162D6EE0EE7FDAF481F69203,
	Zoom__ctor_m48EC87C1D84179E33EFD99EA35B82C25F3574238,
	a_Start_m63227AC9295B3784F99C8D3EAEFF038C0BFCBF1F,
	a_ShowBannerWhenInitialized_mC65521D0CDA0F1665916B1E6C886BB816D4B38E8,
	a__ctor_mB4A142985402040FBF1A5F2339C3A8D394A61004,
	NULL,
	Gun__ctor_mC9C3C6BB532D28E4A18097E833645FB45888F87B,
	GunInfo__ctor_mDE2950671035172277FD7DE5D4A3FF008793AB07,
	NULL,
	NULL,
	Item__ctor_mDD5CE3191836C8F404C284F0DC5C87394F78E84B,
	ItemInfo__ctor_m003DCEDBC674D1078485730A2E99662D1B4E42DA,
	Launcher_Awake_mBE44C29C9ABCBA09F0089E2C1F008FFED84C2A3F,
	Launcher_Start_mB785B8C7AD443649D3A8030352990E194FB22DE8,
	Launcher_OnConnectedToMaster_m983E3D84ED222F36B555BB29F609990265F61C03,
	Launcher_OnJoinedLobby_m68167B6F0642E60D1BF4335BEC526BF7B32B4DB3,
	Launcher_CreateRoom_mBDE023EC6A9A761CAD0D5709340E0006636B7965,
	Launcher_OnJoinedRoom_mA980BB15177B8E0BBBC5BF74F059F03B555EBEFF,
	Launcher_OnMasterClientSwitched_mF0D3467CEBC9910696D694708A4CE9072739497F,
	Launcher_OnCreateRoomFailed_m305254A650520122D67E66B8566D2CC1CBA4748F,
	Launcher_StartGame_mD32628C64EC2C4DFAA065DD02D4B2E2DFB8153D3,
	Launcher_LeaveRoom_mC5E8162D72AB21EE997DC2B074B4FE0BCEA887B5,
	Launcher_JoinRoom_m9488E87A9E6713795FC6DF2040D54014CEDCDEB2,
	Launcher_OnLeftRoom_mB0EB1CCAC9232941AD6C67B86A6BEEEA1CAC2F45,
	Launcher_OnRoomListUpdate_m901025C882658EB3152DF30719A93FF86AF49A7F,
	Launcher_OnPlayerEnteredRoom_m245D4B5F41F7C85E6921955E4EF50280D8856C46,
	Launcher__ctor_m5E3C1ED0409DFB8090A7820B3322EDD6C771845D,
	Menu_Open_mB25514E8FE3D2C26D274B58EB5C1EC8A742DA869,
	Menu_Close_m6ABFF54072F3527CC37871ED1B6A4A8E34157E14,
	Menu__ctor_mD372D109F6554E1F9A25291964C852C9F6BFC463,
	MenuManager_Awake_m509E86B86EE3FD70E7831B2B0B421F9826B1D184,
	MenuManager_OpenMenu_mDC79E1407E5157CE953463A6D6CF8B3ADAF5E632,
	MenuManager_OpenMenu_m1BFE39E135FAB6BBD17AA215B75CCD99CF544347,
	MenuManager_CloseMenu_m2C26269D235C4027E7CE4A5E3EDA6633605271E8,
	MenuManager__ctor_mF9508A23E828387B76DB818A2E34D3A8AC9063EF,
	PlayerController_Awake_m118C1D205A374B627E1EC963E5837E23CF554573,
	PlayerController_Start_mC0C9B9461D0BDAC48EC43715818A4BA63C4F45EF,
	PlayerController_Update_m38903EF1C8F12B9388303741F8040EE26C33DC33,
	PlayerController_Look_m0A973768C9C0EFAF29B9B6E6D48DE7FD1BDC8A65,
	PlayerController_Move_m0CD456A5EA1116F1B4EA5A731C7EAC46D26B598F,
	PlayerController_Jump_m3056E2DF0CD8445804DCDAB6521E81541F0218A1,
	PlayerController_EquipItem_m1322B70356CB44651260E1449AE0285B1BE8BDC7,
	PlayerController_OnPlayerPropertiesUpdate_m9659F27002514187A768F0356707B049B1E28FE3,
	PlayerController_SetGroundedState_m22C1F6A5A43405EA167EBC18CCAE03007AB8BA34,
	PlayerController_FixedUpdate_m914EA3E3CCE4DF6AEB2E78317FFC1D507DACEBDE,
	PlayerController_TakeDamage_m65FA43A04541D6C86BD5BAB74A6CC8FCA8AAEFAF,
	PlayerController_RPC_TakeDamage_m41A1A5DDDCA1AF5F00617D86ACF4E18AAC8DBB2F,
	PlayerController_Die_m5293C32D23350D28D5F7466E7BE49E8165AB7224,
	PlayerController__ctor_m648E40092E37395F4307411E855445886113CD60,
	PlayerGroundCheck_Awake_m36EE07E428348599E3727959C76D402D79FA07EF,
	PlayerGroundCheck_OnTriggerEnter_m6B50610ABBB08642992AC330CFB3E728BE3DC237,
	PlayerGroundCheck_OnTriggerExit_m0B9A071704BEDB0D39208165A499F3AEC4AE5B0A,
	PlayerGroundCheck_OnTriggerStay_m99DC3BE18E1058A61E5FA959EBF9AC0B25445137,
	PlayerGroundCheck__ctor_m4E3D61425004DCD63469198CAE187866C0405CA9,
	PlayerListItem_SetUp_m1C6390C932D02AA99B3A3C11D2B0E03EC767CEEB,
	PlayerListItem_OnPlayerLeftRoom_m5F5EA99F615B44A25DDBBBAA9FFB64615B2CF1D2,
	PlayerListItem_OnLeftRoom_m8453AFEA487748F2D047FD1C6AAF2D851E38C02D,
	PlayerListItem__ctor_m5066BDA3D1AB0786E49BB61ED077EADEED903D4C,
	PlayerManager_Awake_mED34BFB5AC87623E77EC44EC1E9881604F4851E6,
	PlayerManager_Start_m5969CE13735048121AC12C6C4D41B52C1B996E56,
	PlayerManager_CreateController_m8EB6C1724955124A0CD17A5720705B469586A9EB,
	PlayerManager_Die_m75C93CC4A75E4B9105A0019BFEE978967FCFF512,
	PlayerManager__ctor_mE56F430BAC9016609685221F2A5B7C018A00ADAE,
	RoomListItem_SetUp_m302822AB8CDCF1E8A01E3FB320C78EFC64325885,
	RoomListItem_OnClick_m960A620D179224589B3AB197D4FFC8E2C5311E09,
	RoomListItem__ctor_mAA396EAADBE8FC3E83B660225D271A39B194C117,
	RoomManager_Awake_mF88A6570DF44FCAD111987A861556E034E9D1BC9,
	RoomManager_OnEnable_mB358C3A46698171DF465CF95D605D4CD03028C05,
	RoomManager_OnDisable_mEEDE4F57B633F5F079021AE698EC9342869A4F75,
	RoomManager_OnSceneLoaded_m35280C2883C6C63A8B83DD0EA3BE6F5E2ED28933,
	RoomManager__ctor_m647CD75713362D4AE755130C4C3148F47AF980C3,
	SingleShotGun_Awake_mBD1001FA17F85394EAE92FB9E60571F2AD9EC87E,
	SingleShotGun_Use_m518C9D255972C04CC5E6A79DE46B4B3E032A5D3A,
	SingleShotGun_Shoot_m940FC6312E3C23835B8F357CBFF29E430DA9CD19,
	SingleShotGun_RPC_Shoot_mB04E734FD3FF2EDEE85F0DE102D4F997735C708C,
	SingleShotGun__ctor_mA04B340EA5BB326827D4E492C0CCF09D369308D0,
	SpawnManager_Awake_m6C18AC22045742445D37B45F609C218A47A06322,
	SpawnManager_GetSpawnpoint_m6DEAAEEF29BA08B04B298061917DE55D42EB0BB4,
	SpawnManager__ctor_m7DCC863664A8B146149D9C23833658ED3BDC8DF5,
	Spawnpoint_Awake_mA7ABB39DEB7323B9AE0C56BB5576790C269A8AEE,
	Spawnpoint__ctor_mFDB9FF2B781E8A8CCBBD734BEB0EC3A255846AEA,
	requestOwner_OnMouseDown_m83B3CD7D15FD9853AA230D5288DAFE5EDB0DDA8D,
	requestOwner__ctor_m904076799ED4888E9E2B0325FE1E7BF68F873ADC,
	SphereRotationCopy_Start_m7BD8A03EE8C0674CE9CC577C9532C7029195C931,
	SphereRotationCopy_Update_m67B5E1165C0EA8B429C9D009A553129F5CC71AC2,
	SphereRotationCopy__ctor_mCF6DA51CFFE64E7879272562C2096D7F35DD633C,
	TestScript_Start_m37FFC63451F28F640DBC8E81F6921CA912BCF9BE,
	TestScript_Update_mF00A4D69B7E86CF3061303B401FBCF2CB433F44C,
	TestScript_Change_mDEAA9F4EA63257AD29B85FF01461D964F425C4C3,
	TestScript__ctor_mAF795D5D902560987B93306D9BB0169F4CD0CF18,
	Try_Awake_m84F234E4C3E41BAC92540482A382863E6A1BB37D,
	Try_Update_m0A0CDCEC34F921E403FAE59FEC4F74FAB60B75A2,
	Try__ctor_m17D029E7B5721BFF27701E579B38EA87F6EBBACF,
	SliderMenuAnim_Start_m73AE2B603B2A0BD95EF2C9D55722E8B8144BD487,
	SliderMenuAnim_ShowHideMenu_mE19AF5B471CD1FCC880230433B2800F491F78EFC,
	SliderMenuAnim_TaskOnClick_m2871F04D722815586595A4B109775782C9A4E4AC,
	SliderMenuAnim_Update_m15931CB9D192BC3E481A4BE05244C5A1418601A1,
	SliderMenuAnim__ctor_m6073C281A6191217FC659A6703CF93C68D09EF3C,
	UIController_Start_m25C8537A29A929C6B8BB8AD754CC846D444822EE,
	UIController_Update_mA639146623182EEFE585BB46CD8ED3D5739FBF2B,
	UIController_Violet_mB24E63FAE4BE78666BE43D00AEF0DA424B22DF97,
	UIController_Blue_mC38911C5A8E5687035B761CA64D2D8694CAFBF0C,
	UIController_T2_m2F63ECE4CF2689B57C0C82F88A24076293E861AD,
	UIController_T3_m3A1ACDB43925A76DF937AE30B155592BEDC8FB5E,
	UIController_T4_m54C95E4DA3B75212930598EBC32B527BCA0E9DAF,
	UIController__ctor_m218DB9E5110A9E50B5F9C61416BB83F05FBBD4EA,
	autoRotate_Start_m9363279D08053EEB673436AC190003177F8D3A90,
	autoRotate_Update_m3D4D109E5362717DAC05CE5266D311E82BB7E961,
	autoRotate__ctor_m5C0D326F57791805343C13CF60E50A49DFEA61D4,
	checkSpeed_Start_m722A1142423CADA051D34F44954C8C3A9915F33F,
	checkSpeed_Update_m6A830F6EC7B4B1655775D6F0DD3E6820E8572638,
	checkSpeed_setOff_m055A893FA07F16038C392F678B42A2250FDB7F4C,
	checkSpeed_ShowDelayResult_m2CD16A00FBD6C795A488F74DA88DD462A19EEF60,
	checkSpeed_HideDelayResult_mAE700EE2CAFE68D553D407B79DE37C2FF561F2FC,
	checkSpeed_ShowPanel_m25EF319423D104189F43850EED85CF1EF55ADDA1,
	checkSpeed_TaskOnClick_m2009252AAD804EC64978F00B9363B33B79317850,
	checkSpeed_Count_m39A95CAFA26200810D6F13B6C7673F5F67D2771E,
	checkSpeed_ShowAds_m5AA89B6CE52A03B92D424D49E733821D5C6A54CC,
	checkSpeed_ExampleCoroutine_mDABBFB8CB4FDB0C17F01555CD70F919A9DBC694B,
	checkSpeed__ctor_m81BA37C44B493F9B765E6AE5A1D9E53C06C1BE8E,
	music_start_mE225EFF996F99C34D930819F83DDB7C28E5A03BC,
	music_Update_m95568B9C3E26D7EE11F461BF39CF60E80456FD06,
	music_OnTriggerEnter_mC9BE77BCCF7B047549CEDF40156C690B76C7A60B,
	music__ctor_m09A10B55B29748150FC90AF118B0EF64309ECBA2,
	quayImage_ShowHideMenu_m6F1C2D7C82B28331419397268658BCEA769D21E8,
	quayImage__ctor_m1918A22F261B94C2F9A394B631324CAEC154EEAB,
	quayOb_ShowHideMenu_mF399E9573304E6A972F5B037D8566133BB21B05B,
	quayOb__ctor_mFA6E9E51EE55AF3581484FF08BF5E7890D4965D1,
	TrailStyleProperties_supportsColor_m74C64ED9A5FF4FAB30FE7983EB4832EBBA7274D9,
	TrailEffect_get_active_m43D2115A024DA2A036C428FD4AA847D108FF9576,
	TrailEffect_set_active_mBC53600CB75EC165C601BFC3626B7CED5BA56366,
	TrailEffect_OnEnable_mE98FD1EB5F5F002AB3A9005EE5F04A09BB26ABB2,
	TrailEffect_DestroyMaterial_mC8099DC8807AEDEE8642615D1ADA5C4DA1C9E6C7,
	TrailEffect_OnDestroy_m6F0B7050334218166F8FC81A41B9DAA634800215,
	TrailEffect_OnValidate_m81C4CF0EBE1D2BEEA27B304646FD5D38F80FAEC2,
	TrailEffect_Start_m111C99E6B44D84A596A92F45E9E6648040FB5323,
	TrailEffect_LateUpdate_m4DB3B616F525A5294B2CDBCC48E2283D5F871DC2,
	TrailEffect_OnCollisionEnter_m823C59480FEBAD55F8B5F2033AE734ABB67964D6,
	TrailEffect_CheckEditorSettings_m6A8D0E9EA54773660B89C707A427AA92DBCB70A2,
	TrailEffect_Clear_mC3F0032209A756B27ABCEA92765A13A2C091C5CB,
	TrailEffect_UpdateMaterialProperties_m2F474EC36B4CAA1BB1ACCC75C7A1B93981F4F63D,
	TrailEffect_GetEffectMaterial_m51E16EB143E92887CCBD6A11D9C5A2E24CDBD7FA,
	TrailEffect_BuildQuadMesh_m7CC3BB3C477626EF4763A3EA07324FED5B025891,
	TrailEffect_GetSnapshotScale_m7B8D5E8CF29CFE38ABC0E4B75F9111539249407E,
	TrailEffect_GetRandomizedPosition_m6E8CCF7614439CFA12BC51AB24214AEE66270A25,
	TrailEffect_GetSnapshotColor_mAC00415914A73CE662331C48E378C22FE7580FF8,
	TrailEffect_StoreCurrentPositions_mBE6727D1DF19CCC12C58FADFB695472E48D0039E,
	TrailEffect_AddSnapshot_mEE91DB9D36E4D49EF5C5163752904539A81F0156,
	TrailEffect_AddSnapshot_mE0BAAE73DF4EBA8A85EE1246372CFAA6C9EFD17A,
	TrailEffect_RenderTrail_mF849F085C7281A473BC3584B3099FA3118E77157,
	TrailEffect_SendToGPU_m8B47A8C5185376A0E0D8A0D3D094E8AA95F12B8E,
	TrailEffect_SetupMesh_m9B25E5B036B49C841049C5313E350A05D7C7DC16,
	TrailEffect_QuickSort_mEB9022C6DA66B0F661288624E298C0401D7705E9,
	TrailEffect__ctor_m146C6456AF05CC091935F15510FC6196ADA12575,
	TrailEffect__cctor_m51B15A6306C5EADA96E3897937483A8CA35EE80A,
	TrailEffectProfile_Load_m1923C8C017E9296FD265CE1698AF9B6602BFEFA2,
	TrailEffectProfile_Save_mAA050027DEE769FE3C0920B1F740E825365613E6,
	TrailEffectProfile__ctor_m2078430C15C9BB093D02A63DE0CF6B7DD1983CB7,
	MoveObject_Update_m2DEB375B198277A6C6FFE22018DFFE9BD27BA474,
	MoveObject__ctor_m8DBB58DC0E376E16F6CF29896EDAFA7F5EDB64FC,
	RotateObject_Start_m11202E3F7EFD21D8AE43E1A85C9FACF79AB02E88,
	RotateObject_Update_mB2B0381F3994D60E9587DCA76F1B65E65D7D3DD2,
	RotateObject_SetAngles_mDC778E57D2F780F9D1E92258D4DCCD87A497AACC,
	RotateObject__ctor_m9AD1C26C2C387C3A57DD9020CD35C4EC48B5F25C,
	Shooter_Start_m449703F2EF2E040C688F96CB2E0F1E069FA13966,
	Shooter_Update_mDEB0C852272F71C07F718BB3F9E6E19E048FD4BA,
	Shooter_NewTarget_m4988EAFF66BFE8DCF060243F510EC7A7DA2F7361,
	Shooter_Shoot_m45165A30E96836110D79DFC4A8552E288615FB51,
	Shooter__ctor_m20C9CEB0B4E71E680793568285D229337D82F2D7,
	quay_Start_m438EFEF9F20ED8BFEBDAA081DCBC9C99590F4ABC,
	quay_Update_m787D3FFBE3C127921BD4E999B446EB6AABA755F6,
	quay_SetAngles_mDEA4E425F24840427EEBB5553A78FF904A0FCAA4,
	quay__ctor_m6DB84E087354AF43F2C288AED6D9125E23D28ECA,
	APITester_Start_mAB25FF60FEF44B2DA7EE42C1535059A051F698FE,
	APITester_OnFPSLevelChanged_m851238E35C8B8D7670E300FAD89FFE521BB3BFD7,
	APITester_OnGUI_m5B2FB1710DE4A96BB44729BD123D6FBFD5207165,
	APITester_DrawCommonTab_m64CC0E9C76F058F390CA7CDDED1AB1FFE954FA81,
	APITester_DrawLookFeelTab_m5902D4039EDD5022B73D05BB40BA7B57F0AB6196,
	APITester_DrawFPSCounterTab_mD46A16333641FD2C06B597561E826235E04FB2C5,
	APITester_DrawMemoryCounterTab_m71EF1325D86A29A70C1078CEF3843F175A6143AC,
	APITester_DrawDeviceInfoTab_m3E28DA3D4FB1E1377AB986401E794F0FC5AAC3FA,
	APITester_SliderLabel_m9C74C6CC30C44FADEEDE460B9F64FC695C0C1391,
	APITester_ColorSliders_m2F5CB92F1EF22953468DDD92FDD6379093778597,
	APITester_Vector2Slider_m21A8FAE4E48EB46EC0D14DA2F9FEE953AA6751EA,
	APITester__ctor_m3D281F191D6C0262EDA5C55DF6755BB9A2B67D53,
	AFPSCounter_get_KeepAlive_m5A8C6CD23ED12F2A9382B59558E2EC7B65309BEC,
	AFPSCounter_get_OperationMode_m4DD7F6CA23CE8BC215363539D784371CF366C9EB,
	AFPSCounter_set_OperationMode_m890A124B66509F2AF1464DF70171AAE846465EC0,
	AFPSCounter_get_ForceFrameRate_m4542BF0F18A295F5E19A6091ED7F5D6C55A4E6ED,
	AFPSCounter_set_ForceFrameRate_m275BDEDF18EAA087D7C15EEFEC26AF76EE70A307,
	AFPSCounter_get_ForcedFrameRate_mA2F6EDAA8DDBDE34BFDA7DC22B65CBC6861D9802,
	AFPSCounter_set_ForcedFrameRate_mC12E6CDF83E19908176079CF0961B208E909C12E,
	AFPSCounter_get_Background_m83FADE568C99A13383B584021364711FB144F37F,
	AFPSCounter_set_Background_m04A6B707AD8F4CE004BE9182190BC37BF95CA263,
	AFPSCounter_get_BackgroundColor_m7FDA699DC12AE7C2D619457EAE1CABC18ADB03B0,
	AFPSCounter_set_BackgroundColor_mC4B10F36F79A5C17602ED5EECA85B48393627605,
	AFPSCounter_get_BackgroundPadding_mFCC91C5DB5D07256A122B9D62CD3F396385479F0,
	AFPSCounter_set_BackgroundPadding_mA6FE0BA934CFB433ED03FF0A974B27418B287FE8,
	AFPSCounter_get_Shadow_mAF551B893EE03C0BF963F20D8224E15DEBBE1DF1,
	AFPSCounter_set_Shadow_m05CAB4367EFAD74F5DCC0A0DF75ABB10F249EEB1,
	AFPSCounter_get_ShadowColor_mCF2DE635A0F431BDA818F86147AB18A4CC07C2AB,
	AFPSCounter_set_ShadowColor_mEA0F297E58FD1DB32E94E5439E2B68590B1D02A9,
	AFPSCounter_get_ShadowDistance_m63238D38AB7A477F3640BFC8D536AC1761CED800,
	AFPSCounter_set_ShadowDistance_m952714D486CF9469A7A26593E72B845B81913160,
	AFPSCounter_get_Outline_m61E32DDD03826D1ECD02EBC7BD765F88A0F6CB92,
	AFPSCounter_set_Outline_mCEDCA93957857EE392E8CAF9F35A15B1997D3903,
	AFPSCounter_get_OutlineColor_mCC2022E391E67513F2FA9EE419752DC600744B3F,
	AFPSCounter_set_OutlineColor_mCEBB14D3347629591E58403B7D5E1AEFB01C3CE0,
	AFPSCounter_get_OutlineDistance_m8D48D954B84C96DCB6D61E3F999C276E950682EE,
	AFPSCounter_set_OutlineDistance_m6274A354C99030B493924C6188B9017DEA9DE81C,
	AFPSCounter_get_AutoScale_m47BAFE805420D18B95C3E2E92E11BB9BA1D113DD,
	AFPSCounter_set_AutoScale_m734A44DE54640562E4051AA7EC9080B03BC1BA93,
	AFPSCounter_get_ScaleFactor_m4FE3403E95E66BD2CE6650DC4F8933BE162387E8,
	AFPSCounter_set_ScaleFactor_m775F1679ECEFC295A816B3DDB841931428D9FD4F,
	AFPSCounter_get_LabelsFont_mB787B64AB5C89818FDC2FDE7BB44630EF4BF9DCC,
	AFPSCounter_set_LabelsFont_m5D7E5E3E54C815180B85CC8BBD0514DF1FE9CD38,
	AFPSCounter_get_FontSize_m40ABC3E716B629A4FD1888A2307C6429663072C5,
	AFPSCounter_set_FontSize_m57F5736592B01C0BA34934C60BEEBDF34657D15C,
	AFPSCounter_get_LineSpacing_m72F025A02AB338FD925BBD79C5F29BCA652F1D9A,
	AFPSCounter_set_LineSpacing_m9F14E09ACBB4B9AC54A24536F0215C64CDC5469B,
	AFPSCounter_get_CountersSpacing_m085DA79359030BAAB59FC2715727500860AD62B8,
	AFPSCounter_set_CountersSpacing_mEB585A80541A8C0F294D62171727FBAA0690CA91,
	AFPSCounter_get_PaddingOffset_mE21673488D8F487490821F26265A403BE157ABC6,
	AFPSCounter_set_PaddingOffset_m08A97FFA6F202AA33041B53A5E83B37D74C0C3C0,
	AFPSCounter_get_PixelPerfect_m7208225279AE5E0CE976C9C61F5B50182F685BE3,
	AFPSCounter_set_PixelPerfect_mDCACB07A6377D3D31F523943C8B63F6FA5FB47AB,
	AFPSCounter_get_SortingOrder_mD850F1156B9149E9863038E8842A30BBDB432999,
	AFPSCounter_set_SortingOrder_mA58F1653A581002AE7312252068E53CD1FE92786,
	AFPSCounter__ctor_m832FB20EA8D3D0CD4723CD75CF4AED5A915CDE69,
	AFPSCounter_get_Instance_m25999F071293B98B6A6055B992D5852C253B6551,
	AFPSCounter_set_Instance_m5E73D5651F3B2538533D9527BA89DF389ADE606F,
	AFPSCounter_GetOrCreateInstance_mE4CA579C7C1383F114A2AD83438B559E5292C023,
	AFPSCounter_AddToScene_mCBA906A87E07E059B5BF2E290A54B80A415A2ED9,
	AFPSCounter_AddToScene_m5C85E859666E6D84ED6605AC60A88F0EF6DD1A1C,
	AFPSCounter_Dispose_m6B61A94CD658A57F8692DCE97E257243672F01EE,
	AFPSCounter_SelfDestroy_mB55351A9D20DE980ABA05BF3C9C5C75F4E5287FD,
	AFPSCounter_Color32ToHex_m391758187A4FAAAC7BAEB809234D72579BE52995,
	AFPSCounter_CreateInScene_m65F42CBF2499AAA4CAD0F181996248B1CB9E914E,
	AFPSCounter_Awake_m8B83738138B66339AF9E65646C94D13753D2DDDB,
	AFPSCounter_Start_m7EDDBD16A86E236A217488D86F052AA796FD99D5,
	AFPSCounter_Update_m6729648743EB953A01A9160CC03ED1837327C57E,
	AFPSCounter_OnLevelWasLoadedNew_m7FA557326BC065F0FAE5F83E62147CF561FF09F9,
	AFPSCounter_OnLevelLoadedCallback_mEA70846C38CAD3C3B8988C2F1946B8D902B64059,
	AFPSCounter_OnEnable_m4C614B23FEAB650C6A0D9733A7FD094A5A4740A0,
	AFPSCounter_OnDisable_m440B23337FFD0E14E1B0B25CB6DADFC93A0BBB2F,
	AFPSCounter_OnDestroy_mD51B182BA2F66F4F9A21B4EF7D025D3C436C74F1,
	AFPSCounter_MakeDrawableLabelDirty_mC69A00CD17F827610B99B5B56FA4599F705C7235,
	AFPSCounter_UpdateTexts_m4615BA3CEFD143BDC5FF31AB6EF3BE29DDD83608,
	AFPSCounter_ConfigureCanvas_mE2929F4CD52CAFE8FC5E12DB0FE67FD0452A4CFE,
	AFPSCounter_ConfigureLabels_mDD8AD5D440A2DF19A672BBD559AE13623428CBCD,
	AFPSCounter_DisposeInternal_mB6143DFC1BF978EEB9CF738B8787974BE18E943E,
	AFPSCounter_ProcessHotKey_mABE7B7E1E3A967A09210459D446BA23D58118C7F,
	AFPSCounter_CircleGestureMade_mFB0A43EFE4838B85AF9AC14E08392148B11F256D,
	AFPSCounter_SwitchCounter_m4D397CDB57146D6C4F88FFE6161F37D448C56DB1,
	AFPSCounter_ActivateCounters_m34DA74D2EEFE0FBC707E0C0B533AA8647015C443,
	AFPSCounter_DeactivateCounters_m4888302BB0CA2A7A9D24C9E83C03488B9E053C12,
	AFPSCounter_RefreshForcedFrameRate_mE0DCC065A416B13A5EEC6C41B34687E8E05BD5DB,
	AFPSCounter_RefreshForcedFrameRate_m48DEF4BDA5E42768AC6F19160C217B4E9F04C6ED,
	AFPSRenderRecorder_OnPreCull_m03B0C133CD6E408E925AE8E0A8B2ED53E3444B9F,
	AFPSRenderRecorder_OnPostRender_m7F026054A791EA575A094DFCD71004C9BAD5B447,
	AFPSRenderRecorder__ctor_m01D1679EB490DDFB5887AE93BDFEF5733F8849A8,
	CachedNumbers_ToStringLookup_m874AA28CC1DD3591D02E9385A9054D2614503C9C,
	CachedNumbers_AppendLookup_m1C8C702F5F0F594F2F1F9CE3960CE39F53FD2DB7,
	CachedNumbers_AppendLookup_mA043ADCA836B25E9ECAFC6CCD727B8D4BC5C0FFC,
	CachedNumbers_AppendLookup_mFBA88774EE7882CA127F7785EF4B727339E6DF76,
	CachedNumbers__cctor_m6E3D14BF3D05AD44A79D541028993308D6FFDBC3,
	UIUtils_ResetRectTransform_m81621830AA325D07663D772F955D5EBC7B8CC28A,
	UIUtils__ctor_mDDEF4C8AF620EBD49498C504DC0A37DECDA980A6,
	DrawableLabel__ctor_mC66608C93362955855FC69EC80EC1AED3487BA60,
	DrawableLabel_CheckAndUpdate_mF4B40592B517A250EAD810FD1C1673FDAE8E2142,
	DrawableLabel_Clear_m360F53B1609E9825D820AE05ED9B89AA530C9C68,
	DrawableLabel_Destroy_m2D5E8B65616392BBB3C1DBD084EABCE896F942E1,
	DrawableLabel_ChangeFont_mCBED015B24BFB01B03F823549586C761A5083471,
	DrawableLabel_ChangeFontSize_m0CF54CA5E31D52A2802FFFDD740AAA30984DF230,
	DrawableLabel_ChangeOffset_mF42912E6A9469DFEAABD0A1967F63EBD8C411918,
	DrawableLabel_ChangeLineSpacing_m0BE1F2B15B4F7BA66C9E41D2D12E3AA4ECED6099,
	DrawableLabel_ChangeBackground_m63C79858DFE39DA1E62A912651D52A212BA62FD4,
	DrawableLabel_ChangeBackgroundColor_m95DAE299E3FD5942EFA3CEE3D5ED27C260D9A6D2,
	DrawableLabel_ChangeBackgroundPadding_m241A7EB8875B7A4553E23DD905997CB688DDC748,
	DrawableLabel_ChangeShadow_m7A19B3947C222198595F441B8C3672D82013E097,
	DrawableLabel_ChangeShadowColor_mB330A41DF2C0A45E2B75CE17D3A170C5B9A5D1D6,
	DrawableLabel_ChangeShadowDistance_m511217DB8EE48403E7C9B27158A33D4D8CFA2750,
	DrawableLabel_ChangeOutline_mF919EBBD492F7B6733D98C23A17AAB8EEB45AE82,
	DrawableLabel_ChangeOutlineColor_m6A4C83343BA13F0C03AC4AC51733D8671F683113,
	DrawableLabel_ChangeOutlineDistance_mB0987F8A4DD711866C2A84197D019D5A4F71A6F6,
	DrawableLabel_UpdateTextPosition_m6379D1D7EEAAD01CF1D80BC1A9C828A5301F133E,
	DrawableLabel_NormalizeOffset_mE2C143FB22CE2F820F005EA645DF6063DC25F7D7,
	DrawableLabel_ApplyBackground_m1F1B5108D0C945FE1D20D35093FBFC0293736E2F,
	DrawableLabel_ApplyShadow_m69219D73BF1AB8C35603DE4FC7EDC2310B228305,
	DrawableLabel_ApplyOutline_m8C2A0757FB05A4434C22EBAE6C3902DF2EAF352E,
	DrawableLabel_ApplyFont_m8BD23047628EAA99F876F793AEB0111B8CE72322,
	LabelEffect__ctor_mBF98A97961C4ECC28EE4CCC4A3A58D1D835EA655,
	LabelEffect__ctor_mDC574AF0661D68903C2B65A175ABF2FB41EB172D,
	BaseCounterData_get_Enabled_mCE6C02FC29A3507F2839AD864C36AA9991ECCA69,
	BaseCounterData_set_Enabled_m6D84859FD1F2AF8C008D46DA424BB95B9C2F0F2E,
	BaseCounterData_get_Anchor_mB730844CD84018967D155DF8794DAA03398A7DBE,
	BaseCounterData_set_Anchor_m3D38369B40499AB0D8093E90ED8BC161F4262B6A,
	BaseCounterData_get_Color_mE2CD8365ECCA3147BFA085A9146E78FEC7EFC490,
	BaseCounterData_set_Color_mA481BCCA8DC98A8893BCBA537B22F582F8FF8397,
	BaseCounterData_get_Style_m9800563C6D72D152D5326D0DB409B7FF58F1387E,
	BaseCounterData_set_Style_mBF96D3D5FBF979E1D9C1324243A7A61A3D55CD7F,
	BaseCounterData_get_ExtraText_m5055EB58C09C71B843BB316EF29EDB13209AD729,
	BaseCounterData_set_ExtraText_m263FBB6F9804DE07D8D11906A5A20C91CD1598A9,
	BaseCounterData_Refresh_mDDB172CCBE6C5AFC37174F42949269490D64DBC1,
	BaseCounterData_UpdateValue_mDDB4304D4492A2A46EB0F28C4A98C19C8911B80D,
	NULL,
	BaseCounterData_Init_m82E1579FBC12C981C261E11F933FD5FBF1124FF8,
	BaseCounterData_Destroy_mC5AB0741DE461BFE2527B1CD0F3F84840EF07EF3,
	BaseCounterData_Activate_m2BE9D4570B7AC1AC094C3A6A52AD8994293693FB,
	BaseCounterData_Deactivate_m83B94FF102C5C14FAC6A9F7BFAD591F6FCA5287C,
	BaseCounterData_PerformInitActions_mCD8A7F827CEC0C6685B2FFE6650D7425FB5DBD1B,
	BaseCounterData_PerformActivationActions_m9CECE1A10E5C447DC598C396DFAD3D56C246FD6E,
	BaseCounterData_PerformDeActivationActions_m809C1825166442678A76676A9A772B670AA4D46B,
	NULL,
	NULL,
	BaseCounterData_ApplyTextStyles_m04893D5C643278E072C504D233087579886193AD,
	BaseCounterData__ctor_mBEA3D85FDCE56703BE080CFDAA24F1EFE12453D9,
	UpdatableCounterData_get_UpdateInterval_m3AB6F672A9D8D05F76C087AFC6E9FE1631789CC9,
	UpdatableCounterData_set_UpdateInterval_mE32E14C27DE8A2BB4351A18646BC861407D93FE9,
	UpdatableCounterData_PerformInitActions_m70FCF767225CC9E58836EF3F4BA1C6AADA01BF52,
	UpdatableCounterData_PerformDeActivationActions_mFF02982D491975F13158E984531C1999FBA87F98,
	NULL,
	UpdatableCounterData_StartUpdateCoroutine_m7E62E6A62EA83BE8B224C7698CEC967B52A98C32,
	UpdatableCounterData_StopUpdateCoroutine_m4CF0359A3756076100ACB53490FE44A9EFC24773,
	UpdatableCounterData__ctor_m1394C5615BB26CF154D97CBEF1C2449F78981E45,
	DeviceInfoCounterData_get_Platform_m017CBA4A4CDD3F2AB1B19308A8D8C3032B7BD0DA,
	DeviceInfoCounterData_set_Platform_mE6B0157BBB34019A640B32F15D43B7A2B006B782,
	DeviceInfoCounterData_get_CpuModel_m40BF570350E6CFBA26CFD1CCF87558F56A6A686F,
	DeviceInfoCounterData_set_CpuModel_m57EA85426464112F41BD9D6C1E14AD48D5E470CC,
	DeviceInfoCounterData_get_CpuModelNewLine_m361667B089B4CE2D4D9111F6F4C014C39CBBDD12,
	DeviceInfoCounterData_set_CpuModelNewLine_m3F4C700B3CC84B3882A47654C78CD671EE264EE3,
	DeviceInfoCounterData_get_GpuModel_mB1660E43B3FBCDBFEFD60F98D92E174D6C68B3C3,
	DeviceInfoCounterData_set_GpuModel_m078F9CF2CA5AE54D0A9515C627B03ACD7C60C498,
	DeviceInfoCounterData_get_GpuModelNewLine_m8FEB82B89B09F8B7C5E47FBE7CE14057A06012BC,
	DeviceInfoCounterData_set_GpuModelNewLine_m0D20B993AB7577C236BC7F48924DB5F5DAA361CB,
	DeviceInfoCounterData_get_GpuApi_m9593D818F6FE663FF715198FCE303950368C6278,
	DeviceInfoCounterData_set_GpuApi_m144D34998071A4203843256C61FE5F3C520897EB,
	DeviceInfoCounterData_get_GpuApiNewLine_m1B059735FDFFC72F6306EC0C6D2475F361984746,
	DeviceInfoCounterData_set_GpuApiNewLine_m880703910389A22D97DC64D147D7DAA3956C4AEA,
	DeviceInfoCounterData_get_GpuSpec_m5F396C83B7812E6F72AC7C1ECB32EB5E0FB0B91A,
	DeviceInfoCounterData_set_GpuSpec_m6B57C03B8F4F91220198DFD0DF4C55F8D9CD4C1D,
	DeviceInfoCounterData_get_GpuSpecNewLine_m0AB0E2DC1A7699DB9083F2F0165104B8DC67A708,
	DeviceInfoCounterData_set_GpuSpecNewLine_mA89F2052A26454F34D68551B3F721CD108B235C3,
	DeviceInfoCounterData_get_RamSize_m1967659DD4488E9600B8AAF4FC3D1160F86E22C6,
	DeviceInfoCounterData_set_RamSize_m28111203323B34DC25C1BAF3DA8E0587CB5E0F6F,
	DeviceInfoCounterData_get_RamSizeNewLine_mE867B4DC7810DC9FF4CAD8C63601895450BA57B8,
	DeviceInfoCounterData_set_RamSizeNewLine_m8CECF583D17AE9844BA0B6C9C241EB56BF3DD31C,
	DeviceInfoCounterData_get_ScreenData_m4FF126F032515B276FABF43B0FEAB5B9542172DC,
	DeviceInfoCounterData_set_ScreenData_m2740BDE8E7C27D0EDB1A8EA9BE14726677A8AC6F,
	DeviceInfoCounterData_get_ScreenDataNewLine_m7AD3CDCE799D9B0A28C2A1C7CE3C4B6E06B0BBD4,
	DeviceInfoCounterData_set_ScreenDataNewLine_m47C1FCFBA96815638B75B7F02DD2537D68E84DFB,
	DeviceInfoCounterData_get_DeviceModel_mFD9DF4B197209E31648E225EFA5975721C4008B0,
	DeviceInfoCounterData_set_DeviceModel_mFFA202BA5C922E18B6C0A2ECAB43F2C15D3EF423,
	DeviceInfoCounterData_get_DeviceModelNewLine_mEAA79D861DE8B26CE8D2E0A8C19380C9117ECCDC,
	DeviceInfoCounterData_set_DeviceModelNewLine_m3EEEF2F64B02B4C8E978F523552F4C9093434CFE,
	DeviceInfoCounterData_get_LastValue_mBF5DB5DE6A8F8A58C45F8AE7DBAA172D0ED93F84,
	DeviceInfoCounterData_set_LastValue_m461D44BE044B7BE8B6A4E6748D6B27898547723D,
	DeviceInfoCounterData__ctor_mD412BAA57075C3C09CD1B44750C3BDE1481F15A8,
	DeviceInfoCounterData_UpdateValue_m841067C9DB4FB83F876E0412CDEE12A07B9DDAF7,
	DeviceInfoCounterData_HasData_m1B73320008BDFB065C20B16E51C0FD39CD62FC03,
	DeviceInfoCounterData_CacheCurrentColor_m557BF2F061736F269943BDB6D885BDB6C085332C,
	FPSCounterData_add_OnFPSLevelChange_m7585CDC194A6928D8DBCDF971A593C92737C648E,
	FPSCounterData_remove_OnFPSLevelChange_mD231157491CAE742FEC17BE3BB52B399715B29BD,
	FPSCounterData_get_RealtimeFPS_mBD46DCC15D876C8ADFC8FD8B60E6EB5176ED124A,
	FPSCounterData_set_RealtimeFPS_mB6CFC7BF7E78C1F96F0500DB4269F80097DB5A15,
	FPSCounterData_get_Milliseconds_mAED803B889B76DCFF34BBED0471D2626E0E7F10F,
	FPSCounterData_set_Milliseconds_m412AC8AA6634941AFDBD572F6EB5C5B52832104F,
	FPSCounterData_get_Average_m201622A0C48860DF263EE87A220969FA0249AEA7,
	FPSCounterData_set_Average_mF727E43B57274692A2344F6E674500793B7D1859,
	FPSCounterData_get_AverageMilliseconds_m32B0AFAD501769417AC80D3816420DCBB07B985A,
	FPSCounterData_set_AverageMilliseconds_mD11099D5DCE3BD9F0A37507752E8FB54849047AD,
	FPSCounterData_get_AverageNewLine_m93A7ECB57DD0E9E8BB1B1CAE0C26381C716903FA,
	FPSCounterData_set_AverageNewLine_m579FA5E435BDB5AFA57D1097238A6160E2D2AD72,
	FPSCounterData_get_AverageSamples_m4C85A2EB0DD5041BD9114D7172FE13CD9FA44EFB,
	FPSCounterData_set_AverageSamples_mB5F36EC428D73DDDA965C10BDA0D731EF09AD2C7,
	FPSCounterData_get_MinMax_m6F3B4FA06836A9776B90FCCF13B5D64F3C330D04,
	FPSCounterData_set_MinMax_mE490075353D00A92C90C123EABFE1164C3E3A45A,
	FPSCounterData_get_MinMaxMilliseconds_m915F44EC51D1DCA63DA4984CBFD6905270AC10D1,
	FPSCounterData_set_MinMaxMilliseconds_mB6FAEA26369A1AD95BC068446E31D90506F737C0,
	FPSCounterData_get_MinMaxNewLine_m16C9504F57DFB716BAE901F436872BCF27A5C1C1,
	FPSCounterData_set_MinMaxNewLine_mA3EB09735E5B6D1B656332EBAF9F635F0BBB403A,
	FPSCounterData_get_MinMaxTwoLines_mBD3EA827B415A15E5D2433F665020146AC1EA0F5,
	FPSCounterData_set_MinMaxTwoLines_m5BA0A778034BD53FCA6F00E56854C785F04ECA84,
	FPSCounterData_get_Render_m0885B41F9FDECEDC486BD98352E2D9308FAA8B5E,
	FPSCounterData_set_Render_mAFDD188A468510624409190556F47F238E004384,
	FPSCounterData_get_RenderNewLine_m5889E0319FCFA2D094909A26CB8DFFABD50EA6A3,
	FPSCounterData_set_RenderNewLine_m53FFF25C4E633F26B67F6974A7DFB2AC1B8D8F14,
	FPSCounterData_get_RenderAutoAdd_mC44A1ED59065A8A562E160C991335451E80A0DA9,
	FPSCounterData_set_RenderAutoAdd_m480610443C01288657995BEFAEC761EBC5BF3A69,
	FPSCounterData_get_ColorWarning_m360523333AC6DDD562D5C757CD40B4B9DF388978,
	FPSCounterData_set_ColorWarning_mB53D394580014AA8B5F128A73C2D68A253D6BBE9,
	FPSCounterData_get_ColorCritical_m4EF384BC88234387C39374A412C36933E70A5C0C,
	FPSCounterData_set_ColorCritical_mD31F4A354D53C1BE4F5C8477E52D990339E04468,
	FPSCounterData_get_ColorRender_mC0253E52EBFF3692D3BF14B20002C051EF9C28C2,
	FPSCounterData_set_ColorRender_mA578FD848ABA6E0115EA7B2E3F316AC71CAD4E60,
	FPSCounterData_get_LastValue_m39CA894A3E874CC1B71C9F1AE493BE754C466D0A,
	FPSCounterData_set_LastValue_m0563BD6D231C4A587354CC29C11A5BC36AD632B3,
	FPSCounterData_get_LastMillisecondsValue_m922B8E6DF8C707420D28F5C4002B0264A9C658CB,
	FPSCounterData_set_LastMillisecondsValue_mE67A01A5592A4BBFDE59D74D40BB92FED6C44FD8,
	FPSCounterData_get_LastRenderValue_m2766C4B231755458C04607E9E0ED811B6C2F00C1,
	FPSCounterData_set_LastRenderValue_mC0FBAA0A34FF9A8F388F3D08A8A9FF198A1D81A1,
	FPSCounterData_get_LastAverageValue_m00CAB1D9063E9138E39B0BE0391244A43CEADA68,
	FPSCounterData_set_LastAverageValue_m64918AE4A95CEC0B6FF368B1E0E8980E1B528459,
	FPSCounterData_get_LastAverageMillisecondsValue_m197762D13BAD8DC3A1132EFEAEE010E135F7D0FB,
	FPSCounterData_set_LastAverageMillisecondsValue_mFCCD3FC93BC678EE6692D9E4DBDB36CC9F306FDC,
	FPSCounterData_get_LastMinimumValue_mA5D56209FAC6735B25B121280493F4F91365ECF8,
	FPSCounterData_set_LastMinimumValue_m7CB562861E8FD7EFE38F521787AED0785D830EAA,
	FPSCounterData_get_LastMaximumValue_m6F66B92422B5488E16FA012964DE33F2F3A2B8BD,
	FPSCounterData_set_LastMaximumValue_m3161C0C6D289880D86E774520B5823A299B91C8C,
	FPSCounterData_get_LastMinMillisecondsValue_m45FA26E32AAE674308AA61CB4BD9E45F0B508988,
	FPSCounterData_set_LastMinMillisecondsValue_mE65A3B7CAC66633F057FBA5E230394056C2E2317,
	FPSCounterData_get_LastMaxMillisecondsValue_mA9CAF13FEB2B3D8D5E3920AC14C43B0E1B0F4F8A,
	FPSCounterData_set_LastMaxMillisecondsValue_m42829B94916C24D71B5D230825B953C3F50F1B7D,
	FPSCounterData_get_CurrentFpsLevel_m463F5E4468FC5E4332B2D6C77F0C00517E9C82EA,
	FPSCounterData_set_CurrentFpsLevel_m4B1411AE8CA69C8656F5FAF8277DDEFBE48295B9,
	FPSCounterData__ctor_m754F045BF9CB506FA16A5799D5F2A56FA84B0701,
	FPSCounterData_ResetAverage_m3BC1CC7F2EAC545724AEE5CBF4E3080C5F1735F5,
	FPSCounterData_ResetMinMax_m74B0C068B21016F173151830061A0C285F939383,
	FPSCounterData_OnLevelLoadedCallback_mC359DABBE419B124F839628100F64328511D102B,
	FPSCounterData_AddRenderTime_mA394B787687F183D6B14E6086FAA47E9B1FC8CF3,
	FPSCounterData_UpdateValue_m6284DEE2CD58FE628D79CD1F9272E2D5F4B50322,
	FPSCounterData_PerformActivationActions_m8EBA9D98C239C575AC378C80648BE97A24FCBC3A,
	FPSCounterData_PerformDeActivationActions_mFACC0BD50B3C3CCAF1C568DEAFBABE12464FDCC7,
	FPSCounterData_UpdateCounter_mE219B1F1D671D3711059185761267A118A1E5676,
	FPSCounterData_HasData_mB349675A62E5E9624025101BB582299FD8AD3BF9,
	FPSCounterData_CacheCurrentColor_mC6E20B5A46621C75F26A2EC363E4F074542CB130,
	FPSCounterData_CacheWarningColor_mCBCD7BC25AADA85E0637019894CEFFF9883DA48C,
	FPSCounterData_CacheCriticalColor_mB5DA038566F3789E4AF666D5D998E72AB4D60721,
	FPSCounterData_GetAverageFromAccumulatedSamples_mDBF340F83AB59EB86F6A08BA33060BCB63541E19,
	FPSCounterData_TryToAddRenderRecorder_mEECDEE1E013DA4EF86695052B49C69B8BE522BAF,
	FPSCounterData_TryToRemoveRenderRecorder_mB9D188E702DDBADC00451AC43F2C29F4BF103747,
	MemoryCounterData_get_Precise_m5D1643FEB81798E7462763301B21C0A2F18C3BD0,
	MemoryCounterData_set_Precise_m2F3EC102D54F95D9784C83CD9E04BF0B2E9E0C55,
	MemoryCounterData_get_Total_mC3B79CE65394A8D3B1A06AA5908A5CDC00BB8DFB,
	MemoryCounterData_set_Total_mFC96803584D8BC207CDAB9518896023D948CED9C,
	MemoryCounterData_get_Allocated_m93C09D6DECD4822472BD7B2ECCE8E2A39CEECC6D,
	MemoryCounterData_set_Allocated_m93B94D3770B3E370300BFC0ED48EFECF4F19D94F,
	MemoryCounterData_get_MonoUsage_mE610658F234B8147369D9096D4E3D3CA90F7E855,
	MemoryCounterData_set_MonoUsage_m23E13002E78331227E1EEE3D5FDF625FFE047BBE,
	MemoryCounterData_get_Gfx_m5F71EA66B668E07EE8F9C3DCD42E25307EA9BA65,
	MemoryCounterData_set_Gfx_m8ECE8704AC39B4306375A7DF2C6E414BCC0BDCA8,
	MemoryCounterData_get_LastTotalValue_mC3FA6D93FAA711C4DF036433D402549840C48470,
	MemoryCounterData_set_LastTotalValue_mACB28C8F1462CEE2BA3A7025D96FAB6EBAC33DCA,
	MemoryCounterData_get_LastAllocatedValue_m04179F2A2411345C34C2E288525D21DD311C8EF9,
	MemoryCounterData_set_LastAllocatedValue_m22DD873AB4437050253CCDBDA68C57B7FEF15C32,
	MemoryCounterData_get_LastMonoValue_mD473805AC6C76B55FE906516034D3B755942EA9F,
	MemoryCounterData_set_LastMonoValue_m1B163B304D9D8F99BA638E19012AFADA7518D667,
	MemoryCounterData_get_LastGfxValue_mA1F4607105F5424C8D0A33AF2DD4430C7F1F4094,
	MemoryCounterData_set_LastGfxValue_mDBFBC87ECE94678BB5ADFD128A246E1D950ADD67,
	MemoryCounterData__ctor_m84637F746FF1B81581645C75A0654520D1D8417F,
	MemoryCounterData_UpdateValue_mC2ECC67FDF37AD6F4BB563E439C7A6056BEACCED,
	MemoryCounterData_PerformActivationActions_mA145517DC2422898BB5EC5F788FDB8AD3458CF56,
	MemoryCounterData_PerformDeActivationActions_m29AC51AF1E311FA7A66C2F36199A0B298C4609A0,
	MemoryCounterData_UpdateCounter_m843E7A64DAC22D9F33CAC644239336D0808CFE6B,
	MemoryCounterData_HasData_m0DD3A405B790AF0DA21773862657303BC16406AB,
	MemoryCounterData_CacheCurrentColor_m67BCCE53C36916E28D413338DB90D43C32E09E5B,
	U3CShowBannerWhenInitializedU3Ed__5__ctor_mA88EAE8C984717338C2878F95EB55B8DCAE33F26,
	U3CShowBannerWhenInitializedU3Ed__5_System_IDisposable_Dispose_mFC1D58F2F3B15F569923387609A4A6364F6D1441,
	U3CShowBannerWhenInitializedU3Ed__5_MoveNext_m0069192D726CB966FF7C417E2C46C022CB95A67C,
	U3CShowBannerWhenInitializedU3Ed__5_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m78D172B313675722DCCDDAF745FB62EAE97BF726,
	U3CShowBannerWhenInitializedU3Ed__5_System_Collections_IEnumerator_Reset_mFA252E29C63DC1B3320FB55AC07FAC066FFBE328,
	U3CShowBannerWhenInitializedU3Ed__5_System_Collections_IEnumerator_get_Current_mF5C066EF95515B4E2DD38C4139FC4C52A8705B6C,
	U3CShowBannerWhenInitializedU3Ed__4__ctor_mD73E44C0243C69C4599459C4D562146A6A57E539,
	U3CShowBannerWhenInitializedU3Ed__4_System_IDisposable_Dispose_m5CF45BD21A14FE3615504B8AA01308C4C6B94D28,
	U3CShowBannerWhenInitializedU3Ed__4_MoveNext_mB55F1BA8591B14C8754DEC4B598C042731549612,
	U3CShowBannerWhenInitializedU3Ed__4_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m8B6332F0D0D4B37EC68C4F0F0C4D92190C6A770E,
	U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_Reset_m9A7D3DECACF5FEC4B02349B56EE620D5F08913DF,
	U3CShowBannerWhenInitializedU3Ed__4_System_Collections_IEnumerator_get_Current_m87DE22D9156CA19C6CD47214B7FE08DD417340A2,
	U3CExampleCoroutineU3Ed__34__ctor_mC506945B0390F81DACDD1DAB824FC88D3F3149AF,
	U3CExampleCoroutineU3Ed__34_System_IDisposable_Dispose_mDD49C433332AFB8593053903EEFCA7140C3D7EE1,
	U3CExampleCoroutineU3Ed__34_MoveNext_m8D88167669EB21EF9AA6F85F102C51D7ABA5A0DB,
	U3CExampleCoroutineU3Ed__34_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mA2192D2D4E742050B2B9A0691539170715660BC1,
	U3CExampleCoroutineU3Ed__34_System_Collections_IEnumerator_Reset_m542AFC9D999F08380138158C01DF39ECEBD6962B,
	U3CExampleCoroutineU3Ed__34_System_Collections_IEnumerator_get_Current_m0EB2D7E0EB3721883F1699F0642D1E5B1CC01A77,
	U3CUpdateCounterU3Ed__151__ctor_mF5F3418D0DC6964868A5372983FEE83196DC0F59,
	U3CUpdateCounterU3Ed__151_System_IDisposable_Dispose_m6CD3CF8E44532CEF678B24641F8E2C1C848093DD,
	U3CUpdateCounterU3Ed__151_MoveNext_m6861156104B6349925476103F01B51CCB531721B,
	U3CUpdateCounterU3Ed__151_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_mB371302E75CE1B142F88BED56C239A3841CA4BEC,
	U3CUpdateCounterU3Ed__151_System_Collections_IEnumerator_Reset_m3A5EFF1CF0A101DBCF1AB67834086FCA2B11A33F,
	U3CUpdateCounterU3Ed__151_System_Collections_IEnumerator_get_Current_m7D0B4BB248BFCC7A4CE1E37223BF5E232F0646E7,
	U3CUpdateCounterU3Ed__48__ctor_m1AE440D5F8067F0C9CD2DB32337887D124AE12E9,
	U3CUpdateCounterU3Ed__48_System_IDisposable_Dispose_m019A4B31FEA587F323FF2192DBCCAE552CF5D0B8,
	U3CUpdateCounterU3Ed__48_MoveNext_m62FA9C5D8F4361846B77789E28E40BA82B9CEFE8,
	U3CUpdateCounterU3Ed__48_System_Collections_Generic_IEnumeratorU3CSystem_ObjectU3E_get_Current_m1602D234FADE2A2EE994831AF5E79614BAFC463B,
	U3CUpdateCounterU3Ed__48_System_Collections_IEnumerator_Reset_m1BC14925698F9D3424B4E758A6230A61A992EC57,
	U3CUpdateCounterU3Ed__48_System_Collections_IEnumerator_get_Current_m983C3345D2C76D37903FBE2FA708D29E55E1329F,
};
static const int32_t s_InvokerIndices[523] = 
{
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	23,
	23,
	23,
	26,
	23,
	26,
	31,
	23,
	27,
	1439,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	338,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	1849,
	23,
	23,
	26,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	26,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	32,
	27,
	31,
	23,
	338,
	338,
	23,
	23,
	23,
	26,
	26,
	26,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	1946,
	23,
	23,
	23,
	23,
	1342,
	23,
	23,
	14,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	14,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	23,
	23,
	46,
	89,
	31,
	23,
	26,
	23,
	23,
	23,
	23,
	26,
	23,
	23,
	23,
	28,
	14,
	1344,
	1344,
	1329,
	23,
	23,
	2102,
	23,
	38,
	14,
	136,
	23,
	3,
	26,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	23,
	23,
	23,
	1460,
	2103,
	2104,
	23,
	89,
	89,
	31,
	89,
	31,
	10,
	32,
	89,
	31,
	1329,
	1330,
	10,
	32,
	89,
	31,
	1329,
	1330,
	1354,
	1355,
	89,
	31,
	1329,
	1330,
	1354,
	1355,
	89,
	31,
	728,
	338,
	14,
	26,
	10,
	32,
	728,
	338,
	10,
	32,
	1354,
	1355,
	89,
	31,
	10,
	32,
	23,
	4,
	159,
	823,
	4,
	823,
	3,
	3,
	2105,
	823,
	23,
	23,
	23,
	1946,
	23,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	23,
	23,
	89,
	23,
	23,
	23,
	23,
	31,
	23,
	23,
	23,
	2106,
	115,
	368,
	2107,
	3,
	159,
	23,
	2108,
	23,
	23,
	23,
	26,
	32,
	1355,
	338,
	31,
	1330,
	32,
	31,
	1330,
	1355,
	31,
	1330,
	1355,
	23,
	23,
	23,
	23,
	23,
	23,
	2109,
	2110,
	89,
	31,
	89,
	31,
	1329,
	1330,
	10,
	32,
	14,
	26,
	23,
	23,
	31,
	26,
	23,
	23,
	23,
	23,
	23,
	23,
	89,
	23,
	23,
	23,
	728,
	338,
	23,
	23,
	14,
	23,
	23,
	23,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	14,
	26,
	23,
	31,
	89,
	23,
	26,
	26,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	10,
	32,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	1329,
	1330,
	1329,
	1330,
	1329,
	1330,
	10,
	32,
	728,
	338,
	728,
	338,
	10,
	32,
	728,
	338,
	10,
	32,
	10,
	32,
	728,
	338,
	728,
	338,
	89,
	31,
	23,
	23,
	31,
	23,
	338,
	31,
	23,
	23,
	14,
	89,
	23,
	23,
	23,
	728,
	3,
	3,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	89,
	31,
	177,
	204,
	177,
	204,
	177,
	204,
	177,
	204,
	23,
	31,
	23,
	23,
	14,
	89,
	23,
	32,
	23,
	89,
	14,
	23,
	14,
	32,
	23,
	89,
	14,
	23,
	14,
	32,
	23,
	89,
	14,
	23,
	14,
	32,
	23,
	89,
	14,
	23,
	14,
	32,
	23,
	89,
	14,
	23,
	14,
};
extern const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule;
const Il2CppCodeGenModule g_AssemblyU2DCSharpCodeGenModule = 
{
	"Assembly-CSharp.dll",
	523,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	0,
	NULL,
	0,
	NULL,
	0,
	NULL,
	NULL,
};
