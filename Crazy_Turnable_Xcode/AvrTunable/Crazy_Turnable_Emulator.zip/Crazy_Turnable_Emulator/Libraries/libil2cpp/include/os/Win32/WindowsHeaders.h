#pragma once

#if IL2CPP_TARGET_WINDOWS || IL2CPP_TARGET_WINDOWS_GAMES

#include "../c-api/Win32/WindowsHeaders.h"

#endif
