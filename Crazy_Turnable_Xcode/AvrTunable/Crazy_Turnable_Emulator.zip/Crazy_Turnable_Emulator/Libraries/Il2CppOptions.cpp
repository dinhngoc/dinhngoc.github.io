bool il2cpp_no_exceptions = false;
extern "C" bool Unity_il2cppNoExceptions() { return il2cpp_no_exceptions; }
