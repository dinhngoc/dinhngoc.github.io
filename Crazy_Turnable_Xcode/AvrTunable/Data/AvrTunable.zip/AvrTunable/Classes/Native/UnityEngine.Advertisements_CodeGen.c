﻿#include "il2cpp-config.h"

#ifndef _MSC_VER
# include <alloca.h>
#else
# include <malloc.h>
#endif



#include "codegen/il2cpp-codegen-metadata.h"



extern const RuntimeMethod* IosBanner_UnityAdsBannerClick_m64AE141B67AC8303DCB6074D65BDDEDEAD483AEF_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidError_mBEE10F30BF7C0ADE11902976DF5F271D11778D58_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidHide_m388BF2978CA575D09935957B1D33AA329BEFF628_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidLoad_mE6E3534E4C772FFF746ADD4D3C99818C23B5E12D_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidShow_m3120A02395BCBF393FA6D6CA0E338FC035A3AC83_RuntimeMethod_var;
extern const RuntimeMethod* IosBanner_UnityAdsBannerDidUnload_m37C9378F35879F763BD7DF4326010DBADA94E706_RuntimeMethod_var;
extern const RuntimeMethod* IosInitializationListener_OnInitializationComplete_m5C1D21F520E9041AEB12472927EAD7880EE8F723_RuntimeMethod_var;
extern const RuntimeMethod* IosInitializationListener_OnInitializationFailed_m20705DB3847A26369E1BECDE24515EC935FC18BE_RuntimeMethod_var;
extern const RuntimeMethod* IosLoadListener_OnLoadFailure_mE48F1E2C64E55357454B5F38691F712A05AEC408_RuntimeMethod_var;
extern const RuntimeMethod* IosLoadListener_OnLoadSuccess_mACCFA237ACF117DBC6DCFBCA5FA893FA150D893E_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsDidError_m1FD041ADCF92A2FC629260C81EE5553519D66BC7_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsDidFinish_m22B0654A8F7A3FE1FC148A257565711E0B59DEB8_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsDidStart_m42C9E6831D166DE71597242632BB487A85BD769B_RuntimeMethod_var;
extern const RuntimeMethod* IosPlatform_UnityAdsReady_mA9E4CF6B2D5E3221AC2C620D458C119F3EDC64FA_RuntimeMethod_var;
extern const RuntimeMethod* IosShowListener_OnShowClick_m08D50F89BA9E45F3047B4D5BD497E38741939B08_RuntimeMethod_var;
extern const RuntimeMethod* IosShowListener_OnShowComplete_m233B64E74571ADCD363EECB90C7A42A91D30027E_RuntimeMethod_var;
extern const RuntimeMethod* IosShowListener_OnShowFailure_m1F449F5BA0EFA79DCD526B4AFA4FEC23611DC737_RuntimeMethod_var;
extern const RuntimeMethod* IosShowListener_OnShowStart_mE42C6FD6E21AFC9BBBDCD99B272DEF7FC375E494_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mC4F34F7E115EBACCBF488E35161B3765379754BF_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m56F70A02157D109E98C81C22262686A560A479FC_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mD96F20497B37585C57677515C6B671F4A1DC1227_RuntimeMethod_var;
extern const RuntimeMethod* PurchasingPlatform_UnityAdsPurchasingInitialize_m4004786A5894AF8350718CDC9346426D0E09619C_RuntimeMethod_var;


IL2CPP_EXTERN_C_BEGIN
IL2CPP_EXTERN_C_END




// 0x00000001 System.Void UnityEngine.Advertisements.Advertisement::.cctor()
extern void Advertisement__cctor_m52E1D772906D0B337709705DB5DF0E48C9B1D6F7 (void);
// 0x00000002 System.Boolean UnityEngine.Advertisements.Advertisement::get_isInitialized()
extern void Advertisement_get_isInitialized_m1C01B43E06433CFDE61A692463DA4447BDC98407 (void);
// 0x00000003 System.Boolean UnityEngine.Advertisements.Advertisement::get_isSupported()
extern void Advertisement_get_isSupported_m7DB9D5062BE0F832C8A0A2F3DC3952C46439C468 (void);
// 0x00000004 System.Boolean UnityEngine.Advertisements.Advertisement::get_debugMode()
extern void Advertisement_get_debugMode_m62CE2552DD4667FFC13E22DBFC36F8500B5F18E7 (void);
// 0x00000005 System.Void UnityEngine.Advertisements.Advertisement::set_debugMode(System.Boolean)
extern void Advertisement_set_debugMode_mEAFCF663B855FC7BD6A0A7A4BA0B31D597C18DC6 (void);
// 0x00000006 System.String UnityEngine.Advertisements.Advertisement::get_version()
extern void Advertisement_get_version_m39B6859A9BE15054B8A32E2FCFCC0B53777A8EDB (void);
// 0x00000007 System.Boolean UnityEngine.Advertisements.Advertisement::get_isShowing()
extern void Advertisement_get_isShowing_m161300800925F8FE0BC8B055A2329D850534BD27 (void);
// 0x00000008 System.Void UnityEngine.Advertisements.Advertisement::Initialize(System.String)
extern void Advertisement_Initialize_m6B5635CB28DC096033005BCECF5B06BFCED325E8 (void);
// 0x00000009 System.Void UnityEngine.Advertisements.Advertisement::Initialize(System.String,System.Boolean)
extern void Advertisement_Initialize_m5839818AF61B8E2F8A8C4081E75EE06904FB9281 (void);
// 0x0000000A System.Void UnityEngine.Advertisements.Advertisement::Initialize(System.String,System.Boolean,System.Boolean)
extern void Advertisement_Initialize_m68FFB59A47D1D45BE72D93F9C40DA993912CA83E (void);
// 0x0000000B System.Void UnityEngine.Advertisements.Advertisement::Initialize(System.String,System.Boolean,System.Boolean,UnityEngine.Advertisements.IUnityAdsInitializationListener)
extern void Advertisement_Initialize_m2451DC90D17F25AE331E6B0269E6B6E9F417F85E (void);
// 0x0000000C System.Boolean UnityEngine.Advertisements.Advertisement::IsReady()
extern void Advertisement_IsReady_m86E4F1FFA66A61CB90CE53EAE5134A1DEA62EB69 (void);
// 0x0000000D System.Boolean UnityEngine.Advertisements.Advertisement::IsReady(System.String)
extern void Advertisement_IsReady_mB0C468846BA1EB6F79E0975E6F576040BCBF8D71 (void);
// 0x0000000E System.Void UnityEngine.Advertisements.Advertisement::Load(System.String)
extern void Advertisement_Load_mF08D6827C3C696CC96913A648B6DA2176D89C7A9 (void);
// 0x0000000F System.Void UnityEngine.Advertisements.Advertisement::Load(System.String,UnityEngine.Advertisements.IUnityAdsLoadListener)
extern void Advertisement_Load_mBA07C0E271CA4E868C1F149061FD8AFA6C3E6356 (void);
// 0x00000010 System.Void UnityEngine.Advertisements.Advertisement::Show()
extern void Advertisement_Show_m31F94834C933936AEFE8F77417B26D73E0E64DAA (void);
// 0x00000011 System.Void UnityEngine.Advertisements.Advertisement::Show(UnityEngine.Advertisements.ShowOptions)
extern void Advertisement_Show_m831A92003168618ED42FBBBB114DAEEE3EEE2515 (void);
// 0x00000012 System.Void UnityEngine.Advertisements.Advertisement::Show(System.String)
extern void Advertisement_Show_m357F8ACFF0830636134E30309DC55ABA34A5855C (void);
// 0x00000013 System.Void UnityEngine.Advertisements.Advertisement::Show(System.String,UnityEngine.Advertisements.ShowOptions)
extern void Advertisement_Show_m88B56E134E3A966BFFAF5CCC812733975EDD72DD (void);
// 0x00000014 System.Void UnityEngine.Advertisements.Advertisement::Show(System.String,UnityEngine.Advertisements.IUnityAdsShowListener)
extern void Advertisement_Show_m743B10BD30AAC81286F342A86202F9667179E2DD (void);
// 0x00000015 System.Void UnityEngine.Advertisements.Advertisement::Show(System.String,UnityEngine.Advertisements.ShowOptions,UnityEngine.Advertisements.IUnityAdsShowListener)
extern void Advertisement_Show_m8F157B553AF2B1A71F1D9F2E65634E6E5F7102FA (void);
// 0x00000016 System.Void UnityEngine.Advertisements.Advertisement::SetMetaData(UnityEngine.Advertisements.MetaData)
extern void Advertisement_SetMetaData_m7D525ADE1551BCF6AA50C65975ECEC17AA2D5C1C (void);
// 0x00000017 System.Void UnityEngine.Advertisements.Advertisement::AddListener(UnityEngine.Advertisements.IUnityAdsListener)
extern void Advertisement_AddListener_mE65054284863005B98668C5BBE3DE9717B8323BA (void);
// 0x00000018 System.Void UnityEngine.Advertisements.Advertisement::RemoveListener(UnityEngine.Advertisements.IUnityAdsListener)
extern void Advertisement_RemoveListener_m1F85A647140B0C8EAEF19F511D7D8699A1628F8B (void);
// 0x00000019 UnityEngine.Advertisements.PlacementState UnityEngine.Advertisements.Advertisement::GetPlacementState()
extern void Advertisement_GetPlacementState_mEC09D916B7DC457BAE7BAC3197046E3BCE1DE9F2 (void);
// 0x0000001A UnityEngine.Advertisements.PlacementState UnityEngine.Advertisements.Advertisement::GetPlacementState(System.String)
extern void Advertisement_GetPlacementState_m90F6F5095AB56EF764384E863CBA9DF6CBF2B5BC (void);
// 0x0000001B UnityEngine.Advertisements.Platform.IPlatform UnityEngine.Advertisements.Advertisement::CreatePlatform()
extern void Advertisement_CreatePlatform_m6CEDF37CB020DCD5F67C3A2C4EADD4946D5C073D (void);
// 0x0000001C System.Boolean UnityEngine.Advertisements.Advertisement::IsSupported()
extern void Advertisement_IsSupported_m22D58DAFCF06EE34A28FCA70F3F83F0EB3C1B43E (void);
// 0x0000001D UnityEngine.Advertisements.Utilities.IUnityLifecycleManager UnityEngine.Advertisements.Banner::get_UnityLifecycleManager()
extern void Banner_get_UnityLifecycleManager_mE30C2332D59DFEE93636C03DB17377D2A5038087 (void);
// 0x0000001E System.Boolean UnityEngine.Advertisements.Banner::get_IsLoaded()
extern void Banner_get_IsLoaded_mD03A5A558F590B78747BEEC6D6674DEC561C0E36 (void);
// 0x0000001F System.Boolean UnityEngine.Advertisements.Banner::get_ShowAfterLoad()
extern void Banner_get_ShowAfterLoad_m59F9227CC72DFA2A534212325337CCB030FB7558 (void);
// 0x00000020 System.Void UnityEngine.Advertisements.Banner::set_ShowAfterLoad(System.Boolean)
extern void Banner_set_ShowAfterLoad_m3C4AB777B09A8AA1E112679A6D1113405D6B432A (void);
// 0x00000021 System.Void UnityEngine.Advertisements.Banner::.ctor(UnityEngine.Advertisements.INativeBanner,UnityEngine.Advertisements.Utilities.IUnityLifecycleManager)
extern void Banner__ctor_m0116AAD0DE60B0E60216407F52CEF792AB380D37 (void);
// 0x00000022 System.Void UnityEngine.Advertisements.Banner::Load(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void Banner_Load_m0BFAA399533961215AE11B6FFD9F973022BC68D8 (void);
// 0x00000023 System.Void UnityEngine.Advertisements.Banner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_Show_mB82FF1D83E3F90C59B1719D312757E7C73A89FEA (void);
// 0x00000024 System.Void UnityEngine.Advertisements.Banner::Hide(System.Boolean)
extern void Banner_Hide_m040995248E0D5110F09C273D76D40989C7DCBB79 (void);
// 0x00000025 System.Void UnityEngine.Advertisements.Banner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void Banner_SetPosition_mF0CD74BA344244E2298032F8E05A93CCB39DBBED (void);
// 0x00000026 System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidShow(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_UnityAdsBannerDidShow_m258EACA558D69B70E0E2AB1A5BDCC0C3BCA3CE9C (void);
// 0x00000027 System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidHide(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_UnityAdsBannerDidHide_m2DFE26934F52C9C8781195BE0FC4F60399176AA4 (void);
// 0x00000028 System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerClick(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_UnityAdsBannerClick_mC5C8D932B671A20761FEFA9F591C86E5B0023554 (void);
// 0x00000029 System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidLoad(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void Banner_UnityAdsBannerDidLoad_m8EEA613C407B219FC2D571B9180B0609B62DB50D (void);
// 0x0000002A System.Void UnityEngine.Advertisements.Banner::UnityAdsBannerDidError(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void Banner_UnityAdsBannerDidError_mC4FA738D90B18288EAF2D7049FC4C3CCF62B83E2 (void);
// 0x0000002B UnityEngine.Advertisements.BannerLoadOptions/LoadCallback UnityEngine.Advertisements.BannerLoadOptions::get_loadCallback()
extern void BannerLoadOptions_get_loadCallback_m37677430405266FBE17C65136F61E5EF087C2172 (void);
// 0x0000002C System.Void UnityEngine.Advertisements.BannerLoadOptions::set_loadCallback(UnityEngine.Advertisements.BannerLoadOptions/LoadCallback)
extern void BannerLoadOptions_set_loadCallback_m45A71D4B6725AFBA65DA59F7247A3FC5EBB6C7FD (void);
// 0x0000002D UnityEngine.Advertisements.BannerLoadOptions/ErrorCallback UnityEngine.Advertisements.BannerLoadOptions::get_errorCallback()
extern void BannerLoadOptions_get_errorCallback_m5AC99A074E22CAC9C4A22955FF1CD6636C386084 (void);
// 0x0000002E System.Void UnityEngine.Advertisements.BannerLoadOptions::set_errorCallback(UnityEngine.Advertisements.BannerLoadOptions/ErrorCallback)
extern void BannerLoadOptions_set_errorCallback_m63A6D83978EABC15FF36EAD00EF9AC9836C560CB (void);
// 0x0000002F System.Void UnityEngine.Advertisements.BannerLoadOptions::.ctor()
extern void BannerLoadOptions__ctor_m72C3D5020D2A3F95D782444EBF680FC450D975EE (void);
// 0x00000030 UnityEngine.Advertisements.BannerOptions/BannerCallback UnityEngine.Advertisements.BannerOptions::get_showCallback()
extern void BannerOptions_get_showCallback_mC0E013AA66B4E479C727B161979D909D029DACEF (void);
// 0x00000031 System.Void UnityEngine.Advertisements.BannerOptions::set_showCallback(UnityEngine.Advertisements.BannerOptions/BannerCallback)
extern void BannerOptions_set_showCallback_m23C2C3F54258E645185822103432F7BF08397854 (void);
// 0x00000032 UnityEngine.Advertisements.BannerOptions/BannerCallback UnityEngine.Advertisements.BannerOptions::get_hideCallback()
extern void BannerOptions_get_hideCallback_m8A6A29097B506C3C035FBBD9015A274F03DC6FA2 (void);
// 0x00000033 System.Void UnityEngine.Advertisements.BannerOptions::set_hideCallback(UnityEngine.Advertisements.BannerOptions/BannerCallback)
extern void BannerOptions_set_hideCallback_m75DCCB0181010E409DCEA85D4BFC596971FC7316 (void);
// 0x00000034 UnityEngine.Advertisements.BannerOptions/BannerCallback UnityEngine.Advertisements.BannerOptions::get_clickCallback()
extern void BannerOptions_get_clickCallback_mCB2C1AA8F92047CE23BC36966218364154C17C74 (void);
// 0x00000035 System.Void UnityEngine.Advertisements.BannerOptions::set_clickCallback(UnityEngine.Advertisements.BannerOptions/BannerCallback)
extern void BannerOptions_set_clickCallback_m5DBFDD399C73B2A96035AB78EB373FB490134252 (void);
// 0x00000036 System.Void UnityEngine.Advertisements.BannerOptions::.ctor()
extern void BannerOptions__ctor_m045B88E9E89A8A0115FDE98D0EF61410196573B8 (void);
// 0x00000037 System.Boolean UnityEngine.Advertisements.Configuration::get_enabled()
extern void Configuration_get_enabled_mF18E740138295E18B275124D831DCDD6DD4DDE62 (void);
// 0x00000038 System.String UnityEngine.Advertisements.Configuration::get_defaultPlacement()
extern void Configuration_get_defaultPlacement_m27C87984CE3AF25E6E3C8420E3FDBC75A069DCCC (void);
// 0x00000039 System.Collections.Generic.Dictionary`2<System.String,System.Boolean> UnityEngine.Advertisements.Configuration::get_placements()
extern void Configuration_get_placements_mC269A1EA3158C8127F971C2D1CD6672F1B7D8F11 (void);
// 0x0000003A System.Void UnityEngine.Advertisements.Configuration::.ctor(System.String)
extern void Configuration__ctor_m887D661502F7A61F2A1966155AB5AD1F3D27CD59 (void);
// 0x0000003B UnityEngine.Advertisements.Utilities.IUnityLifecycleManager UnityEngine.Advertisements.IBanner::get_UnityLifecycleManager()
// 0x0000003C System.Boolean UnityEngine.Advertisements.IBanner::get_IsLoaded()
// 0x0000003D System.Boolean UnityEngine.Advertisements.IBanner::get_ShowAfterLoad()
// 0x0000003E System.Void UnityEngine.Advertisements.IBanner::set_ShowAfterLoad(System.Boolean)
// 0x0000003F System.Void UnityEngine.Advertisements.IBanner::Load(System.String,UnityEngine.Advertisements.BannerLoadOptions)
// 0x00000040 System.Void UnityEngine.Advertisements.IBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000041 System.Void UnityEngine.Advertisements.IBanner::Hide(System.Boolean)
// 0x00000042 System.Void UnityEngine.Advertisements.IBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
// 0x00000043 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidShow(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000044 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidHide(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000045 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerClick(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x00000046 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidLoad(System.String,UnityEngine.Advertisements.BannerLoadOptions)
// 0x00000047 System.Void UnityEngine.Advertisements.IBanner::UnityAdsBannerDidError(System.String,UnityEngine.Advertisements.BannerLoadOptions)
// 0x00000048 System.Boolean UnityEngine.Advertisements.INativeBanner::get_IsLoaded()
// 0x00000049 System.Void UnityEngine.Advertisements.INativeBanner::SetupBanner(UnityEngine.Advertisements.IBanner)
// 0x0000004A System.Void UnityEngine.Advertisements.INativeBanner::Load(System.String,UnityEngine.Advertisements.BannerLoadOptions)
// 0x0000004B System.Void UnityEngine.Advertisements.INativeBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
// 0x0000004C System.Void UnityEngine.Advertisements.INativeBanner::Hide(System.Boolean)
// 0x0000004D System.Void UnityEngine.Advertisements.INativeBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
// 0x0000004E System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsReady(System.String)
// 0x0000004F System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsDidError(System.String)
// 0x00000050 System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsDidStart(System.String)
// 0x00000051 System.Void UnityEngine.Advertisements.IUnityAdsListener::OnUnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
// 0x00000052 System.Void UnityEngine.Advertisements.IUnityAdsInitializationListener::OnInitializationComplete()
// 0x00000053 System.Void UnityEngine.Advertisements.IUnityAdsInitializationListener::OnInitializationFailed(UnityEngine.Advertisements.UnityAdsInitializationError,System.String)
// 0x00000054 System.Void UnityEngine.Advertisements.IUnityAdsLoadListener::OnUnityAdsAdLoaded(System.String)
// 0x00000055 System.Void UnityEngine.Advertisements.IUnityAdsLoadListener::OnUnityAdsFailedToLoad(System.String,UnityEngine.Advertisements.UnityAdsLoadError,System.String)
// 0x00000056 System.Void UnityEngine.Advertisements.IUnityAdsShowListener::OnUnityAdsShowFailure(System.String,UnityEngine.Advertisements.UnityAdsShowError,System.String)
// 0x00000057 System.Void UnityEngine.Advertisements.IUnityAdsShowListener::OnUnityAdsShowStart(System.String)
// 0x00000058 System.Void UnityEngine.Advertisements.IUnityAdsShowListener::OnUnityAdsShowClick(System.String)
// 0x00000059 System.Void UnityEngine.Advertisements.IUnityAdsShowListener::OnUnityAdsShowComplete(System.String,UnityEngine.Advertisements.UnityAdsShowCompletionState)
// 0x0000005A System.String UnityEngine.Advertisements.MetaData::get_category()
extern void MetaData_get_category_mE557188BA130522D1F5E9FF1E0EA74C6B70A3D7B (void);
// 0x0000005B System.Void UnityEngine.Advertisements.MetaData::set_category(System.String)
extern void MetaData_set_category_mC7842C7C0884F77BC1907FFF1F4921D3289E0520 (void);
// 0x0000005C System.Void UnityEngine.Advertisements.MetaData::.ctor(System.String)
extern void MetaData__ctor_m721A701D2C7AB4C4225CF40A3981FE6D216E11D2 (void);
// 0x0000005D System.Void UnityEngine.Advertisements.MetaData::Set(System.String,System.Object)
extern void MetaData_Set_m5768578DC77104453F82BCB1B08DA79FAEB6EB85 (void);
// 0x0000005E System.Object UnityEngine.Advertisements.MetaData::Get(System.String)
extern void MetaData_Get_mD183BFB965634057C3540E73A9CAAB3D11F0E34D (void);
// 0x0000005F System.Collections.Generic.IDictionary`2<System.String,System.Object> UnityEngine.Advertisements.MetaData::Values()
extern void MetaData_Values_m280A5C4E0D8F6BF158D8C72DAB0B246DF1CB8552 (void);
// 0x00000060 System.String UnityEngine.Advertisements.MetaData::ToJSON()
extern void MetaData_ToJSON_mB3DAC3CB05FDFA9328585787D3F2FC4E19185371 (void);
// 0x00000061 System.Void UnityEngine.Advertisements.AndroidInitializationListener::.ctor(UnityEngine.Advertisements.Platform.IPlatform,UnityEngine.Advertisements.IUnityAdsInitializationListener)
extern void AndroidInitializationListener__ctor_m591420AEE2802666F33C33CE609B41E80D6F9675 (void);
// 0x00000062 System.Void UnityEngine.Advertisements.AndroidInitializationListener::onInitializationComplete()
extern void AndroidInitializationListener_onInitializationComplete_m6659B1B07789AEDC70873C8E6641559C81B94CEF (void);
// 0x00000063 System.Void UnityEngine.Advertisements.AndroidInitializationListener::onInitializationFailed(UnityEngine.AndroidJavaObject,System.String)
extern void AndroidInitializationListener_onInitializationFailed_m2FDE29A8C0EEACB0A0CD235E2148015E0C4B97EF (void);
// 0x00000064 System.Void UnityEngine.Advertisements.AndroidLoadListener::.ctor(UnityEngine.Advertisements.Platform.IPlatform,UnityEngine.Advertisements.IUnityAdsLoadListener)
extern void AndroidLoadListener__ctor_mAA72ADDE0D5C54196737B1E61DED6316CB79D731 (void);
// 0x00000065 System.Void UnityEngine.Advertisements.AndroidLoadListener::onUnityAdsAdLoaded(System.String)
extern void AndroidLoadListener_onUnityAdsAdLoaded_m99695817E960F675EFB5AAD36D2EBF26C41191D5 (void);
// 0x00000066 System.Void UnityEngine.Advertisements.AndroidLoadListener::onUnityAdsFailedToLoad(System.String,UnityEngine.AndroidJavaObject,System.String)
extern void AndroidLoadListener_onUnityAdsFailedToLoad_mDDB6BD6440767A1BD25A314EBC1938CEB6A42247 (void);
// 0x00000067 System.Void UnityEngine.Advertisements.AndroidShowListener::.ctor(UnityEngine.Advertisements.Platform.IPlatform,UnityEngine.Advertisements.IUnityAdsShowListener)
extern void AndroidShowListener__ctor_mE09E4127293811F85D0A52A6AF32F0F3EC19E114 (void);
// 0x00000068 System.Void UnityEngine.Advertisements.AndroidShowListener::onUnityAdsShowFailure(System.String,UnityEngine.AndroidJavaObject,System.String)
extern void AndroidShowListener_onUnityAdsShowFailure_m5CD4D56F515626A2ABDCCB215A887AC6B264CD22 (void);
// 0x00000069 System.Void UnityEngine.Advertisements.AndroidShowListener::onUnityAdsShowStart(System.String)
extern void AndroidShowListener_onUnityAdsShowStart_mA81D8550865A2B1EA02429CFC4BEE7E18B9F79F6 (void);
// 0x0000006A System.Void UnityEngine.Advertisements.AndroidShowListener::onUnityAdsShowClick(System.String)
extern void AndroidShowListener_onUnityAdsShowClick_m5E0DBE4FCA4ADD20E91019D98EC9BBF9FCA49459 (void);
// 0x0000006B System.Void UnityEngine.Advertisements.AndroidShowListener::onUnityAdsShowComplete(System.String,UnityEngine.AndroidJavaObject)
extern void AndroidShowListener_onUnityAdsShowComplete_m8697D673772E7A5AEB8D27A1E17111272BEFBF29 (void);
// 0x0000006C System.Void UnityEngine.Advertisements.INativePlatform::SetupPlatform(UnityEngine.Advertisements.Platform.IPlatform)
// 0x0000006D System.Void UnityEngine.Advertisements.INativePlatform::Initialize(System.String,System.Boolean,System.Boolean,UnityEngine.Advertisements.IUnityAdsInitializationListener)
// 0x0000006E System.Void UnityEngine.Advertisements.INativePlatform::Load(System.String,UnityEngine.Advertisements.IUnityAdsLoadListener)
// 0x0000006F System.Void UnityEngine.Advertisements.INativePlatform::Show(System.String,UnityEngine.Advertisements.IUnityAdsShowListener)
// 0x00000070 System.Void UnityEngine.Advertisements.INativePlatform::SetMetaData(UnityEngine.Advertisements.MetaData)
// 0x00000071 System.Boolean UnityEngine.Advertisements.INativePlatform::GetDebugMode()
// 0x00000072 System.Void UnityEngine.Advertisements.INativePlatform::SetDebugMode(System.Boolean)
// 0x00000073 System.String UnityEngine.Advertisements.INativePlatform::GetVersion()
// 0x00000074 System.Boolean UnityEngine.Advertisements.INativePlatform::IsInitialized()
// 0x00000075 System.Boolean UnityEngine.Advertisements.INativePlatform::IsReady(System.String)
// 0x00000076 UnityEngine.Advertisements.PlacementState UnityEngine.Advertisements.INativePlatform::GetPlacementState(System.String)
// 0x00000077 System.IntPtr UnityEngine.Advertisements.IosShowListener::ShowListenerCreate(UnityEngine.Advertisements.IosShowListener/ShowFailureCallback,UnityEngine.Advertisements.IosShowListener/ShowStartCallback,UnityEngine.Advertisements.IosShowListener/ShowClickCallback,UnityEngine.Advertisements.IosShowListener/ShowCompleteCallback)
extern void IosShowListener_ShowListenerCreate_m7E7CECEFE3F8B16B7BE85A96651A94F6478CEF13 (void);
// 0x00000078 System.Void UnityEngine.Advertisements.IosShowListener::ShowListenerDestroy(System.IntPtr)
extern void IosShowListener_ShowListenerDestroy_mC88C69D0DA3291A80BC46C32FB7EC937E602A2D9 (void);
// 0x00000079 System.Void UnityEngine.Advertisements.IosShowListener::.ctor(UnityEngine.Advertisements.IUnityAdsShowListener,UnityEngine.Advertisements.IUnityAdsShowListener)
extern void IosShowListener__ctor_m4F14E89EB6630D7EAD2477794B3363E75F7D6BB1 (void);
// 0x0000007A System.Void UnityEngine.Advertisements.IosShowListener::Dispose()
extern void IosShowListener_Dispose_mB53DFBBD9CC6DECAEB0860B893B7F0E376F37676 (void);
// 0x0000007B System.Void UnityEngine.Advertisements.IosShowListener::OnShowFailure(System.String,UnityEngine.Advertisements.UnityAdsShowError,System.String)
extern void IosShowListener_OnShowFailure_m0EB6A914FA1270E446FAC739013CF5540337D218 (void);
// 0x0000007C System.Void UnityEngine.Advertisements.IosShowListener::OnShowStart(System.String)
extern void IosShowListener_OnShowStart_m0BD2790A1EDCA1C8836543C11CDF21C943CFF764 (void);
// 0x0000007D System.Void UnityEngine.Advertisements.IosShowListener::OnShowClick(System.String)
extern void IosShowListener_OnShowClick_mEF92B8FED73C716D86ACE0254231FF1A41D3FC73 (void);
// 0x0000007E System.Void UnityEngine.Advertisements.IosShowListener::OnShowComplete(System.String,UnityEngine.Advertisements.UnityAdsShowCompletionState)
extern void IosShowListener_OnShowComplete_m5B29B63AD95CBBB863D335AE3547E754FD24ED72 (void);
// 0x0000007F System.Void UnityEngine.Advertisements.IosShowListener::OnShowFailure(System.IntPtr,System.String,System.Int32,System.String)
extern void IosShowListener_OnShowFailure_m1F449F5BA0EFA79DCD526B4AFA4FEC23611DC737 (void);
// 0x00000080 System.Void UnityEngine.Advertisements.IosShowListener::OnShowStart(System.IntPtr,System.String)
extern void IosShowListener_OnShowStart_mE42C6FD6E21AFC9BBBDCD99B272DEF7FC375E494 (void);
// 0x00000081 System.Void UnityEngine.Advertisements.IosShowListener::OnShowClick(System.IntPtr,System.String)
extern void IosShowListener_OnShowClick_m08D50F89BA9E45F3047B4D5BD497E38741939B08 (void);
// 0x00000082 System.Void UnityEngine.Advertisements.IosShowListener::OnShowComplete(System.IntPtr,System.String,System.Int32)
extern void IosShowListener_OnShowComplete_m233B64E74571ADCD363EECB90C7A42A91D30027E (void);
// 0x00000083 System.Action`1<UnityEngine.Advertisements.ShowResult> UnityEngine.Advertisements.ShowOptions::get_resultCallback()
extern void ShowOptions_get_resultCallback_mBDF7C8F33645D0C9322FC9E9459924FB59C6355C (void);
// 0x00000084 System.Void UnityEngine.Advertisements.ShowOptions::set_resultCallback(System.Action`1<UnityEngine.Advertisements.ShowResult>)
extern void ShowOptions_set_resultCallback_m3A6AE34F4996F4824374235A881C24D3B85DF24E (void);
// 0x00000085 System.String UnityEngine.Advertisements.ShowOptions::get_gamerSid()
extern void ShowOptions_get_gamerSid_mCFE8CCA152EFEDDFF4503803CE86F519140848C4 (void);
// 0x00000086 System.Void UnityEngine.Advertisements.ShowOptions::set_gamerSid(System.String)
extern void ShowOptions_set_gamerSid_m43F550758438C335C1C3DA19863B0002648FE813 (void);
// 0x00000087 System.Void UnityEngine.Advertisements.ShowOptions::.ctor()
extern void ShowOptions__ctor_m870E075D40F9D65228F35733FEB995C021BEA92F (void);
// 0x00000088 System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::add_OnApplicationQuitEventHandler(UnityEngine.Events.UnityAction)
extern void ApplicationQuit_add_OnApplicationQuitEventHandler_m2153EFB5B8E4FBEBAEDE3A75710004EA43FFCF1C (void);
// 0x00000089 System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::remove_OnApplicationQuitEventHandler(UnityEngine.Events.UnityAction)
extern void ApplicationQuit_remove_OnApplicationQuitEventHandler_m83EBF68F4BE91FE0C33DE86D123C5AC3C2A9424A (void);
// 0x0000008A System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::OnApplicationQuit()
extern void ApplicationQuit_OnApplicationQuit_mC3E119DF3764A3EDA1686196FE8721A8CA6A3B5C (void);
// 0x0000008B System.Void UnityEngine.Advertisements.Utilities.ApplicationQuit::.ctor()
extern void ApplicationQuit__ctor_m239E2A1680B0D4C2C9E38161F4064977AFC06BD3 (void);
// 0x0000008C System.Void UnityEngine.Advertisements.Utilities.CoroutineExecutor::Update()
extern void CoroutineExecutor_Update_m7ACF3E0CFFBF53889AD233FD6C7922C8AE4A9B71 (void);
// 0x0000008D System.Void UnityEngine.Advertisements.Utilities.CoroutineExecutor::.ctor()
extern void CoroutineExecutor__ctor_m014EB67E58FD803B7A1AD79493EE9203B2018150 (void);
// 0x0000008E UnityEngine.Advertisements.ShowResult UnityEngine.Advertisements.Utilities.EnumUtilities::GetShowResultsFromCompletionState(UnityEngine.Advertisements.UnityAdsShowCompletionState)
extern void EnumUtilities_GetShowResultsFromCompletionState_m7F603E6D34416F890D0C1B1FE81CF564B513F5CC (void);
// 0x0000008F T UnityEngine.Advertisements.Utilities.EnumUtilities::GetEnumFromAndroidJavaObject(UnityEngine.AndroidJavaObject,T)
// 0x00000090 UnityEngine.Coroutine UnityEngine.Advertisements.Utilities.IUnityLifecycleManager::StartCoroutine(System.Collections.IEnumerator)
// 0x00000091 System.Void UnityEngine.Advertisements.Utilities.IUnityLifecycleManager::Post(System.Action)
// 0x00000092 System.Void UnityEngine.Advertisements.Utilities.IUnityLifecycleManager::SetOnApplicationQuitCallback(UnityEngine.Events.UnityAction)
// 0x00000093 System.Object UnityEngine.Advertisements.Utilities.Json::Deserialize(System.String)
extern void Json_Deserialize_mC9CF7DC20F96E3B2E53C2C125AE9F35B08C5CDFC (void);
// 0x00000094 System.String UnityEngine.Advertisements.Utilities.Json::Serialize(System.Object)
extern void Json_Serialize_m8FC74A4B2C34176F8062B6097FCF24126B0F5CAC (void);
// 0x00000095 System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::.ctor()
extern void UnityLifecycleManager__ctor_m369FEC9D7C6399AE2E0FF7101DADD6E403712873 (void);
// 0x00000096 System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::Initialize()
extern void UnityLifecycleManager_Initialize_m16C569D5D2DDED13E9AE28FB86F1732479C8C315 (void);
// 0x00000097 UnityEngine.Coroutine UnityEngine.Advertisements.Utilities.UnityLifecycleManager::StartCoroutine(System.Collections.IEnumerator)
extern void UnityLifecycleManager_StartCoroutine_m16B16D3D504BF71147FFE9C996952AD97D8F509D (void);
// 0x00000098 System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::Post(System.Action)
extern void UnityLifecycleManager_Post_mB8349441FD9073B233AE460BE22FAF5AD37AE992 (void);
// 0x00000099 System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::Dispose()
extern void UnityLifecycleManager_Dispose_m1B3A528ABA5ADBEECB41C5C760460A1998C58A38 (void);
// 0x0000009A System.Void UnityEngine.Advertisements.Utilities.UnityLifecycleManager::SetOnApplicationQuitCallback(UnityEngine.Events.UnityAction)
extern void UnityLifecycleManager_SetOnApplicationQuitCallback_mA35C6454001EB05ECF9CE1A92EC68047C94FB2A3 (void);
// 0x0000009B System.Void UnityEngine.Advertisements.Purchasing.IPurchasingEventSender::SendPurchasingEvent(System.String)
// 0x0000009C System.Boolean UnityEngine.Advertisements.Purchasing.Purchasing::Initialize(UnityEngine.Advertisements.Purchasing.IPurchasingEventSender)
extern void Purchasing_Initialize_m7B97864F3F8DE36834B9D4806BA535DA51671F0C (void);
// 0x0000009D System.Boolean UnityEngine.Advertisements.Purchasing.Purchasing::InitiatePurchasingCommand(System.String)
extern void Purchasing_InitiatePurchasingCommand_m57469B23AF1BEF4A61D88F8ECB3A6CFB48C7F256 (void);
// 0x0000009E System.String UnityEngine.Advertisements.Purchasing.Purchasing::GetPurchasingCatalog()
extern void Purchasing_GetPurchasingCatalog_m9891E4FF2635394DFFF2748910A0149943FDD546 (void);
// 0x0000009F System.String UnityEngine.Advertisements.Purchasing.Purchasing::GetPromoVersion()
extern void Purchasing_GetPromoVersion_m5E4C0890F43DFA870A53B3610A4CE6BA026338ED (void);
// 0x000000A0 System.Boolean UnityEngine.Advertisements.Purchasing.Purchasing::SendEvent(System.String)
extern void Purchasing_SendEvent_m662912F361C5EFC0BEB551F3A53F2B8DE351083C (void);
// 0x000000A1 System.Void UnityEngine.Advertisements.Purchasing.Purchasing::.cctor()
extern void Purchasing__cctor_m71D2788D601C85D73A1F90B930724B88342156FF (void);
// 0x000000A2 UnityEngine.Advertisements.Purchasing.PurchasingPlatform UnityEngine.Advertisements.Purchasing.PurchasingPlatform::get_Instance()
extern void PurchasingPlatform_get_Instance_m376B995017FD53D5F465E9FB22267DD17FE5AAF2 (void);
// 0x000000A3 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::set_Instance(UnityEngine.Advertisements.Purchasing.PurchasingPlatform)
extern void PurchasingPlatform_set_Instance_m8335E0D23D7A4D3A100EFCF70A4262C9604411BD (void);
// 0x000000A4 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingDispatchReturnEvent(System.Int64,System.String)
extern void PurchasingPlatform_UnityAdsPurchasingDispatchReturnEvent_m865E890CFF9835F525DF90F633A48AF5AF7F3B07 (void);
// 0x000000A5 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetDidInitiatePurchasingCommandCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingDidInitiatePurchasingCommand)
extern void PurchasingPlatform_UnityAdsSetDidInitiatePurchasingCommandCallback_mA5E26D1343552B4F0332A25E7F187D70D843A391 (void);
// 0x000000A6 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetGetProductCatalogCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetProductCatalog)
extern void PurchasingPlatform_UnityAdsSetGetProductCatalogCallback_m8AB4F65A6C08F99D58D4C313FAB734DDF69EDAC7 (void);
// 0x000000A7 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetGetVersionCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetPurchasingVersion)
extern void PurchasingPlatform_UnityAdsSetGetVersionCallback_m73441F22CA3B60A6B1E2AB7032DDACA33FC1B62E (void);
// 0x000000A8 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsSetInitializePurchasingCallback(UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingInitialize)
extern void PurchasingPlatform_UnityAdsSetInitializePurchasingCallback_m2285E992C073ED26769B9FB1EE385861D37CF775 (void);
// 0x000000A9 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsDidInitiatePurchasingCommand(System.String)
extern void PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mC4F34F7E115EBACCBF488E35161B3765379754BF (void);
// 0x000000AA System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingGetProductCatalog()
extern void PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m56F70A02157D109E98C81C22262686A560A479FC (void);
// 0x000000AB System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingGetPurchasingVersion()
extern void PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mD96F20497B37585C57677515C6B671F4A1DC1227 (void);
// 0x000000AC System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::UnityAdsPurchasingInitialize()
extern void PurchasingPlatform_UnityAdsPurchasingInitialize_m4004786A5894AF8350718CDC9346426D0E09619C (void);
// 0x000000AD System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::Initialize()
extern void PurchasingPlatform_Initialize_m8C5496F575B6E838A80DC75281D0642C795078FF (void);
// 0x000000AE System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::SendPurchasingEvent(System.String)
extern void PurchasingPlatform_SendPurchasingEvent_m7E1BD56DCA41B2DC88131265C93EBD81259A921D (void);
// 0x000000AF System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform::.ctor()
extern void PurchasingPlatform__ctor_m4331BE43EF4984D4185B327548B1C9F5123A54E3 (void);
// 0x000000B0 System.Void UnityEngine.Advertisements.Platform.IPlatform::add_OnStart(System.EventHandler`1<UnityEngine.Advertisements.Events.StartEventArgs>)
// 0x000000B1 System.Void UnityEngine.Advertisements.Platform.IPlatform::remove_OnStart(System.EventHandler`1<UnityEngine.Advertisements.Events.StartEventArgs>)
// 0x000000B2 System.Void UnityEngine.Advertisements.Platform.IPlatform::add_OnFinish(System.EventHandler`1<UnityEngine.Advertisements.Events.FinishEventArgs>)
// 0x000000B3 System.Void UnityEngine.Advertisements.Platform.IPlatform::remove_OnFinish(System.EventHandler`1<UnityEngine.Advertisements.Events.FinishEventArgs>)
// 0x000000B4 UnityEngine.Advertisements.IBanner UnityEngine.Advertisements.Platform.IPlatform::get_Banner()
// 0x000000B5 UnityEngine.Advertisements.Utilities.IUnityLifecycleManager UnityEngine.Advertisements.Platform.IPlatform::get_UnityLifecycleManager()
// 0x000000B6 UnityEngine.Advertisements.INativePlatform UnityEngine.Advertisements.Platform.IPlatform::get_NativePlatform()
// 0x000000B7 System.Boolean UnityEngine.Advertisements.Platform.IPlatform::get_IsInitialized()
// 0x000000B8 System.Boolean UnityEngine.Advertisements.Platform.IPlatform::get_IsShowing()
// 0x000000B9 System.String UnityEngine.Advertisements.Platform.IPlatform::get_Version()
// 0x000000BA System.Boolean UnityEngine.Advertisements.Platform.IPlatform::get_DebugMode()
// 0x000000BB System.Void UnityEngine.Advertisements.Platform.IPlatform::set_DebugMode(System.Boolean)
// 0x000000BC System.Collections.Generic.HashSet`1<UnityEngine.Advertisements.IUnityAdsListener> UnityEngine.Advertisements.Platform.IPlatform::get_Listeners()
// 0x000000BD System.Void UnityEngine.Advertisements.Platform.IPlatform::Initialize(System.String,System.Boolean,System.Boolean,UnityEngine.Advertisements.IUnityAdsInitializationListener)
// 0x000000BE System.Void UnityEngine.Advertisements.Platform.IPlatform::Load(System.String,UnityEngine.Advertisements.IUnityAdsLoadListener)
// 0x000000BF System.Void UnityEngine.Advertisements.Platform.IPlatform::Show(System.String,UnityEngine.Advertisements.ShowOptions,UnityEngine.Advertisements.IUnityAdsShowListener)
// 0x000000C0 System.Void UnityEngine.Advertisements.Platform.IPlatform::AddListener(UnityEngine.Advertisements.IUnityAdsListener)
// 0x000000C1 System.Void UnityEngine.Advertisements.Platform.IPlatform::RemoveListener(UnityEngine.Advertisements.IUnityAdsListener)
// 0x000000C2 System.Boolean UnityEngine.Advertisements.Platform.IPlatform::IsReady(System.String)
// 0x000000C3 UnityEngine.Advertisements.PlacementState UnityEngine.Advertisements.Platform.IPlatform::GetPlacementState(System.String)
// 0x000000C4 System.Void UnityEngine.Advertisements.Platform.IPlatform::SetMetaData(UnityEngine.Advertisements.MetaData)
// 0x000000C5 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsReady(System.String)
// 0x000000C6 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsDidError(System.String)
// 0x000000C7 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsDidStart(System.String)
// 0x000000C8 System.Void UnityEngine.Advertisements.Platform.IPlatform::UnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
// 0x000000C9 System.Void UnityEngine.Advertisements.Platform.Platform::add_OnStart(System.EventHandler`1<UnityEngine.Advertisements.Events.StartEventArgs>)
extern void Platform_add_OnStart_m4CCC0A40221A5C08A2CDAC53E8D5BDE10D3C8351 (void);
// 0x000000CA System.Void UnityEngine.Advertisements.Platform.Platform::remove_OnStart(System.EventHandler`1<UnityEngine.Advertisements.Events.StartEventArgs>)
extern void Platform_remove_OnStart_m1C270153A43C4E94FF440AA6CF6EF0B7D92CA185 (void);
// 0x000000CB System.Void UnityEngine.Advertisements.Platform.Platform::add_OnFinish(System.EventHandler`1<UnityEngine.Advertisements.Events.FinishEventArgs>)
extern void Platform_add_OnFinish_m15DFC29065F86B3B9DA918CB7F8BB089D86591DE (void);
// 0x000000CC System.Void UnityEngine.Advertisements.Platform.Platform::remove_OnFinish(System.EventHandler`1<UnityEngine.Advertisements.Events.FinishEventArgs>)
extern void Platform_remove_OnFinish_m40E075AF1A0107C7190242103B7033D9345F6AE3 (void);
// 0x000000CD UnityEngine.Advertisements.IBanner UnityEngine.Advertisements.Platform.Platform::get_Banner()
extern void Platform_get_Banner_m97AFECBBBAF48C7B5A345AF1EE5C45209C050329 (void);
// 0x000000CE UnityEngine.Advertisements.Utilities.IUnityLifecycleManager UnityEngine.Advertisements.Platform.Platform::get_UnityLifecycleManager()
extern void Platform_get_UnityLifecycleManager_m97C9CC36483A73D5C90A96866789DF8C0C8133E2 (void);
// 0x000000CF UnityEngine.Advertisements.INativePlatform UnityEngine.Advertisements.Platform.Platform::get_NativePlatform()
extern void Platform_get_NativePlatform_mC66B09E84BD53B90DEF2F7F68225EB57EB8A6796 (void);
// 0x000000D0 System.Boolean UnityEngine.Advertisements.Platform.Platform::get_IsInitialized()
extern void Platform_get_IsInitialized_m19661CA3030933F62AF20C8384EFE2ADC8B97C66 (void);
// 0x000000D1 System.Boolean UnityEngine.Advertisements.Platform.Platform::get_IsShowing()
extern void Platform_get_IsShowing_mA551BD72286383227ABD6161E21357E89972550E (void);
// 0x000000D2 System.Void UnityEngine.Advertisements.Platform.Platform::set_IsShowing(System.Boolean)
extern void Platform_set_IsShowing_m712A3A6B5FB6A618353812142AAB0E6D54C7E9F7 (void);
// 0x000000D3 System.String UnityEngine.Advertisements.Platform.Platform::get_Version()
extern void Platform_get_Version_m3623DC6D1D20F4E9B7A56C8C0733DC4937A9952A (void);
// 0x000000D4 System.Boolean UnityEngine.Advertisements.Platform.Platform::get_DebugMode()
extern void Platform_get_DebugMode_m13FC53CEA266DC1161931AF895397E65F7010ECD (void);
// 0x000000D5 System.Void UnityEngine.Advertisements.Platform.Platform::set_DebugMode(System.Boolean)
extern void Platform_set_DebugMode_m83E17ED67E02B08FCFDA864E5DCDDCB45B315DF0 (void);
// 0x000000D6 System.Collections.Generic.HashSet`1<UnityEngine.Advertisements.IUnityAdsListener> UnityEngine.Advertisements.Platform.Platform::get_Listeners()
extern void Platform_get_Listeners_m448B5DCB0475ECD7D2D71EAEBBEAD3A6B1C74322 (void);
// 0x000000D7 System.Void UnityEngine.Advertisements.Platform.Platform::.ctor(UnityEngine.Advertisements.INativePlatform,UnityEngine.Advertisements.IBanner,UnityEngine.Advertisements.Utilities.IUnityLifecycleManager)
extern void Platform__ctor_m17186969821C864E4D8BB7C909137E0C7C5608D9 (void);
// 0x000000D8 System.Void UnityEngine.Advertisements.Platform.Platform::Initialize(System.String,System.Boolean,System.Boolean,UnityEngine.Advertisements.IUnityAdsInitializationListener)
extern void Platform_Initialize_mA273C7552B41E4AD8E4C293285AA1121C4550E9A (void);
// 0x000000D9 System.Void UnityEngine.Advertisements.Platform.Platform::Load(System.String)
extern void Platform_Load_m9B9D1490876B216636BC7DD13CA793F97F46E1A4 (void);
// 0x000000DA System.Void UnityEngine.Advertisements.Platform.Platform::Load(System.String,UnityEngine.Advertisements.IUnityAdsLoadListener)
extern void Platform_Load_m2CB4A0F4FB27440901552C56A61F4DC54CAA773C (void);
// 0x000000DB System.Void UnityEngine.Advertisements.Platform.Platform::Show(System.String,UnityEngine.Advertisements.ShowOptions,UnityEngine.Advertisements.IUnityAdsShowListener)
extern void Platform_Show_m2DEFF1A65813BEB3430DB9E47694AC37A5C628A2 (void);
// 0x000000DC System.Void UnityEngine.Advertisements.Platform.Platform::AddListener(UnityEngine.Advertisements.IUnityAdsListener)
extern void Platform_AddListener_mC151CA68BC5A176169D072A70EA9642BCAEF6571 (void);
// 0x000000DD System.Void UnityEngine.Advertisements.Platform.Platform::RemoveListener(UnityEngine.Advertisements.IUnityAdsListener)
extern void Platform_RemoveListener_m112D3C1344835B5EFCDE013785048AE4E0FF988F (void);
// 0x000000DE System.Boolean UnityEngine.Advertisements.Platform.Platform::IsReady(System.String)
extern void Platform_IsReady_mB2891E3422F9CC0D8667D24757530A2638EAC213 (void);
// 0x000000DF UnityEngine.Advertisements.PlacementState UnityEngine.Advertisements.Platform.Platform::GetPlacementState(System.String)
extern void Platform_GetPlacementState_m0F2BCDA009BC61C14AF2950A0AFC4AFD27A6E8CC (void);
// 0x000000E0 System.Void UnityEngine.Advertisements.Platform.Platform::SetMetaData(UnityEngine.Advertisements.MetaData)
extern void Platform_SetMetaData_m17C3A65CA16D80CD026728E9CC118C4A7795CA6C (void);
// 0x000000E1 System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsReady(System.String)
extern void Platform_UnityAdsReady_m87617D19B85ECCB079DEC36965B7EA67B5687B00 (void);
// 0x000000E2 System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsDidError(System.String)
extern void Platform_UnityAdsDidError_m2BD791A567D64231EA88B1A5F679E8DD758FF1B8 (void);
// 0x000000E3 System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsDidStart(System.String)
extern void Platform_UnityAdsDidStart_m2D8762382F7302548E1F28600138BD0BEAA54EB0 (void);
// 0x000000E4 System.Void UnityEngine.Advertisements.Platform.Platform::UnityAdsDidFinish(System.String,UnityEngine.Advertisements.ShowResult)
extern void Platform_UnityAdsDidFinish_mFE66E66B2B8ACEF5D1CBCD847C4505F287B318BF (void);
// 0x000000E5 System.Collections.Generic.HashSet`1<UnityEngine.Advertisements.IUnityAdsListener> UnityEngine.Advertisements.Platform.Platform::GetClonedHashSet(System.Collections.Generic.HashSet`1<UnityEngine.Advertisements.IUnityAdsListener>)
extern void Platform_GetClonedHashSet_m9B9FA72BA90E7087A0D2438C46C06D09FDB68F34 (void);
// 0x000000E6 System.Void UnityEngine.Advertisements.Platform.Platform::<Initialize>b__30_0(System.Object,UnityEngine.Advertisements.Events.StartEventArgs)
extern void Platform_U3CInitializeU3Eb__30_0_m47F5CC8A10F22E483FAE404A4CAA36B867F0325B (void);
// 0x000000E7 System.Void UnityEngine.Advertisements.Platform.Platform::<Initialize>b__30_1(System.Object,UnityEngine.Advertisements.Events.FinishEventArgs)
extern void Platform_U3CInitializeU3Eb__30_1_m510A7C88373E4D81922BFFA44E284A648BCD5AB5 (void);
// 0x000000E8 System.Boolean UnityEngine.Advertisements.Platform.iOS.IosBanner::get_IsLoaded()
extern void IosBanner_get_IsLoaded_mA5FCD8CC559AE885D0D220A1C2C1D9973F8BD542 (void);
// 0x000000E9 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::set_IsLoaded(System.Boolean)
extern void IosBanner_set_IsLoaded_m4A5F87ED363645F1FE64E814121CC0F45EAF3202 (void);
// 0x000000EA System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerShow(System.String,System.Boolean)
extern void IosBanner_UnityAdsBannerShow_mCA57B1527FD27663D727C2C863D7CCEABCB4F41E (void);
// 0x000000EB System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerHide(System.Boolean)
extern void IosBanner_UnityAdsBannerHide_mE158DC816CEAFD522C9F8D8D0B2539FBA0295BB7 (void);
// 0x000000EC System.Boolean UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerIsLoaded()
extern void IosBanner_UnityAdsBannerIsLoaded_m6733432B7E7A7AF8AD669CE3CE6EB76E9B327925 (void);
// 0x000000ED System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerSetPosition(System.Int32)
extern void IosBanner_UnityAdsBannerSetPosition_m8427AF7CFC95628450CFDF6D8D6DAE9331435C84 (void);
// 0x000000EE System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerShowCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerShowDelegate)
extern void IosBanner_UnityAdsSetBannerShowCallback_mC9658554E6DFF098A22F7AC79631A51068433958 (void);
// 0x000000EF System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerHideCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerHideDelegate)
extern void IosBanner_UnityAdsSetBannerHideCallback_m63BEB2C8E57DEBD4B6413D5B808408B66D87F4DB (void);
// 0x000000F0 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerClickCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerClickDelegate)
extern void IosBanner_UnityAdsSetBannerClickCallback_m4177784A68961587A6E346427600DBCF303E80D2 (void);
// 0x000000F1 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerErrorCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerErrorDelegate)
extern void IosBanner_UnityAdsSetBannerErrorCallback_mE19536F9CD2312BB4A3882AAD129A0A7E1E91C5F (void);
// 0x000000F2 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerUnloadCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerUnloadDelegate)
extern void IosBanner_UnityAdsSetBannerUnloadCallback_m1C5B0AC22DD96436161ECDC843B6A46E31543B71 (void);
// 0x000000F3 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsSetBannerLoadCallback(UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerLoadDelegate)
extern void IosBanner_UnityAdsSetBannerLoadCallback_m865AC53E15647BF4E44DAB5B061655E84BD5CB6C (void);
// 0x000000F4 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityBannerInitialize()
extern void IosBanner_UnityBannerInitialize_m87FA22B7F8717EDB2887D10386AE11CAF4F19CEE (void);
// 0x000000F5 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidShow(System.String)
extern void IosBanner_UnityAdsBannerDidShow_m3120A02395BCBF393FA6D6CA0E338FC035A3AC83 (void);
// 0x000000F6 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidHide(System.String)
extern void IosBanner_UnityAdsBannerDidHide_m388BF2978CA575D09935957B1D33AA329BEFF628 (void);
// 0x000000F7 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerClick(System.String)
extern void IosBanner_UnityAdsBannerClick_m64AE141B67AC8303DCB6074D65BDDEDEAD483AEF (void);
// 0x000000F8 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidError(System.String)
extern void IosBanner_UnityAdsBannerDidError_mBEE10F30BF7C0ADE11902976DF5F271D11778D58 (void);
// 0x000000F9 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidUnload(System.String)
extern void IosBanner_UnityAdsBannerDidUnload_m37C9378F35879F763BD7DF4326010DBADA94E706 (void);
// 0x000000FA System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::UnityAdsBannerDidLoad(System.String)
extern void IosBanner_UnityAdsBannerDidLoad_mE6E3534E4C772FFF746ADD4D3C99818C23B5E12D (void);
// 0x000000FB System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::SetupBanner(UnityEngine.Advertisements.IBanner)
extern void IosBanner_SetupBanner_m954669BA682BC31515563E6D481C50599AC46076 (void);
// 0x000000FC System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::Load(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void IosBanner_Load_mCF83EB2528DAE6BD5F3DAB8E2E63A1DEE9328D3B (void);
// 0x000000FD System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void IosBanner_Show_m1B30DB60B3597A4A034BDB330B9A2920FC3C1E4D (void);
// 0x000000FE System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::Hide(System.Boolean)
extern void IosBanner_Hide_mD89FFFB5D5CC270FB5B5C8BB9B3D7497FFD6A79F (void);
// 0x000000FF System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void IosBanner_SetPosition_m496A06603175794AAEC1BFCC5182771EDEE686D2 (void);
// 0x00000100 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner::.ctor()
extern void IosBanner__ctor_mE4836FCAC5D463FF8428FE7352064DC69F44F5F6 (void);
// 0x00000101 System.IntPtr UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::InitializationListenerCreate(UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitSuccessCallback,UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitFailureCallback)
extern void IosInitializationListener_InitializationListenerCreate_mA8AF3ACF4565AE255D37F828BBFED7307CDCB9F5 (void);
// 0x00000102 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::InitializationListenerDestroy(System.IntPtr)
extern void IosInitializationListener_InitializationListenerDestroy_m47D86F5B9ED766F4D039CB8ED2438E9B814383F6 (void);
// 0x00000103 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::.ctor(UnityEngine.Advertisements.IUnityAdsInitializationListener,UnityEngine.Advertisements.IUnityAdsInitializationListener)
extern void IosInitializationListener__ctor_m1C225AB8C2D9B678D378A360C024D29D36726FE1 (void);
// 0x00000104 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::Dispose()
extern void IosInitializationListener_Dispose_m9311B00ED0F4D5CB9B3D758D97BCE5A2A759C8BA (void);
// 0x00000105 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::OnInitializationComplete()
extern void IosInitializationListener_OnInitializationComplete_m8CF5F45E354B34D225B9A32EDF80214CD696EEF7 (void);
// 0x00000106 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::OnInitializationFailed(UnityEngine.Advertisements.UnityAdsInitializationError,System.String)
extern void IosInitializationListener_OnInitializationFailed_m328C7E854C5E2194A0334B0BF4B0943DB2D70DE7 (void);
// 0x00000107 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::OnInitializationComplete(System.IntPtr)
extern void IosInitializationListener_OnInitializationComplete_m5C1D21F520E9041AEB12472927EAD7880EE8F723 (void);
// 0x00000108 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener::OnInitializationFailed(System.IntPtr,System.Int32,System.String)
extern void IosInitializationListener_OnInitializationFailed_m20705DB3847A26369E1BECDE24515EC935FC18BE (void);
// 0x00000109 System.IntPtr UnityEngine.Advertisements.Platform.iOS.IosLoadListener::LoadListenerCreate(UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadSuccessCallback,UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadFailureCallback)
extern void IosLoadListener_LoadListenerCreate_mD49F3BA9EF1EB94AC811730A19B3118180117EA5 (void);
// 0x0000010A System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener::LoadListenerDestroy(System.IntPtr)
extern void IosLoadListener_LoadListenerDestroy_m2DAEF2DFC91195FB2A4C4AC6535D588031201D5F (void);
// 0x0000010B System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener::.ctor(UnityEngine.Advertisements.IUnityAdsLoadListener,UnityEngine.Advertisements.IUnityAdsLoadListener)
extern void IosLoadListener__ctor_m4DAC58F12ED2470FD087CC6808A0BFE6E450F1B1 (void);
// 0x0000010C System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener::Dispose()
extern void IosLoadListener_Dispose_mF4401EFC2C2D29252A29378D375CCC6D782EE087 (void);
// 0x0000010D System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener::OnLoadSuccess(System.String)
extern void IosLoadListener_OnLoadSuccess_mCD4C8EE6F7E3A0376F4EB1709646555B26A9AAAA (void);
// 0x0000010E System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener::OnLoadFailure(System.String,UnityEngine.Advertisements.UnityAdsLoadError,System.String)
extern void IosLoadListener_OnLoadFailure_m1D5BB1C51B30DA99E9D70B0B8548EF36754CA5CF (void);
// 0x0000010F System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener::OnLoadSuccess(System.IntPtr,System.String)
extern void IosLoadListener_OnLoadSuccess_mACCFA237ACF117DBC6DCFBCA5FA893FA150D893E (void);
// 0x00000110 System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener::OnLoadFailure(System.IntPtr,System.String,System.Int32,System.String)
extern void IosLoadListener_OnLoadFailure_mE48F1E2C64E55357454B5F38691F712A05AEC408 (void);
// 0x00000111 System.IntPtr UnityEngine.Advertisements.Platform.iOS.IosNativeObject::get_NativePtr()
extern void IosNativeObject_get_NativePtr_m70F0060C2BE0027EAD205623693F5522273D7D5E (void);
// 0x00000112 System.Void UnityEngine.Advertisements.Platform.iOS.IosNativeObject::set_NativePtr(System.IntPtr)
extern void IosNativeObject_set_NativePtr_m2F5808DA8B1CE8B9983B321BF4E3A384E9FF8415 (void);
// 0x00000113 T UnityEngine.Advertisements.Platform.iOS.IosNativeObject::Get(System.IntPtr)
// 0x00000114 System.Void UnityEngine.Advertisements.Platform.iOS.IosNativeObject::Dispose()
extern void IosNativeObject_Dispose_m97DE423FA0CDA9886510E563CF3106C20D372173 (void);
// 0x00000115 System.Boolean UnityEngine.Advertisements.Platform.iOS.IosNativeObject::CheckDisposedAndLogError(System.String)
extern void IosNativeObject_CheckDisposedAndLogError_mC5BD769254B21ED66F9FB256F4AAE02DAD813D43 (void);
// 0x00000116 System.Void UnityEngine.Advertisements.Platform.iOS.IosNativeObject::BridgeTransfer(System.IntPtr)
extern void IosNativeObject_BridgeTransfer_mF70B93701A5891545A1C4FF12CB1BF33F939A72F (void);
// 0x00000117 System.Void UnityEngine.Advertisements.Platform.iOS.IosNativeObject::.ctor()
extern void IosNativeObject__ctor_m084AA40BB515668A227859CF0C6C514D3EF61707 (void);
// 0x00000118 System.Void UnityEngine.Advertisements.Platform.iOS.IosNativeObject::.cctor()
extern void IosNativeObject__cctor_m1CFA8382105A813D98D61111379B68FBB2ECB562 (void);
// 0x00000119 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsInitialize(System.String,System.Boolean,System.Boolean,System.IntPtr)
extern void IosPlatform_UnityAdsInitialize_m7F792FD8C8C4213E60B5CDE29CF15BFAFF7202CA (void);
// 0x0000011A System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsLoad(System.String,System.IntPtr)
extern void IosPlatform_UnityAdsLoad_m74D8787A1EE65EFA87F779EEC8D9C48970F3B9B2 (void);
// 0x0000011B System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsShow(System.String,System.IntPtr)
extern void IosPlatform_UnityAdsShow_m78B05A21E37B20C90BFEBA11E73870D8A0C2B38B (void);
// 0x0000011C System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsGetDebugMode()
extern void IosPlatform_UnityAdsGetDebugMode_m529F081EE77335C695FF55F7F6AA2374B1B1BAB5 (void);
// 0x0000011D System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetDebugMode(System.Boolean)
extern void IosPlatform_UnityAdsSetDebugMode_m75EE2424DC58160A3C53C59AAB63F637BF24CF4C (void);
// 0x0000011E System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsIsReady(System.String)
extern void IosPlatform_UnityAdsIsReady_mBB145935C94449C20C3D8CE1C4C8AA5AF52CC175 (void);
// 0x0000011F System.Int64 UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsGetPlacementState(System.String)
extern void IosPlatform_UnityAdsGetPlacementState_m2662630C1AC6FD599760D155BD525DE306CA80F2 (void);
// 0x00000120 System.String UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsGetVersion()
extern void IosPlatform_UnityAdsGetVersion_m988279238980B7318E733AAD804CFD0399143AF7 (void);
// 0x00000121 System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsIsInitialized()
extern void IosPlatform_UnityAdsIsInitialized_mB595E4B35A3FA2361D041D589B1DD646E74703F6 (void);
// 0x00000122 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetMetaData(System.String,System.String)
extern void IosPlatform_UnityAdsSetMetaData_mC8E95162AD60440FA7190082F0E9BCC912AC27C3 (void);
// 0x00000123 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetReadyCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsReadyDelegate)
extern void IosPlatform_UnityAdsSetReadyCallback_m3C359000C268FF33B3B99DA392DBF055DB43E817 (void);
// 0x00000124 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetDidErrorCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidErrorDelegate)
extern void IosPlatform_UnityAdsSetDidErrorCallback_m110F976323E17EE15AB8DA900AF674D75D6AEAE1 (void);
// 0x00000125 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetDidStartCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidStartDelegate)
extern void IosPlatform_UnityAdsSetDidStartCallback_mA68270B26EB969B34EDB18A442347000509F36FA (void);
// 0x00000126 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsSetDidFinishCallback(UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidFinishDelegate)
extern void IosPlatform_UnityAdsSetDidFinishCallback_m64BB031218D08B38C731DBC63EE9F9FC767A1535 (void);
// 0x00000127 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsReady(System.String)
extern void IosPlatform_UnityAdsReady_mA9E4CF6B2D5E3221AC2C620D458C119F3EDC64FA (void);
// 0x00000128 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsDidError(System.Int64,System.String)
extern void IosPlatform_UnityAdsDidError_m1FD041ADCF92A2FC629260C81EE5553519D66BC7 (void);
// 0x00000129 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsDidStart(System.String)
extern void IosPlatform_UnityAdsDidStart_m42C9E6831D166DE71597242632BB487A85BD769B (void);
// 0x0000012A System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::UnityAdsDidFinish(System.String,System.Int64)
extern void IosPlatform_UnityAdsDidFinish_m22B0654A8F7A3FE1FC148A257565711E0B59DEB8 (void);
// 0x0000012B System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::SetupPlatform(UnityEngine.Advertisements.Platform.IPlatform)
extern void IosPlatform_SetupPlatform_m0E9E7ABFD5B388B9A31FA9D88D20BA47E7EFAC14 (void);
// 0x0000012C System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::Initialize(System.String,System.Boolean,System.Boolean,UnityEngine.Advertisements.IUnityAdsInitializationListener)
extern void IosPlatform_Initialize_mF8BEED3F3ABAFEBE1B2C7423F9E0E9C93FBA659B (void);
// 0x0000012D System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::Load(System.String,UnityEngine.Advertisements.IUnityAdsLoadListener)
extern void IosPlatform_Load_m55575724B95E404C751AA9CD6B87C81380303A51 (void);
// 0x0000012E System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::Show(System.String,UnityEngine.Advertisements.IUnityAdsShowListener)
extern void IosPlatform_Show_mBB529F8F8855B4D67DAFBE0EBB77A691A3E7824E (void);
// 0x0000012F System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::SetMetaData(UnityEngine.Advertisements.MetaData)
extern void IosPlatform_SetMetaData_m58323D2F7440828FB4279C41485CA0BCF5AD6A27 (void);
// 0x00000130 System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::GetDebugMode()
extern void IosPlatform_GetDebugMode_m77B1C0758908BE92A376E0ACF8BB98FD7B8C8671 (void);
// 0x00000131 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::SetDebugMode(System.Boolean)
extern void IosPlatform_SetDebugMode_m18AFF991BBBD7B11F44F6EECA9F070ACC6D79868 (void);
// 0x00000132 System.String UnityEngine.Advertisements.Platform.iOS.IosPlatform::GetVersion()
extern void IosPlatform_GetVersion_m07DDEEA493DBD6C8F1EB57B954D9EA3992CB801A (void);
// 0x00000133 System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::IsInitialized()
extern void IosPlatform_IsInitialized_m552D9503986D869D1EB4CA3918FBA996D818DF42 (void);
// 0x00000134 System.Boolean UnityEngine.Advertisements.Platform.iOS.IosPlatform::IsReady(System.String)
extern void IosPlatform_IsReady_m8F1C9ABBEA143D8D77464D3B97CA1864BFA14BEC (void);
// 0x00000135 UnityEngine.Advertisements.PlacementState UnityEngine.Advertisements.Platform.iOS.IosPlatform::GetPlacementState(System.String)
extern void IosPlatform_GetPlacementState_m1C0D4480EA8448AE089A906DF1D6D8FAE266B686 (void);
// 0x00000136 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnInitializationComplete()
extern void IosPlatform_OnInitializationComplete_m165FAB3FE7AA2D0F34BD78F93BC0D326D6EB1532 (void);
// 0x00000137 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnInitializationFailed(UnityEngine.Advertisements.UnityAdsInitializationError,System.String)
extern void IosPlatform_OnInitializationFailed_m49567293B42372DBF5018CB81D57E14788ACBD02 (void);
// 0x00000138 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnUnityAdsAdLoaded(System.String)
extern void IosPlatform_OnUnityAdsAdLoaded_mF4DA6031AEC83A48DDA8E5D285B31BC6D1C35B66 (void);
// 0x00000139 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnUnityAdsFailedToLoad(System.String,UnityEngine.Advertisements.UnityAdsLoadError,System.String)
extern void IosPlatform_OnUnityAdsFailedToLoad_m0DC077F4C279BF37030DBBDB5CDD0CDE34E214D1 (void);
// 0x0000013A System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnUnityAdsShowFailure(System.String,UnityEngine.Advertisements.UnityAdsShowError,System.String)
extern void IosPlatform_OnUnityAdsShowFailure_m11DAE59056BF022001F3B7DE97AE62F70E11B5DD (void);
// 0x0000013B System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnUnityAdsShowStart(System.String)
extern void IosPlatform_OnUnityAdsShowStart_m6ADFC172A3BC7E32CB0D4815AA99A2596F88E0F2 (void);
// 0x0000013C System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnUnityAdsShowClick(System.String)
extern void IosPlatform_OnUnityAdsShowClick_m50DA88641B2F930C68718947337FBF91508FB051 (void);
// 0x0000013D System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::OnUnityAdsShowComplete(System.String,UnityEngine.Advertisements.UnityAdsShowCompletionState)
extern void IosPlatform_OnUnityAdsShowComplete_m54F545D7A67256297A041B2D7F9B6012BBA99879 (void);
// 0x0000013E System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform::.ctor()
extern void IosPlatform__ctor_m2D4882ADE2DF9D277B8C4CD8BD8A381220E22C23 (void);
// 0x0000013F System.Boolean UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::get_IsLoaded()
extern void UnsupportedBanner_get_IsLoaded_m0BB039D0D6A9BF5032CE36ABC17CA5264A6D0C9F (void);
// 0x00000140 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::SetupBanner(UnityEngine.Advertisements.IBanner)
extern void UnsupportedBanner_SetupBanner_m912E55A701E9B7647A52FF47BB735B880A9B9943 (void);
// 0x00000141 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::Load(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void UnsupportedBanner_Load_mD93A5A66C0BB2099AC16F863F6A9D9C40F083580 (void);
// 0x00000142 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void UnsupportedBanner_Show_mE8D919BE12EC291D44E3D104001A66BEE66D28B0 (void);
// 0x00000143 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::Hide(System.Boolean)
extern void UnsupportedBanner_Hide_m80C192F85C87A4EF9727B3CFB27030474EB3E345 (void);
// 0x00000144 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void UnsupportedBanner_SetPosition_mB6C4C53925FEEF718053ED01B54EFEA3C55C5113 (void);
// 0x00000145 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedBanner::.ctor()
extern void UnsupportedBanner__ctor_m6B41D663C41D5098FFBDD7FDF870348D596FFE1B (void);
// 0x00000146 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::SetupPlatform(UnityEngine.Advertisements.Platform.IPlatform)
extern void UnsupportedPlatform_SetupPlatform_m07FFBDEE6F0A87E89C281B7FF625B2E9904FDA61 (void);
// 0x00000147 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::Initialize(System.String,System.Boolean,System.Boolean,UnityEngine.Advertisements.IUnityAdsInitializationListener)
extern void UnsupportedPlatform_Initialize_m33A7B49C94ED72F8463C62B66CAEED5BABA37642 (void);
// 0x00000148 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::Load(System.String,UnityEngine.Advertisements.IUnityAdsLoadListener)
extern void UnsupportedPlatform_Load_mAE05B1813FCAD4C25EC71645B6CE9701808BE9B1 (void);
// 0x00000149 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::Show(System.String,UnityEngine.Advertisements.IUnityAdsShowListener)
extern void UnsupportedPlatform_Show_mCF02ECE9470901A269E5026921B9BC952DE22BF0 (void);
// 0x0000014A System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::SetMetaData(UnityEngine.Advertisements.MetaData)
extern void UnsupportedPlatform_SetMetaData_m16280B0463B803DE13CA0D6FDADF6BDAFF6C0854 (void);
// 0x0000014B System.Boolean UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::GetDebugMode()
extern void UnsupportedPlatform_GetDebugMode_m71BDBB707F6ED58AFAF6B75297E255E53B0216D2 (void);
// 0x0000014C System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::SetDebugMode(System.Boolean)
extern void UnsupportedPlatform_SetDebugMode_m732446E57AC582DBA4E3961C3AD4231E3A3D1BB3 (void);
// 0x0000014D System.String UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::GetVersion()
extern void UnsupportedPlatform_GetVersion_m5368C4F0EEEF0A1A7D7221CB0FF8168BBB16B0D9 (void);
// 0x0000014E System.Boolean UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::IsInitialized()
extern void UnsupportedPlatform_IsInitialized_m87921E9D42AA30840904CAC680D72D0BC6D068E6 (void);
// 0x0000014F System.Boolean UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::IsReady(System.String)
extern void UnsupportedPlatform_IsReady_m2AFABAA0485BFE82500BA9998CB7FF11889CB7FB (void);
// 0x00000150 UnityEngine.Advertisements.PlacementState UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::GetPlacementState(System.String)
extern void UnsupportedPlatform_GetPlacementState_m65F12CFBDEB7F81220EF70081BA49405DAE0F7D2 (void);
// 0x00000151 System.Void UnityEngine.Advertisements.Platform.Unsupported.UnsupportedPlatform::.ctor()
extern void UnsupportedPlatform__ctor_mC4AE014E85C8D4B552EA8F1585AFB71EDC14B6B9 (void);
// 0x00000152 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::Awake()
extern void BannerPlaceholder_Awake_m898C4FE0CABA7D5F18A819EC4FC8F380E742BBDD (void);
// 0x00000153 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::OnGUI()
extern void BannerPlaceholder_OnGUI_mA70376B47DB047D475A3F4864C774ADF6C25DC0C (void);
// 0x00000154 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::ShowBanner(UnityEngine.Advertisements.BannerPosition,UnityEngine.Advertisements.BannerOptions)
extern void BannerPlaceholder_ShowBanner_m2B52D0FB6836358B080F05F594F2951AA11BE737 (void);
// 0x00000155 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::HideBanner()
extern void BannerPlaceholder_HideBanner_mBA6E9608FD218386724DE609F6A26B6B1F6456AB (void);
// 0x00000156 UnityEngine.Texture2D UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::BackgroundTexture(System.Int32,System.Int32,UnityEngine.Color)
extern void BannerPlaceholder_BackgroundTexture_m7E61CFE31A02520E2BEAE8C0BAD276C4FF53DDD8 (void);
// 0x00000157 UnityEngine.Rect UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::GetBannerRect(UnityEngine.Advertisements.BannerPosition)
extern void BannerPlaceholder_GetBannerRect_m9A55094BE7F6A137DD5FE7700F470B6862955DC7 (void);
// 0x00000158 System.Void UnityEngine.Advertisements.Platform.Editor.BannerPlaceholder::.ctor()
extern void BannerPlaceholder__ctor_mCCFA246032A19408FAEF07A5DB842D1B95379675 (void);
// 0x00000159 UnityEngine.AndroidJavaObject UnityEngine.Advertisements.Platform.Android.BannerBundle::get_bannerView()
extern void BannerBundle_get_bannerView_mE50FB92E90747E75AB5DE63FE1C213B41ADFDEE3 (void);
// 0x0000015A System.String UnityEngine.Advertisements.Platform.Android.BannerBundle::get_bannerPlacementId()
extern void BannerBundle_get_bannerPlacementId_m2EE1A282B8B4C4736F5D9DB99AAA7E9CCF9A8AD8 (void);
// 0x0000015B System.Void UnityEngine.Advertisements.Platform.Android.BannerBundle::.ctor(System.String,UnityEngine.AndroidJavaObject)
extern void BannerBundle__ctor_mDD42F9A5AE41820E548E5575BA1CFAA6C7A5B203 (void);
// 0x0000015C System.String UnityEngine.Advertisements.Events.FinishEventArgs::get_placementId()
extern void FinishEventArgs_get_placementId_m91D1164FE93ED198B873A37DD0EA85DB620AA084 (void);
// 0x0000015D UnityEngine.Advertisements.ShowResult UnityEngine.Advertisements.Events.FinishEventArgs::get_showResult()
extern void FinishEventArgs_get_showResult_mAB26315E89A05B14A156DDA6ED353101BD6FE777 (void);
// 0x0000015E System.Void UnityEngine.Advertisements.Events.FinishEventArgs::.ctor(System.String,UnityEngine.Advertisements.ShowResult)
extern void FinishEventArgs__ctor_m2392AE3702DF11744E0158FA3DF644C831EC84EA (void);
// 0x0000015F System.String UnityEngine.Advertisements.Events.StartEventArgs::get_placementId()
extern void StartEventArgs_get_placementId_m22F9475913A5805D375AE71958129FB5C26E0560 (void);
// 0x00000160 System.Void UnityEngine.Advertisements.Events.StartEventArgs::.ctor(System.String)
extern void StartEventArgs__ctor_mFDFC795C296E269DF42A892E3DD64368531C4722 (void);
// 0x00000161 System.Void UnityEngine.Advertisements.Advertisement/Banner::Load()
extern void Banner_Load_mBA47B5839D40225B0B923B2457331C092613A2FE (void);
// 0x00000162 System.Void UnityEngine.Advertisements.Advertisement/Banner::Load(UnityEngine.Advertisements.BannerLoadOptions)
extern void Banner_Load_m56AF64046B75377371D61DE62C41D5831D15BA51 (void);
// 0x00000163 System.Void UnityEngine.Advertisements.Advertisement/Banner::Load(System.String)
extern void Banner_Load_m542459C4BC49F26B18BFB8018DC8A6AE1122CA98 (void);
// 0x00000164 System.Void UnityEngine.Advertisements.Advertisement/Banner::Load(System.String,UnityEngine.Advertisements.BannerLoadOptions)
extern void Banner_Load_m91F0E9246B5844FA2A49B2AC5196DB3CB54B3662 (void);
// 0x00000165 System.Void UnityEngine.Advertisements.Advertisement/Banner::Show()
extern void Banner_Show_mEF8162A84A573020DC235FABBA28328C39F51799 (void);
// 0x00000166 System.Void UnityEngine.Advertisements.Advertisement/Banner::Show(UnityEngine.Advertisements.BannerOptions)
extern void Banner_Show_m00D0F19D67BCAD877A69A04D1BEB2F4254C2B05E (void);
// 0x00000167 System.Void UnityEngine.Advertisements.Advertisement/Banner::Show(System.String)
extern void Banner_Show_m37266C62650718DEFA8D22BA202ED2E3FF6F918A (void);
// 0x00000168 System.Void UnityEngine.Advertisements.Advertisement/Banner::Show(System.String,UnityEngine.Advertisements.BannerOptions)
extern void Banner_Show_m8D6A3EFFB38C3A03ADC2EE8E39BBFD563EAA30F1 (void);
// 0x00000169 System.Void UnityEngine.Advertisements.Advertisement/Banner::Hide(System.Boolean)
extern void Banner_Hide_mEAFFF7D35BB3C6D24648DE71DCD8CB8BA9D9C0A1 (void);
// 0x0000016A System.Void UnityEngine.Advertisements.Advertisement/Banner::SetPosition(UnityEngine.Advertisements.BannerPosition)
extern void Banner_SetPosition_m9702B5000DEAE4559A78FFB893D3E44B99D409B0 (void);
// 0x0000016B System.Boolean UnityEngine.Advertisements.Advertisement/Banner::get_isLoaded()
extern void Banner_get_isLoaded_m4B6DDD0C7419B6B0E5C0DFFC642C4978F1159C33 (void);
// 0x0000016C System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass15_0::.ctor()
extern void U3CU3Ec__DisplayClass15_0__ctor_mCC64FD7367BC9BB33D4E2E0A1FAEC78B9C7F33F8 (void);
// 0x0000016D System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass15_0::<UnityAdsBannerDidShow>b__0()
extern void U3CU3Ec__DisplayClass15_0_U3CUnityAdsBannerDidShowU3Eb__0_m7CD84618ECF27A68FBA842600C383272BC1B226B (void);
// 0x0000016E System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass16_0::.ctor()
extern void U3CU3Ec__DisplayClass16_0__ctor_m38A2279BA62CCB0FF0D94289B9B77FFD3F72AF87 (void);
// 0x0000016F System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass16_0::<UnityAdsBannerDidHide>b__0()
extern void U3CU3Ec__DisplayClass16_0_U3CUnityAdsBannerDidHideU3Eb__0_m3765549A302A79F9D507F28F1F2A253D00D8CE91 (void);
// 0x00000170 System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass17_0::.ctor()
extern void U3CU3Ec__DisplayClass17_0__ctor_m0CE7C483B69FB8884EC29A4799816C4B8B7E8A2B (void);
// 0x00000171 System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass17_0::<UnityAdsBannerClick>b__0()
extern void U3CU3Ec__DisplayClass17_0_U3CUnityAdsBannerClickU3Eb__0_m5E947FF1D791AC388EB9C0CAB49BCBB4B69474F0 (void);
// 0x00000172 System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass18_0::.ctor()
extern void U3CU3Ec__DisplayClass18_0__ctor_mA4357B8B800CD0993FB4E4BEB8F8801A07FE3084 (void);
// 0x00000173 System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass18_0::<UnityAdsBannerDidLoad>b__0()
extern void U3CU3Ec__DisplayClass18_0_U3CUnityAdsBannerDidLoadU3Eb__0_m54C06CA2E4529401D06B8EE3F4FA0CDDC253A636 (void);
// 0x00000174 System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass19_0::.ctor()
extern void U3CU3Ec__DisplayClass19_0__ctor_m499C02EEC0A5F2FBC23FEE6CF7BFC7FABB8DA4CE (void);
// 0x00000175 System.Void UnityEngine.Advertisements.Banner/<>c__DisplayClass19_0::<UnityAdsBannerDidError>b__0()
extern void U3CU3Ec__DisplayClass19_0_U3CUnityAdsBannerDidErrorU3Eb__0_m20094F7296DD2DEFC0FB3AC92F998EF972C69EFA (void);
// 0x00000176 System.Void UnityEngine.Advertisements.BannerLoadOptions/LoadCallback::.ctor(System.Object,System.IntPtr)
extern void LoadCallback__ctor_m305157FEACA5F8F1428052C0B272ED74A82D664A (void);
// 0x00000177 System.Void UnityEngine.Advertisements.BannerLoadOptions/LoadCallback::Invoke()
extern void LoadCallback_Invoke_m9570E4CB10A505C83FE45B561EC87FC8C0240676 (void);
// 0x00000178 System.IAsyncResult UnityEngine.Advertisements.BannerLoadOptions/LoadCallback::BeginInvoke(System.AsyncCallback,System.Object)
extern void LoadCallback_BeginInvoke_m7F2E7A77679D0645C5346244CF9BCA5AC5BD544C (void);
// 0x00000179 System.Void UnityEngine.Advertisements.BannerLoadOptions/LoadCallback::EndInvoke(System.IAsyncResult)
extern void LoadCallback_EndInvoke_mDA5E0B4A3AC36F0E0AFF68674D89497D47E3A7B7 (void);
// 0x0000017A System.Void UnityEngine.Advertisements.BannerLoadOptions/ErrorCallback::.ctor(System.Object,System.IntPtr)
extern void ErrorCallback__ctor_mBAC1DF97ECC0A531A6349BE2BDAC98D83B815B55 (void);
// 0x0000017B System.Void UnityEngine.Advertisements.BannerLoadOptions/ErrorCallback::Invoke(System.String)
extern void ErrorCallback_Invoke_m4EB1D40DB65FA4F6EEE59E5FBD0EAF3148042403 (void);
// 0x0000017C System.IAsyncResult UnityEngine.Advertisements.BannerLoadOptions/ErrorCallback::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void ErrorCallback_BeginInvoke_mD1CFA430D8B4F52D46CDE7A2C41ABBE48E5AD714 (void);
// 0x0000017D System.Void UnityEngine.Advertisements.BannerLoadOptions/ErrorCallback::EndInvoke(System.IAsyncResult)
extern void ErrorCallback_EndInvoke_m66010D943DED5C042A3FACFB2B90D59470F7D6D1 (void);
// 0x0000017E System.Void UnityEngine.Advertisements.BannerOptions/BannerCallback::.ctor(System.Object,System.IntPtr)
extern void BannerCallback__ctor_mADACAD326678A5610264029F20626AE6BD4D75C2 (void);
// 0x0000017F System.Void UnityEngine.Advertisements.BannerOptions/BannerCallback::Invoke()
extern void BannerCallback_Invoke_m4E89C14132D2FCE64E7FF24105EF46D52383DBB8 (void);
// 0x00000180 System.IAsyncResult UnityEngine.Advertisements.BannerOptions/BannerCallback::BeginInvoke(System.AsyncCallback,System.Object)
extern void BannerCallback_BeginInvoke_m6EBF38D280C56CEE854ABF51BF9B9C2E81052062 (void);
// 0x00000181 System.Void UnityEngine.Advertisements.BannerOptions/BannerCallback::EndInvoke(System.IAsyncResult)
extern void BannerCallback_EndInvoke_m1F8EE2B6FE1F87122D02AFAAB285C2CEF738DB01 (void);
// 0x00000182 System.Void UnityEngine.Advertisements.IosShowListener/ShowFailureCallback::.ctor(System.Object,System.IntPtr)
extern void ShowFailureCallback__ctor_m79836133154E24B888DBEAE5C54722B72999CA84 (void);
// 0x00000183 System.Void UnityEngine.Advertisements.IosShowListener/ShowFailureCallback::Invoke(System.IntPtr,System.String,System.Int32,System.String)
extern void ShowFailureCallback_Invoke_mD286AB758F4ED4E8902F7A9B10ED80DB6A4A9E10 (void);
// 0x00000184 System.IAsyncResult UnityEngine.Advertisements.IosShowListener/ShowFailureCallback::BeginInvoke(System.IntPtr,System.String,System.Int32,System.String,System.AsyncCallback,System.Object)
extern void ShowFailureCallback_BeginInvoke_mA65BDE7BADE130C828803A637BB45CE7BD6F6179 (void);
// 0x00000185 System.Void UnityEngine.Advertisements.IosShowListener/ShowFailureCallback::EndInvoke(System.IAsyncResult)
extern void ShowFailureCallback_EndInvoke_m1EA01D094F9DC3D2F5DB5ADFB9C5F31040B2A5E0 (void);
// 0x00000186 System.Void UnityEngine.Advertisements.IosShowListener/ShowStartCallback::.ctor(System.Object,System.IntPtr)
extern void ShowStartCallback__ctor_mC654721326B73BD91BF3D4C41B44F816DFEAE771 (void);
// 0x00000187 System.Void UnityEngine.Advertisements.IosShowListener/ShowStartCallback::Invoke(System.IntPtr,System.String)
extern void ShowStartCallback_Invoke_m10596277AC24F5C4753A153E2061C1E4A466CA82 (void);
// 0x00000188 System.IAsyncResult UnityEngine.Advertisements.IosShowListener/ShowStartCallback::BeginInvoke(System.IntPtr,System.String,System.AsyncCallback,System.Object)
extern void ShowStartCallback_BeginInvoke_mE7456BB973000DB63E792C7AC8A4F66BE0E283EB (void);
// 0x00000189 System.Void UnityEngine.Advertisements.IosShowListener/ShowStartCallback::EndInvoke(System.IAsyncResult)
extern void ShowStartCallback_EndInvoke_m6EE2B8A1964854A744B9C3ABF3B03F1758204F58 (void);
// 0x0000018A System.Void UnityEngine.Advertisements.IosShowListener/ShowClickCallback::.ctor(System.Object,System.IntPtr)
extern void ShowClickCallback__ctor_mC814019CA28D94102C27B95E1C634686CAC35DC8 (void);
// 0x0000018B System.Void UnityEngine.Advertisements.IosShowListener/ShowClickCallback::Invoke(System.IntPtr,System.String)
extern void ShowClickCallback_Invoke_m42B9DDC63B6627583B51CDEE24EE5AFC2F9B890E (void);
// 0x0000018C System.IAsyncResult UnityEngine.Advertisements.IosShowListener/ShowClickCallback::BeginInvoke(System.IntPtr,System.String,System.AsyncCallback,System.Object)
extern void ShowClickCallback_BeginInvoke_mBDC6AFDA526D6A6B3EFB3F00E9091D046DCDEB5B (void);
// 0x0000018D System.Void UnityEngine.Advertisements.IosShowListener/ShowClickCallback::EndInvoke(System.IAsyncResult)
extern void ShowClickCallback_EndInvoke_mC7F766D4AD1DD111EBD299F9796AD3728EEDE64F (void);
// 0x0000018E System.Void UnityEngine.Advertisements.IosShowListener/ShowCompleteCallback::.ctor(System.Object,System.IntPtr)
extern void ShowCompleteCallback__ctor_mF9E99494300C4B7D7E0C14AA5E9C92FFDD55395E (void);
// 0x0000018F System.Void UnityEngine.Advertisements.IosShowListener/ShowCompleteCallback::Invoke(System.IntPtr,System.String,System.Int32)
extern void ShowCompleteCallback_Invoke_m62E31F55BCEF98EDB9505396FB647B2379F0EDE6 (void);
// 0x00000190 System.IAsyncResult UnityEngine.Advertisements.IosShowListener/ShowCompleteCallback::BeginInvoke(System.IntPtr,System.String,System.Int32,System.AsyncCallback,System.Object)
extern void ShowCompleteCallback_BeginInvoke_m66B6D90C47DCEBDFFD98475EFBCC9E75984D80EB (void);
// 0x00000191 System.Void UnityEngine.Advertisements.IosShowListener/ShowCompleteCallback::EndInvoke(System.IAsyncResult)
extern void ShowCompleteCallback_EndInvoke_m25656B1D47AB4E6D1DD44E2DA67DA3083E531BD6 (void);
// 0x00000192 System.Boolean UnityEngine.Advertisements.Utilities.Json/Parser::IsWordBreak(System.Char)
extern void Parser_IsWordBreak_m8B54B909FE036BA2082AE8EC387A2ADFC21EAC6F (void);
// 0x00000193 System.Void UnityEngine.Advertisements.Utilities.Json/Parser::.ctor(System.String)
extern void Parser__ctor_m42EEF2B0976B20A2CD29DB6C5FCD05E1A012E5F8 (void);
// 0x00000194 System.Object UnityEngine.Advertisements.Utilities.Json/Parser::Parse(System.String)
extern void Parser_Parse_m90ED5A60B77CD855573389CD84CE032513C746A2 (void);
// 0x00000195 System.Void UnityEngine.Advertisements.Utilities.Json/Parser::Dispose()
extern void Parser_Dispose_m2A07168BD10CEA46DA2CACFD6BD782EE25F82050 (void);
// 0x00000196 System.Collections.Generic.Dictionary`2<System.String,System.Object> UnityEngine.Advertisements.Utilities.Json/Parser::ParseObject()
extern void Parser_ParseObject_m42875CC021A802442E2B284E92292EAD60AE1D55 (void);
// 0x00000197 System.Collections.Generic.List`1<System.Object> UnityEngine.Advertisements.Utilities.Json/Parser::ParseArray()
extern void Parser_ParseArray_m54BC3094FAF3F5F7A17BFC4F4D3E49ED4B62B3ED (void);
// 0x00000198 System.Object UnityEngine.Advertisements.Utilities.Json/Parser::ParseValue()
extern void Parser_ParseValue_m37BEFD4EBF4947BCAE0C81931269FDA1329E7A5F (void);
// 0x00000199 System.Object UnityEngine.Advertisements.Utilities.Json/Parser::ParseByToken(UnityEngine.Advertisements.Utilities.Json/Parser/TOKEN)
extern void Parser_ParseByToken_mCE5106A0660A237B336C54FE533DFC848B6063F3 (void);
// 0x0000019A System.String UnityEngine.Advertisements.Utilities.Json/Parser::ParseString()
extern void Parser_ParseString_mF6555DE9F03D6E1C41AF2275CAB9CDC23E06F8D1 (void);
// 0x0000019B System.Object UnityEngine.Advertisements.Utilities.Json/Parser::ParseNumber()
extern void Parser_ParseNumber_m0CD9E560AA011359DA186D34AD86373AB8B9748E (void);
// 0x0000019C System.Void UnityEngine.Advertisements.Utilities.Json/Parser::EatWhitespace()
extern void Parser_EatWhitespace_mBCE62C7753CFB15C75F55E06FDAF7E2E4C52DB78 (void);
// 0x0000019D System.Char UnityEngine.Advertisements.Utilities.Json/Parser::get_PeekChar()
extern void Parser_get_PeekChar_m520EE6274B12AAEBA29A5FE875EFB0EAD30DDCCF (void);
// 0x0000019E System.Char UnityEngine.Advertisements.Utilities.Json/Parser::get_NextChar()
extern void Parser_get_NextChar_mFD32621E440C5DC97485F103D19D12D98D5BF0C7 (void);
// 0x0000019F System.String UnityEngine.Advertisements.Utilities.Json/Parser::get_NextWord()
extern void Parser_get_NextWord_m10363D1790B1CBAFCE37753265C92C999CA7CCCF (void);
// 0x000001A0 UnityEngine.Advertisements.Utilities.Json/Parser/TOKEN UnityEngine.Advertisements.Utilities.Json/Parser::get_NextToken()
extern void Parser_get_NextToken_m08D211C5295A2B6E0D4C92DE89B02B24867E1A95 (void);
// 0x000001A1 System.Void UnityEngine.Advertisements.Utilities.Json/Serializer::.ctor()
extern void Serializer__ctor_mA9E182BB1AF8DE414EDF580C718579F75D5AA45B (void);
// 0x000001A2 System.String UnityEngine.Advertisements.Utilities.Json/Serializer::Serialize(System.Object)
extern void Serializer_Serialize_mF464E27665130F84BD5166C0D849346C5E757C9F (void);
// 0x000001A3 System.Void UnityEngine.Advertisements.Utilities.Json/Serializer::SerializeValue(System.Object)
extern void Serializer_SerializeValue_mD87B5A13CF1BF235F690E2B3BF5CCF35D503A2D9 (void);
// 0x000001A4 System.Void UnityEngine.Advertisements.Utilities.Json/Serializer::SerializeObject(System.Collections.IDictionary)
extern void Serializer_SerializeObject_m69B76ADE79ABAA227F83B474234DB708EBDBD4A1 (void);
// 0x000001A5 System.Void UnityEngine.Advertisements.Utilities.Json/Serializer::SerializeArray(System.Collections.IList)
extern void Serializer_SerializeArray_mD77EE4394CABA80F36E0B92DBC4B3FD8607D0BDE (void);
// 0x000001A6 System.Void UnityEngine.Advertisements.Utilities.Json/Serializer::SerializeString(System.String)
extern void Serializer_SerializeString_m62F099482076DA02E7E7C570D038B4C2778F1B53 (void);
// 0x000001A7 System.Void UnityEngine.Advertisements.Utilities.Json/Serializer::SerializeOther(System.Object)
extern void Serializer_SerializeOther_m2964B3A04A5F8FBE64F68F10A18FFC37FDCA91F8 (void);
// 0x000001A8 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingDidInitiatePurchasingCommand::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingDidInitiatePurchasingCommand__ctor_m0CDFE57D62FE258EC2DCBC727E237557584B87E4 (void);
// 0x000001A9 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingDidInitiatePurchasingCommand::Invoke(System.String)
extern void unityAdsPurchasingDidInitiatePurchasingCommand_Invoke_m63F32DD9E88AB7425C3A4F23F1AD4DC8A31B407C (void);
// 0x000001AA System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingDidInitiatePurchasingCommand::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void unityAdsPurchasingDidInitiatePurchasingCommand_BeginInvoke_m109F8134CC3047D4331A252CD89BDE79887690D6 (void);
// 0x000001AB System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingDidInitiatePurchasingCommand::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingDidInitiatePurchasingCommand_EndInvoke_m47E4864090AF27EDC395B7ED2B563960FA649B56 (void);
// 0x000001AC System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetProductCatalog::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingGetProductCatalog__ctor_m1E34F7B8E965C1D70109FA360A9204289A97CA00 (void);
// 0x000001AD System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetProductCatalog::Invoke()
extern void unityAdsPurchasingGetProductCatalog_Invoke_mBA94276439A2CFBBA6196C1BCFE7F09C1942EAED (void);
// 0x000001AE System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetProductCatalog::BeginInvoke(System.AsyncCallback,System.Object)
extern void unityAdsPurchasingGetProductCatalog_BeginInvoke_m9CC6AE5B63AC78D93231CC8E591D780C809CC179 (void);
// 0x000001AF System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetProductCatalog::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingGetProductCatalog_EndInvoke_mD8D01C1AB467EE2A48C0D9EDED81842B1D7BA846 (void);
// 0x000001B0 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetPurchasingVersion::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingGetPurchasingVersion__ctor_m9C6B7B1F54A59412838578950E0320DE0960C939 (void);
// 0x000001B1 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetPurchasingVersion::Invoke()
extern void unityAdsPurchasingGetPurchasingVersion_Invoke_m36E062CDDA618EE8FEDF95F9D5082D15EC5B018F (void);
// 0x000001B2 System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetPurchasingVersion::BeginInvoke(System.AsyncCallback,System.Object)
extern void unityAdsPurchasingGetPurchasingVersion_BeginInvoke_mFDB15CE68F658F8332F0B176F373804E9A4F0E47 (void);
// 0x000001B3 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingGetPurchasingVersion::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingGetPurchasingVersion_EndInvoke_m42B0385BBD1249F7126F0170D56E30769335ABD6 (void);
// 0x000001B4 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingInitialize::.ctor(System.Object,System.IntPtr)
extern void unityAdsPurchasingInitialize__ctor_m59D50DD21C20DC777C7B01D370ADC162DA4CCE0C (void);
// 0x000001B5 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingInitialize::Invoke()
extern void unityAdsPurchasingInitialize_Invoke_mBB8052FB178F27227FB27C5340D94573441288A4 (void);
// 0x000001B6 System.IAsyncResult UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingInitialize::BeginInvoke(System.AsyncCallback,System.Object)
extern void unityAdsPurchasingInitialize_BeginInvoke_mF29505F90CE725392CC699DAD7BDBF5D54E4826B (void);
// 0x000001B7 System.Void UnityEngine.Advertisements.Purchasing.PurchasingPlatform/unityAdsPurchasingInitialize::EndInvoke(System.IAsyncResult)
extern void unityAdsPurchasingInitialize_EndInvoke_m71E935BC0D3F6B75C799EB1623EEB834461D0B71 (void);
// 0x000001B8 System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass33_0::.ctor()
extern void U3CU3Ec__DisplayClass33_0__ctor_mF8DEAAC5275198667A04824D28F837EEAD9C851B (void);
// 0x000001B9 System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass33_1::.ctor()
extern void U3CU3Ec__DisplayClass33_1__ctor_mFEF409622B746A97BA20E78634FD3036895F58BD (void);
// 0x000001BA System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass33_1::<Show>b__0(System.Object,UnityEngine.Advertisements.Events.FinishEventArgs)
extern void U3CU3Ec__DisplayClass33_1_U3CShowU3Eb__0_mA1F90EB84923D22E0877D55D4732210E8C15B224 (void);
// 0x000001BB System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass39_0::.ctor()
extern void U3CU3Ec__DisplayClass39_0__ctor_m9B15B9A3C70E740ED72E6517292ED3F4F4D4E72D (void);
// 0x000001BC System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass39_0::<UnityAdsReady>b__0()
extern void U3CU3Ec__DisplayClass39_0_U3CUnityAdsReadyU3Eb__0_m194D9E59AA7F46DDFFDC116B1A1F084F1C560E27 (void);
// 0x000001BD System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass40_0::.ctor()
extern void U3CU3Ec__DisplayClass40_0__ctor_mD121A299B602902B19C09CF267BFCD1F8949A554 (void);
// 0x000001BE System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass40_0::<UnityAdsDidError>b__0()
extern void U3CU3Ec__DisplayClass40_0_U3CUnityAdsDidErrorU3Eb__0_mA466B47C4B8CC88481E66A8AC72F1773C3938295 (void);
// 0x000001BF System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass41_0::.ctor()
extern void U3CU3Ec__DisplayClass41_0__ctor_m34271219435CA5FA96AAF340D3878FEFE51C24F4 (void);
// 0x000001C0 System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass41_0::<UnityAdsDidStart>b__0()
extern void U3CU3Ec__DisplayClass41_0_U3CUnityAdsDidStartU3Eb__0_m480BCB2B59D53A7898062A790CA66C3DE5681EC6 (void);
// 0x000001C1 System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass42_0::.ctor()
extern void U3CU3Ec__DisplayClass42_0__ctor_m6544AA0AC07FDD9337CC99D6021A6BF20C197378 (void);
// 0x000001C2 System.Void UnityEngine.Advertisements.Platform.Platform/<>c__DisplayClass42_0::<UnityAdsDidFinish>b__0()
extern void U3CU3Ec__DisplayClass42_0_U3CUnityAdsDidFinishU3Eb__0_mD1EBE884069C51BCB36DAE5C1CAFB6099E2F9418 (void);
// 0x000001C3 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerShowDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerShowDelegate__ctor_mEA4CB7117B43E34539327FA0D064DAE700A7C9CE (void);
// 0x000001C4 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerShowDelegate::Invoke(System.String)
extern void UnityAdsBannerShowDelegate_Invoke_m1517DF6E4FDA6BAE378898AAC3A47C481FC7B836 (void);
// 0x000001C5 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerShowDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerShowDelegate_BeginInvoke_m09E1DA481D0534CA751469B6B5180BE4265696FB (void);
// 0x000001C6 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerShowDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerShowDelegate_EndInvoke_m173CDD9219D014985AC7C3C622D07455F1F1D757 (void);
// 0x000001C7 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerHideDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerHideDelegate__ctor_m031D46C7BE39CF04A2585DC80E3A4CA2F1E21BFC (void);
// 0x000001C8 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerHideDelegate::Invoke(System.String)
extern void UnityAdsBannerHideDelegate_Invoke_m725C30DE237F6EA626EE7D7462F3E27BE20395B5 (void);
// 0x000001C9 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerHideDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerHideDelegate_BeginInvoke_m7BC8C3BDC119F63A8C8EA2C4013485411B4A673F (void);
// 0x000001CA System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerHideDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerHideDelegate_EndInvoke_mC11967247599324F849DF4D72397807549D5F2FB (void);
// 0x000001CB System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerClickDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerClickDelegate__ctor_mFA9FFA200A21F953B7A63059E4611F9048045F8C (void);
// 0x000001CC System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerClickDelegate::Invoke(System.String)
extern void UnityAdsBannerClickDelegate_Invoke_mBA73DE6AAC4A784BC98E42F364369F6E8B55A19F (void);
// 0x000001CD System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerClickDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerClickDelegate_BeginInvoke_m70D5F8F5255839354F90D79D460D3D0FA7825A62 (void);
// 0x000001CE System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerClickDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerClickDelegate_EndInvoke_mD3EA7ED0D9927175664FE13EB83B08C519422704 (void);
// 0x000001CF System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerUnloadDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerUnloadDelegate__ctor_m5CD5A22A105AC6803A2C6746E5F2311441511C1F (void);
// 0x000001D0 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerUnloadDelegate::Invoke(System.String)
extern void UnityAdsBannerUnloadDelegate_Invoke_m67E339CB33312B6175197720451154898641EFCD (void);
// 0x000001D1 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerUnloadDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerUnloadDelegate_BeginInvoke_m1678927A68A7A380C728F87BBE68F037BE5104EA (void);
// 0x000001D2 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerUnloadDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerUnloadDelegate_EndInvoke_m80D3522DB8D055BC27FACB098C74C4DE78589918 (void);
// 0x000001D3 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerLoadDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerLoadDelegate__ctor_mCE24BA6ABE9A53AC674103060E978A425C290E79 (void);
// 0x000001D4 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerLoadDelegate::Invoke(System.String)
extern void UnityAdsBannerLoadDelegate_Invoke_m9B70F4B3219D969F684B74DC40E6E6CE90E9F1FC (void);
// 0x000001D5 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerLoadDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerLoadDelegate_BeginInvoke_mBCD15984B754F745A4CEB05AD9C3C6567B982FBA (void);
// 0x000001D6 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerLoadDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerLoadDelegate_EndInvoke_mD796A36C1BC6D29D077FECE2F17F55CE5F687F17 (void);
// 0x000001D7 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerErrorDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsBannerErrorDelegate__ctor_m581CCF9AFA3085CAE320E9E852D5736D77173ACC (void);
// 0x000001D8 System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerErrorDelegate::Invoke(System.String)
extern void UnityAdsBannerErrorDelegate_Invoke_mD1DAFC9B1009751085CF752FD8EBF3DAB518EAA3 (void);
// 0x000001D9 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerErrorDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsBannerErrorDelegate_BeginInvoke_mE9F6BDA6A61F86496ABFD310608F44B9DD2CDA83 (void);
// 0x000001DA System.Void UnityEngine.Advertisements.Platform.iOS.IosBanner/UnityAdsBannerErrorDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsBannerErrorDelegate_EndInvoke_mA0EDFD7CFDB9D27D4374E1D5E27EB78B7211389D (void);
// 0x000001DB System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitSuccessCallback::.ctor(System.Object,System.IntPtr)
extern void InitSuccessCallback__ctor_m5153B0A00D50A339FD515B765D9208AF28730A3C (void);
// 0x000001DC System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitSuccessCallback::Invoke(System.IntPtr)
extern void InitSuccessCallback_Invoke_m2E2F94F6B481B6949D377DA96CF20A56C4A94D16 (void);
// 0x000001DD System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitSuccessCallback::BeginInvoke(System.IntPtr,System.AsyncCallback,System.Object)
extern void InitSuccessCallback_BeginInvoke_m2157089A5EA24326EBBA6BCD400F76A42411AF19 (void);
// 0x000001DE System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitSuccessCallback::EndInvoke(System.IAsyncResult)
extern void InitSuccessCallback_EndInvoke_mC034C412F061BF5047BBAC9A0C0B02F5D464D19C (void);
// 0x000001DF System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitFailureCallback::.ctor(System.Object,System.IntPtr)
extern void InitFailureCallback__ctor_mE33C982659190A101B6ADA1E475177E646AF834B (void);
// 0x000001E0 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitFailureCallback::Invoke(System.IntPtr,System.Int32,System.String)
extern void InitFailureCallback_Invoke_mAD66972FF514E8512390379FB296F3AAEDE2847E (void);
// 0x000001E1 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitFailureCallback::BeginInvoke(System.IntPtr,System.Int32,System.String,System.AsyncCallback,System.Object)
extern void InitFailureCallback_BeginInvoke_mBC5540FFA94DAA62C24366F008A3DD6B7F492E16 (void);
// 0x000001E2 System.Void UnityEngine.Advertisements.Platform.iOS.IosInitializationListener/InitFailureCallback::EndInvoke(System.IAsyncResult)
extern void InitFailureCallback_EndInvoke_m21BE381E031C34EF27A6FB17AC759224383259BE (void);
// 0x000001E3 System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadSuccessCallback::.ctor(System.Object,System.IntPtr)
extern void LoadSuccessCallback__ctor_m6D09CD6F5B418754BA31DBA261AE058812A89367 (void);
// 0x000001E4 System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadSuccessCallback::Invoke(System.IntPtr,System.String)
extern void LoadSuccessCallback_Invoke_m2032D08B29582FA063363DEBFCC0667C69D21762 (void);
// 0x000001E5 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadSuccessCallback::BeginInvoke(System.IntPtr,System.String,System.AsyncCallback,System.Object)
extern void LoadSuccessCallback_BeginInvoke_m7C8C526400BD4A7934FAF248F2E4BAFDFCEF7FBC (void);
// 0x000001E6 System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadSuccessCallback::EndInvoke(System.IAsyncResult)
extern void LoadSuccessCallback_EndInvoke_m6E6140AED4ABD4FFBB415219D413D499E5D13894 (void);
// 0x000001E7 System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadFailureCallback::.ctor(System.Object,System.IntPtr)
extern void LoadFailureCallback__ctor_m94F111C40FFBECD9EEC20854C2A032FD362EAC62 (void);
// 0x000001E8 System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadFailureCallback::Invoke(System.IntPtr,System.String,System.Int32,System.String)
extern void LoadFailureCallback_Invoke_m47F04A4F55FB41B6E2B893B7149083DB0DC00834 (void);
// 0x000001E9 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadFailureCallback::BeginInvoke(System.IntPtr,System.String,System.Int32,System.String,System.AsyncCallback,System.Object)
extern void LoadFailureCallback_BeginInvoke_m6E47BB29A94904F6C9D0A926EEA32A0F4B2D623C (void);
// 0x000001EA System.Void UnityEngine.Advertisements.Platform.iOS.IosLoadListener/LoadFailureCallback::EndInvoke(System.IAsyncResult)
extern void LoadFailureCallback_EndInvoke_mE02335B500B800FC3B47C96BB603057AD48B02A6 (void);
// 0x000001EB System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsReadyDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsReadyDelegate__ctor_m208444661206B4D4A7CD97F935906121B4E48230 (void);
// 0x000001EC System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsReadyDelegate::Invoke(System.String)
extern void UnityAdsReadyDelegate_Invoke_m13374A06858BC19B9F03DB13BB4C82E5DA98AE10 (void);
// 0x000001ED System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsReadyDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsReadyDelegate_BeginInvoke_mF40328D42D2FA51EAEF96EE1B54713BF1F8532FB (void);
// 0x000001EE System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsReadyDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsReadyDelegate_EndInvoke_m28E1851F8A8036BA4C9024093CD2EE6AAF1CD2C8 (void);
// 0x000001EF System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidErrorDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsDidErrorDelegate__ctor_mBD6D252365B182851DA55C4EEC2B65B69DD6B8E6 (void);
// 0x000001F0 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidErrorDelegate::Invoke(System.Int64,System.String)
extern void UnityAdsDidErrorDelegate_Invoke_m3CC74A381F4F2BB5975279F5250C22B39C73C3B9 (void);
// 0x000001F1 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidErrorDelegate::BeginInvoke(System.Int64,System.String,System.AsyncCallback,System.Object)
extern void UnityAdsDidErrorDelegate_BeginInvoke_mDB3BEC18F259CA2A2E7A7230FDE50626A1067841 (void);
// 0x000001F2 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidErrorDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsDidErrorDelegate_EndInvoke_mC0E705439221D83B82051BAFE70C7F9A7EF69AC4 (void);
// 0x000001F3 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidStartDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsDidStartDelegate__ctor_mFC85FC90FFDEF06432FF8E06D0764449A7C319DC (void);
// 0x000001F4 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidStartDelegate::Invoke(System.String)
extern void UnityAdsDidStartDelegate_Invoke_m0535EB577523DE1DB964C64BBAEB0412A0E38C6D (void);
// 0x000001F5 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidStartDelegate::BeginInvoke(System.String,System.AsyncCallback,System.Object)
extern void UnityAdsDidStartDelegate_BeginInvoke_mA20B72D0C894993A7607B33FC018D5264AA4397A (void);
// 0x000001F6 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidStartDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsDidStartDelegate_EndInvoke_mB025BCA77165292B83D8CA3B3DA710132B58C632 (void);
// 0x000001F7 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidFinishDelegate::.ctor(System.Object,System.IntPtr)
extern void UnityAdsDidFinishDelegate__ctor_mE8609D65F8CBDD41D8975FBA75903735566ED0CD (void);
// 0x000001F8 System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidFinishDelegate::Invoke(System.String,System.Int64)
extern void UnityAdsDidFinishDelegate_Invoke_mFAB9D2B2F9F3250578899FBDDC3027FBFFB2458F (void);
// 0x000001F9 System.IAsyncResult UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidFinishDelegate::BeginInvoke(System.String,System.Int64,System.AsyncCallback,System.Object)
extern void UnityAdsDidFinishDelegate_BeginInvoke_m93AC44E3814984BE05BACE64937909818F363D63 (void);
// 0x000001FA System.Void UnityEngine.Advertisements.Platform.iOS.IosPlatform/UnityAdsDidFinishDelegate::EndInvoke(System.IAsyncResult)
extern void UnityAdsDidFinishDelegate_EndInvoke_mB54406F0D510D258BCBA191A9E94A7DEA99ADC59 (void);
static Il2CppMethodPointer s_methodPointers[506] = 
{
	Advertisement__cctor_m52E1D772906D0B337709705DB5DF0E48C9B1D6F7,
	Advertisement_get_isInitialized_m1C01B43E06433CFDE61A692463DA4447BDC98407,
	Advertisement_get_isSupported_m7DB9D5062BE0F832C8A0A2F3DC3952C46439C468,
	Advertisement_get_debugMode_m62CE2552DD4667FFC13E22DBFC36F8500B5F18E7,
	Advertisement_set_debugMode_mEAFCF663B855FC7BD6A0A7A4BA0B31D597C18DC6,
	Advertisement_get_version_m39B6859A9BE15054B8A32E2FCFCC0B53777A8EDB,
	Advertisement_get_isShowing_m161300800925F8FE0BC8B055A2329D850534BD27,
	Advertisement_Initialize_m6B5635CB28DC096033005BCECF5B06BFCED325E8,
	Advertisement_Initialize_m5839818AF61B8E2F8A8C4081E75EE06904FB9281,
	Advertisement_Initialize_m68FFB59A47D1D45BE72D93F9C40DA993912CA83E,
	Advertisement_Initialize_m2451DC90D17F25AE331E6B0269E6B6E9F417F85E,
	Advertisement_IsReady_m86E4F1FFA66A61CB90CE53EAE5134A1DEA62EB69,
	Advertisement_IsReady_mB0C468846BA1EB6F79E0975E6F576040BCBF8D71,
	Advertisement_Load_mF08D6827C3C696CC96913A648B6DA2176D89C7A9,
	Advertisement_Load_mBA07C0E271CA4E868C1F149061FD8AFA6C3E6356,
	Advertisement_Show_m31F94834C933936AEFE8F77417B26D73E0E64DAA,
	Advertisement_Show_m831A92003168618ED42FBBBB114DAEEE3EEE2515,
	Advertisement_Show_m357F8ACFF0830636134E30309DC55ABA34A5855C,
	Advertisement_Show_m88B56E134E3A966BFFAF5CCC812733975EDD72DD,
	Advertisement_Show_m743B10BD30AAC81286F342A86202F9667179E2DD,
	Advertisement_Show_m8F157B553AF2B1A71F1D9F2E65634E6E5F7102FA,
	Advertisement_SetMetaData_m7D525ADE1551BCF6AA50C65975ECEC17AA2D5C1C,
	Advertisement_AddListener_mE65054284863005B98668C5BBE3DE9717B8323BA,
	Advertisement_RemoveListener_m1F85A647140B0C8EAEF19F511D7D8699A1628F8B,
	Advertisement_GetPlacementState_mEC09D916B7DC457BAE7BAC3197046E3BCE1DE9F2,
	Advertisement_GetPlacementState_m90F6F5095AB56EF764384E863CBA9DF6CBF2B5BC,
	Advertisement_CreatePlatform_m6CEDF37CB020DCD5F67C3A2C4EADD4946D5C073D,
	Advertisement_IsSupported_m22D58DAFCF06EE34A28FCA70F3F83F0EB3C1B43E,
	Banner_get_UnityLifecycleManager_mE30C2332D59DFEE93636C03DB17377D2A5038087,
	Banner_get_IsLoaded_mD03A5A558F590B78747BEEC6D6674DEC561C0E36,
	Banner_get_ShowAfterLoad_m59F9227CC72DFA2A534212325337CCB030FB7558,
	Banner_set_ShowAfterLoad_m3C4AB777B09A8AA1E112679A6D1113405D6B432A,
	Banner__ctor_m0116AAD0DE60B0E60216407F52CEF792AB380D37,
	Banner_Load_m0BFAA399533961215AE11B6FFD9F973022BC68D8,
	Banner_Show_mB82FF1D83E3F90C59B1719D312757E7C73A89FEA,
	Banner_Hide_m040995248E0D5110F09C273D76D40989C7DCBB79,
	Banner_SetPosition_mF0CD74BA344244E2298032F8E05A93CCB39DBBED,
	Banner_UnityAdsBannerDidShow_m258EACA558D69B70E0E2AB1A5BDCC0C3BCA3CE9C,
	Banner_UnityAdsBannerDidHide_m2DFE26934F52C9C8781195BE0FC4F60399176AA4,
	Banner_UnityAdsBannerClick_mC5C8D932B671A20761FEFA9F591C86E5B0023554,
	Banner_UnityAdsBannerDidLoad_m8EEA613C407B219FC2D571B9180B0609B62DB50D,
	Banner_UnityAdsBannerDidError_mC4FA738D90B18288EAF2D7049FC4C3CCF62B83E2,
	BannerLoadOptions_get_loadCallback_m37677430405266FBE17C65136F61E5EF087C2172,
	BannerLoadOptions_set_loadCallback_m45A71D4B6725AFBA65DA59F7247A3FC5EBB6C7FD,
	BannerLoadOptions_get_errorCallback_m5AC99A074E22CAC9C4A22955FF1CD6636C386084,
	BannerLoadOptions_set_errorCallback_m63A6D83978EABC15FF36EAD00EF9AC9836C560CB,
	BannerLoadOptions__ctor_m72C3D5020D2A3F95D782444EBF680FC450D975EE,
	BannerOptions_get_showCallback_mC0E013AA66B4E479C727B161979D909D029DACEF,
	BannerOptions_set_showCallback_m23C2C3F54258E645185822103432F7BF08397854,
	BannerOptions_get_hideCallback_m8A6A29097B506C3C035FBBD9015A274F03DC6FA2,
	BannerOptions_set_hideCallback_m75DCCB0181010E409DCEA85D4BFC596971FC7316,
	BannerOptions_get_clickCallback_mCB2C1AA8F92047CE23BC36966218364154C17C74,
	BannerOptions_set_clickCallback_m5DBFDD399C73B2A96035AB78EB373FB490134252,
	BannerOptions__ctor_m045B88E9E89A8A0115FDE98D0EF61410196573B8,
	Configuration_get_enabled_mF18E740138295E18B275124D831DCDD6DD4DDE62,
	Configuration_get_defaultPlacement_m27C87984CE3AF25E6E3C8420E3FDBC75A069DCCC,
	Configuration_get_placements_mC269A1EA3158C8127F971C2D1CD6672F1B7D8F11,
	Configuration__ctor_m887D661502F7A61F2A1966155AB5AD1F3D27CD59,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	MetaData_get_category_mE557188BA130522D1F5E9FF1E0EA74C6B70A3D7B,
	MetaData_set_category_mC7842C7C0884F77BC1907FFF1F4921D3289E0520,
	MetaData__ctor_m721A701D2C7AB4C4225CF40A3981FE6D216E11D2,
	MetaData_Set_m5768578DC77104453F82BCB1B08DA79FAEB6EB85,
	MetaData_Get_mD183BFB965634057C3540E73A9CAAB3D11F0E34D,
	MetaData_Values_m280A5C4E0D8F6BF158D8C72DAB0B246DF1CB8552,
	MetaData_ToJSON_mB3DAC3CB05FDFA9328585787D3F2FC4E19185371,
	AndroidInitializationListener__ctor_m591420AEE2802666F33C33CE609B41E80D6F9675,
	AndroidInitializationListener_onInitializationComplete_m6659B1B07789AEDC70873C8E6641559C81B94CEF,
	AndroidInitializationListener_onInitializationFailed_m2FDE29A8C0EEACB0A0CD235E2148015E0C4B97EF,
	AndroidLoadListener__ctor_mAA72ADDE0D5C54196737B1E61DED6316CB79D731,
	AndroidLoadListener_onUnityAdsAdLoaded_m99695817E960F675EFB5AAD36D2EBF26C41191D5,
	AndroidLoadListener_onUnityAdsFailedToLoad_mDDB6BD6440767A1BD25A314EBC1938CEB6A42247,
	AndroidShowListener__ctor_mE09E4127293811F85D0A52A6AF32F0F3EC19E114,
	AndroidShowListener_onUnityAdsShowFailure_m5CD4D56F515626A2ABDCCB215A887AC6B264CD22,
	AndroidShowListener_onUnityAdsShowStart_mA81D8550865A2B1EA02429CFC4BEE7E18B9F79F6,
	AndroidShowListener_onUnityAdsShowClick_m5E0DBE4FCA4ADD20E91019D98EC9BBF9FCA49459,
	AndroidShowListener_onUnityAdsShowComplete_m8697D673772E7A5AEB8D27A1E17111272BEFBF29,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	IosShowListener_ShowListenerCreate_m7E7CECEFE3F8B16B7BE85A96651A94F6478CEF13,
	IosShowListener_ShowListenerDestroy_mC88C69D0DA3291A80BC46C32FB7EC937E602A2D9,
	IosShowListener__ctor_m4F14E89EB6630D7EAD2477794B3363E75F7D6BB1,
	IosShowListener_Dispose_mB53DFBBD9CC6DECAEB0860B893B7F0E376F37676,
	IosShowListener_OnShowFailure_m0EB6A914FA1270E446FAC739013CF5540337D218,
	IosShowListener_OnShowStart_m0BD2790A1EDCA1C8836543C11CDF21C943CFF764,
	IosShowListener_OnShowClick_mEF92B8FED73C716D86ACE0254231FF1A41D3FC73,
	IosShowListener_OnShowComplete_m5B29B63AD95CBBB863D335AE3547E754FD24ED72,
	IosShowListener_OnShowFailure_m1F449F5BA0EFA79DCD526B4AFA4FEC23611DC737,
	IosShowListener_OnShowStart_mE42C6FD6E21AFC9BBBDCD99B272DEF7FC375E494,
	IosShowListener_OnShowClick_m08D50F89BA9E45F3047B4D5BD497E38741939B08,
	IosShowListener_OnShowComplete_m233B64E74571ADCD363EECB90C7A42A91D30027E,
	ShowOptions_get_resultCallback_mBDF7C8F33645D0C9322FC9E9459924FB59C6355C,
	ShowOptions_set_resultCallback_m3A6AE34F4996F4824374235A881C24D3B85DF24E,
	ShowOptions_get_gamerSid_mCFE8CCA152EFEDDFF4503803CE86F519140848C4,
	ShowOptions_set_gamerSid_m43F550758438C335C1C3DA19863B0002648FE813,
	ShowOptions__ctor_m870E075D40F9D65228F35733FEB995C021BEA92F,
	ApplicationQuit_add_OnApplicationQuitEventHandler_m2153EFB5B8E4FBEBAEDE3A75710004EA43FFCF1C,
	ApplicationQuit_remove_OnApplicationQuitEventHandler_m83EBF68F4BE91FE0C33DE86D123C5AC3C2A9424A,
	ApplicationQuit_OnApplicationQuit_mC3E119DF3764A3EDA1686196FE8721A8CA6A3B5C,
	ApplicationQuit__ctor_m239E2A1680B0D4C2C9E38161F4064977AFC06BD3,
	CoroutineExecutor_Update_m7ACF3E0CFFBF53889AD233FD6C7922C8AE4A9B71,
	CoroutineExecutor__ctor_m014EB67E58FD803B7A1AD79493EE9203B2018150,
	EnumUtilities_GetShowResultsFromCompletionState_m7F603E6D34416F890D0C1B1FE81CF564B513F5CC,
	NULL,
	NULL,
	NULL,
	NULL,
	Json_Deserialize_mC9CF7DC20F96E3B2E53C2C125AE9F35B08C5CDFC,
	Json_Serialize_m8FC74A4B2C34176F8062B6097FCF24126B0F5CAC,
	UnityLifecycleManager__ctor_m369FEC9D7C6399AE2E0FF7101DADD6E403712873,
	UnityLifecycleManager_Initialize_m16C569D5D2DDED13E9AE28FB86F1732479C8C315,
	UnityLifecycleManager_StartCoroutine_m16B16D3D504BF71147FFE9C996952AD97D8F509D,
	UnityLifecycleManager_Post_mB8349441FD9073B233AE460BE22FAF5AD37AE992,
	UnityLifecycleManager_Dispose_m1B3A528ABA5ADBEECB41C5C760460A1998C58A38,
	UnityLifecycleManager_SetOnApplicationQuitCallback_mA35C6454001EB05ECF9CE1A92EC68047C94FB2A3,
	NULL,
	Purchasing_Initialize_m7B97864F3F8DE36834B9D4806BA535DA51671F0C,
	Purchasing_InitiatePurchasingCommand_m57469B23AF1BEF4A61D88F8ECB3A6CFB48C7F256,
	Purchasing_GetPurchasingCatalog_m9891E4FF2635394DFFF2748910A0149943FDD546,
	Purchasing_GetPromoVersion_m5E4C0890F43DFA870A53B3610A4CE6BA026338ED,
	Purchasing_SendEvent_m662912F361C5EFC0BEB551F3A53F2B8DE351083C,
	Purchasing__cctor_m71D2788D601C85D73A1F90B930724B88342156FF,
	PurchasingPlatform_get_Instance_m376B995017FD53D5F465E9FB22267DD17FE5AAF2,
	PurchasingPlatform_set_Instance_m8335E0D23D7A4D3A100EFCF70A4262C9604411BD,
	PurchasingPlatform_UnityAdsPurchasingDispatchReturnEvent_m865E890CFF9835F525DF90F633A48AF5AF7F3B07,
	PurchasingPlatform_UnityAdsSetDidInitiatePurchasingCommandCallback_mA5E26D1343552B4F0332A25E7F187D70D843A391,
	PurchasingPlatform_UnityAdsSetGetProductCatalogCallback_m8AB4F65A6C08F99D58D4C313FAB734DDF69EDAC7,
	PurchasingPlatform_UnityAdsSetGetVersionCallback_m73441F22CA3B60A6B1E2AB7032DDACA33FC1B62E,
	PurchasingPlatform_UnityAdsSetInitializePurchasingCallback_m2285E992C073ED26769B9FB1EE385861D37CF775,
	PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mC4F34F7E115EBACCBF488E35161B3765379754BF,
	PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m56F70A02157D109E98C81C22262686A560A479FC,
	PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mD96F20497B37585C57677515C6B671F4A1DC1227,
	PurchasingPlatform_UnityAdsPurchasingInitialize_m4004786A5894AF8350718CDC9346426D0E09619C,
	PurchasingPlatform_Initialize_m8C5496F575B6E838A80DC75281D0642C795078FF,
	PurchasingPlatform_SendPurchasingEvent_m7E1BD56DCA41B2DC88131265C93EBD81259A921D,
	PurchasingPlatform__ctor_m4331BE43EF4984D4185B327548B1C9F5123A54E3,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	NULL,
	Platform_add_OnStart_m4CCC0A40221A5C08A2CDAC53E8D5BDE10D3C8351,
	Platform_remove_OnStart_m1C270153A43C4E94FF440AA6CF6EF0B7D92CA185,
	Platform_add_OnFinish_m15DFC29065F86B3B9DA918CB7F8BB089D86591DE,
	Platform_remove_OnFinish_m40E075AF1A0107C7190242103B7033D9345F6AE3,
	Platform_get_Banner_m97AFECBBBAF48C7B5A345AF1EE5C45209C050329,
	Platform_get_UnityLifecycleManager_m97C9CC36483A73D5C90A96866789DF8C0C8133E2,
	Platform_get_NativePlatform_mC66B09E84BD53B90DEF2F7F68225EB57EB8A6796,
	Platform_get_IsInitialized_m19661CA3030933F62AF20C8384EFE2ADC8B97C66,
	Platform_get_IsShowing_mA551BD72286383227ABD6161E21357E89972550E,
	Platform_set_IsShowing_m712A3A6B5FB6A618353812142AAB0E6D54C7E9F7,
	Platform_get_Version_m3623DC6D1D20F4E9B7A56C8C0733DC4937A9952A,
	Platform_get_DebugMode_m13FC53CEA266DC1161931AF895397E65F7010ECD,
	Platform_set_DebugMode_m83E17ED67E02B08FCFDA864E5DCDDCB45B315DF0,
	Platform_get_Listeners_m448B5DCB0475ECD7D2D71EAEBBEAD3A6B1C74322,
	Platform__ctor_m17186969821C864E4D8BB7C909137E0C7C5608D9,
	Platform_Initialize_mA273C7552B41E4AD8E4C293285AA1121C4550E9A,
	Platform_Load_m9B9D1490876B216636BC7DD13CA793F97F46E1A4,
	Platform_Load_m2CB4A0F4FB27440901552C56A61F4DC54CAA773C,
	Platform_Show_m2DEFF1A65813BEB3430DB9E47694AC37A5C628A2,
	Platform_AddListener_mC151CA68BC5A176169D072A70EA9642BCAEF6571,
	Platform_RemoveListener_m112D3C1344835B5EFCDE013785048AE4E0FF988F,
	Platform_IsReady_mB2891E3422F9CC0D8667D24757530A2638EAC213,
	Platform_GetPlacementState_m0F2BCDA009BC61C14AF2950A0AFC4AFD27A6E8CC,
	Platform_SetMetaData_m17C3A65CA16D80CD026728E9CC118C4A7795CA6C,
	Platform_UnityAdsReady_m87617D19B85ECCB079DEC36965B7EA67B5687B00,
	Platform_UnityAdsDidError_m2BD791A567D64231EA88B1A5F679E8DD758FF1B8,
	Platform_UnityAdsDidStart_m2D8762382F7302548E1F28600138BD0BEAA54EB0,
	Platform_UnityAdsDidFinish_mFE66E66B2B8ACEF5D1CBCD847C4505F287B318BF,
	Platform_GetClonedHashSet_m9B9FA72BA90E7087A0D2438C46C06D09FDB68F34,
	Platform_U3CInitializeU3Eb__30_0_m47F5CC8A10F22E483FAE404A4CAA36B867F0325B,
	Platform_U3CInitializeU3Eb__30_1_m510A7C88373E4D81922BFFA44E284A648BCD5AB5,
	IosBanner_get_IsLoaded_mA5FCD8CC559AE885D0D220A1C2C1D9973F8BD542,
	IosBanner_set_IsLoaded_m4A5F87ED363645F1FE64E814121CC0F45EAF3202,
	IosBanner_UnityAdsBannerShow_mCA57B1527FD27663D727C2C863D7CCEABCB4F41E,
	IosBanner_UnityAdsBannerHide_mE158DC816CEAFD522C9F8D8D0B2539FBA0295BB7,
	IosBanner_UnityAdsBannerIsLoaded_m6733432B7E7A7AF8AD669CE3CE6EB76E9B327925,
	IosBanner_UnityAdsBannerSetPosition_m8427AF7CFC95628450CFDF6D8D6DAE9331435C84,
	IosBanner_UnityAdsSetBannerShowCallback_mC9658554E6DFF098A22F7AC79631A51068433958,
	IosBanner_UnityAdsSetBannerHideCallback_m63BEB2C8E57DEBD4B6413D5B808408B66D87F4DB,
	IosBanner_UnityAdsSetBannerClickCallback_m4177784A68961587A6E346427600DBCF303E80D2,
	IosBanner_UnityAdsSetBannerErrorCallback_mE19536F9CD2312BB4A3882AAD129A0A7E1E91C5F,
	IosBanner_UnityAdsSetBannerUnloadCallback_m1C5B0AC22DD96436161ECDC843B6A46E31543B71,
	IosBanner_UnityAdsSetBannerLoadCallback_m865AC53E15647BF4E44DAB5B061655E84BD5CB6C,
	IosBanner_UnityBannerInitialize_m87FA22B7F8717EDB2887D10386AE11CAF4F19CEE,
	IosBanner_UnityAdsBannerDidShow_m3120A02395BCBF393FA6D6CA0E338FC035A3AC83,
	IosBanner_UnityAdsBannerDidHide_m388BF2978CA575D09935957B1D33AA329BEFF628,
	IosBanner_UnityAdsBannerClick_m64AE141B67AC8303DCB6074D65BDDEDEAD483AEF,
	IosBanner_UnityAdsBannerDidError_mBEE10F30BF7C0ADE11902976DF5F271D11778D58,
	IosBanner_UnityAdsBannerDidUnload_m37C9378F35879F763BD7DF4326010DBADA94E706,
	IosBanner_UnityAdsBannerDidLoad_mE6E3534E4C772FFF746ADD4D3C99818C23B5E12D,
	IosBanner_SetupBanner_m954669BA682BC31515563E6D481C50599AC46076,
	IosBanner_Load_mCF83EB2528DAE6BD5F3DAB8E2E63A1DEE9328D3B,
	IosBanner_Show_m1B30DB60B3597A4A034BDB330B9A2920FC3C1E4D,
	IosBanner_Hide_mD89FFFB5D5CC270FB5B5C8BB9B3D7497FFD6A79F,
	IosBanner_SetPosition_m496A06603175794AAEC1BFCC5182771EDEE686D2,
	IosBanner__ctor_mE4836FCAC5D463FF8428FE7352064DC69F44F5F6,
	IosInitializationListener_InitializationListenerCreate_mA8AF3ACF4565AE255D37F828BBFED7307CDCB9F5,
	IosInitializationListener_InitializationListenerDestroy_m47D86F5B9ED766F4D039CB8ED2438E9B814383F6,
	IosInitializationListener__ctor_m1C225AB8C2D9B678D378A360C024D29D36726FE1,
	IosInitializationListener_Dispose_m9311B00ED0F4D5CB9B3D758D97BCE5A2A759C8BA,
	IosInitializationListener_OnInitializationComplete_m8CF5F45E354B34D225B9A32EDF80214CD696EEF7,
	IosInitializationListener_OnInitializationFailed_m328C7E854C5E2194A0334B0BF4B0943DB2D70DE7,
	IosInitializationListener_OnInitializationComplete_m5C1D21F520E9041AEB12472927EAD7880EE8F723,
	IosInitializationListener_OnInitializationFailed_m20705DB3847A26369E1BECDE24515EC935FC18BE,
	IosLoadListener_LoadListenerCreate_mD49F3BA9EF1EB94AC811730A19B3118180117EA5,
	IosLoadListener_LoadListenerDestroy_m2DAEF2DFC91195FB2A4C4AC6535D588031201D5F,
	IosLoadListener__ctor_m4DAC58F12ED2470FD087CC6808A0BFE6E450F1B1,
	IosLoadListener_Dispose_mF4401EFC2C2D29252A29378D375CCC6D782EE087,
	IosLoadListener_OnLoadSuccess_mCD4C8EE6F7E3A0376F4EB1709646555B26A9AAAA,
	IosLoadListener_OnLoadFailure_m1D5BB1C51B30DA99E9D70B0B8548EF36754CA5CF,
	IosLoadListener_OnLoadSuccess_mACCFA237ACF117DBC6DCFBCA5FA893FA150D893E,
	IosLoadListener_OnLoadFailure_mE48F1E2C64E55357454B5F38691F712A05AEC408,
	IosNativeObject_get_NativePtr_m70F0060C2BE0027EAD205623693F5522273D7D5E,
	IosNativeObject_set_NativePtr_m2F5808DA8B1CE8B9983B321BF4E3A384E9FF8415,
	NULL,
	IosNativeObject_Dispose_m97DE423FA0CDA9886510E563CF3106C20D372173,
	IosNativeObject_CheckDisposedAndLogError_mC5BD769254B21ED66F9FB256F4AAE02DAD813D43,
	IosNativeObject_BridgeTransfer_mF70B93701A5891545A1C4FF12CB1BF33F939A72F,
	IosNativeObject__ctor_m084AA40BB515668A227859CF0C6C514D3EF61707,
	IosNativeObject__cctor_m1CFA8382105A813D98D61111379B68FBB2ECB562,
	IosPlatform_UnityAdsInitialize_m7F792FD8C8C4213E60B5CDE29CF15BFAFF7202CA,
	IosPlatform_UnityAdsLoad_m74D8787A1EE65EFA87F779EEC8D9C48970F3B9B2,
	IosPlatform_UnityAdsShow_m78B05A21E37B20C90BFEBA11E73870D8A0C2B38B,
	IosPlatform_UnityAdsGetDebugMode_m529F081EE77335C695FF55F7F6AA2374B1B1BAB5,
	IosPlatform_UnityAdsSetDebugMode_m75EE2424DC58160A3C53C59AAB63F637BF24CF4C,
	IosPlatform_UnityAdsIsReady_mBB145935C94449C20C3D8CE1C4C8AA5AF52CC175,
	IosPlatform_UnityAdsGetPlacementState_m2662630C1AC6FD599760D155BD525DE306CA80F2,
	IosPlatform_UnityAdsGetVersion_m988279238980B7318E733AAD804CFD0399143AF7,
	IosPlatform_UnityAdsIsInitialized_mB595E4B35A3FA2361D041D589B1DD646E74703F6,
	IosPlatform_UnityAdsSetMetaData_mC8E95162AD60440FA7190082F0E9BCC912AC27C3,
	IosPlatform_UnityAdsSetReadyCallback_m3C359000C268FF33B3B99DA392DBF055DB43E817,
	IosPlatform_UnityAdsSetDidErrorCallback_m110F976323E17EE15AB8DA900AF674D75D6AEAE1,
	IosPlatform_UnityAdsSetDidStartCallback_mA68270B26EB969B34EDB18A442347000509F36FA,
	IosPlatform_UnityAdsSetDidFinishCallback_m64BB031218D08B38C731DBC63EE9F9FC767A1535,
	IosPlatform_UnityAdsReady_mA9E4CF6B2D5E3221AC2C620D458C119F3EDC64FA,
	IosPlatform_UnityAdsDidError_m1FD041ADCF92A2FC629260C81EE5553519D66BC7,
	IosPlatform_UnityAdsDidStart_m42C9E6831D166DE71597242632BB487A85BD769B,
	IosPlatform_UnityAdsDidFinish_m22B0654A8F7A3FE1FC148A257565711E0B59DEB8,
	IosPlatform_SetupPlatform_m0E9E7ABFD5B388B9A31FA9D88D20BA47E7EFAC14,
	IosPlatform_Initialize_mF8BEED3F3ABAFEBE1B2C7423F9E0E9C93FBA659B,
	IosPlatform_Load_m55575724B95E404C751AA9CD6B87C81380303A51,
	IosPlatform_Show_mBB529F8F8855B4D67DAFBE0EBB77A691A3E7824E,
	IosPlatform_SetMetaData_m58323D2F7440828FB4279C41485CA0BCF5AD6A27,
	IosPlatform_GetDebugMode_m77B1C0758908BE92A376E0ACF8BB98FD7B8C8671,
	IosPlatform_SetDebugMode_m18AFF991BBBD7B11F44F6EECA9F070ACC6D79868,
	IosPlatform_GetVersion_m07DDEEA493DBD6C8F1EB57B954D9EA3992CB801A,
	IosPlatform_IsInitialized_m552D9503986D869D1EB4CA3918FBA996D818DF42,
	IosPlatform_IsReady_m8F1C9ABBEA143D8D77464D3B97CA1864BFA14BEC,
	IosPlatform_GetPlacementState_m1C0D4480EA8448AE089A906DF1D6D8FAE266B686,
	IosPlatform_OnInitializationComplete_m165FAB3FE7AA2D0F34BD78F93BC0D326D6EB1532,
	IosPlatform_OnInitializationFailed_m49567293B42372DBF5018CB81D57E14788ACBD02,
	IosPlatform_OnUnityAdsAdLoaded_mF4DA6031AEC83A48DDA8E5D285B31BC6D1C35B66,
	IosPlatform_OnUnityAdsFailedToLoad_m0DC077F4C279BF37030DBBDB5CDD0CDE34E214D1,
	IosPlatform_OnUnityAdsShowFailure_m11DAE59056BF022001F3B7DE97AE62F70E11B5DD,
	IosPlatform_OnUnityAdsShowStart_m6ADFC172A3BC7E32CB0D4815AA99A2596F88E0F2,
	IosPlatform_OnUnityAdsShowClick_m50DA88641B2F930C68718947337FBF91508FB051,
	IosPlatform_OnUnityAdsShowComplete_m54F545D7A67256297A041B2D7F9B6012BBA99879,
	IosPlatform__ctor_m2D4882ADE2DF9D277B8C4CD8BD8A381220E22C23,
	UnsupportedBanner_get_IsLoaded_m0BB039D0D6A9BF5032CE36ABC17CA5264A6D0C9F,
	UnsupportedBanner_SetupBanner_m912E55A701E9B7647A52FF47BB735B880A9B9943,
	UnsupportedBanner_Load_mD93A5A66C0BB2099AC16F863F6A9D9C40F083580,
	UnsupportedBanner_Show_mE8D919BE12EC291D44E3D104001A66BEE66D28B0,
	UnsupportedBanner_Hide_m80C192F85C87A4EF9727B3CFB27030474EB3E345,
	UnsupportedBanner_SetPosition_mB6C4C53925FEEF718053ED01B54EFEA3C55C5113,
	UnsupportedBanner__ctor_m6B41D663C41D5098FFBDD7FDF870348D596FFE1B,
	UnsupportedPlatform_SetupPlatform_m07FFBDEE6F0A87E89C281B7FF625B2E9904FDA61,
	UnsupportedPlatform_Initialize_m33A7B49C94ED72F8463C62B66CAEED5BABA37642,
	UnsupportedPlatform_Load_mAE05B1813FCAD4C25EC71645B6CE9701808BE9B1,
	UnsupportedPlatform_Show_mCF02ECE9470901A269E5026921B9BC952DE22BF0,
	UnsupportedPlatform_SetMetaData_m16280B0463B803DE13CA0D6FDADF6BDAFF6C0854,
	UnsupportedPlatform_GetDebugMode_m71BDBB707F6ED58AFAF6B75297E255E53B0216D2,
	UnsupportedPlatform_SetDebugMode_m732446E57AC582DBA4E3961C3AD4231E3A3D1BB3,
	UnsupportedPlatform_GetVersion_m5368C4F0EEEF0A1A7D7221CB0FF8168BBB16B0D9,
	UnsupportedPlatform_IsInitialized_m87921E9D42AA30840904CAC680D72D0BC6D068E6,
	UnsupportedPlatform_IsReady_m2AFABAA0485BFE82500BA9998CB7FF11889CB7FB,
	UnsupportedPlatform_GetPlacementState_m65F12CFBDEB7F81220EF70081BA49405DAE0F7D2,
	UnsupportedPlatform__ctor_mC4AE014E85C8D4B552EA8F1585AFB71EDC14B6B9,
	BannerPlaceholder_Awake_m898C4FE0CABA7D5F18A819EC4FC8F380E742BBDD,
	BannerPlaceholder_OnGUI_mA70376B47DB047D475A3F4864C774ADF6C25DC0C,
	BannerPlaceholder_ShowBanner_m2B52D0FB6836358B080F05F594F2951AA11BE737,
	BannerPlaceholder_HideBanner_mBA6E9608FD218386724DE609F6A26B6B1F6456AB,
	BannerPlaceholder_BackgroundTexture_m7E61CFE31A02520E2BEAE8C0BAD276C4FF53DDD8,
	BannerPlaceholder_GetBannerRect_m9A55094BE7F6A137DD5FE7700F470B6862955DC7,
	BannerPlaceholder__ctor_mCCFA246032A19408FAEF07A5DB842D1B95379675,
	BannerBundle_get_bannerView_mE50FB92E90747E75AB5DE63FE1C213B41ADFDEE3,
	BannerBundle_get_bannerPlacementId_m2EE1A282B8B4C4736F5D9DB99AAA7E9CCF9A8AD8,
	BannerBundle__ctor_mDD42F9A5AE41820E548E5575BA1CFAA6C7A5B203,
	FinishEventArgs_get_placementId_m91D1164FE93ED198B873A37DD0EA85DB620AA084,
	FinishEventArgs_get_showResult_mAB26315E89A05B14A156DDA6ED353101BD6FE777,
	FinishEventArgs__ctor_m2392AE3702DF11744E0158FA3DF644C831EC84EA,
	StartEventArgs_get_placementId_m22F9475913A5805D375AE71958129FB5C26E0560,
	StartEventArgs__ctor_mFDFC795C296E269DF42A892E3DD64368531C4722,
	Banner_Load_mBA47B5839D40225B0B923B2457331C092613A2FE,
	Banner_Load_m56AF64046B75377371D61DE62C41D5831D15BA51,
	Banner_Load_m542459C4BC49F26B18BFB8018DC8A6AE1122CA98,
	Banner_Load_m91F0E9246B5844FA2A49B2AC5196DB3CB54B3662,
	Banner_Show_mEF8162A84A573020DC235FABBA28328C39F51799,
	Banner_Show_m00D0F19D67BCAD877A69A04D1BEB2F4254C2B05E,
	Banner_Show_m37266C62650718DEFA8D22BA202ED2E3FF6F918A,
	Banner_Show_m8D6A3EFFB38C3A03ADC2EE8E39BBFD563EAA30F1,
	Banner_Hide_mEAFFF7D35BB3C6D24648DE71DCD8CB8BA9D9C0A1,
	Banner_SetPosition_m9702B5000DEAE4559A78FFB893D3E44B99D409B0,
	Banner_get_isLoaded_m4B6DDD0C7419B6B0E5C0DFFC642C4978F1159C33,
	U3CU3Ec__DisplayClass15_0__ctor_mCC64FD7367BC9BB33D4E2E0A1FAEC78B9C7F33F8,
	U3CU3Ec__DisplayClass15_0_U3CUnityAdsBannerDidShowU3Eb__0_m7CD84618ECF27A68FBA842600C383272BC1B226B,
	U3CU3Ec__DisplayClass16_0__ctor_m38A2279BA62CCB0FF0D94289B9B77FFD3F72AF87,
	U3CU3Ec__DisplayClass16_0_U3CUnityAdsBannerDidHideU3Eb__0_m3765549A302A79F9D507F28F1F2A253D00D8CE91,
	U3CU3Ec__DisplayClass17_0__ctor_m0CE7C483B69FB8884EC29A4799816C4B8B7E8A2B,
	U3CU3Ec__DisplayClass17_0_U3CUnityAdsBannerClickU3Eb__0_m5E947FF1D791AC388EB9C0CAB49BCBB4B69474F0,
	U3CU3Ec__DisplayClass18_0__ctor_mA4357B8B800CD0993FB4E4BEB8F8801A07FE3084,
	U3CU3Ec__DisplayClass18_0_U3CUnityAdsBannerDidLoadU3Eb__0_m54C06CA2E4529401D06B8EE3F4FA0CDDC253A636,
	U3CU3Ec__DisplayClass19_0__ctor_m499C02EEC0A5F2FBC23FEE6CF7BFC7FABB8DA4CE,
	U3CU3Ec__DisplayClass19_0_U3CUnityAdsBannerDidErrorU3Eb__0_m20094F7296DD2DEFC0FB3AC92F998EF972C69EFA,
	LoadCallback__ctor_m305157FEACA5F8F1428052C0B272ED74A82D664A,
	LoadCallback_Invoke_m9570E4CB10A505C83FE45B561EC87FC8C0240676,
	LoadCallback_BeginInvoke_m7F2E7A77679D0645C5346244CF9BCA5AC5BD544C,
	LoadCallback_EndInvoke_mDA5E0B4A3AC36F0E0AFF68674D89497D47E3A7B7,
	ErrorCallback__ctor_mBAC1DF97ECC0A531A6349BE2BDAC98D83B815B55,
	ErrorCallback_Invoke_m4EB1D40DB65FA4F6EEE59E5FBD0EAF3148042403,
	ErrorCallback_BeginInvoke_mD1CFA430D8B4F52D46CDE7A2C41ABBE48E5AD714,
	ErrorCallback_EndInvoke_m66010D943DED5C042A3FACFB2B90D59470F7D6D1,
	BannerCallback__ctor_mADACAD326678A5610264029F20626AE6BD4D75C2,
	BannerCallback_Invoke_m4E89C14132D2FCE64E7FF24105EF46D52383DBB8,
	BannerCallback_BeginInvoke_m6EBF38D280C56CEE854ABF51BF9B9C2E81052062,
	BannerCallback_EndInvoke_m1F8EE2B6FE1F87122D02AFAAB285C2CEF738DB01,
	ShowFailureCallback__ctor_m79836133154E24B888DBEAE5C54722B72999CA84,
	ShowFailureCallback_Invoke_mD286AB758F4ED4E8902F7A9B10ED80DB6A4A9E10,
	ShowFailureCallback_BeginInvoke_mA65BDE7BADE130C828803A637BB45CE7BD6F6179,
	ShowFailureCallback_EndInvoke_m1EA01D094F9DC3D2F5DB5ADFB9C5F31040B2A5E0,
	ShowStartCallback__ctor_mC654721326B73BD91BF3D4C41B44F816DFEAE771,
	ShowStartCallback_Invoke_m10596277AC24F5C4753A153E2061C1E4A466CA82,
	ShowStartCallback_BeginInvoke_mE7456BB973000DB63E792C7AC8A4F66BE0E283EB,
	ShowStartCallback_EndInvoke_m6EE2B8A1964854A744B9C3ABF3B03F1758204F58,
	ShowClickCallback__ctor_mC814019CA28D94102C27B95E1C634686CAC35DC8,
	ShowClickCallback_Invoke_m42B9DDC63B6627583B51CDEE24EE5AFC2F9B890E,
	ShowClickCallback_BeginInvoke_mBDC6AFDA526D6A6B3EFB3F00E9091D046DCDEB5B,
	ShowClickCallback_EndInvoke_mC7F766D4AD1DD111EBD299F9796AD3728EEDE64F,
	ShowCompleteCallback__ctor_mF9E99494300C4B7D7E0C14AA5E9C92FFDD55395E,
	ShowCompleteCallback_Invoke_m62E31F55BCEF98EDB9505396FB647B2379F0EDE6,
	ShowCompleteCallback_BeginInvoke_m66B6D90C47DCEBDFFD98475EFBCC9E75984D80EB,
	ShowCompleteCallback_EndInvoke_m25656B1D47AB4E6D1DD44E2DA67DA3083E531BD6,
	Parser_IsWordBreak_m8B54B909FE036BA2082AE8EC387A2ADFC21EAC6F,
	Parser__ctor_m42EEF2B0976B20A2CD29DB6C5FCD05E1A012E5F8,
	Parser_Parse_m90ED5A60B77CD855573389CD84CE032513C746A2,
	Parser_Dispose_m2A07168BD10CEA46DA2CACFD6BD782EE25F82050,
	Parser_ParseObject_m42875CC021A802442E2B284E92292EAD60AE1D55,
	Parser_ParseArray_m54BC3094FAF3F5F7A17BFC4F4D3E49ED4B62B3ED,
	Parser_ParseValue_m37BEFD4EBF4947BCAE0C81931269FDA1329E7A5F,
	Parser_ParseByToken_mCE5106A0660A237B336C54FE533DFC848B6063F3,
	Parser_ParseString_mF6555DE9F03D6E1C41AF2275CAB9CDC23E06F8D1,
	Parser_ParseNumber_m0CD9E560AA011359DA186D34AD86373AB8B9748E,
	Parser_EatWhitespace_mBCE62C7753CFB15C75F55E06FDAF7E2E4C52DB78,
	Parser_get_PeekChar_m520EE6274B12AAEBA29A5FE875EFB0EAD30DDCCF,
	Parser_get_NextChar_mFD32621E440C5DC97485F103D19D12D98D5BF0C7,
	Parser_get_NextWord_m10363D1790B1CBAFCE37753265C92C999CA7CCCF,
	Parser_get_NextToken_m08D211C5295A2B6E0D4C92DE89B02B24867E1A95,
	Serializer__ctor_mA9E182BB1AF8DE414EDF580C718579F75D5AA45B,
	Serializer_Serialize_mF464E27665130F84BD5166C0D849346C5E757C9F,
	Serializer_SerializeValue_mD87B5A13CF1BF235F690E2B3BF5CCF35D503A2D9,
	Serializer_SerializeObject_m69B76ADE79ABAA227F83B474234DB708EBDBD4A1,
	Serializer_SerializeArray_mD77EE4394CABA80F36E0B92DBC4B3FD8607D0BDE,
	Serializer_SerializeString_m62F099482076DA02E7E7C570D038B4C2778F1B53,
	Serializer_SerializeOther_m2964B3A04A5F8FBE64F68F10A18FFC37FDCA91F8,
	unityAdsPurchasingDidInitiatePurchasingCommand__ctor_m0CDFE57D62FE258EC2DCBC727E237557584B87E4,
	unityAdsPurchasingDidInitiatePurchasingCommand_Invoke_m63F32DD9E88AB7425C3A4F23F1AD4DC8A31B407C,
	unityAdsPurchasingDidInitiatePurchasingCommand_BeginInvoke_m109F8134CC3047D4331A252CD89BDE79887690D6,
	unityAdsPurchasingDidInitiatePurchasingCommand_EndInvoke_m47E4864090AF27EDC395B7ED2B563960FA649B56,
	unityAdsPurchasingGetProductCatalog__ctor_m1E34F7B8E965C1D70109FA360A9204289A97CA00,
	unityAdsPurchasingGetProductCatalog_Invoke_mBA94276439A2CFBBA6196C1BCFE7F09C1942EAED,
	unityAdsPurchasingGetProductCatalog_BeginInvoke_m9CC6AE5B63AC78D93231CC8E591D780C809CC179,
	unityAdsPurchasingGetProductCatalog_EndInvoke_mD8D01C1AB467EE2A48C0D9EDED81842B1D7BA846,
	unityAdsPurchasingGetPurchasingVersion__ctor_m9C6B7B1F54A59412838578950E0320DE0960C939,
	unityAdsPurchasingGetPurchasingVersion_Invoke_m36E062CDDA618EE8FEDF95F9D5082D15EC5B018F,
	unityAdsPurchasingGetPurchasingVersion_BeginInvoke_mFDB15CE68F658F8332F0B176F373804E9A4F0E47,
	unityAdsPurchasingGetPurchasingVersion_EndInvoke_m42B0385BBD1249F7126F0170D56E30769335ABD6,
	unityAdsPurchasingInitialize__ctor_m59D50DD21C20DC777C7B01D370ADC162DA4CCE0C,
	unityAdsPurchasingInitialize_Invoke_mBB8052FB178F27227FB27C5340D94573441288A4,
	unityAdsPurchasingInitialize_BeginInvoke_mF29505F90CE725392CC699DAD7BDBF5D54E4826B,
	unityAdsPurchasingInitialize_EndInvoke_m71E935BC0D3F6B75C799EB1623EEB834461D0B71,
	U3CU3Ec__DisplayClass33_0__ctor_mF8DEAAC5275198667A04824D28F837EEAD9C851B,
	U3CU3Ec__DisplayClass33_1__ctor_mFEF409622B746A97BA20E78634FD3036895F58BD,
	U3CU3Ec__DisplayClass33_1_U3CShowU3Eb__0_mA1F90EB84923D22E0877D55D4732210E8C15B224,
	U3CU3Ec__DisplayClass39_0__ctor_m9B15B9A3C70E740ED72E6517292ED3F4F4D4E72D,
	U3CU3Ec__DisplayClass39_0_U3CUnityAdsReadyU3Eb__0_m194D9E59AA7F46DDFFDC116B1A1F084F1C560E27,
	U3CU3Ec__DisplayClass40_0__ctor_mD121A299B602902B19C09CF267BFCD1F8949A554,
	U3CU3Ec__DisplayClass40_0_U3CUnityAdsDidErrorU3Eb__0_mA466B47C4B8CC88481E66A8AC72F1773C3938295,
	U3CU3Ec__DisplayClass41_0__ctor_m34271219435CA5FA96AAF340D3878FEFE51C24F4,
	U3CU3Ec__DisplayClass41_0_U3CUnityAdsDidStartU3Eb__0_m480BCB2B59D53A7898062A790CA66C3DE5681EC6,
	U3CU3Ec__DisplayClass42_0__ctor_m6544AA0AC07FDD9337CC99D6021A6BF20C197378,
	U3CU3Ec__DisplayClass42_0_U3CUnityAdsDidFinishU3Eb__0_mD1EBE884069C51BCB36DAE5C1CAFB6099E2F9418,
	UnityAdsBannerShowDelegate__ctor_mEA4CB7117B43E34539327FA0D064DAE700A7C9CE,
	UnityAdsBannerShowDelegate_Invoke_m1517DF6E4FDA6BAE378898AAC3A47C481FC7B836,
	UnityAdsBannerShowDelegate_BeginInvoke_m09E1DA481D0534CA751469B6B5180BE4265696FB,
	UnityAdsBannerShowDelegate_EndInvoke_m173CDD9219D014985AC7C3C622D07455F1F1D757,
	UnityAdsBannerHideDelegate__ctor_m031D46C7BE39CF04A2585DC80E3A4CA2F1E21BFC,
	UnityAdsBannerHideDelegate_Invoke_m725C30DE237F6EA626EE7D7462F3E27BE20395B5,
	UnityAdsBannerHideDelegate_BeginInvoke_m7BC8C3BDC119F63A8C8EA2C4013485411B4A673F,
	UnityAdsBannerHideDelegate_EndInvoke_mC11967247599324F849DF4D72397807549D5F2FB,
	UnityAdsBannerClickDelegate__ctor_mFA9FFA200A21F953B7A63059E4611F9048045F8C,
	UnityAdsBannerClickDelegate_Invoke_mBA73DE6AAC4A784BC98E42F364369F6E8B55A19F,
	UnityAdsBannerClickDelegate_BeginInvoke_m70D5F8F5255839354F90D79D460D3D0FA7825A62,
	UnityAdsBannerClickDelegate_EndInvoke_mD3EA7ED0D9927175664FE13EB83B08C519422704,
	UnityAdsBannerUnloadDelegate__ctor_m5CD5A22A105AC6803A2C6746E5F2311441511C1F,
	UnityAdsBannerUnloadDelegate_Invoke_m67E339CB33312B6175197720451154898641EFCD,
	UnityAdsBannerUnloadDelegate_BeginInvoke_m1678927A68A7A380C728F87BBE68F037BE5104EA,
	UnityAdsBannerUnloadDelegate_EndInvoke_m80D3522DB8D055BC27FACB098C74C4DE78589918,
	UnityAdsBannerLoadDelegate__ctor_mCE24BA6ABE9A53AC674103060E978A425C290E79,
	UnityAdsBannerLoadDelegate_Invoke_m9B70F4B3219D969F684B74DC40E6E6CE90E9F1FC,
	UnityAdsBannerLoadDelegate_BeginInvoke_mBCD15984B754F745A4CEB05AD9C3C6567B982FBA,
	UnityAdsBannerLoadDelegate_EndInvoke_mD796A36C1BC6D29D077FECE2F17F55CE5F687F17,
	UnityAdsBannerErrorDelegate__ctor_m581CCF9AFA3085CAE320E9E852D5736D77173ACC,
	UnityAdsBannerErrorDelegate_Invoke_mD1DAFC9B1009751085CF752FD8EBF3DAB518EAA3,
	UnityAdsBannerErrorDelegate_BeginInvoke_mE9F6BDA6A61F86496ABFD310608F44B9DD2CDA83,
	UnityAdsBannerErrorDelegate_EndInvoke_mA0EDFD7CFDB9D27D4374E1D5E27EB78B7211389D,
	InitSuccessCallback__ctor_m5153B0A00D50A339FD515B765D9208AF28730A3C,
	InitSuccessCallback_Invoke_m2E2F94F6B481B6949D377DA96CF20A56C4A94D16,
	InitSuccessCallback_BeginInvoke_m2157089A5EA24326EBBA6BCD400F76A42411AF19,
	InitSuccessCallback_EndInvoke_mC034C412F061BF5047BBAC9A0C0B02F5D464D19C,
	InitFailureCallback__ctor_mE33C982659190A101B6ADA1E475177E646AF834B,
	InitFailureCallback_Invoke_mAD66972FF514E8512390379FB296F3AAEDE2847E,
	InitFailureCallback_BeginInvoke_mBC5540FFA94DAA62C24366F008A3DD6B7F492E16,
	InitFailureCallback_EndInvoke_m21BE381E031C34EF27A6FB17AC759224383259BE,
	LoadSuccessCallback__ctor_m6D09CD6F5B418754BA31DBA261AE058812A89367,
	LoadSuccessCallback_Invoke_m2032D08B29582FA063363DEBFCC0667C69D21762,
	LoadSuccessCallback_BeginInvoke_m7C8C526400BD4A7934FAF248F2E4BAFDFCEF7FBC,
	LoadSuccessCallback_EndInvoke_m6E6140AED4ABD4FFBB415219D413D499E5D13894,
	LoadFailureCallback__ctor_m94F111C40FFBECD9EEC20854C2A032FD362EAC62,
	LoadFailureCallback_Invoke_m47F04A4F55FB41B6E2B893B7149083DB0DC00834,
	LoadFailureCallback_BeginInvoke_m6E47BB29A94904F6C9D0A926EEA32A0F4B2D623C,
	LoadFailureCallback_EndInvoke_mE02335B500B800FC3B47C96BB603057AD48B02A6,
	UnityAdsReadyDelegate__ctor_m208444661206B4D4A7CD97F935906121B4E48230,
	UnityAdsReadyDelegate_Invoke_m13374A06858BC19B9F03DB13BB4C82E5DA98AE10,
	UnityAdsReadyDelegate_BeginInvoke_mF40328D42D2FA51EAEF96EE1B54713BF1F8532FB,
	UnityAdsReadyDelegate_EndInvoke_m28E1851F8A8036BA4C9024093CD2EE6AAF1CD2C8,
	UnityAdsDidErrorDelegate__ctor_mBD6D252365B182851DA55C4EEC2B65B69DD6B8E6,
	UnityAdsDidErrorDelegate_Invoke_m3CC74A381F4F2BB5975279F5250C22B39C73C3B9,
	UnityAdsDidErrorDelegate_BeginInvoke_mDB3BEC18F259CA2A2E7A7230FDE50626A1067841,
	UnityAdsDidErrorDelegate_EndInvoke_mC0E705439221D83B82051BAFE70C7F9A7EF69AC4,
	UnityAdsDidStartDelegate__ctor_mFC85FC90FFDEF06432FF8E06D0764449A7C319DC,
	UnityAdsDidStartDelegate_Invoke_m0535EB577523DE1DB964C64BBAEB0412A0E38C6D,
	UnityAdsDidStartDelegate_BeginInvoke_mA20B72D0C894993A7607B33FC018D5264AA4397A,
	UnityAdsDidStartDelegate_EndInvoke_mB025BCA77165292B83D8CA3B3DA710132B58C632,
	UnityAdsDidFinishDelegate__ctor_mE8609D65F8CBDD41D8975FBA75903735566ED0CD,
	UnityAdsDidFinishDelegate_Invoke_mFAB9D2B2F9F3250578899FBDDC3027FBFFB2458F,
	UnityAdsDidFinishDelegate_BeginInvoke_m93AC44E3814984BE05BACE64937909818F363D63,
	UnityAdsDidFinishDelegate_EndInvoke_mB54406F0D510D258BCBA191A9E94A7DEA99ADC59,
};
static const int32_t s_InvokerIndices[506] = 
{
	3,
	49,
	49,
	49,
	859,
	4,
	49,
	159,
	615,
	1801,
	2079,
	49,
	116,
	159,
	142,
	3,
	159,
	159,
	142,
	142,
	191,
	159,
	159,
	159,
	106,
	94,
	4,
	49,
	14,
	89,
	89,
	31,
	27,
	27,
	27,
	31,
	32,
	27,
	27,
	27,
	27,
	27,
	14,
	26,
	14,
	26,
	23,
	14,
	26,
	14,
	26,
	14,
	26,
	23,
	89,
	14,
	14,
	26,
	14,
	89,
	89,
	31,
	27,
	27,
	31,
	32,
	27,
	27,
	27,
	27,
	27,
	89,
	26,
	27,
	27,
	31,
	32,
	26,
	26,
	26,
	137,
	23,
	62,
	26,
	107,
	107,
	26,
	26,
	137,
	14,
	26,
	26,
	27,
	28,
	14,
	14,
	27,
	23,
	27,
	27,
	26,
	202,
	27,
	202,
	26,
	26,
	27,
	26,
	1199,
	27,
	27,
	26,
	89,
	31,
	14,
	89,
	9,
	112,
	2080,
	25,
	27,
	23,
	107,
	26,
	26,
	137,
	2081,
	1194,
	1194,
	2082,
	14,
	26,
	14,
	26,
	23,
	26,
	26,
	23,
	23,
	23,
	23,
	21,
	-1,
	28,
	26,
	26,
	0,
	0,
	23,
	23,
	28,
	26,
	23,
	26,
	26,
	116,
	116,
	4,
	4,
	116,
	3,
	4,
	159,
	2088,
	159,
	159,
	159,
	159,
	159,
	3,
	3,
	3,
	23,
	26,
	23,
	26,
	26,
	26,
	26,
	14,
	14,
	14,
	89,
	89,
	14,
	89,
	31,
	14,
	1199,
	27,
	202,
	26,
	26,
	9,
	112,
	26,
	26,
	26,
	26,
	137,
	26,
	26,
	26,
	26,
	14,
	14,
	14,
	89,
	89,
	31,
	14,
	89,
	31,
	14,
	202,
	1199,
	26,
	27,
	202,
	26,
	26,
	9,
	112,
	26,
	26,
	26,
	26,
	137,
	0,
	27,
	27,
	89,
	31,
	615,
	859,
	49,
	169,
	159,
	159,
	159,
	159,
	159,
	159,
	3,
	159,
	159,
	159,
	159,
	159,
	159,
	26,
	27,
	27,
	31,
	32,
	23,
	1671,
	25,
	27,
	23,
	23,
	62,
	25,
	1835,
	1671,
	25,
	27,
	23,
	26,
	107,
	1194,
	2081,
	15,
	7,
	-1,
	23,
	9,
	25,
	23,
	3,
	2089,
	1018,
	1018,
	49,
	859,
	116,
	156,
	4,
	49,
	142,
	159,
	159,
	159,
	159,
	159,
	2088,
	159,
	157,
	26,
	1199,
	27,
	27,
	26,
	89,
	31,
	14,
	89,
	9,
	112,
	23,
	62,
	26,
	107,
	107,
	26,
	26,
	137,
	23,
	89,
	26,
	27,
	27,
	31,
	32,
	23,
	26,
	1199,
	27,
	27,
	26,
	89,
	31,
	14,
	89,
	9,
	112,
	23,
	23,
	23,
	62,
	23,
	2093,
	1665,
	23,
	14,
	14,
	27,
	14,
	10,
	137,
	14,
	26,
	3,
	159,
	159,
	142,
	3,
	159,
	159,
	142,
	859,
	169,
	49,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	131,
	23,
	105,
	26,
	131,
	26,
	209,
	26,
	131,
	23,
	105,
	26,
	131,
	2083,
	2084,
	26,
	131,
	1126,
	2085,
	26,
	131,
	1126,
	2085,
	26,
	131,
	2086,
	2087,
	26,
	48,
	26,
	0,
	23,
	14,
	14,
	14,
	34,
	14,
	14,
	23,
	241,
	241,
	14,
	10,
	23,
	0,
	26,
	26,
	26,
	26,
	26,
	131,
	26,
	209,
	26,
	131,
	23,
	105,
	26,
	131,
	23,
	105,
	26,
	131,
	23,
	105,
	26,
	23,
	23,
	27,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	23,
	131,
	26,
	209,
	26,
	131,
	26,
	209,
	26,
	131,
	26,
	209,
	26,
	131,
	26,
	209,
	26,
	131,
	26,
	209,
	26,
	131,
	26,
	209,
	26,
	131,
	7,
	846,
	26,
	131,
	1836,
	1837,
	26,
	131,
	1126,
	2085,
	26,
	131,
	2083,
	2084,
	26,
	131,
	26,
	209,
	26,
	131,
	2090,
	2091,
	26,
	131,
	26,
	209,
	26,
	131,
	176,
	2092,
	26,
};
static const Il2CppTokenIndexMethodTuple s_reversePInvokeIndices[22] = 
{
	{ 0x0600007F, 8,  (void**)&IosShowListener_OnShowFailure_m1F449F5BA0EFA79DCD526B4AFA4FEC23611DC737_RuntimeMethod_var, 0 },
	{ 0x06000080, 9,  (void**)&IosShowListener_OnShowStart_mE42C6FD6E21AFC9BBBDCD99B272DEF7FC375E494_RuntimeMethod_var, 0 },
	{ 0x06000081, 10,  (void**)&IosShowListener_OnShowClick_m08D50F89BA9E45F3047B4D5BD497E38741939B08_RuntimeMethod_var, 0 },
	{ 0x06000082, 11,  (void**)&IosShowListener_OnShowComplete_m233B64E74571ADCD363EECB90C7A42A91D30027E_RuntimeMethod_var, 0 },
	{ 0x060000A9, 26,  (void**)&PurchasingPlatform_UnityAdsDidInitiatePurchasingCommand_mC4F34F7E115EBACCBF488E35161B3765379754BF_RuntimeMethod_var, 0 },
	{ 0x060000AA, 27,  (void**)&PurchasingPlatform_UnityAdsPurchasingGetProductCatalog_m56F70A02157D109E98C81C22262686A560A479FC_RuntimeMethod_var, 0 },
	{ 0x060000AB, 28,  (void**)&PurchasingPlatform_UnityAdsPurchasingGetPurchasingVersion_mD96F20497B37585C57677515C6B671F4A1DC1227_RuntimeMethod_var, 0 },
	{ 0x060000AC, 29,  (void**)&PurchasingPlatform_UnityAdsPurchasingInitialize_m4004786A5894AF8350718CDC9346426D0E09619C_RuntimeMethod_var, 0 },
	{ 0x060000F5, 12,  (void**)&IosBanner_UnityAdsBannerDidShow_m3120A02395BCBF393FA6D6CA0E338FC035A3AC83_RuntimeMethod_var, 0 },
	{ 0x060000F6, 13,  (void**)&IosBanner_UnityAdsBannerDidHide_m388BF2978CA575D09935957B1D33AA329BEFF628_RuntimeMethod_var, 0 },
	{ 0x060000F7, 14,  (void**)&IosBanner_UnityAdsBannerClick_m64AE141B67AC8303DCB6074D65BDDEDEAD483AEF_RuntimeMethod_var, 0 },
	{ 0x060000F8, 15,  (void**)&IosBanner_UnityAdsBannerDidError_mBEE10F30BF7C0ADE11902976DF5F271D11778D58_RuntimeMethod_var, 0 },
	{ 0x060000F9, 16,  (void**)&IosBanner_UnityAdsBannerDidUnload_m37C9378F35879F763BD7DF4326010DBADA94E706_RuntimeMethod_var, 0 },
	{ 0x060000FA, 17,  (void**)&IosBanner_UnityAdsBannerDidLoad_mE6E3534E4C772FFF746ADD4D3C99818C23B5E12D_RuntimeMethod_var, 0 },
	{ 0x06000107, 18,  (void**)&IosInitializationListener_OnInitializationComplete_m5C1D21F520E9041AEB12472927EAD7880EE8F723_RuntimeMethod_var, 0 },
	{ 0x06000108, 19,  (void**)&IosInitializationListener_OnInitializationFailed_m20705DB3847A26369E1BECDE24515EC935FC18BE_RuntimeMethod_var, 0 },
	{ 0x0600010F, 20,  (void**)&IosLoadListener_OnLoadSuccess_mACCFA237ACF117DBC6DCFBCA5FA893FA150D893E_RuntimeMethod_var, 0 },
	{ 0x06000110, 21,  (void**)&IosLoadListener_OnLoadFailure_mE48F1E2C64E55357454B5F38691F712A05AEC408_RuntimeMethod_var, 0 },
	{ 0x06000127, 22,  (void**)&IosPlatform_UnityAdsReady_mA9E4CF6B2D5E3221AC2C620D458C119F3EDC64FA_RuntimeMethod_var, 0 },
	{ 0x06000128, 23,  (void**)&IosPlatform_UnityAdsDidError_m1FD041ADCF92A2FC629260C81EE5553519D66BC7_RuntimeMethod_var, 0 },
	{ 0x06000129, 24,  (void**)&IosPlatform_UnityAdsDidStart_m42C9E6831D166DE71597242632BB487A85BD769B_RuntimeMethod_var, 0 },
	{ 0x0600012A, 25,  (void**)&IosPlatform_UnityAdsDidFinish_m22B0654A8F7A3FE1FC148A257565711E0B59DEB8_RuntimeMethod_var, 0 },
};
static const Il2CppTokenRangePair s_rgctxIndices[2] = 
{
	{ 0x0600008F, { 0, 2 } },
	{ 0x06000113, { 2, 1 } },
};
static const Il2CppRGCTXDefinition s_rgctxValues[3] = 
{
	{ (Il2CppRGCTXDataType)1, 20511 },
	{ (Il2CppRGCTXDataType)2, 20511 },
	{ (Il2CppRGCTXDataType)2, 20599 },
};
extern const Il2CppCodeGenModule g_UnityEngine_AdvertisementsCodeGenModule;
const Il2CppCodeGenModule g_UnityEngine_AdvertisementsCodeGenModule = 
{
	"UnityEngine.Advertisements.dll",
	506,
	s_methodPointers,
	0,
	NULL,
	s_InvokerIndices,
	22,
	s_reversePInvokeIndices,
	2,
	s_rgctxIndices,
	3,
	s_rgctxValues,
	NULL,
};
